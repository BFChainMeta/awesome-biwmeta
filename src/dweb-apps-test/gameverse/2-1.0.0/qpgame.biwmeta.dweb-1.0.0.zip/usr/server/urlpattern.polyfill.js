// https://esm.sh/v135/urlpattern-polyfill@9.0.0/denonext/urlpattern.js
var O = class {
  type = 3;
  name = "";
  prefix = "";
  value = "";
  suffix = "";
  modifier = 3;
  constructor(t, e, s, i, o, u) {
    this.type = t, this.name = e, this.prefix = s, this.value = i, this.suffix = o, this.modifier = u;
  }
  hasCustomName() {
    return this.name !== "" && typeof this.name != "number";
  }
};
var Q = /[$_\p{ID_Start}]/u;
var Y = /[$_\u200C\u200D\p{ID_Continue}]/u;
var D = ".*";
function tt(t, e) {
  return (e ? /^[\x00-\xFF]*$/ : /^[\x00-\x7F]*$/).test(t);
}
function M(t, e = false) {
  let s = [], i = 0;
  for (; i < t.length; ) {
    let o = t[i], u = function(h) {
      if (!e)
        throw new TypeError(h);
      s.push({ type: "INVALID_CHAR", index: i, value: t[i++] });
    };
    if (o === "*") {
      s.push({ type: "ASTERISK", index: i, value: t[i++] });
      continue;
    }
    if (o === "+" || o === "?") {
      s.push({ type: "OTHER_MODIFIER", index: i, value: t[i++] });
      continue;
    }
    if (o === "\\") {
      s.push({ type: "ESCAPED_CHAR", index: i++, value: t[i++] });
      continue;
    }
    if (o === "{") {
      s.push({ type: "OPEN", index: i, value: t[i++] });
      continue;
    }
    if (o === "}") {
      s.push({ type: "CLOSE", index: i, value: t[i++] });
      continue;
    }
    if (o === ":") {
      let h = "", r = i + 1;
      for (; r < t.length; ) {
        let a = t.substr(r, 1);
        if (r === i + 1 && Q.test(a) || r !== i + 1 && Y.test(a)) {
          h += t[r++];
          continue;
        }
        break;
      }
      if (!h) {
        u(`Missing parameter name at ${i}`);
        continue;
      }
      s.push({ type: "NAME", index: i, value: h }), i = r;
      continue;
    }
    if (o === "(") {
      let h = 1, r = "", a = i + 1, n = false;
      if (t[a] === "?") {
        u(`Pattern cannot start with "?" at ${a}`);
        continue;
      }
      for (; a < t.length; ) {
        if (!tt(t[a], false)) {
          u(`Invalid character '${t[a]}' at ${a}.`), n = true;
          break;
        }
        if (t[a] === "\\") {
          r += t[a++] + t[a++];
          continue;
        }
        if (t[a] === ")") {
          if (h--, h === 0) {
            a++;
            break;
          }
        } else if (t[a] === "(" && (h++, t[a + 1] !== "?")) {
          u(`Capturing groups are not allowed at ${a}`), n = true;
          break;
        }
        r += t[a++];
      }
      if (n)
        continue;
      if (h) {
        u(`Unbalanced pattern at ${i}`);
        continue;
      }
      if (!r) {
        u(`Missing pattern at ${i}`);
        continue;
      }
      s.push({ type: "REGEX", index: i, value: r }), i = a;
      continue;
    }
    s.push({ type: "CHAR", index: i, value: t[i++] });
  }
  return s.push({ type: "END", index: i, value: "" }), s;
}
function F(t, e = {}) {
  let s = M(t);
  e.delimiter ??= "/#?", e.prefixes ??= "./";
  let i = `[^${g(e.delimiter)}]+?`, o = [], u = 0, h = 0, r = "", a = /* @__PURE__ */ new Set(), n = (p) => {
    if (h < s.length && s[h].type === p)
      return s[h++].value;
  }, f = () => n("OTHER_MODIFIER") ?? n("ASTERISK"), w = (p) => {
    let c = n(p);
    if (c !== void 0)
      return c;
    let { type: l, index: R } = s[h];
    throw new TypeError(`Unexpected ${l} at ${R}, expected ${p}`);
  }, v = () => {
    let p = "", c;
    for (; c = n("CHAR") ?? n("ESCAPED_CHAR"); )
      p += c;
    return p;
  }, J = (p) => p, P = e.encodePart || J, T = "", U = (p) => {
    T += p;
  }, I = () => {
    T.length && (o.push(new O(3, "", "", P(T), "", 3)), T = "");
  }, _ = (p, c, l, R, b) => {
    let d = 3;
    switch (b) {
      case "?":
        d = 1;
        break;
      case "*":
        d = 0;
        break;
      case "+":
        d = 2;
        break;
    }
    if (!c && !l && d === 3) {
      U(p);
      return;
    }
    if (I(), !c && !l) {
      if (!p)
        return;
      o.push(new O(3, "", "", P(p), "", d));
      return;
    }
    let m;
    l ? l === "*" ? m = D : m = l : m = i;
    let C = 2;
    m === i ? (C = 1, m = "") : m === D && (C = 0, m = "");
    let x;
    if (c ? x = c : l && (x = u++), a.has(x))
      throw new TypeError(`Duplicate name '${x}'.`);
    a.add(x), o.push(new O(C, x, P(p), m, P(R), d));
  };
  for (; h < s.length; ) {
    let p = n("CHAR"), c = n("NAME"), l = n("REGEX");
    if (!c && !l && (l = n("ASTERISK")), c || l) {
      let b = p ?? "";
      e.prefixes.indexOf(b) === -1 && (U(b), b = ""), I();
      let d = f();
      _(b, c, l, "", d);
      continue;
    }
    let R = p ?? n("ESCAPED_CHAR");
    if (R) {
      U(R);
      continue;
    }
    if (n("OPEN")) {
      let b = v(), d = n("NAME"), m = n("REGEX");
      !d && !m && (m = n("ASTERISK"));
      let C = v();
      w("CLOSE");
      let x = f();
      _(b, d, m, C, x);
      continue;
    }
    I(), w("END");
  }
  return o;
}
function g(t) {
  return t.replace(/([.+*?^${}()[\]|/\\])/g, "\\$1");
}
function j(t) {
  return t && t.ignoreCase ? "ui" : "u";
}
function et(t, e, s) {
  return W(F(t, s), e, s);
}
function k(t) {
  switch (t) {
    case 0:
      return "*";
    case 1:
      return "?";
    case 2:
      return "+";
    case 3:
      return "";
  }
}
function W(t, e, s = {}) {
  s.delimiter ??= "/#?", s.prefixes ??= "./", s.sensitive ??= false, s.strict ??= false, s.end ??= true, s.start ??= true, s.endsWith = "";
  let i = s.start ? "^" : "";
  for (let r of t) {
    if (r.type === 3) {
      r.modifier === 3 ? i += g(r.value) : i += `(?:${g(r.value)})${k(r.modifier)}`;
      continue;
    }
    e && e.push(r.name);
    let a = `[^${g(s.delimiter)}]+?`, n = r.value;
    if (r.type === 1 ? n = a : r.type === 0 && (n = D), !r.prefix.length && !r.suffix.length) {
      r.modifier === 3 || r.modifier === 1 ? i += `(${n})${k(r.modifier)}` : i += `((?:${n})${k(r.modifier)})`;
      continue;
    }
    if (r.modifier === 3 || r.modifier === 1) {
      i += `(?:${g(r.prefix)}(${n})${g(r.suffix)})`, i += k(r.modifier);
      continue;
    }
    i += `(?:${g(r.prefix)}`, i += `((?:${n})(?:`, i += g(r.suffix), i += g(r.prefix), i += `(?:${n}))*)${g(r.suffix)})`, r.modifier === 0 && (i += "?");
  }
  let o = `[${g(s.endsWith)}]|$`, u = `[${g(s.delimiter)}]`;
  if (s.end)
    return s.strict || (i += `${u}?`), s.endsWith.length ? i += `(?=${o})` : i += "$", new RegExp(i, j(s));
  s.strict || (i += `(?:${u}(?=${o}))?`);
  let h = false;
  if (t.length) {
    let r = t[t.length - 1];
    r.type === 3 && r.modifier === 3 && (h = s.delimiter.indexOf(r) > -1);
  }
  return h || (i += `(?=${u}|${o})`), new RegExp(i, j(s));
}
var E = { delimiter: "", prefixes: "", sensitive: true, strict: true };
var st = { delimiter: ".", prefixes: "", sensitive: true, strict: true };
var rt = { delimiter: "/", prefixes: "/", sensitive: true, strict: true };
function it(t, e) {
  return t.length ? t[0] === "/" ? true : !e || t.length < 2 ? false : (t[0] == "\\" || t[0] == "{") && t[1] == "/" : false;
}
function K(t, e) {
  return t.startsWith(e) ? t.substring(e.length, t.length) : t;
}
function nt(t, e) {
  return t.endsWith(e) ? t.substr(0, t.length - e.length) : t;
}
function G(t) {
  return !t || t.length < 2 ? false : t[0] === "[" || (t[0] === "\\" || t[0] === "{") && t[1] === "[";
}
var X = ["ftp", "file", "http", "https", "ws", "wss"];
function V(t) {
  if (!t)
    return true;
  for (let e of X)
    if (t.test(e))
      return true;
  return false;
}
function ht(t, e) {
  if (t = K(t, "#"), e || t === "")
    return t;
  let s = new URL("https://example.com");
  return s.hash = t, s.hash ? s.hash.substring(1, s.hash.length) : "";
}
function at(t, e) {
  if (t = K(t, "?"), e || t === "")
    return t;
  let s = new URL("https://example.com");
  return s.search = t, s.search ? s.search.substring(1, s.search.length) : "";
}
function ot(t, e) {
  return e || t === "" ? t : G(t) ? q(t) : Z(t);
}
function ut(t, e) {
  if (e || t === "")
    return t;
  let s = new URL("https://example.com");
  return s.password = t, s.password;
}
function pt(t, e) {
  if (e || t === "")
    return t;
  let s = new URL("https://example.com");
  return s.username = t, s.username;
}
function ct(t, e, s) {
  if (s || t === "")
    return t;
  if (e && !X.includes(e))
    return new URL(`${e}:${t}`).pathname;
  let i = t[0] == "/";
  return t = new URL(i ? t : "/-" + t, "https://example.com").pathname, i || (t = t.substring(2, t.length)), t;
}
function ft(t, e, s) {
  return z(e) === t && (t = ""), s || t === "" ? t : B(t);
}
function lt(t, e) {
  return t = nt(t, ":"), e || t === "" ? t : N(t);
}
function z(t) {
  switch (t) {
    case "ws":
    case "http":
      return "80";
    case "wws":
    case "https":
      return "443";
    case "ftp":
      return "21";
    default:
      return "";
  }
}
function N(t) {
  if (t === "")
    return t;
  if (/^[-+.A-Za-z0-9]*$/.test(t))
    return t.toLowerCase();
  throw new TypeError(`Invalid protocol '${t}'.`);
}
function mt(t) {
  if (t === "")
    return t;
  let e = new URL("https://example.com");
  return e.username = t, e.username;
}
function gt(t) {
  if (t === "")
    return t;
  let e = new URL("https://example.com");
  return e.password = t, e.password;
}
function Z(t) {
  if (t === "")
    return t;
  if (/[\t\n\r #%/:<>?@[\]^\\|]/g.test(t))
    throw new TypeError(`Invalid hostname '${t}'`);
  let e = new URL("https://example.com");
  return e.hostname = t, e.hostname;
}
function q(t) {
  if (t === "")
    return t;
  if (/[^0-9a-fA-F[\]:]/g.test(t))
    throw new TypeError(`Invalid IPv6 hostname '${t}'`);
  return t.toLowerCase();
}
function B(t) {
  if (t === "" || /^[0-9]*$/.test(t) && parseInt(t) <= 65535)
    return t;
  throw new TypeError(`Invalid port '${t}'.`);
}
function dt(t) {
  if (t === "")
    return t;
  let e = new URL("https://example.com");
  return e.pathname = t[0] !== "/" ? "/-" + t : t, t[0] !== "/" ? e.pathname.substring(2, e.pathname.length) : e.pathname;
}
function wt(t) {
  return t === "" ? t : new URL(`data:${t}`).pathname;
}
function yt(t) {
  if (t === "")
    return t;
  let e = new URL("https://example.com");
  return e.search = t, e.search.substring(1, e.search.length);
}
function bt(t) {
  if (t === "")
    return t;
  let e = new URL("https://example.com");
  return e.hash = t, e.hash.substring(1, e.hash.length);
}
var xt = class {
  #n;
  #r = [];
  #e = {};
  #t = 0;
  #i = 1;
  #f = 0;
  #o = 0;
  #l = 0;
  #m = 0;
  #g = false;
  constructor(t) {
    this.#n = t;
  }
  get result() {
    return this.#e;
  }
  parse() {
    for (this.#r = M(this.#n, true); this.#t < this.#r.length; this.#t += this.#i) {
      if (this.#i = 1, this.#r[this.#t].type === "END") {
        if (this.#o === 0) {
          this.#b(), this.#u() ? this.#s(9, 1) : this.#p() ? (this.#s(8, 1), this.#e.hash = "") : (this.#s(7, 0), this.#e.search = "", this.#e.hash = "");
          continue;
        } else if (this.#o === 2) {
          this.#c(5);
          continue;
        }
        this.#s(10, 0);
        break;
      }
      if (this.#l > 0)
        if (this.#C())
          this.#l -= 1;
        else
          continue;
      if (this.#k()) {
        this.#l += 1;
        continue;
      }
      switch (this.#o) {
        case 0:
          this.#x() && (this.#e.username = "", this.#e.password = "", this.#e.hostname = "", this.#e.port = "", this.#e.pathname = "", this.#e.search = "", this.#e.hash = "", this.#c(1));
          break;
        case 1:
          if (this.#x()) {
            this.#O();
            let t = 7, e = 1;
            this.#g && (this.#e.pathname = "/"), this.#E() ? (t = 2, e = 3) : this.#g && (t = 2), this.#s(t, e);
          }
          break;
        case 2:
          this.#w() ? this.#c(3) : (this.#y() || this.#p() || this.#u()) && this.#c(5);
          break;
        case 3:
          this.#v() ? this.#s(4, 1) : this.#w() && this.#s(5, 1);
          break;
        case 4:
          this.#w() && this.#s(5, 1);
          break;
        case 5:
          this.#L() ? this.#m += 1 : this.#A() && (this.#m -= 1), this.#R() && !this.#m ? this.#s(6, 1) : this.#y() ? this.#s(7, 0) : this.#p() ? this.#s(8, 1) : this.#u() && this.#s(9, 1);
          break;
        case 6:
          this.#y() ? this.#s(7, 0) : this.#p() ? this.#s(8, 1) : this.#u() && this.#s(9, 1);
          break;
        case 7:
          this.#p() ? this.#s(8, 1) : this.#u() && this.#s(9, 1);
          break;
        case 8:
          this.#u() && this.#s(9, 1);
          break;
        case 9:
          break;
        case 10:
          break;
      }
    }
  }
  #s(t, e) {
    switch (this.#o) {
      case 0:
        break;
      case 1:
        this.#e.protocol = this.#a();
        break;
      case 2:
        break;
      case 3:
        this.#e.username = this.#a();
        break;
      case 4:
        this.#e.password = this.#a();
        break;
      case 5:
        this.#e.hostname = this.#a();
        break;
      case 6:
        this.#e.port = this.#a();
        break;
      case 7:
        this.#e.pathname = this.#a();
        break;
      case 8:
        this.#e.search = this.#a();
        break;
      case 9:
        this.#e.hash = this.#a();
        break;
      case 10:
        break;
    }
    this.#$(t, e);
  }
  #$(t, e) {
    this.#o = t, this.#f = this.#t + e, this.#t += e, this.#i = 0;
  }
  #b() {
    this.#t = this.#f, this.#i = 0;
  }
  #c(t) {
    this.#b(), this.#o = t;
  }
  #d(t) {
    return t < 0 && (t = this.#r.length - t), t < this.#r.length ? this.#r[t] : this.#r[this.#r.length - 1];
  }
  #h(t, e) {
    let s = this.#d(t);
    return s.value === e && (s.type === "CHAR" || s.type === "ESCAPED_CHAR" || s.type === "INVALID_CHAR");
  }
  #x() {
    return this.#h(this.#t, ":");
  }
  #E() {
    return this.#h(this.#t + 1, "/") && this.#h(this.#t + 2, "/");
  }
  #w() {
    return this.#h(this.#t, "@");
  }
  #v() {
    return this.#h(this.#t, ":");
  }
  #R() {
    return this.#h(this.#t, ":");
  }
  #y() {
    return this.#h(this.#t, "/");
  }
  #p() {
    if (this.#h(this.#t, "?"))
      return true;
    if (this.#r[this.#t].value !== "?")
      return false;
    let t = this.#d(this.#t - 1);
    return t.type !== "NAME" && t.type !== "REGEX" && t.type !== "CLOSE" && t.type !== "ASTERISK";
  }
  #u() {
    return this.#h(this.#t, "#");
  }
  #k() {
    return this.#r[this.#t].type == "OPEN";
  }
  #C() {
    return this.#r[this.#t].type == "CLOSE";
  }
  #L() {
    return this.#h(this.#t, "[");
  }
  #A() {
    return this.#h(this.#t, "]");
  }
  #a() {
    let t = this.#r[this.#t], e = this.#d(this.#f).index;
    return this.#n.substring(e, t.index);
  }
  #O() {
    let t = {};
    Object.assign(t, E), t.encodePart = N;
    let e = et(this.#a(), void 0, t);
    this.#g = V(e);
  }
};
var S = ["protocol", "username", "password", "hostname", "port", "pathname", "search", "hash"];
var $ = "*";
function H(t, e) {
  if (typeof t != "string")
    throw new TypeError("parameter 1 is not of type 'string'.");
  let s = new URL(t, e);
  return { protocol: s.protocol.substring(0, s.protocol.length - 1), username: s.username, password: s.password, hostname: s.hostname, port: s.port, pathname: s.pathname, search: s.search !== "" ? s.search.substring(1, s.search.length) : void 0, hash: s.hash !== "" ? s.hash.substring(1, s.hash.length) : void 0 };
}
function y(t, e) {
  return e ? A(t) : t;
}
function L(t, e, s) {
  let i;
  if (typeof e.baseURL == "string")
    try {
      i = new URL(e.baseURL), t.protocol = y(i.protocol.substring(0, i.protocol.length - 1), s), t.username = y(i.username, s), t.password = y(i.password, s), t.hostname = y(i.hostname, s), t.port = y(i.port, s), t.pathname = y(i.pathname, s), t.search = y(i.search.substring(1, i.search.length), s), t.hash = y(i.hash.substring(1, i.hash.length), s);
    } catch {
      throw new TypeError(`invalid baseURL '${e.baseURL}'.`);
    }
  if (typeof e.protocol == "string" && (t.protocol = lt(e.protocol, s)), typeof e.username == "string" && (t.username = pt(e.username, s)), typeof e.password == "string" && (t.password = ut(e.password, s)), typeof e.hostname == "string" && (t.hostname = ot(e.hostname, s)), typeof e.port == "string" && (t.port = ft(e.port, t.protocol, s)), typeof e.pathname == "string") {
    if (t.pathname = e.pathname, i && !it(t.pathname, s)) {
      let o = i.pathname.lastIndexOf("/");
      o >= 0 && (t.pathname = y(i.pathname.substring(0, o + 1), s) + t.pathname);
    }
    t.pathname = ct(t.pathname, t.protocol, s);
  }
  return typeof e.search == "string" && (t.search = at(e.search, s)), typeof e.hash == "string" && (t.hash = ht(e.hash, s)), t;
}
function A(t) {
  return t.replace(/([+*?:{}()\\])/g, "\\$1");
}
function $t(t) {
  return t.replace(/([.+*?^${}()[\]|/\\])/g, "\\$1");
}
function Et(t, e) {
  e.delimiter ??= "/#?", e.prefixes ??= "./", e.sensitive ??= false, e.strict ??= false, e.end ??= true, e.start ??= true, e.endsWith = "";
  let s = ".*", i = `[^${$t(e.delimiter)}]+?`, o = /[$_\u200C\u200D\p{ID_Continue}]/u, u = "";
  for (let h = 0; h < t.length; ++h) {
    let r = t[h];
    if (r.type === 3) {
      if (r.modifier === 3) {
        u += A(r.value);
        continue;
      }
      u += `{${A(r.value)}}${k(r.modifier)}`;
      continue;
    }
    let a = r.hasCustomName(), n = !!r.suffix.length || !!r.prefix.length && (r.prefix.length !== 1 || !e.prefixes.includes(r.prefix)), f = h > 0 ? t[h - 1] : null, w = h < t.length - 1 ? t[h + 1] : null;
    if (!n && a && r.type === 1 && r.modifier === 3 && w && !w.prefix.length && !w.suffix.length)
      if (w.type === 3) {
        let v = w.value.length > 0 ? w.value[0] : "";
        n = o.test(v);
      } else
        n = !w.hasCustomName();
    if (!n && !r.prefix.length && f && f.type === 3) {
      let v = f.value[f.value.length - 1];
      n = e.prefixes.includes(v);
    }
    n && (u += "{"), u += A(r.prefix), a && (u += `:${r.name}`), r.type === 2 ? u += `(${r.value})` : r.type === 1 ? a || (u += `(${i})`) : r.type === 0 && (!a && (!f || f.type === 3 || f.modifier !== 3 || n || r.prefix !== "") ? u += "*" : u += `(${s})`), r.type === 1 && a && r.suffix.length && o.test(r.suffix[0]) && (u += "\\"), u += A(r.suffix), n && (u += "}"), r.modifier !== 3 && (u += k(r.modifier));
  }
  return u;
}
var vt = class {
  #n;
  #r = {};
  #e = {};
  #t = {};
  #i = {};
  constructor(t = {}, e, s) {
    try {
      let i;
      if (typeof e == "string" ? i = e : s = e, typeof t == "string") {
        let r = new xt(t);
        if (r.parse(), t = r.result, i === void 0 && typeof t.protocol != "string")
          throw new TypeError("A base URL must be provided for a relative constructor string.");
        t.baseURL = i;
      } else {
        if (!t || typeof t != "object")
          throw new TypeError("parameter 1 is not of type 'string' and cannot convert to dictionary.");
        if (i)
          throw new TypeError("parameter 1 is not of type 'string'.");
      }
      typeof s > "u" && (s = { ignoreCase: false });
      let o = { ignoreCase: s.ignoreCase === true }, u = { pathname: $, protocol: $, username: $, password: $, hostname: $, port: $, search: $, hash: $ };
      this.#n = L(u, t, true), z(this.#n.protocol) === this.#n.port && (this.#n.port = "");
      let h;
      for (h of S) {
        if (!(h in this.#n))
          continue;
        let r = {}, a = this.#n[h];
        switch (this.#e[h] = [], h) {
          case "protocol":
            Object.assign(r, E), r.encodePart = N;
            break;
          case "username":
            Object.assign(r, E), r.encodePart = mt;
            break;
          case "password":
            Object.assign(r, E), r.encodePart = gt;
            break;
          case "hostname":
            Object.assign(r, st), G(a) ? r.encodePart = q : r.encodePart = Z;
            break;
          case "port":
            Object.assign(r, E), r.encodePart = B;
            break;
          case "pathname":
            V(this.#r.protocol) ? (Object.assign(r, rt, o), r.encodePart = dt) : (Object.assign(r, E, o), r.encodePart = wt);
            break;
          case "search":
            Object.assign(r, E, o), r.encodePart = yt;
            break;
          case "hash":
            Object.assign(r, E, o), r.encodePart = bt;
            break;
        }
        try {
          this.#i[h] = F(a, r), this.#r[h] = W(this.#i[h], this.#e[h], r), this.#t[h] = Et(this.#i[h], r);
        } catch {
          throw new TypeError(`invalid ${h} pattern '${this.#n[h]}'.`);
        }
      }
    } catch (i) {
      throw new TypeError(`Failed to construct 'URLPattern': ${i.message}`);
    }
  }
  test(t = {}, e) {
    let s = { pathname: "", protocol: "", username: "", password: "", hostname: "", port: "", search: "", hash: "" };
    if (typeof t != "string" && e)
      throw new TypeError("parameter 1 is not of type 'string'.");
    if (typeof t > "u")
      return false;
    try {
      typeof t == "object" ? s = L(s, t, false) : s = L(s, H(t, e), false);
    } catch {
      return false;
    }
    let i;
    for (i of S)
      if (!this.#r[i].exec(s[i]))
        return false;
    return true;
  }
  exec(t = {}, e) {
    let s = { pathname: "", protocol: "", username: "", password: "", hostname: "", port: "", search: "", hash: "" };
    if (typeof t != "string" && e)
      throw new TypeError("parameter 1 is not of type 'string'.");
    if (typeof t > "u")
      return;
    try {
      typeof t == "object" ? s = L(s, t, false) : s = L(s, H(t, e), false);
    } catch {
      return null;
    }
    let i = {};
    e ? i.inputs = [t, e] : i.inputs = [t];
    let o;
    for (o of S) {
      let u = this.#r[o].exec(s[o]);
      if (!u)
        return null;
      let h = {};
      for (let [r, a] of this.#e[o].entries())
        if (typeof a == "string" || typeof a == "number") {
          let n = u[r + 1];
          h[a] = n;
        }
      i[o] = { input: s[o] ?? "", groups: h };
    }
    return i;
  }
  static compareComponent(t, e, s) {
    let i = (r, a) => {
      for (let n of ["type", "modifier", "prefix", "value", "suffix"]) {
        if (r[n] < a[n])
          return -1;
        if (r[n] !== a[n])
          return 1;
      }
      return 0;
    }, o = new O(3, "", "", "", "", 3), u = new O(0, "", "", "", "", 3), h = (r, a) => {
      let n = 0;
      for (; n < Math.min(r.length, a.length); ++n) {
        let f = i(r[n], a[n]);
        if (f)
          return f;
      }
      return r.length === a.length ? 0 : i(r[n] ?? o, a[n] ?? o);
    };
    return !e.#t[t] && !s.#t[t] ? 0 : e.#t[t] && !s.#t[t] ? h(e.#i[t], [u]) : !e.#t[t] && s.#t[t] ? h([u], s.#i[t]) : h(e.#i[t], s.#i[t]);
  }
  get protocol() {
    return this.#t.protocol;
  }
  get username() {
    return this.#t.username;
  }
  get password() {
    return this.#t.password;
  }
  get hostname() {
    return this.#t.hostname;
  }
  get port() {
    return this.#t.port;
  }
  get pathname() {
    return this.#t.pathname;
  }
  get search() {
    return this.#t.search;
  }
  get hash() {
    return this.#t.hash;
  }
};

// https://esm.sh/v135/urlpattern-polyfill@9.0.0/denonext/urlpattern-polyfill.mjs
globalThis.URLPattern || (globalThis.URLPattern = vt);
