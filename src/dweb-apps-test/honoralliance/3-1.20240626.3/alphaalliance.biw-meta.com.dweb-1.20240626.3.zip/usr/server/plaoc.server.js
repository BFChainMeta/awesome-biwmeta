// helper/response-json.polyfill.ts
if (typeof Response.json !== "function") {
  Response.json = (data, init = {}) => {
    const headers = new Headers(init.headers);
    headers.set("Content-Type", "application/json");
    return new Response(JSON.stringify(data), { ...init, headers });
  };
}

// helper/urlpattern.polyfill.ts
if (typeof URLPattern === "undefined") {
  await import("./urlpattern-polyfill-SEBNDUPK.js");
}

// ../../dweb-helper/src/PromiseOut.ts
var isPromiseLike = (value) => {
  return value instanceof Object && typeof value.then === "function";
};
var PromiseOut = class _PromiseOut {
  static resolve(v) {
    const po = new _PromiseOut();
    po.resolve(v);
    return po;
  }
  static reject(reason) {
    const po = new _PromiseOut();
    po.reject(reason);
    return po;
  }
  static sleep(ms) {
    const po = new _PromiseOut();
    let ti = setTimeout(() => {
      ti = void 0;
      po.resolve();
    }, ms);
    po.onFinished(() => ti !== void 0 && clearTimeout(ti));
    return po;
  }
  promise;
  is_resolved = false;
  is_rejected = false;
  is_finished = false;
  value;
  reason;
  resolve;
  reject;
  _innerFinally;
  _innerFinallyArg;
  _innerThen;
  _innerCatch;
  constructor() {
    this.promise = new Promise((resolve, reject) => {
      this.resolve = (value) => {
        try {
          if (isPromiseLike(value)) {
            value.then(this.resolve, this.reject);
          } else {
            this.is_resolved = true;
            this.is_finished = true;
            resolve(this.value = value);
            this._runThen();
            this._innerFinallyArg = Object.freeze({
              status: "resolved",
              result: this.value
            });
            this._runFinally();
          }
        } catch (err) {
          this.reject(err);
        }
      };
      this.reject = (reason) => {
        this.is_rejected = true;
        this.is_finished = true;
        reject(this.reason = reason);
        this._runCatch();
        this._innerFinallyArg = Object.freeze({
          status: "rejected",
          reason: this.reason
        });
        this._runFinally();
      };
    });
  }
  onSuccess(innerThen) {
    if (this.is_resolved) {
      this.__callInnerThen(innerThen);
    } else {
      (this._innerThen || (this._innerThen = [])).push(innerThen);
    }
  }
  onError(innerCatch) {
    if (this.is_rejected) {
      this.__callInnerCatch(innerCatch);
    } else {
      (this._innerCatch || (this._innerCatch = [])).push(innerCatch);
    }
  }
  onFinished(innerFinally) {
    if (this.is_finished) {
      this.__callInnerFinally(innerFinally);
    } else {
      (this._innerFinally || (this._innerFinally = [])).push(innerFinally);
    }
  }
  _runFinally() {
    if (this._innerFinally) {
      for (const innerFinally of this._innerFinally) {
        this.__callInnerFinally(innerFinally);
      }
      this._innerFinally = void 0;
    }
  }
  __callInnerFinally(innerFinally) {
    queueMicrotask(async () => {
      try {
        await innerFinally(this._innerFinallyArg);
      } catch (err) {
        console.error("Unhandled promise rejection when running onFinished", innerFinally, err);
      }
    });
  }
  _runThen() {
    if (this._innerThen) {
      for (const innerThen of this._innerThen) {
        this.__callInnerThen(innerThen);
      }
      this._innerThen = void 0;
    }
  }
  _runCatch() {
    if (this._innerCatch) {
      for (const innerCatch of this._innerCatch) {
        this.__callInnerCatch(innerCatch);
      }
      this._innerCatch = void 0;
    }
  }
  __callInnerThen(innerThen) {
    queueMicrotask(async () => {
      try {
        await innerThen(this.value);
      } catch (err) {
        console.error("Unhandled promise rejection when running onSuccess", innerThen, err);
      }
    });
  }
  __callInnerCatch(innerCatch) {
    queueMicrotask(async () => {
      try {
        await innerCatch(this.value);
      } catch (err) {
        console.error("Unhandled promise rejection when running onError", innerCatch, err);
      }
    });
  }
};

// ../../dweb-helper/src/decorator/$once.ts
var $once = (fn) => {
  let first = true;
  let resolved;
  let rejected;
  let success = false;
  return Object.defineProperties(
    function(...args) {
      if (first) {
        first = false;
        try {
          resolved = fn.apply(this, args);
          success = true;
        } catch (err) {
          rejected = err;
        }
      }
      if (success) {
        return resolved;
      }
      throw rejected;
    },
    {
      hasRun: {
        get() {
          return !first;
        }
      },
      result: {
        get() {
          if (success) {
            return resolved;
          } else {
            throw rejected;
          }
        }
      },
      origin: {
        configurable: true,
        writable: false,
        value: fn
      },
      reset: {
        configurable: true,
        writable: true,
        value: () => {
          first = true;
          resolved = void 0;
          rejected = void 0;
          success = false;
        }
      }
    }
  );
};

// ../../dweb-helper/src/fun/binaryHelper.ts
var binaryToU8a = (binary) => {
  if (binary instanceof Uint8Array) {
    return binary;
  }
  if (ArrayBuffer.isView(binary)) {
    return new Uint8Array(binary.buffer, binary.byteOffset, binary.byteLength);
  }
  return new Uint8Array(binary);
};

// ../../dweb-helper/src/encoding.ts
var textEncoder = new TextEncoder();
var simpleEncoder = (data, encoding) => {
  if (encoding === "base64") {
    const byteCharacters = atob(data);
    const binary = new Uint8Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      binary[i] = byteCharacters.charCodeAt(i);
    }
    return binary;
  } else if (encoding === "hex") {
    const binary = new Uint8Array(data.length / 2);
    for (let i = 0; i < binary.length; i++) {
      const start = i + i;
      binary[i] = parseInt(data.slice(start, start + 2), 16);
    }
    return binary;
  }
  return textEncoder.encode(data);
};
var textDecoder = new TextDecoder();
var simpleDecoder = (data, encoding) => {
  if (encoding === "base64") {
    let binary = "";
    const bytes = binaryToU8a(data);
    for (const byte of bytes) {
      binary += String.fromCharCode(byte);
    }
    return btoa(binary);
  } else if (encoding === "hex") {
    let hex = "";
    const bytes = binaryToU8a(data);
    for (const byte of bytes) {
      hex += byte.toString(16).padStart(2, "0");
    }
    return hex;
  }
  return textDecoder.decode(data);
};

// ../../dweb-helper/src/fun/mapHelper.ts
var mapHelper = new class {
  getOrPut(map, key, putter) {
    if (map.has(key)) {
      return map.get(key);
    }
    const put = putter(key);
    map.set(key, put);
    return put;
  }
  getAndRemove(map, key) {
    const val = map.get(key);
    if (map.delete(key)) {
      return val;
    }
  }
}();

// ../../dweb-helper/src/stream/readableStreamHelper.ts
async function* _doRead(reader, options) {
  const signal = options?.signal;
  if (signal !== void 0) {
    signal.addEventListener("abort", (reason) => reader.cancel(reason));
  }
  try {
    while (true) {
      const item = await reader.read();
      if (item.done) {
        break;
      }
      yield item.value;
    }
  } catch (err) {
    reader.cancel(err);
  } finally {
    reader.releaseLock();
  }
}
var streamRead = (stream, options) => {
  return _doRead(stream.getReader(), options);
};

// deps.ts
var { jsProcess, http, ipc, core } = navigator.dweb;
var {
  IpcFetchError,
  Ipc,
  IpcBodySender,
  IpcEvent,
  IpcError,
  IpcRequest,
  IpcRawResponse,
  IpcStreamData,
  IpcStreamEnd,
  IpcStreamPaused,
  IpcStreamPulling,
  IpcServerRequest,
  IpcRawRequest,
  //
  IpcHeaders,
  IpcClientRequest,
  IpcResponse,
  ReadableStreamOut,
  //
  PureChannel,
  PureFrameType,
  PureFrame,
  PureTextFrame,
  PureBinaryFrame
} = ipc;
var { IpcFetchEvent, ChannelEndpoint } = core;
var { ServerUrlInfo, ServerStartResult } = http;

// helper/http-helper.ts
var HttpServer = class {
  constructor(channelId) {
    this.channelId = channelId;
    this.init(channelId);
  }
  _serverP = new PromiseOut();
  // deno-lint-ignore require-await
  async init(channelId) {
    const target = `http-server-${channelId}`;
    this._serverP.resolve(http.createHttpDwebServer(jsProcess, this._getOptions(), target));
  }
  getServer() {
    return this._serverP.promise;
  }
  async getStartResult() {
    const server = await this.getServer();
    return server.startResult;
  }
  async stop() {
    const server = await this._serverP.promise;
    return await server.close();
  }
  listen = $once(async (...onFetchs) => {
    const server = await this.getServer();
    return server.listen(...onFetchs);
  });
};

// helper/mwebview-helper.ts
var apply_window = () => {
  return jsProcess.nativeFetch("file://window.sys.dweb/mainWindow").text();
};
var open_main_window = () => {
  return jsProcess.nativeFetch("file://window.sys.dweb/openMainWindow").text();
};
var mwebview_open_activate = async (wid, url) => {
  const openUrl = new URL(`file://mwebview.browser.dweb/openOrActivate`);
  openUrl.searchParams.set("wid", wid);
  openUrl.searchParams.set("url", url);
  await jsProcess.nativeFetch(openUrl);
};
var mwebview_destroy = () => {
  return jsProcess.nativeFetch(`file://mwebview.browser.dweb/close/app`).boolean();
};

// http-api-server.ts
var DNS_PREFIX = "/dns.std.dweb/";
var INTERNAL_PREFIX = "/internal/";
var Server_api = class extends HttpServer {
  constructor(getWid, handlers = []) {
    super("api");
    this.getWid = getWid;
    this.handlers = handlers;
  }
  jsRuntime = jsProcess.bootstrapContext;
  _getOptions() {
    return {
      subdomain: "api"
    };
  }
  async start() {
    const serverIpc = await this.listen(...this.handlers, this._provider.bind(this));
    return serverIpc.internalServerError().cors();
  }
  // deno-lint-ignore require-await
  async _provider(event) {
    if (event.pathname.startsWith(DNS_PREFIX)) {
      return this._onDns(event);
    } else if (event.pathname.startsWith(INTERNAL_PREFIX)) {
      return this._onInternal(event);
    }
    return this._onApi(event);
  }
  async _onDns(event) {
    const url = new URL("file:/" + event.pathname + event.search);
    const pathname = url.pathname;
    const result = async () => {
      if (pathname === "/restart") {
        queueMicrotask(() => {
          this.jsRuntime.dns.restart(jsProcess.mmid);
        });
        return Response.json(true);
      }
      if (pathname === "/close") {
        const bool = await mwebview_destroy();
        return Response.json(bool);
      }
      if (pathname === "/query") {
        const mmid = event.searchParams.get("mmid");
        const data = await this.jsRuntime.dns.query(mmid);
        if (data) {
          return Response.json(data);
        }
        return new Response(null, { status: 404 });
      }
      return Response.json(false);
    };
    return await result();
  }
  callbacks = /* @__PURE__ */ new Map();
  #remote = {
    mmid: "localhost.dweb",
    ipc_support_protocols: { cbor: false, protobuf: false, json: false },
    dweb_deeplinks: [],
    categories: [],
    name: ""
  };
  async _onInternal(event) {
    const pathname = event.pathname.slice(INTERNAL_PREFIX.length);
    if (pathname === "window-info") {
      return Response.json({ wid: await this.getWid() });
    }
    if (pathname === "callback") {
      const id = event.searchParams.get("id");
      if (!id) {
        return IpcResponse.fromText(event.reqId, 500, new IpcHeaders(), "invalid search params, miss 'id'", event.ipc);
      }
      const ipc2 = await mapHelper.getOrPut(this.callbacks, id, () => new PromiseOut()).promise;
      const response = await ipc2.request(event.url.href, event.ipcRequest.toPureClientRequest());
      return response.toResponse();
    }
    if (pathname === "registry-callback") {
      const id = event.searchParams.get("id");
      if (!id) {
        return IpcResponse.fromText(event.reqId, 500, new IpcHeaders(), "invalid search params, miss 'id'", event.ipc);
      }
      const endpoint = new ChannelEndpoint(`${jsProcess.mmid}-api-server`, event.request.body);
      const readableStreamIpc = jsProcess.ipcPool.createIpc(endpoint, 0, this.#remote, this.#remote);
      mapHelper.getOrPut(this.callbacks, id, () => new PromiseOut()).resolve(readableStreamIpc);
      return IpcResponse.fromStream(event.reqId, 200, void 0, endpoint.stream, event.ipc);
    }
    if (pathname.startsWith("/usr")) {
      const response = await jsProcess.nativeRequest(`file://${pathname}`);
      return new IpcResponse(event.reqId, response.statusCode, response.headers, response.body, event.ipc);
    }
  }
  /**
   * request 事件处理器
   */
  async _onApi(event) {
    const { pathname, search } = event;
    const path = `file:/${pathname}${search}`;
    const mmid = new URL(path).host;
    const targetIpc = await jsProcess.connect(mmid);
    const { ipcRequest } = event;
    const req = ipcRequest.toPureClientRequest();
    let ipcProxyResponse = await targetIpc.request(path, req);
    if (ipcProxyResponse.statusCode === 401) {
      if (await jsProcess.requestDwebPermissions(await ipcProxyResponse.body.text())) {
        ipcProxyResponse = await targetIpc.request(path, req);
      }
    }
    return ipcProxyResponse.toResponse();
  }
};

// ../../dweb-core/src/internal/ipcEventExt.ts
var onAllIpc = (runtime, onConnectName, cb) => {
  for (const ipc2 of runtime.connectedIpcs) {
    cb(ipc2);
  }
  runtime.onConnect(onConnectName).collect((onConnectEvent) => {
    cb(onConnectEvent.consume());
  });
};

// ../../dweb-core/src/ipc/ipc-message/internal/IpcData.ts
var $dataToBinary = (data, encoding) => {
  switch (encoding) {
    case 8 /* BINARY */: {
      return data;
    }
    case 4 /* BASE64 */: {
      return simpleEncoder(data, "base64");
    }
    case 2 /* UTF8 */: {
      return simpleEncoder(data, "utf8");
    }
  }
  throw new Error(`unknown encoding: ${encoding}`);
};
var $dataToText = (data, encoding) => {
  switch (encoding) {
    case 8 /* BINARY */: {
      return simpleDecoder(data, "utf8");
    }
    case 4 /* BASE64 */: {
      return simpleDecoder(simpleEncoder(data, "base64"), "utf8");
    }
    case 2 /* UTF8 */: {
      return data;
    }
  }
  throw new Error(`unknown encoding: ${encoding}`);
};

// ../../dweb-core/src/ipc/ipc-message/internal/IpcMessage.ts
var ipcMessageBase = (type) => ({ type });

// ../../dweb-core/src/ipc/ipc-message/IpcEvent.ts
var ipcEvent = (name, data, encoding, order) => ({
  ...ipcMessageBase("event" /* EVENT */),
  name,
  data,
  encoding,
  order
});
var IpcEvent2 = Object.assign(ipcEvent, {
  fromBase64(name, data, order) {
    return ipcEvent(name, simpleDecoder(data, "base64"), 4 /* BASE64 */, order);
  },
  fromBinary(name, data, order) {
    return Object.assign(ipcEvent(name, data, 8 /* BINARY */, order), {
      toJSON: $once(() => IpcEvent2.fromBase64(name, data, order))
    });
  },
  fromUtf8(name, data, order) {
    return ipcEvent(name, simpleDecoder(data, "utf8"), 2 /* UTF8 */, order);
  },
  fromText(name, data, order) {
    return ipcEvent(name, data, 2 /* UTF8 */, order);
  },
  binary(event) {
    return $dataToBinary(event.data, event.encoding);
  },
  text(event) {
    return $dataToText(event.data, event.encoding);
  }
});

// ../../dweb-core/src/ipc/ipc-message/channel/PureChannel.ts
var INCOME = Symbol.for("pureChannel.income");
var OUTGOING = Symbol.for("pureChannel.outgoing");

// helper/duplexIpc.ts
var createDuplexIpc = (ipcPool, subdomain, mmid, ipcRequest) => {
  const remote = {
    mmid,
    name: `${subdomain}.${mmid}`,
    ipc_support_protocols: {
      cbor: false,
      protobuf: false,
      json: false
    },
    dweb_deeplinks: [],
    categories: []
  };
  const endpoint = new ChannelEndpoint(`${mmid}-plaoc-external-duplex`);
  const streamIpc = ipcPool.createIpc(endpoint, 0, remote, remote, true);
  const pureServerChannel = ipcRequest.getChannel();
  const channel = pureServerChannel.start();
  void (async () => {
    for await (const chunk of streamRead(endpoint.stream)) {
      channel.sendBinary(chunk);
    }
  })();
  void (async () => {
    for await (const pureFrame of streamRead(channel[INCOME].stream)) {
      endpoint.send(pureFrame.data);
    }
  })();
  return streamIpc;
};

// helper/promise-toggle.ts
var PromiseToggle = class {
  constructor(initState) {
    if (initState.type === "open") {
      this.toggleOpen(initState.value);
    } else {
      this.toggleClose(initState.value);
    }
  }
  _open = new PromiseOut();
  _close = new PromiseOut();
  waitOpen() {
    return this._open.promise;
  }
  waitClose() {
    return this._close.promise;
  }
  get isOpen() {
    return this._open.is_resolved;
  }
  get isClose() {
    return this._close.is_resolved;
  }
  get openValue() {
    return this._open.value;
  }
  get closeValue() {
    return this._close.value;
  }
  /**
   * 切换到开的状态
   * @param value
   * @returns
   */
  toggleOpen(value) {
    if (this._open.is_resolved) {
      return;
    }
    this._open.resolve(value);
    if (this._close.is_resolved) {
      this._close = new PromiseOut();
    }
  }
  /**
   * 切换到开的状态
   * @param value
   * @returns
   */
  toggleClose(value) {
    if (this._close.is_resolved) {
      return;
    }
    this._close.resolve(value);
    if (this._open.is_resolved) {
      this._open = new PromiseOut();
    }
  }
};

// http-external-server.ts
var Server_external = class extends HttpServer {
  constructor(handlers = []) {
    super("external");
    this.handlers = handlers;
    onAllIpc(jsProcess, "for-external", (ipc2) => {
      ipc2.onRequest("get-external").collect(async (requestEvent) => {
        const request = requestEvent.consumeFilter(
          (request2) => request2.parsed_url.pathname == "/wait-external-ready" /* WAIT_EXTERNAL_READY */
        );
        if (request) {
          await this.ipcPo.waitOpen();
          ipc2.postMessage(IpcResponse.fromJson(request.reqId, 200, void 0, {}, ipc2));
        }
      });
    });
  }
  /**
   * 这个token是内部使用的，就作为 特殊的 url.pathname 来处理内部操作
   */
  _getOptions() {
    return {
      subdomain: "external"
    };
  }
  token = crypto.randomUUID();
  async start() {
    const serverIpc = await this.listen(...this.handlers, this._provider.bind(this));
    return serverIpc.internalServerError().cors();
  }
  ipcPo = new PromiseToggle({
    type: "close",
    value: void 0
  });
  //窗口关闭的时候需要重新等待连接
  closeRegisterIpc() {
    this.ipcPo.toggleClose();
  }
  #externalWaitters = /* @__PURE__ */ new Map();
  // 是否需要激活
  #needActivity = true;
  async _provider(event) {
    const { pathname } = event;
    if (pathname.startsWith(`/${this.token}`)) {
      if (!event.ipcRequest.hasDuplex) {
        return { status: 500 };
      }
      if (this.ipcPo.isOpen) {
        this.ipcPo.toggleClose();
      }
      const streamIpc = createDuplexIpc(
        jsProcess.ipcPool,
        this._getOptions().subdomain,
        jsProcess.mmid,
        event.ipcRequest
      );
      streamIpc.onClosed(() => {
        this.ipcPo.toggleClose();
      });
      this.ipcPo.toggleOpen(streamIpc);
      streamIpc.onRequest("get-external-fetch").collect(async (event2) => {
        const request = event2.data;
        const mmid = request.parsed_url.host;
        if (!mmid) {
          return streamIpc.postMessage(
            IpcResponse.fromText(request.reqId, 404, void 0, "not found mmid", streamIpc)
          );
        }
        this.#needActivity = !!request.parsed_url.searchParams.get("activate");
        await mapHelper.getOrPut(this.#externalWaitters, mmid, async () => {
          const ipc3 = await jsProcess.connect(mmid).catch((err) => {
            this.#externalWaitters.delete(mmid);
            streamIpc.postMessage(IpcResponse.fromText(request.reqId, 502, void 0, err, streamIpc));
            throw err;
          });
          ipc3.onClosed(() => {
            this.#externalWaitters.delete(mmid);
          });
          await ipc3.request(`file://${mmid}${"/wait-external-ready" /* WAIT_EXTERNAL_READY */}`);
          return ipc3;
        });
        const ipc2 = await this.#externalWaitters.get(mmid);
        if (ipc2 && this.#needActivity) {
          ipc2.postMessage(IpcEvent.fromText("activity" /* ACTIVITY */, "renderer" /* RENDERER */));
        }
        const ext_options = this._getOptions();
        request.headers.append("X-External-Dweb-Host", jsProcess.mmid);
        let body = null;
        if (request.method !== "GET" && request.method !== "HEAD") {
          body = await request.body.stream();
        }
        const res = await jsProcess.nativeFetch(
          `https://${ext_options.subdomain}.${mmid}${request.parsed_url.pathname}${request.parsed_url.search}`,
          {
            method: request.method,
            headers: request.headers,
            duplex: "half",
            body
          }
        );
        streamIpc.postMessage(await IpcResponse.fromResponse(request.reqId, res, streamIpc));
      });
      return { status: 101 };
    } else {
      const ipc2 = await this.ipcPo.waitOpen();
      const response = (await ipc2.request(event.request.url, event.request)).toResponse();
      return IpcResponse.fromResponse(event.ipcRequest.reqId, response, event.ipc);
    }
  }
};

// shim/db.shim.ts
var setupDB = async (sessionId, isClear = false) => {
  document.currentScript?.parentElement?.removeChild(document.currentScript);
  const KEY = "--plaoc-session-id--";
  console.log(
    "\u662F\u5426\u6E05\u7A7A\u6570\u636E\uFF1A",
    localStorage.getItem(KEY) !== null && localStorage.getItem(KEY) !== sessionId && isClear
  );
  if (localStorage.getItem(KEY) !== sessionId && isClear) {
    if (localStorage.getItem(KEY) == null) {
      localStorage.setItem(KEY, sessionId);
      return;
    }
    console.log("clearSession=>", sessionId);
    localStorage.clear();
    localStorage.setItem(KEY, sessionId);
    sessionStorage.clear();
    const tasks = [];
    const t1 = indexedDB.databases().then((dbs) => {
      for (const db of dbs) {
        if (db.name) {
          indexedDB.deleteDatabase(db.name);
        }
      }
    });
    tasks.push(t1.catch(console.error));
    if (typeof cookieStore === "object") {
      const t2 = cookieStore.getAll().then((cookies) => {
        for (const c of cookies) {
          cookieStore.delete(c.name);
        }
      });
      tasks.push(t2.catch(console.error));
    }
    await Promise.all(tasks);
    location.replace(location.href);
  }
};

// shim/fetch.shim.ts
var setupFetch = () => {
  const nativeFetch = fetch;
  const dwebFetch = (input, init) => {
    return nativeFetch(new DwebRequest(input, init));
  };
  const getBaseUrl = typeof document === "object" ? () => document.baseURI : () => location.href;
  const NativeRequest = Request;
  class DwebRequest extends NativeRequest {
    constructor(input, init) {
      let inputUrl;
      if (input instanceof URL) {
        inputUrl = input;
      } else if (typeof input === "string") {
        inputUrl = new URL(input, getBaseUrl());
      }
      if (inputUrl !== void 0) {
        if (inputUrl.username) {
          const dwebHeaders = new Headers(init?.headers);
          dwebHeaders.set("X-Dweb-Host", decodeURIComponent(inputUrl.username));
          init = {
            ...init,
            headers: dwebHeaders
          };
        }
        inputUrl.username = "";
        input = inputUrl;
      }
      super(input, init);
    }
  }
  const G = typeof globalThis === "object" ? globalThis : self;
  Object.assign(G, {
    fetch: dwebFetch,
    Request: DwebRequest,
    dwebShim: { nativeFetch, NativeRequest }
  });
};

// http-www-server.ts
var CONFIG_PREFIX = "/config.sys.dweb/";
var Server_www = class extends HttpServer {
  constructor(plaocConfig, handlers = []) {
    super("wwww");
    this.plaocConfig = plaocConfig;
    this.handlers = handlers;
  }
  get jsonPlaoc() {
    return this.plaocConfig.config;
  }
  lang = null;
  sessionInfo = jsProcess.nativeFetch("file:///usr/sys/session.json").then((res) => res.json());
  _getOptions() {
    return {
      subdomain: "www"
    };
  }
  encoder = new TextEncoder();
  async start() {
    const lang = await jsProcess.nativeFetch("file://config.sys.dweb/getLang").text();
    if (lang) {
      this.lang = lang;
    } else if (this.jsonPlaoc) {
      this.lang = this.jsonPlaoc.defaultConfig.lang;
    }
    const serverIpc = await this.listen(...this.handlers, this._provider.bind(this));
    return serverIpc.noFound();
  }
  async _provider(request, root = "www") {
    let { pathname } = request;
    if (pathname.startsWith(CONFIG_PREFIX)) {
      return this._config(request);
    }
    let remoteIpcResponse;
    if (this.jsonPlaoc) {
      const proxyRequest = this._plaocForwarder(request, this.jsonPlaoc);
      pathname = proxyRequest.url.pathname;
      const plaocShims = new Set((proxyRequest.url.searchParams.get("plaoc-shim") ?? "").split(",").filter(Boolean));
      if (plaocShims.has("fetch")) {
        remoteIpcResponse = await jsProcess.nativeRequest(`file:///usr/${root}${pathname}`, {
          headers: proxyRequest.headers
        });
        const rawText = await remoteIpcResponse.toResponse().text();
        remoteIpcResponse = IpcResponse.fromText(
          remoteIpcResponse.reqId,
          remoteIpcResponse.statusCode,
          remoteIpcResponse.headers,
          `;(${setupFetch.toString()})();${rawText}`,
          remoteIpcResponse.ipc
        );
      } else {
        const sourceResponse = await jsProcess.nativeRequest(`file:///usr/${root}${pathname}?mode=stream`, {
          headers: proxyRequest.headers
        });
        if (sourceResponse.headers.get("Content-Type")?.includes("text/html") && !plaocShims.has("raw")) {
          const rawText = await sourceResponse.toResponse().text();
          const installTime = (await this.sessionInfo).installTime;
          const text = `<script>(${setupDB.toString()})("${installTime}",
          ${this.jsonPlaoc.isClear});<\/script>${rawText}`;
          const binary = this.encoder.encode(text);
          remoteIpcResponse = IpcResponse.fromBinary(
            request.reqId,
            sourceResponse.statusCode,
            sourceResponse.headers,
            binary,
            sourceResponse.ipc
          );
        } else {
          remoteIpcResponse = new IpcResponse(
            request.reqId,
            sourceResponse.statusCode,
            sourceResponse.headers,
            sourceResponse.body,
            request.ipc
          );
        }
      }
    } else {
      const response = await jsProcess.nativeRequest(`file:///usr/${root}${pathname}?mode=stream`);
      remoteIpcResponse = new IpcResponse(
        request.reqId,
        response.statusCode,
        response.headers,
        response.body,
        request.ipc
      );
    }
    return remoteIpcResponse;
  }
  _config(event) {
    const pathname = event.pathname.slice(CONFIG_PREFIX.length);
    if (pathname.startsWith("/setLang")) {
      const lang = event.searchParams.get("lang");
      this.lang = lang;
    }
    return jsProcess.nativeFetch(`file:/${event.pathname}${event.search}`);
  }
  /**
   * 转发plaoc.json请求
   * @param request
   * @param config
   */
  _plaocForwarder(request, config) {
    const redirects = config.redirect;
    for (const redirect of redirects) {
      if (!this._matchMethod(request.method, redirect.matchMethod)) {
        continue;
      }
      const urlPattern = new URLPattern({
        pathname: redirect.matchUrl.pathname,
        search: redirect.matchUrl.search
      });
      const pattern = urlPattern.exec(request.url);
      if (!pattern)
        continue;
      const url = redirect.to.url.replace(/\{\{\s*(.*?)\s*\}\}/g, (_exp, match) => {
        const func = new Function("pattern", "lang", "config", `return ${match}`);
        return func(pattern, this.lang, config);
      }).replace(/\\/g, "/").replace(/\/\//g, "/");
      const newUrl = new URL(url, request.url);
      request.url.hash = newUrl.hash;
      request.url.host = newUrl.host;
      request.url.hostname = newUrl.hostname;
      request.url.href = newUrl.href;
      request.url.password = newUrl.password;
      request.url.pathname = newUrl.pathname;
      request.url.port = newUrl.port;
      request.url.protocol = newUrl.protocol;
      request.url.search = newUrl.search;
      request.url.username = newUrl.username;
      const appendHeaders = redirect.to.appendHeaders;
      if (appendHeaders && Object.keys(appendHeaders).length !== 0) {
        for (const header of Object.entries(appendHeaders)) {
          request.headers.append(header[0], header[1]);
        }
      }
      const removeHeaders = redirect.to.removeHeaders;
      if (removeHeaders && Object.keys(removeHeaders).length !== 0) {
        for (const header of Object.keys(removeHeaders)) {
          request.headers.delete(header[0]);
        }
      }
      return request;
    }
    return request;
  }
  /**
   * 匹配 * 和 method
   * @param method
   * @param methods
   * @returns
   */
  _matchMethod(method, methods) {
    if (!methods)
      return true;
    if (methods.join().indexOf("*") !== -1)
      return true;
    for (const me in methods) {
      if (me.toLocaleUpperCase() === method) {
        return true;
      }
    }
    return false;
  }
};

// helper/queue.ts
var queue = (fun) => {
  let queuer = Promise.resolve();
  return function(...args) {
    return queuer = queuer.finally(() => fun(...args));
  };
};

// middleware-importer.ts
var MiddlewareImporter = class {
  static async init(path) {
    if (!path) {
      return [];
    }
    try {
      const middleware = await import(join("./middleware", path));
      console.log("middleware=>", middleware);
      return middleware.default.handlers;
    } catch (_e) {
    }
  }
};
function join(...paths) {
  let joinedPath = paths[0];
  for (let i = 1; i < paths.length; i++) {
    let path = paths[i];
    if (path.startsWith(".")) {
      path = path.substring(1);
    }
    const precededBySlash = joinedPath.endsWith("/");
    const followedBySlash = path.startsWith("/");
    if (precededBySlash && followedBySlash) {
      joinedPath += path.substring(1);
    } else if (!precededBySlash && !followedBySlash) {
      joinedPath += "/" + path;
    } else {
      joinedPath += path;
    }
  }
  return joinedPath;
}

// plaoc-config.ts
var PlaocConfig = class _PlaocConfig {
  constructor(config) {
    this.config = config;
  }
  static async init() {
    try {
      const readPlaoc = await jsProcess.nativeRequest(`file:///usr/www/plaoc.json`);
      return new _PlaocConfig(JSON.parse(await readPlaoc.body.text()));
    } catch {
      return new _PlaocConfig({ isClear: false, redirect: [], defaultConfig: { lang: "en" } });
    }
  }
};

// main.ts
var main = async () => {
  console.log("start main");
  const indexHrefPo = new PromiseOut();
  let wid_po = new PromiseOut();
  const getWinId = () => wid_po.promise;
  const setWinId = (win_id) => {
    if (wid_po.is_finished) {
      wid_po = PromiseOut.resolve(win_id);
    } else {
      wid_po.resolve(win_id);
    }
  };
  const delWinId = (win_id) => {
    if (wid_po.value === win_id) {
      wid_po = new PromiseOut();
    }
  };
  const tryOpenView = queue(async () => {
    const url = await indexHrefPo.promise;
    const wid = await getWinId();
    console.log("mwebview_open=>", url, wid);
    await mwebview_open_activate(wid, url);
  });
  jsProcess.onActivity(async (ipcEvent2) => {
    console.log(`${jsProcess.mmid} onActivity`, ipcEvent2.data);
    const win_id = await apply_window();
    console.log("win_id=>", win_id);
    setWinId(win_id);
  });
  jsProcess.onRenderer((ipcEvent2) => {
    const text = IpcEvent.text(ipcEvent2);
    console.log(`${jsProcess.mmid} onRenderer`, text);
    setWinId(text);
    tryOpenView();
  });
  const plaocConfig = await PlaocConfig.init();
  const wwwServer = new Server_www(plaocConfig, await MiddlewareImporter.init(plaocConfig.config.middlewares?.www));
  const externalServer = new Server_external(await MiddlewareImporter.init(plaocConfig.config.middlewares?.external));
  const apiServer = new Server_api(getWinId, await MiddlewareImporter.init(plaocConfig.config.middlewares?.api));
  jsProcess.onRendererDestroy((ipcEvent2) => {
    const text = IpcEvent.text(ipcEvent2);
    console.log(`${jsProcess.mmid} onRendererDestroy`, text);
    externalServer.closeRegisterIpc();
    delWinId(text);
  });
  jsProcess.onShortcut(async (ipcEvent2) => {
    console.log(`${jsProcess.mmid} onShortcut`, ipcEvent2.data);
    const ipc2 = await externalServer.ipcPo.waitOpen();
    ipc2.postMessage(ipcEvent2);
  });
  const wwwListenerTask = wwwServer.start().finally(() => console.log("wwwServer started"));
  const externalListenerTask = externalServer.start().finally(() => console.log("externalServer started"));
  const apiListenerTask = apiServer.start().finally(() => console.log("apiServer started"));
  const wwwStartResult = await wwwServer.getStartResult();
  await apiServer.getStartResult();
  const indexHref = wwwStartResult.urlInfo.buildHtmlUrl(false, (url) => {
    url.pathname = "/index.html";
    url.searchParams.set("X-Plaoc-External-Url" /* EXTERNAL_URL */, externalServer.token);
  }).href;
  console.log("open in browser:", indexHref);
  await Promise.all([wwwListenerTask, externalListenerTask, apiListenerTask]);
  indexHrefPo.resolve(indexHref);
  console.log("indexUrl.href", indexHref);
  setWinId(await open_main_window());
};
try {
  void main();
} catch (e) {
  jsProcess.close(`\u540E\u7AEF\u9519\u8BEF\uFF1A${e}`);
}

// shim/crypto.shims.ts
if (typeof crypto.randomUUID !== "function") {
  crypto.randomUUID = function randomUUID() {
    return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (_c) => {
      const c = +_c;
      return (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16);
    });
  };
}

// middlewares/base-router.ts
var BaseRouter = class {
};

// middlewares/router.ts
var Router = class extends BaseRouter {
  constructor() {
    super();
  }
  handlers = [];
  use(...handlers) {
    this.handlers.push(...handlers);
  }
};
export {
  Router
};
//!此处为js ipc特有垫片，防止有些webview版本过低，出现无法支持的函数
