**<font size=3>Plus Meta BIW Platform Privacy Policy</font>**

<span class="asset-text">last updated on: 2024/07/08</span>

**<font size=3>1. Information collection</font>**

&emsp;&emsp;<span class="asset-text">The wealth management APP collects user data based on user usage, browsing, searching, etc. These data include but are not limited to: device information, IP address, operating system, browser type, application version, language settings, access time, access location, access history, geographical location information, etc.</span>

**<font size=3>2. Use of information</font>**

&emsp;&emsp;<span class="asset-text">The wealth management APP uses user data collected to provide, maintain and improve services. The APP may use these data to: manage accounts, process orders, notify users of services and updates, identify users, ensure service security, provide customer support with users, etc.</span>

**<font size=3>3. Information protection</font>**

&emsp;&emsp;<span class="asset-text">The wealth management APP will take reasonable security measures to protect users' personal information and usage habits from unauthorized access, use or disclosure. The wealth management APP will strengthen coordination and cooperation with third-party service providers to better protect the security of user data. At the same time, when deemed necessary, the wealth management APP will disclose information to the payment agents or other platforms to achieve the business instructed and authorized by users.</span>

**<font size=3>4. Information sharing</font>**

&emsp;&emsp;<span class="asset-text">The wealth management APP does not sell, rent or trade users' personal information in other ways. However, in order to provide and improve the service, the APP may share user data with third parties under the following circumstances: 
- &emsp;&emsp;<span class="asset-text">- Sharing user information with the user's explicit consent;</span>
- &emsp;&emsp;<span class="asset-text">- If required by law, regulation, legal process or government;</span>
- &emsp;&emsp;<span class="asset-text">- In the case of partners or creditors;</span>
- &emsp;&emsp;<span class="asset-text">- Sharing preferences and data to protect the assets or property of the wealth management APP, users, or others.</span>
</span>

**<font size=3>5. Information storage and access</font>**

&emsp;&emsp;<span class="asset-text">The wealth management APP will save user data within a reasonable period of time in order to provide services for business and other legitimate purposes. Users can request access, correction or deletion of their personal information at any time. The APP will update or delete the user's personal information upon request within a reasonable time.</span>

**<font size=3>6. Disclaimer</font>**

&emsp;&emsp;<span class="asset-text">The wealth management APP shall not be liable for any loss caused by the wealth management APP to users' personal information, the APP does not assume any responsibility. Under the premise of complying with legal procedures, the wealth management APP has the right to disclose users' personal information in order to protect its own interests and the interests of other users.</span>

**<font size=3>7. Alteration of the agreement</font>**

&emsp;&emsp;<span class="asset-text">The wealth management APP reserves the right to modify or update the terms of this privacy agreement at any time. If the wealth management APP modifies the privacy agreement, it will publish the updated terms in the app and inform the user of the effective date of the update. If the user continues to use the wealth management APP service within the validity period of the contract terms, it is indicated that the revised privacy policy is accepted.</span>

**<font size=3>8. Applicable Law</font>**

&emsp;&emsp;<span class="asset-text">This Privacy Agreement shall apply to the laws of the People's Republic of China. In case of any dispute, a consensus shall be reached through negotiation or other means. Otherwise, the dispute shall be submitted to the people's court with jurisdiction for settlement.</span>






