**<font size=3>Plus Meta BIW Platform User Agreement</font>**

<span class="asset-text">last updated on: 2024/07/08</span>

**<font size=3>1. Service description</font>**

&emsp;&emsp;<span class="asset-text">This Agreement applies to the financial investment services provided by PlusMeta-BIW wealth management to users, including but not limited to financial purchase, financial transactions, etc. PlusMeta-BIW Financial Management will wholeheartedly provide users with perfect services, but also hope that users can abide by this agreement, maintain the order of the financial market and healthy investment ecology.</span>

**<font size=3>2. Service fee</font>**

&emsp;&emsp;<span class="asset-text">The service of this wealth management APP may charge a certain service fee. Please check the service fee information before using the service. If you have any questions, please contact the customer service.</span>

**<font size=3>3. User information</font>**

&emsp;&emsp;<span class="asset-text">When using the service of this wealth management platform APP, users need to provide address public key and address name for purchasing products.</span>

**<font size=3>4. User behavior</font>**

&emsp;&emsp;<span class="asset-text">Users of this wealth management platform APP shall not use this Service for any illegal, infringing, destructive, unethical or improper behavior, nor shall they use this Service for any advertising or marketing of enterprises.</span>

**<font size=3>5. Account security</font>**

&emsp;&emsp;<span class="asset-text">Personal accounts shall be for personal use only, and users shall keep the account information, address, private key and other information by themselves. Users shall bear the responsibility for the leakage of the account password or the theft of the account. Users should ensure that account information and passwords are provided only to trusted third parties.</span>

**<font size=3>6. Intellectual property</font>**

&emsp;&emsp;<span class="asset-text">All the content of this wealth management platform APP (including but not limited to text, music, software, pictures, videos, etc.) involved in the originality, copyright, trademark, patent and other related rights are owned by us or have been authorized. Without the written consent of us or the right holder, the user shall not use, modify or reprint.</span>

**<font size=3>7. Service change, interruption, termination</font>**

&emsp;&emsp;<span class="asset-text">We can make changes, interruptions, or terminations to the relevant services of this wealth management platform APP at any time. You should ensure your legal assets within a reasonable range. If the service is interrupted due to non-human factors such as system failures, we will do our best to restore the service. Considering technical risks, we cannot guarantee that the service will be provided continuously without interruption.</span>

**<font size=3>8. Disclaimer and Limitation of Liability</font>**

&emsp;&emsp;<span class="asset-text">We do not assume any responsibility for any loss or damage caused by users' use of this wealth management platform APP services. At the same time, we do not assume any liability for any loss caused by service failure, technical problems, including any loss caused by address key disclosure, account theft, etc.</span>

**<font size=3>9. Application of law and dispute settlement</font>**

&emsp;&emsp;<span class="asset-text">The use of this wealth management platform APP services and the interpretation and execution of this Agreement shall be governed by the laws of the People's Republic of China. Any dispute in connection with this Agreement shall be settled through friendly negotiation. If such negotiation fails, it shall be submitted to the local people's court for settlement.</span>




