**<font size=3>《Plus Meta BIW理財平臺 用戶服務協議》</font>**

<span class="asset-text">最近更新於：2024年07月08日</span>

**<font size=3>1. 服務說明</font>**

&emsp;&emsp;<span class="asset-text">本協議適用於PlusMeta-BIW理財向用戶提供的理財投資服務，包括但不限於理財申購、理財交易等。
PlusMeta-BIW理財將竭誠為用戶提供完善的服務，同時也希望用戶能夠遵守本協議約定，維護理財市場的秩序和健康的投資生態。</span>

**<font size=3>2. 服務費用</font>**

&emsp;&emsp;<span class="asset-text">本理財平臺APP服務可能收取一定的服務費用,請用戶在使用服務前查看服務費用相關信息，如有疑問請聯系客服人員。</span>

**<font size=3>3. 用戶信息</font>**

&emsp;&emsp;<span class="asset-text">在使用本理財平臺APP服務時，用戶需提供地址公鑰以及地址名稱等信息，用於購買產品。</span>

**<font size=3>4. 用戶行為</font>**

&emsp;&emsp;<span class="asset-text">本理財平臺APP用戶不得利用本服務進行任何違法侵權、破壞性、不道德或不正當行為，也不得利用本服務進行任何廣告或推銷企業的行為。</span>

**<font size=3>5. 賬戶安全</font>**

&emsp;&emsp;<span class="asset-text">個人賬戶應僅供個人使用，用戶應自行保管賬戶信息以及地址私鑰等信息，對於因賬戶密碼泄露、賬戶被盜等情況，由用戶自行承擔責任。用戶應確保僅向受信任的第三方提供賬戶信息和密碼。</span>

**<font size=3>6. 知識產權</font>**

&emsp;&emsp;<span class="asset-text">本理財平臺APP的所有內容(包括但不限於文字、音樂、軟件、圖片、視頻等)所涉及的原創性、版權、商標、專利等相關權利，均為我們所有或已獲得授權。未經我們或權利人書面同意，用戶不得擅自進行使用、修改或轉載。</span>

**<font size=3>7. 服務的變更、中斷、終止</font>**

&emsp;&emsp;<span class="asset-text">我們可隨時對本理財平臺APP相關服務進行變更、中斷、終止。您應在合理範圍內確保自身合法資產。如因系統故障等非人為因素導致服務有中斷，我們將盡力恢復服務。考慮到技術風險，我們也不能保證服務將一直無中斷地提供。</span>

**<font size=3>8. 免責及限製責任</font>**

&emsp;&emsp;<span class="asset-text">對於因用戶使用本理財平臺APP服務而引起的任何損失或損害，我們不承擔任何責任。同時對服務故障、技術問題等引發的損失，包括由於地址秘鑰泄露、賬戶被盜等而引起的任何損失，我們不承擔任何賠償責任。</span>

**<font size=3>9. 法律適用和爭端解決</font>**

&emsp;&emsp;<span class="asset-text">本理財平臺APP服務的使用及本協議的解釋、執行應適用中華人民共和國法律。任何與本協議有關的爭議應當通過友好協商的方式解決，如不能友好協商，則應提交至我們所在地人民法院解決。</span>




