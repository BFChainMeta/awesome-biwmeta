**<font size=3>《Plus Meta BIW理财平台 隐私协议》</font>**

 <span class="asset-text">最近更新于：2024年07月08日</span>

**<font size=3>1. 服务说明</font>**

&emsp;&emsp;<span class="asset-text">本协议适用于PlusMeta-BIW理财向用户提供的理财投资服务，包括但不限于理财申购、理财交易等。PlusMeta-BIW理财将竭诚为用户提供完善的服务，同时也希望用户能够遵守本协议约定，维护理财市场的秩序和健康的投资生态。</span>

**<font size=3>2. 服务费用</font>**

&emsp;&emsp;<span class="asset-text">本理财平台APP服务可能收取一定的服务费用，请用户在使用服务前查看服务费用相关信息，如有疑问请联系客服人员。</span>

**<font size=3>3. 用户信息</font>**

&emsp;&emsp;<span class="asset-text">在使用本理财平台APP服务时，用户需提供地址公钥以及地址名称等信息，用于购买产品。</span>

**<font size=3>4. 用户行为</font>**

&emsp;&emsp;<span class="asset-text">本理财平台APP用户不得利用本服务进行任何违法、侵权、破坏性、不道德或不正当行为，也不得利用本服务进行任何广告或推销企业的行为。</span>

**<font size=3>5. 账户安全</font>**

&emsp;&emsp;<span class="asset-text">个人账户应仅供个人使用，用户应自行保管账户信息以及地址私钥等信息，对于因账户密码泄露、账户被盗等情况，由用户自行承担责任。用户应确保仅向受信任的第三方提供账户信息和密码。</span>

**<font size=3>6. 知识产权</font>**

&emsp;&emsp;<span class="asset-text">本理财平台APP的所有内容（包括但不限于文字、音乐、软件、图片、视频等）所涉及的原创性、版权、商标、专利等相关权利，均为我们所有或已获得授权。未经我们或权利人书面同意，用户不得擅自进行使用、修改或转载。</span>

**<font size=3>7. 服务的变更、中断、终止</font>**

&emsp;&emsp;<span class="asset-text">我们可随时对本理财平台APP相关服务进行变更、中断、终止。您应在合理范围内确保自身合法资产。如因系统故障等非人为因素导致服务有中断，我们将尽力恢复服务。考虑到技术风险，我们也不能保证服务将一直无中断地提供。</span>

**<font size=3>8. 免责及限制责任</font>**

&emsp;&emsp;<span class="asset-text">对于因用户使用本理财平台APP服务而引起的任何损失或损害，我们不承担任何责任。同时对服务故障、技术问题等引发的损失，包括由于地址秘钥泄露、账户被盗等而引起的任何损失，我们不承担任何赔偿责任。</span>

**<font size=3>9. 法律适用和争端解决</font>**

&emsp;&emsp;<span class="asset-text">本理财平台APP服务的使用及本协议的解释、执行应适用中华人民共和国法律。任何与本协议有关的争议应当通过友好协商的方式解决，如不能友好协商，则应提交至我们所在地人民法院解决。</span>




