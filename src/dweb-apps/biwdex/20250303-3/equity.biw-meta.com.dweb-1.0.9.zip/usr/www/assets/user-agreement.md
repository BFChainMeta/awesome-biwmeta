# Terms of Use
（Last updated at 2023.10.23）

Welcome to BIWDex, a website-hosted user interface (the “Interface” or “App”) provided by BIWDex team (”we”, ”our”, or ”us”). The Interface provides access to a decentralized protocol on the blockchain that allows users to trade certain digital assets (“the BIWDex protocol” or the “Protocol”). The Interface is one, but not the exclusive, means of accessing the Protocol.

This Terms of Service Agreement (the “Agreement”) explains the terms and conditions by which you may access and use the Interface. You must read this Agreement carefully. By accessing or using the Interface, you signify that you have read, understand, and agree to be bound by this Agreement in its entirety. If you do not agree, you are not authorized to access or use the Interface and should not use the Interface.

NOTICE: Please read this Agreement carefully as it governs your use of the Interface. This Agreement contains important information, including a binding arbitration provision and a class action waiver, both of which impact your rights as to how disputes are resolved. The Interface is only available to you — and you should only access the Interface — if you agree completely with these terms.

## 1.	Modification of this Agreement

We reserve the right, in our sole discretion, to modify this Agreement from time to time. If we make any modifications, we will notify you by updating the date at the top of the Agreement. All modifications will be effective when they are posted, and your continued accessing or use of the Interface will serve as confirmation of your acceptance of those modifications. If you do not agree with any modifications to this Agreement, you must immediately stop accessing and using the Interface.

## 2.	Eligibility

To access or use the Interface, you must be able to form a legally binding contract with us. Accordingly, you represent that you are at least the age of majority in your jurisdiction (e.g., eighteen years old) and have the full right, power, and authority to enter into and comply with the terms and conditions of this Agreement on behalf of yourself and any company or legal entity for which you may access or use the Interface.

You further represent that you are not (a) the subject of economic or trade sanctions administered or enforced by any governmental authority or otherwise designated on any list of prohibited or restricted parties or (b) (including but not limited to the following) a citizen, resident, or organization of the Chinese Mainland, Taiwan (province of China), Hong Kong (SAR of China), the United States, Canada, Japan, Cuba, Iran, North Korea, Sudan, Syria, Venezuela, Crimea and Singapore.
 
## 3.	Proprietary Rights

We own all intellectual property and other rights in the Interface and its contents, including (but not limited to) software, text, images, trademarks, service marks, copyrights, patents, and designs. Unlike the Interface, BIWDex protocol are comprised entirely of open-source or source-available software running on the  blockchain.

## 4.	Additional Rights

We reserve the following rights, which do not constitute obligations of ours: (a) with or without notice to you, to modify, substitute, eliminate or add to the Interface; (b) to review, modify, filter, disable, delete and remove any and all content and information from the Interface; and (c) to cooperate with any law enforcement, court or government investigation or order or third party requesting or directing that we disclose information or content that you provide.

## 5.	Privacy

When you use the Interface, the only information we collect from you is your blockchain wallet address, completed transaction hashes, and the token names, symbols, or other blockchain identifiers of the tokens that you swap. We do not collect any personal information from you (e.g., your name or other identifiers that can be linked to you). We do, however, use third-party service providers, like  Cloudflare, and Google Analytics, which may receive or independently obtain your personal information from publicly-available sources. We do not control how these third parties handle your data and you should review their privacy policies to understand how they collect, use, and share your personal information. In particular, please visit https://policies.google.com/technologies/partner-sites to learn more about how Google uses data. By accessing and using the Interface, you understand and consent to our data practices and our service providers’ treatment of your information.

We use the information we collect to detect, prevent, and mitigate financial crime and other illicit or harmful activities on the Interface. For these purposes, we may share the information we collect with blockchain analytics providers. We share information with these service providers only so that they can help us promote the safety, security, and integrity of the Interface. We do not retain the information we collect any longer than necessary for these purposes.

Please note that when you use the Interface, you are interacting with the blockchain, which provides transparency into your transactions. BIWDex Team does not control and is not responsible for any information you make public on the blockchain by taking actions through the Interface.

## 6.	Prohibited Activity

You agree not to engage in, or attempt to engage in, any of the following categories of prohibited activity in relation to your access and use of the Interface:
 
Intellectual Property Infringement. Activity that infringes on or violates any copyright, trademark, service mark, patent, right of publicity, right of privacy, or other proprietary or intellectual property rights under the law.
Cyberattack. Activity that seeks to interfere with or compromise the integrity, security, or proper functioning of any computer, server, network, personal device, or other information technology system, including (but not limited to) the deployment of viruses and denial of service attacks.
Fraud and Misrepresentation. Activity that seeks to defraud us or any other person or entity, including (but not limited to) providing any false, inaccurate, or misleading information in order to unlawfully obtain the property of another.
Market Manipulation. Activity that violates any applicable law, rule, or regulation concerning the integrity of trading markets, including (but not limited to) the manipulative tactics commonly known as spoofing and wash trading.
Securities and Derivatives Violations. Activity that violates any applicable law, rule, or regulation concerning the trading of securities or derivatives.
Any Other Unlawful Conduct. Activity that violates any applicable law, rule, or regulation of Singapore or another relevant jurisdiction, including (but not limited to) the restrictions and regulatory requirements imposed by Singapore law.

## 7.	Not Registered with the MAS or Any Other Agency

We are not registered with the Monetary Authority of Singapore as a national securities exchange or in any other capacity. You understand and acknowledge that we do not broker trading orders on your behalf nor do we collect or earn fees from your trades on the Protocol. We also do not facilitate the execution or settlement of your trades, which occur entirely on the public distributed blockchain.

## 8.	Non-Solicitation; No Investment Advice

You agree and understand that all trades you submit through the Interface are considered unsolicited, which means that you have not received any investment advice from us in connection with any trades, including those you place via our API, and that we do not conduct a suitability review of any trades you submit.

All information provided by the Interface is for informational purposes only and should not be construed as investment advice. You should not take, or refrain from taking, any action based on any information contained in the Interface. We do not make any investment recommendations to you or opine on the merits of any investment transaction or opportunity. You alone are responsible for determining whether any investment, investment strategy or related transaction is appropriate for you based on your personal investment objectives, financial circumstances, and risk tolerance.

## 9.	No Warranties

The Interface is provided on an “AS IS” and “AS AVAILABLE” basis. To the fullest extent permitted by law, we disclaim any representations and warranties of any kind, whether
 
express, implied, or statutory, including (but not limited to) the warranties of merchantability and fitness for a particular purpose. You acknowledge and agree that your use of the Interface is at your own risk. We do not represent or warrant that access to the Interface will be continuous, uninterrupted, timely, or secure; that the information contained in the Interface will be accurate, reliable, complete, or current; or that the Interface will be free from errors, defects, viruses, or other harmful elements. No advice, information, or statement that we make should be treated as creating any warranty concerning the Interface. We do not endorse, guarantee, or assume responsibility for any advertisements, offers, or statements made by third parties concerning the Interface.

## 10.	Non-Custodial and No Fiduciary Duties

The Interface is a purely non-custodial application, meaning you are solely responsible for the custody of the cryptographic private keys to the digital asset wallets you hold. This Agreement is not intended to, and does not, create or impose any fiduciary duties on us. To the fullest extent permitted by law, you acknowledge and agree that we owe no fiduciary duties or liabilities to you or any other party, and that to the extent any such duties or liabilities may exist at law, those duties and liabilities are hereby irrevocably disclaimed, waived, and eliminated. You further agree that the only duties and obligations that we owe you are those set out expressly in this Agreement.

## 11.	Compliance Obligations

The Interface is operated from facilities within Singapore. The Interface may not be available or appropriate for use in other jurisdictions. By accessing or using the Interface, you agree that you are solely and entirely responsible for compliance with all laws and regulations that may apply to you.

## 12.	Assumption of Risk

By accessing and using the Interface, you represent that you are financially and technically sophisticated enough to understand the inherent risks associated with using cryptographic and blockchain-based systems, and that you have a working knowledge of the usage and intricacies of digital assets such as BFMeta. In particular, you understand that blockchain- based transactions are irreversible.

You further understand that the markets for these digital assets are highly volatile due to factors including (but not limited to) adoption, speculation, technology, security, and regulation. You acknowledge and accept that the cost and speed of transacting with cryptographic and blockchain-based systems such as BFMeta are variable and may increase dramatically at any time. You further acknowledge and accept the risk that your digital assets may lose some or all of their value while they are supplied to the Protocol through the Interface, you may suffer loss due to the fluctuation of prices of tokens in a trading pair or liquidity pool, and, especially in expert modes, experience significant price slippage and cost. You understand that anyone can create a token, including fake versions of existing tokens and tokens that falsely claim to represent projects, and acknowledge and accept the risk that
 
you may mistakenly trade those or other tokens. You further acknowledge that we are not responsible for any of these variables or risks, do not own or control the Protocol, and cannot be held liable for any resulting losses that you experience while accessing or using the Interface. Accordingly, you understand and agree to assume full responsibility for all of the risks of accessing and using the Interface to interact with the Protocol.

## 13.	Third-Party Resources and Promotions

The Interface may contain references or links to third-party resources, including (but not limited to) information, materials, products, or services, that we do not own or control. In addition, third parties may offer promotions related to your access and use of the Interface. We do not endorse or assume any responsibility for any such resources or promotions. If you access any such resources or participate in any such promotions, you do so at your own risk, and you understand that this Agreement does not apply to your dealings or relationships with any third parties. You expressly relieve us of any and all liability arising from your use of any such resources or participation in any such promotions.

## 14.	Release of Claims

You expressly agree that you assume all risks in connection with your access and use of the Interface and your interaction with the Protocol. You further expressly waive and release us from any and all liability, claims, causes of action, or damages arising from or in any way relating to your use of the Interface and your interaction with the Protocol.

## 15.	Indemnity

You agree to hold harmless, release, defend, and indemnify us and our officers, directors, employees, contractors, agents, affiliates, and subsidiaries from and against all claims, damages, obligations, losses, liabilities, costs, and expenses arising from: (a) your access and use of the Interface; (b) your violation of any term or condition of this Agreement, the right of any third party, or any other applicable law, rule, or regulation; and (c) any other party’s access and use of the Interface with your assistance or using any device or account that you own or control.

## 16.	Limitation of Liability

Under no circumstances shall we or any of our officers, directors, employees, contractors, agents, affiliates, or subsidiaries be liable to you for any indirect, punitive, incidental, special, consequential, or exemplary damages, including (but not limited to) damages for loss of profits, goodwill, use, data, or other intangible property, arising out of or relating to any access or use of the Interface, nor will we be responsible for any damage, loss, or injury resulting from hacking, tampering, or other unauthorized access or use of the Interface or the information contained within it. We assume no liability or responsibility for any: (a) errors, mistakes, or inaccuracies of content; (b) personal injury or property damage, of any nature whatsoever, resulting from any access or use of the Interface; (c) unauthorized access or use of any secure server or database in our control, or the use of any information or data stored therein; (d) interruption or cessation of function related to the Interface; (e) bugs,
 
viruses, trojan horses, or the like that may be transmitted to or through the Interface; (f) errors or omissions in, or loss or damage incurred as a result of the use of, any content made available through the Interface; and (g) the defamatory, offensive, or illegal conduct of any third party. Under no circumstances shall we or any of our officers, directors, employees, contractors, agents, affiliates, or subsidiaries be liable to you for any claims, proceedings, liabilities, obligations, damages, losses, or costs in an amount exceeding the amount you paid to us in exchange for access to and use of the Interface, or USD$100.00, whichever is greater. This limitation of liability applies regardless of whether the alleged liability is based on contract, tort, negligence, strict liability, or any other basis, and even if we have been advised of the possibility of such liability. Some jurisdictions do not allow the exclusion of certain warranties or the limitation or exclusion of certain liabilities and damages.
Accordingly, some of the disclaimers and limitations set forth in this Agreement may not apply to you. This limitation of liability shall apply to the fullest extent permitted by law.

## 17.	Dispute Resolution

We will use our best efforts to resolve any potential disputes through informal, good faith negotiations. If a potential dispute arises, you must contact us by sending an email to service@BFMeta.org so that we can attempt to resolve it without resorting to formal dispute resolution. If we aren’t able to reach an informal resolution within sixty days of your email, then you and we both agree to resolve the potential dispute according to the process set forth below.

Any claim or controversy arising out of or relating to the Interface, this Agreement, or any other acts or omissions for which you may contend that we are liable, including (but not limited to) any claim or controversy as to arbitrability (”Dispute”), shall be finally and exclusively settled by arbitration under the Arbitration Act and the International Arbitration Act. You understand that you are required to resolve all Disputes by binding arbitration. The arbitration will be held in Singapore, unless you and we both agree to hold it elsewhere.
Unless we agree otherwise, the arbitrator may not consolidate your claims with those of any other party. Any judgment on the award rendered by the arbitrator may be entered in any court of competent jurisdiction.

## 18.	Class Action and Jury Trial Waiver

You must bring any and all Disputes against us in your individual capacity and not as a plaintiff in or member of any purported class action, collective action, private attorney general action, or other representative proceeding. This provision applies to class arbitration. You and we both agree to waive the right to demand a trial by jury.

## 19.	Governing Law

You agree that the laws of Singapore, without regard to principles of conflict of laws, govern this Agreement and any Dispute between you and us. You further agree that the Interface shall be deemed to be based solely in Singapore, and that although the Interface may be available in other jurisdictions, its availability does not give rise to general or specific personal jurisdiction in any forum outside Singapore. Any arbitration conducted pursuant to
 
this Agreement shall be governed by the Arbitration Act and the International Arbitration Act. You agree that the courts of Singapore are the proper forum for any appeals of an arbitration award or for court proceedings in the event that this Agreement’s binding arbitration clause is found to be unenforceable.

## 20.	Entire Agreement

These terms constitute the entire agreement between you and us with respect to the subject matter hereof. This Agreement supersedes any and all prior or contemporaneous written and oral agreements, communications and other understandings (if any) relating to the subject matter of the terms.

<br>
<br>
<br>

# Privacy Policy
（Last updated at 2021.11.01)

## 1. Preface
This Privacy Policy provides our privacy policy regarding the nature, purpose, use, and sharing of personal data or other information collected from the users of the website biw-dex.com and other websites which use subdomains of BIWDex.com (the "Site"). We are committed to protecting and respecting your privacy. Please read this carefully as this Privacy Policy is legally binding when you use the Site.

As used in this Privacy Policy, "we", "us" or "our" refers to BIWDex Team, which has been actively involved in the ecological construction of BIWDex. You can reach us with any request relating to this Privacy Policy via contact details provided below.

## 2. Data processing in connection with the Site

### 2.1	Use of Cookies and Similar Technologies
The Site is using cookies. Cookies are small text files that are placed on your computer by websites that you visit. They are widely used in order to make websites work, or work more efficiently, as well as to provide information to the owners of the site. Cookies are typically stored on your computer's hard drive. Information collected from cookies is used by us to evaluate the effectiveness of our Site and analyze trends. The information collected from cookies allows us to determine such things as which parts of the Site are most visited and difficulties our visitors may experience in accessing the Site. With this knowledge, we can improve the quality of your experience on the Site by recognizing and delivering more of the most desired features and information, as well as by resolving access difficulties.

We use third party service providers, to assist us in better understanding the use of our Site. Our service providers will place cookies on the hard drive of your computer (or use similar technologies) and will receive information that we select that will educate us on such things as how visitors navigate around our Site. This information is aggregated to provide statistical data about our users' browsing actions and patterns, and does not personally identify individuals. This information may include:

-	Computer or mobile device information,
-	Website usage information, such as: Page views, Button clicks, Input form changes (without the values being entered), Errors.


Our service providers analyses this information and provides us with aggregate reports. The information and analysis provided by our service providers will be used to assist us in better understanding our visitors' interests in our Site and how to better serve those interests. If you want to avoid using cookies altogether, you can disable cookies in your browser. However, disabling cookies might make it impossible for you to use certain features of the Site. Your
 
use of the Site with a browser that is configure to accept cookies constitutes an acceptance of our and third-party cookies.





### 2.2	Email Marketing
If you subscribe to our newsletter we may occasionally communicate project news, updates, promotions and related information relating to BIWDex. We shall only do this where you have given us your consent. If you want to opt out of receiving promotional and marketing emails in relation to which you might receive in accordance with this section, you can best opt out by clicking "unsubscribe" at the bottom of an email we sent you.

### 2.3	Your inquiries
You may contact us by e-mail to the following e-mail address: service@bfmeta.org. We use the data that you provide in an email to us, which you may give voluntarily, only in order to answer your contact question or to reply to your email in the best possible manner.

### 2.4	Social media
We may use plugins from social networks such as GitHub, YouTube, Reddit, Twitter, Telegram, Medium on the Site. When you activate them (by clicking on them), the operators of the respective social networks may record that you are on the Site and may use this information. This processing of your personal data lays in the responsibility of these individual social media platforms and occurs according to their privacy policies. Please check with these individual social media platforms regarding their privacy policies. We are not responsible for data collected by these individual social media platforms.

### 2.5	Your rights
#### 2.5.1	Right to access
As a data subject you have the right to obtain from us free information about your personal data processed at any time and a copy of this information. Furthermore, you will have access to the following information: the purposes of the processing; the categories of personal data concerned; where possible, the envisaged period for which the personal data will be processed, or, if not possible, the criteria used to determine that period; the existence of the right to request from us rectification or erasure of personal data, or restriction of processing of personal data concerning you, or to object to such processing; the existence of the right to lodge a complaint with a supervisory authority; where the personal data are not collected directly from you, any available information as to their source; and the existence of automated decision-making, including profiling, and, at least in those cases, meaningful information about the logic involved, as well as the significance and envisaged consequences of such processing for you.

#### 2.5.2	Right to rectification
 
You have the right to obtain from us, without undue delay, the rectification of inaccurate personal data concerning you. Taking into account the purposes of the processing, you shall have the right to have incomplete personal data completed, including by means of providing a supplementary statement.

#### 2.5.3	Right to be forgotten
You have the right to obtain from us the erasure of personal data concerning you as soon as possible, and we shall have the obligation to erase personal data without undue delay where required by the law, including when:

-	the personal data is no longer necessary in relation to the purposes for which they were collected or otherwise processed;
-	there is no longer a legal ground for the processing;
-	you object to the processing and there are no overriding legitimate grounds for the processing;
-	the personal data has been unlawfully processed;
-	the personal data must be erased for compliance with a legal obligation in accordance with the applicable law to which we are subject.


#### 2.5.4	Right to restriction of processing
You have the right to obtain from the Foundation restriction of processing where one of the following applies:

the accuracy of the personal data is contested by you, for a period enabling us to verify the accuracy of the personal data; the processing is unlawful and you oppose the erasure of the personal data and requests instead the restriction of their use instead; we no longer needs the personal data for the purposes of the processing, but they are required by you for the establishment, exercise or defense of legal claims; and/o you have objected to processing pursuant to applicable laws.

#### 2.5.5	Right to object
You have the right to object, on grounds relating to your particular situation, at any time, to the processing of personal data concerning you. We shall no longer process the personal data in the event of the objection, unless we can demonstrate reasonable grounds for the processing, which override the interests, rights and freedoms of you, or for the establishment, exercise or defense of legal claims.

#### 2.5.6	Right to withdraw data protection consent
You have the right to withdraw your consent to processing of your personal data at any time.

## 3.	International transfers
We are entitled to transfer your personal data to third parties abroad for the purposes of the data processing.
 
As personal data processors, they are obliged to protect data privacy to the same extent as we ourselves. We choose the processors carefully to ensure compliance with applicable laws.

## 4.	Data security
We use appropriate technical and organizational security measures to protect your personal data. Our security measures are continuously being improved in line with technical developments.

Please note that any data transmission on the Internet (e.g. communication by e-mail) is generally not secure and we accept no liability for data transmitted to us via the Internet. Unfortunately, absolute protection is not technically possible. This information does not apply to the websites of third parties and the corresponding links given on the Site. We assume no responsibility and liability for these.

## 5.	Duration of data processing
We will process your personal data only for the period necessary to achieve the purpose of the processing, or as required by applicable laws. After the period the personal data will be deleted.

## 6.	Amendments to this Policy
We may amend this Privacy Policy at any time by posting the amended version on the Site including the effective date of the amended version. The current version of the Privacy Policy, as published on the Site, is applicable.



## 7.	Contact
Please contact us with questions, comments, or concerns regarding our Privacy Policy as well as with any requests at service@BFMeta.org.
