import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input, inject } from '@angular/core';
import {
  fadeInLeftTrigger,
  fadeInRightTrigger,
  listFadeInRightTrigger,
  listFadeOutLeftTrigger,
  listFadeRightTrigger,
  pageFadeInRightTrigger,
} from '@bnqkl/framework/animations';
import { CommonPageModule } from '~modules/page.module';
import { $SupportChain } from '~app/tabs/assets/assets.type';
import { AmountFormatPipe } from '~pipes/amount-format/amount-format.pipe';
import { SwapTokenChainIconComponent } from '~components/swap-token-chain-icon/swap-token-chain-icon.component';
import { AssetsPage as AssetsBasePage } from '~app/tabs/assets/assets.component';
import { AddressHiddenPipe } from '@bnqkl/framework/pipes';
import MyAssetAllocationContentPage from '~pages/mine/pages/my-asset-allocation/component/my-asset-allocation-content.component';
/** 钱包页 */
@Component({
  selector: 'bs-assets',
  standalone: true,
  imports: [
    SwapTokenChainIconComponent,
    AmountFormatPipe,
    AddressHiddenPipe,
    CommonPageModule,
    CommonModule,
    MyAssetAllocationContentPage,
  ],
  templateUrl: './assets.component.html',
  styleUrls: ['./assets.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    listFadeRightTrigger,
    listFadeInRightTrigger,
    listFadeOutLeftTrigger,
    fadeInLeftTrigger,
    fadeInRightTrigger,
    pageFadeInRightTrigger,
  ],
})
export class AssetsPage extends AssetsBasePage {
  /** 资产弹窗的数据 */
  @AssetsPage.States(1)
  assetAllocation: { is_open: boolean } = {
    is_open: false,
  };
  /** 可支持的链列表  */
  @Input()
  @AssetsPage.State()
  override supportChainList: $SupportChain[] = [];

  override jumpAssetAllocation() {
    this.assetAllocation.is_open = true;
  }

  get allocationQueryParams() {
    return { pieChartData: JSON.stringify(this.pieChartData) };
  }

  goBack() {
    this.assetAllocation.is_open = false;
  }
}
export default AssetsPage;
