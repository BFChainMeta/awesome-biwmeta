import { r as reactExports, s as setupDialog, R as React, P as Page } from "./index-CvggWz_h.js";
import { d as definePage, a as appAdminInfoFlow, b as appUserInfoFlow } from "./page-wJ61H8A2.js";
const appVersionUpdate = (medatadaUrl) => {
  return (window ?? globalThis).open(`dweb://install?url=${medatadaUrl}`);
};
const _404 = definePage(
  (args) => {
    reactExports.useEffect(() => {
      {
        fetch(`${"https://inviteapi.elephant-fly.com/"}static/version/app.json`).then(
          (res) => res.json()
        ).then(async (info) => {
          const appVersion = localStorage.getItem("APP_VERSION") || "";
          const newVersion = info.version;
          const versionToNumber = (version) => {
            const vcodes = version.replace(/[vV]/, "").split(".");
            let res = 0;
            res += (parseInt(vcodes[0]) || 0) * 1e5;
            res += (parseInt(vcodes[1]) || 0) * 1e3;
            res += parseInt(vcodes[2]) || 0;
            res += (parseInt(vcodes[3]) || 0) * 1e-4;
            return res;
          };
          if (versionToNumber(newVersion) > versionToNumber(appVersion)) {
            const f7_dialog = await setupDialog();
            const dialog = f7_dialog.create({
              /** Dialog title. */
              title: "发现新版本",
              /** Dialog inner text. */
              text: "更新版本",
              buttons: [
                {
                  text: "更新",
                  close: false,
                  onClick: () => {
                    appVersionUpdate(info.dwebUrl);
                  }
                }
              ]
            });
            dialog.open();
          }
        });
      }
      if (location.hash.startsWith("#!/admin")) {
        if (appAdminInfoFlow.value.token) {
          args.safeF7Navigater.adminMain({ reloadAll: true });
        } else {
          args.safeF7Navigater.adminLogin({ reloadAll: true });
        }
      } else {
        if (appUserInfoFlow.value.account) {
          args.safeF7Navigater.tabs({ reloadAll: true });
        } else {
          args.safeF7Navigater.login({ reloadAll: true });
        }
      }
    }, []);
    return /* @__PURE__ */ React.createElement(Page, { name: "Loss", className: "bg-[url('../images/image_login_cover.webp')] bg-cover bg-center bg-no-repeat" }, /* @__PURE__ */ React.createElement("h5", null));
  },
  { bindingHistory: false }
);
export {
  _404 as default
};
