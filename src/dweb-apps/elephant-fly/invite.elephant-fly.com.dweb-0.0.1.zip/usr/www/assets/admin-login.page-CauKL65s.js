import { R as React, P as Page, L as List, f as ListInput, B as Button } from "./index-CvggWz_h.js";
import { b as biwApi } from "./api-uUGDDCgf.js";
import { d as definePage, a as appAdminInfoFlow } from "./page-wJ61H8A2.js";
import { u as useEasyState } from "./toast-DllnHs3T.js";
const adminLogin_page = definePage((args) => {
  const account = useEasyState("");
  const pwd = useEasyState("");
  const logining = useEasyState(false);
  const login = async () => {
    try {
      logining.value = true;
      if (!account.value || !pwd.value) {
        return;
      }
      const admin = await biwApi.user.adminLogin.mutate({ account: account.value, password: pwd.value });
      appAdminInfoFlow.value = admin;
      args.safeF7Navigater.adminMain({
        reloadAll: true
      });
    } finally {
      logining.value = false;
    }
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "login" }, /* @__PURE__ */ React.createElement("div", { className: "flex w-full flex-col items-center justify-center pt-16" }, /* @__PURE__ */ React.createElement("img", { src: "./images/logo.webp", className: "rounded-4 mx-auto h-24 w-24", alt: "" }), /* @__PURE__ */ React.createElement(
    "div",
    {
      className: "w-full max-w-[360px] px-4",
      onKeyDown: (e) => {
        if (e.key == "Enter") {
          login();
        }
      }
    },
    /* @__PURE__ */ React.createElement(List, { strongIos: true, dividersIos: true, insetIos: true }, /* @__PURE__ */ React.createElement(
      ListInput,
      {
        label: "管理员账号",
        type: "text",
        placeholder: "请输入账号",
        clearButton: true,
        value: account.value,
        onInput: (e) => {
          account.value = e.target.value;
        }
      }
    ), /* @__PURE__ */ React.createElement(
      ListInput,
      {
        label: "管理员密码",
        type: "password",
        placeholder: "请输入登录密码",
        clearButton: true,
        value: pwd.value,
        onInput: (e) => {
          pwd.value = e.target.value;
        }
      }
    )),
    /* @__PURE__ */ React.createElement("div", { className: "flex flex-col gap-2 px-4" }, /* @__PURE__ */ React.createElement(Button, { type: "button", roundIos: true, fillIos: true, largeIos: true, onClick: login, loading: logining.value }, "登录"))
  )));
});
export {
  adminLogin_page as default
};
