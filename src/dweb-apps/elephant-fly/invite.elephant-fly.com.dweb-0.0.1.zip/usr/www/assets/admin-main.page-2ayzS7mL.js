import { R as React, P as Page, B as Button, L as List, h as ListItem } from "./index-CvggWz_h.js";
import { b as biwApi } from "./api-uUGDDCgf.js";
import { d as definePage, a as appAdminInfoFlow } from "./page-wJ61H8A2.js";
import { u as useEasyState, t as toast } from "./toast-DllnHs3T.js";
import { u as useFlow } from "./use_flow-v6XFM-bj.js";
const adminMain_page = definePage((args) => {
  const adminInfo = useFlow(appAdminInfoFlow).value;
  const copy = (code) => {
    navigator.clipboard.writeText(code);
    toast("邀请码复制成功");
  };
  const loading = useEasyState(false);
  const genCode = async () => {
    try {
      loading.value = true;
      const admin = await biwApi.user.adminCreateCode.mutate();
      appAdminInfoFlow.value = {
        ...appAdminInfoFlow.value,
        ...admin
      };
    } finally {
      loading.value = false;
    }
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "main" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col w-full min-h-full items-center justify-center py-4 gap-2" }, /* @__PURE__ */ React.createElement("img", { src: "./images/logo.webp", className: "w-24 h-24 rounded-4 mx-auto p-2", alt: "" }), /* @__PURE__ */ React.createElement("div", { className: "flex justify-between gap-2 px-4" }, /* @__PURE__ */ React.createElement(Button, { type: "button", fillIos: true, onClick: genCode, loading: loading.value }, "一键生成邀请码"), /* @__PURE__ */ React.createElement(
    Button,
    {
      fillIos: true,
      color: "red",
      onClick: () => {
        args.safeF7Navigater.adminLogin({
          reloadAll: true
        });
        appAdminInfoFlow.value = {};
      }
    },
    "退出登录"
  )), /* @__PURE__ */ React.createElement("div", { className: "w-full max-w-[360px] px-4" }, /* @__PURE__ */ React.createElement(List, { className: "mt-6" }, /* @__PURE__ */ React.createElement(ListItem, null, "已生成邀请码："), adminInfo.codes && adminInfo.codes.map((code) => {
    return /* @__PURE__ */ React.createElement(ListItem, { key: code, onClick: () => copy(code) }, code);
  })))));
});
export {
  adminMain_page as default
};
