import { M as Modal, e as extend, g as getDevice, a as getDocument, $ as $jsx, b as $, c as ModalMethods, i as iosPreloaderContent, m as mdPreloaderContent } from "./index-CvggWz_h.js";
class Dialog extends Modal {
  constructor(app, params) {
    const extendedParams = extend({
      title: app.params.dialog.title,
      text: void 0,
      content: "",
      buttons: [],
      verticalButtons: false,
      onClick: void 0,
      cssClass: void 0,
      destroyOnClose: false,
      on: {}
    }, params);
    if (typeof extendedParams.closeByBackdropClick === "undefined") {
      extendedParams.closeByBackdropClick = app.params.dialog.closeByBackdropClick;
    }
    if (typeof extendedParams.backdrop === "undefined") {
      extendedParams.backdrop = app.params.dialog.backdrop;
    }
    super(app, extendedParams);
    const dialog2 = this;
    const device = getDevice();
    const document = getDocument();
    const {
      title,
      text,
      content,
      buttons,
      verticalButtons,
      cssClass,
      backdrop
    } = extendedParams;
    dialog2.params = extendedParams;
    let $el;
    if (!dialog2.params.el) {
      const dialogClasses = ["dialog"];
      if (buttons.length === 0) dialogClasses.push("dialog-no-buttons");
      if (buttons.length > 0) dialogClasses.push(`dialog-buttons-${buttons.length}`);
      if (verticalButtons) dialogClasses.push("dialog-buttons-vertical");
      if (cssClass) dialogClasses.push(cssClass);
      let buttonsHTML = "";
      if (buttons.length > 0) {
        buttonsHTML = $jsx("div", {
          class: "dialog-buttons"
        }, buttons.map((button) => $jsx("span", {
          class: `dialog-button${button.strong ? " dialog-button-strong" : ""}${button.color ? ` color-${button.color}` : ""}${button.cssClass ? ` ${button.cssClass}` : ""}`
        }, button.text)));
      }
      const dialogHtml = $jsx("div", {
        class: dialogClasses.join(" ")
      }, $jsx("div", {
        class: "dialog-inner"
      }, title && $jsx("div", {
        class: "dialog-title"
      }, title), text && $jsx("div", {
        class: "dialog-text"
      }, text), content), buttonsHTML);
      $el = $(dialogHtml);
    } else {
      $el = $(dialog2.params.el);
    }
    if ($el && $el.length > 0 && $el[0].f7Modal) {
      return $el[0].f7Modal;
    }
    if ($el.length === 0) {
      return dialog2.destroy();
    }
    let $backdropEl;
    if (backdrop) {
      $backdropEl = app.$el.children(".dialog-backdrop");
      if ($backdropEl.length === 0) {
        $backdropEl = $('<div class="dialog-backdrop"></div>');
        app.$el.append($backdropEl);
      }
    }
    function buttonOnClick(e) {
      const buttonEl = this;
      const index = $(buttonEl).index();
      const button = buttons[index];
      if (button.onClick) button.onClick(dialog2, e);
      if (dialog2.params.onClick) dialog2.params.onClick(dialog2, index);
      if (button.close !== false) dialog2.close();
    }
    let addKeyboardHander;
    function onKeyDown(e) {
      const keyCode = e.keyCode;
      buttons.forEach((button, index) => {
        if (button.keyCodes && button.keyCodes.indexOf(keyCode) >= 0) {
          if (document.activeElement) document.activeElement.blur();
          if (button.onClick) button.onClick(dialog2, e);
          if (dialog2.params.onClick) dialog2.params.onClick(dialog2, index);
          if (button.close !== false) dialog2.close();
        }
      });
    }
    if (buttons && buttons.length > 0) {
      dialog2.on("open", () => {
        $el.find(".dialog-button").each((buttonEl, index) => {
          const button = buttons[index];
          if (button.keyCodes) addKeyboardHander = true;
          $(buttonEl).on("click", buttonOnClick);
        });
        if (addKeyboardHander && !device.ios && !device.android && !device.cordova && !device.capacitor) {
          $(document).on("keydown", onKeyDown);
        }
      });
      dialog2.on("close", () => {
        $el.find(".dialog-button").each((buttonEl) => {
          $(buttonEl).off("click", buttonOnClick);
        });
        if (addKeyboardHander && !device.ios && !device.android && !device.cordova && !device.capacitor) {
          $(document).off("keydown", onKeyDown);
        }
        addKeyboardHander = false;
      });
    }
    extend(dialog2, {
      app,
      $el,
      el: $el[0],
      $backdropEl,
      backdropEl: $backdropEl && $backdropEl[0],
      type: "dialog",
      setProgress(progress, duration) {
        app.progressbar.set($el.find(".progressbar"), progress, duration);
        return dialog2;
      },
      setText(newText) {
        let $textEl = $el.find(".dialog-text");
        if ($textEl.length === 0) {
          $textEl = $('<div class="dialog-text"></div>');
          if (typeof title !== "undefined") {
            $textEl.insertAfter($el.find(".dialog-title"));
          } else {
            $el.find(".dialog-inner").prepend($textEl);
          }
        }
        $textEl.html(newText);
        dialog2.params.text = newText;
        return dialog2;
      },
      setTitle(newTitle) {
        let $titleEl = $el.find(".dialog-title");
        if ($titleEl.length === 0) {
          $titleEl = $('<div class="dialog-title"></div>');
          $el.find(".dialog-inner").prepend($titleEl);
        }
        $titleEl.html(newTitle);
        dialog2.params.title = newTitle;
        return dialog2;
      }
    });
    function handleClick(e) {
      const target = e.target;
      const $target = $(target);
      if ($target.closest(dialog2.el).length === 0) {
        if (dialog2.params.closeByBackdropClick && dialog2.backdropEl && dialog2.backdropEl === target) {
          dialog2.close();
        }
      }
    }
    dialog2.on("opened", () => {
      if (dialog2.params.closeByBackdropClick) {
        app.on("click", handleClick);
      }
    });
    dialog2.on("close", () => {
      if (dialog2.params.closeByBackdropClick) {
        app.off("click", handleClick);
      }
    });
    $el[0].f7Modal = dialog2;
    if (dialog2.params.destroyOnClose) {
      dialog2.once("closed", () => {
        setTimeout(() => {
          dialog2.destroy();
        }, 0);
      });
    }
    return dialog2;
  }
}
const dialog = {
  name: "dialog",
  params: {
    dialog: {
      title: void 0,
      buttonOk: "OK",
      buttonCancel: "Cancel",
      usernamePlaceholder: "Username",
      passwordPlaceholder: "Password",
      preloaderTitle: "Loading... ",
      progressTitle: "Loading... ",
      backdrop: true,
      closeByBackdropClick: false,
      destroyPredefinedDialogs: true,
      keyboardActions: true,
      autoFocus: true
    }
  },
  static: {
    Dialog
  },
  create() {
    const app = this;
    function defaultDialogTitle() {
      return app.params.dialog.title || app.name;
    }
    const destroyOnClose = app.params.dialog.destroyPredefinedDialogs;
    const keyboardActions = app.params.dialog.keyboardActions;
    const autoFocus = app.params.dialog.autoFocus;
    const autoFocusHandler = autoFocus ? {
      on: {
        opened(dialog2) {
          dialog2.$el.find("input").eq(0).focus();
        }
      }
    } : {};
    const isIosTheme = app.theme === "ios";
    app.dialog = extend(ModalMethods({
      app,
      constructor: Dialog,
      defaultSelector: ".dialog.modal-in"
    }), {
      // Shortcuts
      alert() {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
        let [text, title, callbackOk] = args;
        if (args.length === 2 && typeof args[1] === "function") {
          [text, callbackOk, title] = args;
        }
        return new Dialog(app, {
          title: typeof title === "undefined" ? defaultDialogTitle() : title,
          text,
          buttons: [{
            text: app.params.dialog.buttonOk,
            strong: isIosTheme,
            onClick: callbackOk,
            keyCodes: keyboardActions ? [13, 27] : null
          }],
          destroyOnClose
        }).open();
      },
      prompt() {
        for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }
        let [text, title, callbackOk, callbackCancel, defaultValue] = args;
        if (typeof args[1] === "function") {
          [text, callbackOk, callbackCancel, defaultValue, title] = args;
        }
        defaultValue = typeof defaultValue === "undefined" || defaultValue === null ? "" : defaultValue;
        return new Dialog(app, {
          title: typeof title === "undefined" ? defaultDialogTitle() : title,
          text,
          content: `<div class="dialog-input-field input"><input type="text" class="dialog-input" value="${defaultValue}"></div>`,
          buttons: [{
            text: app.params.dialog.buttonCancel,
            keyCodes: keyboardActions ? [27] : null,
            color: null
          }, {
            text: app.params.dialog.buttonOk,
            strong: isIosTheme,
            keyCodes: keyboardActions ? [13] : null
          }],
          onClick(dialog2, index) {
            const inputValue = dialog2.$el.find(".dialog-input").val();
            if (index === 0 && callbackCancel) callbackCancel(inputValue);
            if (index === 1 && callbackOk) callbackOk(inputValue);
          },
          destroyOnClose,
          ...autoFocusHandler
        }).open();
      },
      confirm() {
        for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
          args[_key3] = arguments[_key3];
        }
        let [text, title, callbackOk, callbackCancel] = args;
        if (typeof args[1] === "function") {
          [text, callbackOk, callbackCancel, title] = args;
        }
        return new Dialog(app, {
          title: typeof title === "undefined" ? defaultDialogTitle() : title,
          text,
          buttons: [{
            text: app.params.dialog.buttonCancel,
            onClick: callbackCancel,
            keyCodes: keyboardActions ? [27] : null,
            color: null
          }, {
            text: app.params.dialog.buttonOk,
            strong: isIosTheme,
            onClick: callbackOk,
            keyCodes: keyboardActions ? [13] : null
          }],
          destroyOnClose
        }).open();
      },
      login() {
        for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
          args[_key4] = arguments[_key4];
        }
        let [text, title, callbackOk, callbackCancel] = args;
        if (typeof args[1] === "function") {
          [text, callbackOk, callbackCancel, title] = args;
        }
        return new Dialog(app, {
          title: typeof title === "undefined" ? defaultDialogTitle() : title,
          text,
          // prettier-ignore
          content: `
              <div class="dialog-input-field dialog-input-double input">
                <input type="text" name="dialog-username" placeholder="${app.params.dialog.usernamePlaceholder}" class="dialog-input">
              </div>
              <div class="dialog-input-field dialog-input-double input">
                <input type="password" name="dialog-password" placeholder="${app.params.dialog.passwordPlaceholder}" class="dialog-input">
              </div>`,
          buttons: [{
            text: app.params.dialog.buttonCancel,
            keyCodes: keyboardActions ? [27] : null,
            color: null
          }, {
            text: app.params.dialog.buttonOk,
            strong: isIosTheme,
            keyCodes: keyboardActions ? [13] : null
          }],
          onClick(dialog2, index) {
            const username = dialog2.$el.find('[name="dialog-username"]').val();
            const password = dialog2.$el.find('[name="dialog-password"]').val();
            if (index === 0 && callbackCancel) callbackCancel(username, password);
            if (index === 1 && callbackOk) callbackOk(username, password);
          },
          destroyOnClose,
          ...autoFocusHandler
        }).open();
      },
      password() {
        for (var _len5 = arguments.length, args = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
          args[_key5] = arguments[_key5];
        }
        let [text, title, callbackOk, callbackCancel] = args;
        if (typeof args[1] === "function") {
          [text, callbackOk, callbackCancel, title] = args;
        }
        return new Dialog(app, {
          title: typeof title === "undefined" ? defaultDialogTitle() : title,
          text,
          // prettier-ignore
          content: `
              <div class="dialog-input-field input">
                <input type="password" name="dialog-password" placeholder="${app.params.dialog.passwordPlaceholder}" class="dialog-input">
              </div>`,
          buttons: [{
            text: app.params.dialog.buttonCancel,
            keyCodes: keyboardActions ? [27] : null,
            color: null
          }, {
            text: app.params.dialog.buttonOk,
            strong: isIosTheme,
            keyCodes: keyboardActions ? [13] : null
          }],
          onClick(dialog2, index) {
            const password = dialog2.$el.find('[name="dialog-password"]').val();
            if (index === 0 && callbackCancel) callbackCancel(password);
            if (index === 1 && callbackOk) callbackOk(password);
          },
          destroyOnClose,
          ...autoFocusHandler
        }).open();
      },
      preloader(title, color) {
        const preloaders = {
          iosPreloaderContent,
          mdPreloaderContent
        };
        const preloaderInner = preloaders[`${app.theme}PreloaderContent`] || "";
        return new Dialog(app, {
          title: typeof title === "undefined" || title === null ? app.params.dialog.preloaderTitle : title,
          // prettier-ignore
          content: `<div class="preloader${color ? ` color-${color}` : ""}">${preloaderInner}</div>`,
          cssClass: "dialog-preloader",
          destroyOnClose
        }).open();
      },
      progress() {
        for (var _len6 = arguments.length, args = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
          args[_key6] = arguments[_key6];
        }
        let [title, progress, color] = args;
        if (args.length === 2) {
          if (typeof args[0] === "number") {
            [progress, color, title] = args;
          } else if (typeof args[0] === "string" && typeof args[1] === "string") {
            [title, color, progress] = args;
          }
        } else if (args.length === 1) {
          if (typeof args[0] === "number") {
            [progress, title, color] = args;
          }
        }
        const infinite = typeof progress === "undefined";
        const dialog2 = new Dialog(app, {
          title: typeof title === "undefined" ? app.params.dialog.progressTitle : title,
          cssClass: "dialog-progress",
          // prettier-ignore
          content: `
              <div class="progressbar${infinite ? "-infinite" : ""}${color ? ` color-${color}` : ""}">
                ${!infinite ? "<span></span>" : ""}
              </div>
            `,
          destroyOnClose
        });
        if (!infinite) dialog2.setProgress(progress);
        return dialog2.open();
      }
    });
  }
};
export {
  dialog as default
};
