const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/admin-login.page-CauKL65s.js","assets/api-uUGDDCgf.js","assets/toast-DllnHs3T.js","assets/page-wJ61H8A2.js","assets/admin-main.page-2ayzS7mL.js","assets/use_flow-v6XFM-bj.js","assets/login.page-6FVI0_5x.js","assets/tabs.page-CeSuLwtt.js","assets/registry.page-B7lX67nG.js","assets/404-vys3s6VW.js"])))=>i.map(i=>d[i]);
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
    promise = Promise.allSettled(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
function isObject$2(obj) {
  return obj !== null && typeof obj === "object" && "constructor" in obj && obj.constructor === Object;
}
function extend$2(target = {}, src = {}) {
  Object.keys(src).forEach((key) => {
    if (typeof target[key] === "undefined")
      target[key] = src[key];
    else if (isObject$2(src[key]) && isObject$2(target[key]) && Object.keys(src[key]).length > 0) {
      extend$2(target[key], src[key]);
    }
  });
}
const ssrDocument = {
  body: {},
  addEventListener() {
  },
  removeEventListener() {
  },
  activeElement: {
    blur() {
    },
    nodeName: ""
  },
  querySelector() {
    return null;
  },
  querySelectorAll() {
    return [];
  },
  getElementById() {
    return null;
  },
  createEvent() {
    return {
      initEvent() {
      }
    };
  },
  createElement() {
    return {
      children: [],
      childNodes: [],
      style: {},
      setAttribute() {
      },
      getElementsByTagName() {
        return [];
      }
    };
  },
  createElementNS() {
    return {};
  },
  importNode() {
    return null;
  },
  location: {
    hash: "",
    host: "",
    hostname: "",
    href: "",
    origin: "",
    pathname: "",
    protocol: "",
    search: ""
  }
};
function getDocument() {
  const doc = typeof document !== "undefined" ? document : {};
  extend$2(doc, ssrDocument);
  return doc;
}
const ssrWindow = {
  document: ssrDocument,
  navigator: {
    userAgent: ""
  },
  location: {
    hash: "",
    host: "",
    hostname: "",
    href: "",
    origin: "",
    pathname: "",
    protocol: "",
    search: ""
  },
  history: {
    replaceState() {
    },
    pushState() {
    },
    go() {
    },
    back() {
    }
  },
  CustomEvent: function CustomEvent() {
    return this;
  },
  addEventListener() {
  },
  removeEventListener() {
  },
  getComputedStyle() {
    return {
      getPropertyValue() {
        return "";
      }
    };
  },
  Image() {
  },
  Date() {
  },
  screen: {},
  setTimeout() {
  },
  clearTimeout() {
  },
  matchMedia() {
    return {};
  },
  requestAnimationFrame(callback) {
    if (typeof setTimeout === "undefined") {
      callback();
      return null;
    }
    return setTimeout(callback, 0);
  },
  cancelAnimationFrame(id2) {
    if (typeof setTimeout === "undefined") {
      return;
    }
    clearTimeout(id2);
  }
};
function getWindow() {
  const win = typeof window !== "undefined" ? window : {};
  extend$2(win, ssrWindow);
  return win;
}
function makeReactive(obj) {
  const proto = obj.__proto__;
  Object.defineProperty(obj, "__proto__", {
    get() {
      return proto;
    },
    set(value2) {
      proto.__proto__ = value2;
    }
  });
}
class Dom7 extends Array {
  constructor(items) {
    if (typeof items === "number") {
      super(items);
    } else {
      super(...items || []);
      makeReactive(this);
    }
  }
}
function arrayFlat(arr = []) {
  const res = [];
  arr.forEach((el) => {
    if (Array.isArray(el)) {
      res.push(...arrayFlat(el));
    } else {
      res.push(el);
    }
  });
  return res;
}
function arrayFilter(arr, callback) {
  return Array.prototype.filter.call(arr, callback);
}
function arrayUnique(arr) {
  const uniqueArray = [];
  for (let i = 0; i < arr.length; i += 1) {
    if (uniqueArray.indexOf(arr[i]) === -1) uniqueArray.push(arr[i]);
  }
  return uniqueArray;
}
function toCamelCase(string) {
  return string.toLowerCase().replace(/-(.)/g, (match, group) => group.toUpperCase());
}
function qsa(selector, context) {
  if (typeof selector !== "string") {
    return [selector];
  }
  const a = [];
  const res = context.querySelectorAll(selector);
  for (let i = 0; i < res.length; i += 1) {
    a.push(res[i]);
  }
  return a;
}
function $$1(selector, context) {
  const window2 = getWindow();
  const document2 = getDocument();
  let arr = [];
  if (!context && selector instanceof Dom7) {
    return selector;
  }
  if (!selector) {
    return new Dom7(arr);
  }
  if (typeof selector === "string") {
    const html2 = selector.trim();
    if (html2.indexOf("<") >= 0 && html2.indexOf(">") >= 0) {
      let toCreate = "div";
      if (html2.indexOf("<li") === 0) toCreate = "ul";
      if (html2.indexOf("<tr") === 0) toCreate = "tbody";
      if (html2.indexOf("<td") === 0 || html2.indexOf("<th") === 0) toCreate = "tr";
      if (html2.indexOf("<tbody") === 0) toCreate = "table";
      if (html2.indexOf("<option") === 0) toCreate = "select";
      const tempParent = document2.createElement(toCreate);
      tempParent.innerHTML = html2;
      for (let i = 0; i < tempParent.childNodes.length; i += 1) {
        arr.push(tempParent.childNodes[i]);
      }
    } else {
      arr = qsa(selector.trim(), context || document2);
    }
  } else if (selector.nodeType || selector === window2 || selector === document2) {
    arr.push(selector);
  } else if (Array.isArray(selector)) {
    if (selector instanceof Dom7) return selector;
    arr = selector;
  }
  return new Dom7(arrayUnique(arr));
}
$$1.fn = Dom7.prototype;
function addClass(...classes) {
  const classNames2 = arrayFlat(classes.map((c) => c.split(" ")));
  this.forEach((el) => {
    el.classList.add(...classNames2);
  });
  return this;
}
function removeClass(...classes) {
  const classNames2 = arrayFlat(classes.map((c) => c.split(" ")));
  this.forEach((el) => {
    el.classList.remove(...classNames2);
  });
  return this;
}
function toggleClass(...classes) {
  const classNames2 = arrayFlat(classes.map((c) => c.split(" ")));
  this.forEach((el) => {
    classNames2.forEach((className) => {
      el.classList.toggle(className);
    });
  });
}
function hasClass(...classes) {
  const classNames2 = arrayFlat(classes.map((c) => c.split(" ")));
  return arrayFilter(this, (el) => {
    return classNames2.filter((className) => el.classList.contains(className)).length > 0;
  }).length > 0;
}
function attr(attrs, value2) {
  if (arguments.length === 1 && typeof attrs === "string") {
    if (this[0]) return this[0].getAttribute(attrs);
    return void 0;
  }
  for (let i = 0; i < this.length; i += 1) {
    if (arguments.length === 2) {
      this[i].setAttribute(attrs, value2);
    } else {
      for (const attrName in attrs) {
        this[i][attrName] = attrs[attrName];
        this[i].setAttribute(attrName, attrs[attrName]);
      }
    }
  }
  return this;
}
function removeAttr(attr2) {
  for (let i = 0; i < this.length; i += 1) {
    this[i].removeAttribute(attr2);
  }
  return this;
}
function prop(props, value2) {
  if (arguments.length === 1 && typeof props === "string") {
    if (this[0]) return this[0][props];
  } else {
    for (let i = 0; i < this.length; i += 1) {
      if (arguments.length === 2) {
        this[i][props] = value2;
      } else {
        for (const propName in props) {
          this[i][propName] = props[propName];
        }
      }
    }
    return this;
  }
  return this;
}
function data(key, value2) {
  let el;
  if (typeof value2 === "undefined") {
    el = this[0];
    if (!el) return void 0;
    if (el.dom7ElementDataStorage && key in el.dom7ElementDataStorage) {
      return el.dom7ElementDataStorage[key];
    }
    const dataKey = el.getAttribute(`data-${key}`);
    if (dataKey) {
      return dataKey;
    }
    return void 0;
  }
  for (let i = 0; i < this.length; i += 1) {
    el = this[i];
    if (!el.dom7ElementDataStorage) el.dom7ElementDataStorage = {};
    el.dom7ElementDataStorage[key] = value2;
  }
  return this;
}
function removeData(key) {
  for (let i = 0; i < this.length; i += 1) {
    const el = this[i];
    if (el.dom7ElementDataStorage && el.dom7ElementDataStorage[key]) {
      el.dom7ElementDataStorage[key] = null;
      delete el.dom7ElementDataStorage[key];
    }
  }
}
function dataset() {
  const el = this[0];
  if (!el) return void 0;
  const dataset2 = {};
  if (el.dataset) {
    for (const dataKey in el.dataset) {
      dataset2[dataKey] = el.dataset[dataKey];
    }
  } else {
    for (let i = 0; i < el.attributes.length; i += 1) {
      const attr2 = el.attributes[i];
      if (attr2.name.indexOf("data-") >= 0) {
        dataset2[toCamelCase(attr2.name.split("data-")[1])] = attr2.value;
      }
    }
  }
  for (const key in dataset2) {
    if (dataset2[key] === "false") dataset2[key] = false;
    else if (dataset2[key] === "true") dataset2[key] = true;
    else if (parseFloat(dataset2[key]) === dataset2[key] * 1) dataset2[key] *= 1;
  }
  return dataset2;
}
function val(value2) {
  if (typeof value2 === "undefined") {
    const el = this[0];
    if (!el) return void 0;
    if (el.multiple && el.nodeName.toLowerCase() === "select") {
      const values = [];
      for (let i = 0; i < el.selectedOptions.length; i += 1) {
        values.push(el.selectedOptions[i].value);
      }
      return values;
    }
    return el.value;
  }
  for (let i = 0; i < this.length; i += 1) {
    const el = this[i];
    if (Array.isArray(value2) && el.multiple && el.nodeName.toLowerCase() === "select") {
      for (let j = 0; j < el.options.length; j += 1) {
        el.options[j].selected = value2.indexOf(el.options[j].value) >= 0;
      }
    } else {
      el.value = value2;
    }
  }
  return this;
}
function value(value2) {
  return this.val(value2);
}
function transform(transform2) {
  for (let i = 0; i < this.length; i += 1) {
    this[i].style.transform = transform2;
  }
  return this;
}
function transition(duration) {
  for (let i = 0; i < this.length; i += 1) {
    this[i].style.transitionDuration = typeof duration !== "string" ? `${duration}ms` : duration;
  }
  return this;
}
function on(...args) {
  let [eventType, targetSelector, listener, capture] = args;
  if (typeof args[1] === "function") {
    [eventType, listener, capture] = args;
    targetSelector = void 0;
  }
  if (!capture) capture = false;
  function handleLiveEvent(e) {
    const target = e.target;
    if (!target) return;
    const eventData = e.target.dom7EventData || [];
    if (eventData.indexOf(e) < 0) {
      eventData.unshift(e);
    }
    if ($$1(target).is(targetSelector)) listener.apply(target, eventData);
    else {
      const parents2 = $$1(target).parents();
      for (let k = 0; k < parents2.length; k += 1) {
        if ($$1(parents2[k]).is(targetSelector)) listener.apply(parents2[k], eventData);
      }
    }
  }
  function handleEvent(e) {
    const eventData = e && e.target ? e.target.dom7EventData || [] : [];
    if (eventData.indexOf(e) < 0) {
      eventData.unshift(e);
    }
    listener.apply(this, eventData);
  }
  const events = eventType.split(" ");
  let j;
  for (let i = 0; i < this.length; i += 1) {
    const el = this[i];
    if (!targetSelector) {
      for (j = 0; j < events.length; j += 1) {
        const event = events[j];
        if (!el.dom7Listeners) el.dom7Listeners = {};
        if (!el.dom7Listeners[event]) el.dom7Listeners[event] = [];
        el.dom7Listeners[event].push({
          listener,
          proxyListener: handleEvent
        });
        el.addEventListener(event, handleEvent, capture);
      }
    } else {
      for (j = 0; j < events.length; j += 1) {
        const event = events[j];
        if (!el.dom7LiveListeners) el.dom7LiveListeners = {};
        if (!el.dom7LiveListeners[event]) el.dom7LiveListeners[event] = [];
        el.dom7LiveListeners[event].push({
          listener,
          proxyListener: handleLiveEvent
        });
        el.addEventListener(event, handleLiveEvent, capture);
      }
    }
  }
  return this;
}
function off(...args) {
  let [eventType, targetSelector, listener, capture] = args;
  if (typeof args[1] === "function") {
    [eventType, listener, capture] = args;
    targetSelector = void 0;
  }
  if (!capture) capture = false;
  const events = eventType.split(" ");
  for (let i = 0; i < events.length; i += 1) {
    const event = events[i];
    for (let j = 0; j < this.length; j += 1) {
      const el = this[j];
      let handlers;
      if (!targetSelector && el.dom7Listeners) {
        handlers = el.dom7Listeners[event];
      } else if (targetSelector && el.dom7LiveListeners) {
        handlers = el.dom7LiveListeners[event];
      }
      if (handlers && handlers.length) {
        for (let k = handlers.length - 1; k >= 0; k -= 1) {
          const handler = handlers[k];
          if (listener && handler.listener === listener) {
            el.removeEventListener(event, handler.proxyListener, capture);
            handlers.splice(k, 1);
          } else if (listener && handler.listener && handler.listener.dom7proxy && handler.listener.dom7proxy === listener) {
            el.removeEventListener(event, handler.proxyListener, capture);
            handlers.splice(k, 1);
          } else if (!listener) {
            el.removeEventListener(event, handler.proxyListener, capture);
            handlers.splice(k, 1);
          }
        }
      }
    }
  }
  return this;
}
function once(...args) {
  const dom = this;
  let [eventName, targetSelector, listener, capture] = args;
  if (typeof args[1] === "function") {
    [eventName, listener, capture] = args;
    targetSelector = void 0;
  }
  function onceHandler(...eventArgs) {
    listener.apply(this, eventArgs);
    dom.off(eventName, targetSelector, onceHandler, capture);
    if (onceHandler.dom7proxy) {
      delete onceHandler.dom7proxy;
    }
  }
  onceHandler.dom7proxy = listener;
  return dom.on(eventName, targetSelector, onceHandler, capture);
}
function trigger(...args) {
  const window2 = getWindow();
  const events = args[0].split(" ");
  const eventData = args[1];
  for (let i = 0; i < events.length; i += 1) {
    const event = events[i];
    for (let j = 0; j < this.length; j += 1) {
      const el = this[j];
      if (window2.CustomEvent) {
        const evt = new window2.CustomEvent(event, {
          detail: eventData,
          bubbles: true,
          cancelable: true
        });
        el.dom7EventData = args.filter((data2, dataIndex) => dataIndex > 0);
        el.dispatchEvent(evt);
        el.dom7EventData = [];
        delete el.dom7EventData;
      }
    }
  }
  return this;
}
function transitionStart(callback) {
  const dom = this;
  function fireCallBack(e) {
    if (e.target !== this) return;
    callback.call(this, e);
    dom.off("transitionstart", fireCallBack);
  }
  if (callback) {
    dom.on("transitionstart", fireCallBack);
  }
  return this;
}
function transitionEnd(callback) {
  const dom = this;
  function fireCallBack(e) {
    if (e.target !== this) return;
    callback.call(this, e);
    dom.off("transitionend", fireCallBack);
  }
  if (callback) {
    dom.on("transitionend", fireCallBack);
  }
  return this;
}
function animationEnd(callback) {
  const dom = this;
  function fireCallBack(e) {
    if (e.target !== this) return;
    callback.call(this, e);
    dom.off("animationend", fireCallBack);
  }
  if (callback) {
    dom.on("animationend", fireCallBack);
  }
  return this;
}
function width() {
  const window2 = getWindow();
  if (this[0] === window2) {
    return window2.innerWidth;
  }
  if (this.length > 0) {
    return parseFloat(this.css("width"));
  }
  return null;
}
function outerWidth(includeMargins) {
  if (this.length > 0) {
    if (includeMargins) {
      const styles2 = this.styles();
      return this[0].offsetWidth + parseFloat(styles2.getPropertyValue("margin-right")) + parseFloat(styles2.getPropertyValue("margin-left"));
    }
    return this[0].offsetWidth;
  }
  return null;
}
function height() {
  const window2 = getWindow();
  if (this[0] === window2) {
    return window2.innerHeight;
  }
  if (this.length > 0) {
    return parseFloat(this.css("height"));
  }
  return null;
}
function outerHeight(includeMargins) {
  if (this.length > 0) {
    if (includeMargins) {
      const styles2 = this.styles();
      return this[0].offsetHeight + parseFloat(styles2.getPropertyValue("margin-top")) + parseFloat(styles2.getPropertyValue("margin-bottom"));
    }
    return this[0].offsetHeight;
  }
  return null;
}
function offset() {
  if (this.length > 0) {
    const window2 = getWindow();
    const document2 = getDocument();
    const el = this[0];
    const box = el.getBoundingClientRect();
    const body = document2.body;
    const clientTop = el.clientTop || body.clientTop || 0;
    const clientLeft = el.clientLeft || body.clientLeft || 0;
    const scrollTop2 = el === window2 ? window2.scrollY : el.scrollTop;
    const scrollLeft2 = el === window2 ? window2.scrollX : el.scrollLeft;
    return {
      top: box.top + scrollTop2 - clientTop,
      left: box.left + scrollLeft2 - clientLeft
    };
  }
  return null;
}
function hide() {
  for (let i = 0; i < this.length; i += 1) {
    this[i].style.display = "none";
  }
  return this;
}
function show() {
  const window2 = getWindow();
  for (let i = 0; i < this.length; i += 1) {
    const el = this[i];
    if (el.style.display === "none") {
      el.style.display = "";
    }
    if (window2.getComputedStyle(el, null).getPropertyValue("display") === "none") {
      el.style.display = "block";
    }
  }
  return this;
}
function styles() {
  const window2 = getWindow();
  if (this[0]) return window2.getComputedStyle(this[0], null);
  return {};
}
function css$1(props, value2) {
  const window2 = getWindow();
  let i;
  if (arguments.length === 1) {
    if (typeof props === "string") {
      if (this[0]) return window2.getComputedStyle(this[0], null).getPropertyValue(props);
    } else {
      for (i = 0; i < this.length; i += 1) {
        for (const prop2 in props) {
          this[i].style[prop2] = props[prop2];
        }
      }
      return this;
    }
  }
  if (arguments.length === 2 && typeof props === "string") {
    for (i = 0; i < this.length; i += 1) {
      this[i].style[props] = value2;
    }
    return this;
  }
  return this;
}
function each(callback) {
  if (!callback) return this;
  this.forEach((el, index2) => {
    callback.apply(el, [el, index2]);
  });
  return this;
}
function filter(callback) {
  const result = arrayFilter(this, callback);
  return $$1(result);
}
function html(html2) {
  if (typeof html2 === "undefined") {
    return this[0] ? this[0].innerHTML : null;
  }
  for (let i = 0; i < this.length; i += 1) {
    this[i].innerHTML = html2;
  }
  return this;
}
function text$1(text2) {
  if (typeof text2 === "undefined") {
    return this[0] ? this[0].textContent.trim() : null;
  }
  for (let i = 0; i < this.length; i += 1) {
    this[i].textContent = text2;
  }
  return this;
}
function is(selector) {
  const window2 = getWindow();
  const document2 = getDocument();
  const el = this[0];
  let compareWith;
  let i;
  if (!el || typeof selector === "undefined") return false;
  if (typeof selector === "string") {
    if (el.matches) return el.matches(selector);
    if (el.webkitMatchesSelector) return el.webkitMatchesSelector(selector);
    if (el.msMatchesSelector) return el.msMatchesSelector(selector);
    compareWith = $$1(selector);
    for (i = 0; i < compareWith.length; i += 1) {
      if (compareWith[i] === el) return true;
    }
    return false;
  }
  if (selector === document2) {
    return el === document2;
  }
  if (selector === window2) {
    return el === window2;
  }
  if (selector.nodeType || selector instanceof Dom7) {
    compareWith = selector.nodeType ? [selector] : selector;
    for (i = 0; i < compareWith.length; i += 1) {
      if (compareWith[i] === el) return true;
    }
    return false;
  }
  return false;
}
function index() {
  let child = this[0];
  let i;
  if (child) {
    i = 0;
    while ((child = child.previousSibling) !== null) {
      if (child.nodeType === 1) i += 1;
    }
    return i;
  }
  return void 0;
}
function eq(index2) {
  if (typeof index2 === "undefined") return this;
  const length = this.length;
  if (index2 > length - 1) {
    return $$1([]);
  }
  if (index2 < 0) {
    const returnIndex = length + index2;
    if (returnIndex < 0) return $$1([]);
    return $$1([this[returnIndex]]);
  }
  return $$1([this[index2]]);
}
function append(...els) {
  let newChild;
  const document2 = getDocument();
  for (let k = 0; k < els.length; k += 1) {
    newChild = els[k];
    for (let i = 0; i < this.length; i += 1) {
      if (typeof newChild === "string") {
        const tempDiv = document2.createElement("div");
        tempDiv.innerHTML = newChild;
        while (tempDiv.firstChild) {
          this[i].appendChild(tempDiv.firstChild);
        }
      } else if (newChild instanceof Dom7) {
        for (let j = 0; j < newChild.length; j += 1) {
          this[i].appendChild(newChild[j]);
        }
      } else {
        this[i].appendChild(newChild);
      }
    }
  }
  return this;
}
function appendTo(parent2) {
  $$1(parent2).append(this);
  return this;
}
function prepend(newChild) {
  const document2 = getDocument();
  let i;
  let j;
  for (i = 0; i < this.length; i += 1) {
    if (typeof newChild === "string") {
      const tempDiv = document2.createElement("div");
      tempDiv.innerHTML = newChild;
      for (j = tempDiv.childNodes.length - 1; j >= 0; j -= 1) {
        this[i].insertBefore(tempDiv.childNodes[j], this[i].childNodes[0]);
      }
    } else if (newChild instanceof Dom7) {
      for (j = 0; j < newChild.length; j += 1) {
        this[i].insertBefore(newChild[j], this[i].childNodes[0]);
      }
    } else {
      this[i].insertBefore(newChild, this[i].childNodes[0]);
    }
  }
  return this;
}
function prependTo(parent2) {
  $$1(parent2).prepend(this);
  return this;
}
function insertBefore(selector) {
  const before = $$1(selector);
  for (let i = 0; i < this.length; i += 1) {
    if (before.length === 1) {
      before[0].parentNode.insertBefore(this[i], before[0]);
    } else if (before.length > 1) {
      for (let j = 0; j < before.length; j += 1) {
        before[j].parentNode.insertBefore(this[i].cloneNode(true), before[j]);
      }
    }
  }
}
function insertAfter(selector) {
  const after = $$1(selector);
  for (let i = 0; i < this.length; i += 1) {
    if (after.length === 1) {
      after[0].parentNode.insertBefore(this[i], after[0].nextSibling);
    } else if (after.length > 1) {
      for (let j = 0; j < after.length; j += 1) {
        after[j].parentNode.insertBefore(this[i].cloneNode(true), after[j].nextSibling);
      }
    }
  }
}
function next(selector) {
  if (this.length > 0) {
    if (selector) {
      if (this[0].nextElementSibling && $$1(this[0].nextElementSibling).is(selector)) {
        return $$1([this[0].nextElementSibling]);
      }
      return $$1([]);
    }
    if (this[0].nextElementSibling) return $$1([this[0].nextElementSibling]);
    return $$1([]);
  }
  return $$1([]);
}
function nextAll(selector) {
  const nextEls = [];
  let el = this[0];
  if (!el) return $$1([]);
  while (el.nextElementSibling) {
    const next2 = el.nextElementSibling;
    if (selector) {
      if ($$1(next2).is(selector)) nextEls.push(next2);
    } else nextEls.push(next2);
    el = next2;
  }
  return $$1(nextEls);
}
function prev(selector) {
  if (this.length > 0) {
    const el = this[0];
    if (selector) {
      if (el.previousElementSibling && $$1(el.previousElementSibling).is(selector)) {
        return $$1([el.previousElementSibling]);
      }
      return $$1([]);
    }
    if (el.previousElementSibling) return $$1([el.previousElementSibling]);
    return $$1([]);
  }
  return $$1([]);
}
function prevAll(selector) {
  const prevEls = [];
  let el = this[0];
  if (!el) return $$1([]);
  while (el.previousElementSibling) {
    const prev2 = el.previousElementSibling;
    if (selector) {
      if ($$1(prev2).is(selector)) prevEls.push(prev2);
    } else prevEls.push(prev2);
    el = prev2;
  }
  return $$1(prevEls);
}
function siblings(selector) {
  return this.nextAll(selector).add(this.prevAll(selector));
}
function parent(selector) {
  const parents2 = [];
  for (let i = 0; i < this.length; i += 1) {
    if (this[i].parentNode !== null) {
      if (selector) {
        if ($$1(this[i].parentNode).is(selector)) parents2.push(this[i].parentNode);
      } else {
        parents2.push(this[i].parentNode);
      }
    }
  }
  return $$1(parents2);
}
function parents(selector) {
  const parents2 = [];
  for (let i = 0; i < this.length; i += 1) {
    let parent2 = this[i].parentNode;
    while (parent2) {
      if (selector) {
        if ($$1(parent2).is(selector)) parents2.push(parent2);
      } else {
        parents2.push(parent2);
      }
      parent2 = parent2.parentNode;
    }
  }
  return $$1(parents2);
}
function closest(selector) {
  let closest2 = this;
  if (typeof selector === "undefined") {
    return $$1([]);
  }
  if (!closest2.is(selector)) {
    closest2 = closest2.parents(selector).eq(0);
  }
  return closest2;
}
function find(selector) {
  const foundElements = [];
  for (let i = 0; i < this.length; i += 1) {
    const found = this[i].querySelectorAll(selector);
    for (let j = 0; j < found.length; j += 1) {
      foundElements.push(found[j]);
    }
  }
  return $$1(foundElements);
}
function children(selector) {
  const children2 = [];
  for (let i = 0; i < this.length; i += 1) {
    const childNodes = this[i].children;
    for (let j = 0; j < childNodes.length; j += 1) {
      if (!selector || $$1(childNodes[j]).is(selector)) {
        children2.push(childNodes[j]);
      }
    }
  }
  return $$1(children2);
}
function remove() {
  for (let i = 0; i < this.length; i += 1) {
    if (this[i].parentNode) this[i].parentNode.removeChild(this[i]);
  }
  return this;
}
function detach() {
  return this.remove();
}
function add(...els) {
  const dom = this;
  let i;
  let j;
  for (i = 0; i < els.length; i += 1) {
    const toAdd = $$1(els[i]);
    for (j = 0; j < toAdd.length; j += 1) {
      dom.push(toAdd[j]);
    }
  }
  return dom;
}
function empty() {
  for (let i = 0; i < this.length; i += 1) {
    const el = this[i];
    if (el.nodeType === 1) {
      for (let j = 0; j < el.childNodes.length; j += 1) {
        if (el.childNodes[j].parentNode) {
          el.childNodes[j].parentNode.removeChild(el.childNodes[j]);
        }
      }
      el.textContent = "";
    }
  }
  return this;
}
function scrollTo(...args) {
  const window2 = getWindow();
  let [left, top, duration, easing, callback] = args;
  if (args.length === 4 && typeof easing === "function") {
    callback = easing;
    [left, top, duration, callback, easing] = args;
  }
  if (typeof easing === "undefined") easing = "swing";
  return this.each(function animate2() {
    const el = this;
    let currentTop;
    let currentLeft;
    let maxTop;
    let maxLeft;
    let newTop;
    let newLeft;
    let scrollTop2;
    let scrollLeft2;
    let animateTop = top > 0 || top === 0;
    let animateLeft = left > 0 || left === 0;
    if (typeof easing === "undefined") {
      easing = "swing";
    }
    if (animateTop) {
      currentTop = el.scrollTop;
      if (!duration) {
        el.scrollTop = top;
      }
    }
    if (animateLeft) {
      currentLeft = el.scrollLeft;
      if (!duration) {
        el.scrollLeft = left;
      }
    }
    if (!duration) return;
    if (animateTop) {
      maxTop = el.scrollHeight - el.offsetHeight;
      newTop = Math.max(Math.min(top, maxTop), 0);
    }
    if (animateLeft) {
      maxLeft = el.scrollWidth - el.offsetWidth;
      newLeft = Math.max(Math.min(left, maxLeft), 0);
    }
    let startTime = null;
    if (animateTop && newTop === currentTop) animateTop = false;
    if (animateLeft && newLeft === currentLeft) animateLeft = false;
    function render(time = (/* @__PURE__ */ new Date()).getTime()) {
      if (startTime === null) {
        startTime = time;
      }
      const progress = Math.max(Math.min((time - startTime) / duration, 1), 0);
      const easeProgress = easing === "linear" ? progress : 0.5 - Math.cos(progress * Math.PI) / 2;
      let done;
      if (animateTop) scrollTop2 = currentTop + easeProgress * (newTop - currentTop);
      if (animateLeft) scrollLeft2 = currentLeft + easeProgress * (newLeft - currentLeft);
      if (animateTop && newTop > currentTop && scrollTop2 >= newTop) {
        el.scrollTop = newTop;
        done = true;
      }
      if (animateTop && newTop < currentTop && scrollTop2 <= newTop) {
        el.scrollTop = newTop;
        done = true;
      }
      if (animateLeft && newLeft > currentLeft && scrollLeft2 >= newLeft) {
        el.scrollLeft = newLeft;
        done = true;
      }
      if (animateLeft && newLeft < currentLeft && scrollLeft2 <= newLeft) {
        el.scrollLeft = newLeft;
        done = true;
      }
      if (done) {
        if (callback) callback();
        return;
      }
      if (animateTop) el.scrollTop = scrollTop2;
      if (animateLeft) el.scrollLeft = scrollLeft2;
      window2.requestAnimationFrame(render);
    }
    window2.requestAnimationFrame(render);
  });
}
function scrollTop(...args) {
  let [top, duration, easing, callback] = args;
  if (args.length === 3 && typeof easing === "function") {
    [top, duration, callback, easing] = args;
  }
  const dom = this;
  if (typeof top === "undefined") {
    if (dom.length > 0) return dom[0].scrollTop;
    return null;
  }
  return dom.scrollTo(void 0, top, duration, easing, callback);
}
function scrollLeft(...args) {
  let [left, duration, easing, callback] = args;
  if (args.length === 3 && typeof easing === "function") {
    [left, duration, callback, easing] = args;
  }
  const dom = this;
  if (typeof left === "undefined") {
    if (dom.length > 0) return dom[0].scrollLeft;
    return null;
  }
  return dom.scrollTo(left, void 0, duration, easing, callback);
}
function animate(initialProps, initialParams) {
  const window2 = getWindow();
  const els = this;
  const a = {
    props: Object.assign({}, initialProps),
    params: Object.assign({
      duration: 300,
      easing: "swing"
      // or 'linear'
      /* Callbacks
      begin(elements)
      complete(elements)
      progress(elements, complete, remaining, start, tweenValue)
      */
    }, initialParams),
    elements: els,
    animating: false,
    que: [],
    easingProgress(easing, progress) {
      if (easing === "swing") {
        return 0.5 - Math.cos(progress * Math.PI) / 2;
      }
      if (typeof easing === "function") {
        return easing(progress);
      }
      return progress;
    },
    stop() {
      if (a.frameId) {
        window2.cancelAnimationFrame(a.frameId);
      }
      a.animating = false;
      a.elements.each((el) => {
        const element = el;
        delete element.dom7AnimateInstance;
      });
      a.que = [];
    },
    done(complete) {
      a.animating = false;
      a.elements.each((el) => {
        const element = el;
        delete element.dom7AnimateInstance;
      });
      if (complete) complete(els);
      if (a.que.length > 0) {
        const que = a.que.shift();
        a.animate(que[0], que[1]);
      }
    },
    animate(props, params) {
      if (a.animating) {
        a.que.push([props, params]);
        return a;
      }
      const elements = [];
      a.elements.each((el, index2) => {
        let initialFullValue;
        let initialValue;
        let unit;
        let finalValue;
        let finalFullValue;
        if (!el.dom7AnimateInstance) a.elements[index2].dom7AnimateInstance = a;
        elements[index2] = {
          container: el
        };
        Object.keys(props).forEach((prop2) => {
          initialFullValue = window2.getComputedStyle(el, null).getPropertyValue(prop2).replace(",", ".");
          initialValue = parseFloat(initialFullValue);
          unit = initialFullValue.replace(initialValue, "");
          finalValue = parseFloat(props[prop2]);
          finalFullValue = props[prop2] + unit;
          elements[index2][prop2] = {
            initialFullValue,
            initialValue,
            unit,
            finalValue,
            finalFullValue,
            currentValue: initialValue
          };
        });
      });
      let startTime = null;
      let time;
      let elementsDone = 0;
      let propsDone = 0;
      let done;
      let began = false;
      a.animating = true;
      function render() {
        time = (/* @__PURE__ */ new Date()).getTime();
        let progress;
        let easeProgress;
        if (!began) {
          began = true;
          if (params.begin) params.begin(els);
        }
        if (startTime === null) {
          startTime = time;
        }
        if (params.progress) {
          params.progress(els, Math.max(Math.min((time - startTime) / params.duration, 1), 0), startTime + params.duration - time < 0 ? 0 : startTime + params.duration - time, startTime);
        }
        elements.forEach((element) => {
          const el = element;
          if (done || el.done) return;
          Object.keys(props).forEach((prop2) => {
            if (done || el.done) return;
            progress = Math.max(Math.min((time - startTime) / params.duration, 1), 0);
            easeProgress = a.easingProgress(params.easing, progress);
            const {
              initialValue,
              finalValue,
              unit
            } = el[prop2];
            el[prop2].currentValue = initialValue + easeProgress * (finalValue - initialValue);
            const currentValue = el[prop2].currentValue;
            if (finalValue > initialValue && currentValue >= finalValue || finalValue < initialValue && currentValue <= finalValue) {
              el.container.style[prop2] = finalValue + unit;
              propsDone += 1;
              if (propsDone === Object.keys(props).length) {
                el.done = true;
                elementsDone += 1;
              }
              if (elementsDone === elements.length) {
                done = true;
              }
            }
            if (done) {
              a.done(params.complete);
              return;
            }
            el.container.style[prop2] = currentValue + unit;
          });
        });
        if (done) return;
        a.frameId = window2.requestAnimationFrame(render);
      }
      a.frameId = window2.requestAnimationFrame(render);
      return a;
    }
  };
  if (a.elements.length === 0) {
    return els;
  }
  let animateInstance;
  for (let i = 0; i < a.elements.length; i += 1) {
    if (a.elements[i].dom7AnimateInstance) {
      animateInstance = a.elements[i].dom7AnimateInstance;
    } else a.elements[i].dom7AnimateInstance = a;
  }
  if (!animateInstance) {
    animateInstance = a;
  }
  if (initialProps === "stop") {
    animateInstance.stop();
  } else {
    animateInstance.animate(a.props, a.params);
  }
  return els;
}
function stop() {
  const els = this;
  for (let i = 0; i < els.length; i += 1) {
    if (els[i].dom7AnimateInstance) {
      els[i].dom7AnimateInstance.stop();
    }
  }
}
const noTrigger = "resize scroll".split(" ");
function shortcut(name2) {
  function eventHandler(...args) {
    if (typeof args[0] === "undefined") {
      for (let i = 0; i < this.length; i += 1) {
        if (noTrigger.indexOf(name2) < 0) {
          if (name2 in this[i]) this[i][name2]();
          else {
            $$1(this[i]).trigger(name2);
          }
        }
      }
      return this;
    }
    return this.on(name2, ...args);
  }
  return eventHandler;
}
const click = shortcut("click");
const blur = shortcut("blur");
const focus = shortcut("focus");
const focusin = shortcut("focusin");
const focusout = shortcut("focusout");
const keyup = shortcut("keyup");
const keydown = shortcut("keydown");
const keypress = shortcut("keypress");
const submit = shortcut("submit");
const change = shortcut("change");
const mousedown = shortcut("mousedown");
const mousemove = shortcut("mousemove");
const mouseup = shortcut("mouseup");
const mouseenter = shortcut("mouseenter");
const mouseleave = shortcut("mouseleave");
const mouseout = shortcut("mouseout");
const mouseover = shortcut("mouseover");
const touchstart = shortcut("touchstart");
const touchend = shortcut("touchend");
const touchmove = shortcut("touchmove");
const resize = shortcut("resize");
const scroll = shortcut("scroll");
const methods = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  $: $$1,
  add,
  addClass,
  animate,
  animationEnd,
  append,
  appendTo,
  attr,
  blur,
  change,
  children,
  click,
  closest,
  css: css$1,
  data,
  dataset,
  default: $$1,
  detach,
  each,
  empty,
  eq,
  filter,
  find,
  focus,
  focusin,
  focusout,
  hasClass,
  height,
  hide,
  html,
  index,
  insertAfter,
  insertBefore,
  is,
  keydown,
  keypress,
  keyup,
  mousedown,
  mouseenter,
  mouseleave,
  mousemove,
  mouseout,
  mouseover,
  mouseup,
  next,
  nextAll,
  off,
  offset,
  on,
  once,
  outerHeight,
  outerWidth,
  parent,
  parents,
  prepend,
  prependTo,
  prev,
  prevAll,
  prop,
  remove,
  removeAttr,
  removeClass,
  removeData,
  resize,
  scroll,
  scrollLeft,
  scrollTo,
  scrollTop,
  show,
  siblings,
  stop,
  styles,
  submit,
  text: text$1,
  toggleClass,
  touchend,
  touchmove,
  touchstart,
  transform,
  transition,
  transitionEnd,
  transitionStart,
  trigger,
  val,
  value,
  width
}, Symbol.toStringTag, { value: "Module" }));
Object.keys(methods).forEach((methodName) => {
  if (methodName === "$") return;
  $$1.fn[methodName] = methods[methodName];
});
const $ = $$1;
function signum(num) {
  return num < 0 ? -1 : 0 === num ? 0 : 1;
}
function lerp(start, stop2, amount) {
  return (1 - amount) * start + amount * stop2;
}
function clampInt(min, max, input) {
  return input < min ? min : input > max ? max : input;
}
function clampDouble(min, max, input) {
  return input < min ? min : input > max ? max : input;
}
function sanitizeDegreesDouble(degrees) {
  return (degrees %= 360) < 0 && (degrees += 360), degrees;
}
function rotationDirection(from, to) {
  return sanitizeDegreesDouble(to - from) <= 180 ? 1 : -1;
}
function differenceDegrees(a, b) {
  return 180 - Math.abs(Math.abs(a - b) - 180);
}
function matrixMultiply(row, matrix) {
  return [row[0] * matrix[0][0] + row[1] * matrix[0][1] + row[2] * matrix[0][2], row[0] * matrix[1][0] + row[1] * matrix[1][1] + row[2] * matrix[1][2], row[0] * matrix[2][0] + row[1] * matrix[2][1] + row[2] * matrix[2][2]];
}
const SRGB_TO_XYZ = [[0.41233895, 0.35762064, 0.18051042], [0.2126, 0.7152, 0.0722], [0.01932141, 0.11916382, 0.95034478]], XYZ_TO_SRGB = [[3.2413774792388685, -1.5376652402851851, -0.49885366846268053], [-0.9691452513005321, 1.8758853451067872, 0.04156585616912061], [0.05562093689691305, -0.20395524564742123, 1.0571799111220335]], WHITE_POINT_D65 = [95.047, 100, 108.883];
function argbFromRgb(red2, green2, blue) {
  return (255 << 24 | (255 & red2) << 16 | (255 & green2) << 8 | 255 & blue) >>> 0;
}
function argbFromLinrgb(linrgb) {
  return argbFromRgb(delinearized(linrgb[0]), delinearized(linrgb[1]), delinearized(linrgb[2]));
}
function redFromArgb(argb) {
  return argb >> 16 & 255;
}
function greenFromArgb(argb) {
  return argb >> 8 & 255;
}
function blueFromArgb(argb) {
  return 255 & argb;
}
function argbFromXyz(x, y, z) {
  const matrix = XYZ_TO_SRGB, linearR = matrix[0][0] * x + matrix[0][1] * y + matrix[0][2] * z, linearG = matrix[1][0] * x + matrix[1][1] * y + matrix[1][2] * z, linearB = matrix[2][0] * x + matrix[2][1] * y + matrix[2][2] * z;
  return argbFromRgb(delinearized(linearR), delinearized(linearG), delinearized(linearB));
}
function xyzFromArgb(argb) {
  return matrixMultiply([linearized(redFromArgb(argb)), linearized(greenFromArgb(argb)), linearized(blueFromArgb(argb))], SRGB_TO_XYZ);
}
function argbFromLstar(lstar) {
  const component = delinearized(yFromLstar(lstar));
  return argbFromRgb(component, component, component);
}
function lstarFromArgb(argb) {
  return 116 * labF(xyzFromArgb(argb)[1] / 100) - 16;
}
function yFromLstar(lstar) {
  return 100 * labInvf((lstar + 16) / 116);
}
function lstarFromY(y) {
  return 116 * labF(y / 100) - 16;
}
function linearized(rgbComponent) {
  const normalized = rgbComponent / 255;
  return normalized <= 0.040449936 ? normalized / 12.92 * 100 : 100 * Math.pow((normalized + 0.055) / 1.055, 2.4);
}
function delinearized(rgbComponent) {
  const normalized = rgbComponent / 100;
  let delinearized2 = 0;
  return delinearized2 = normalized <= 31308e-7 ? 12.92 * normalized : 1.055 * Math.pow(normalized, 1 / 2.4) - 0.055, clampInt(0, 255, Math.round(255 * delinearized2));
}
function whitePointD65() {
  return WHITE_POINT_D65;
}
function labF(t) {
  return t > 216 / 24389 ? Math.pow(t, 1 / 3) : (903.2962962962963 * t + 16) / 116;
}
function labInvf(ft) {
  const ft3 = ft * ft * ft;
  return ft3 > 216 / 24389 ? ft3 : (116 * ft - 16) / 903.2962962962963;
}
class ViewingConditions {
  static make(whitePoint, adaptingLuminance, backgroundLstar, surround, discountingIlluminant) {
    if (whitePoint === void 0) {
      whitePoint = whitePointD65();
    }
    if (adaptingLuminance === void 0) {
      adaptingLuminance = 200 / Math.PI * yFromLstar(50) / 100;
    }
    if (backgroundLstar === void 0) {
      backgroundLstar = 50;
    }
    if (surround === void 0) {
      surround = 2;
    }
    if (discountingIlluminant === void 0) {
      discountingIlluminant = false;
    }
    const xyz = whitePoint, rW = 0.401288 * xyz[0] + 0.650173 * xyz[1] + -0.051461 * xyz[2], gW = -0.250268 * xyz[0] + 1.204414 * xyz[1] + 0.045854 * xyz[2], bW = -2079e-6 * xyz[0] + 0.048952 * xyz[1] + 0.953127 * xyz[2], f = 0.8 + surround / 10, c = f >= 0.9 ? lerp(0.59, 0.69, 10 * (f - 0.9)) : lerp(0.525, 0.59, 10 * (f - 0.8));
    let d = discountingIlluminant ? 1 : f * (1 - 1 / 3.6 * Math.exp((-adaptingLuminance - 42) / 92));
    d = d > 1 ? 1 : d < 0 ? 0 : d;
    const nc = f, rgbD = [d * (100 / rW) + 1 - d, d * (100 / gW) + 1 - d, d * (100 / bW) + 1 - d], k = 1 / (5 * adaptingLuminance + 1), k4 = k * k * k * k, k4F = 1 - k4, fl = k4 * adaptingLuminance + 0.1 * k4F * k4F * Math.cbrt(5 * adaptingLuminance), n = yFromLstar(backgroundLstar) / whitePoint[1], z = 1.48 + Math.sqrt(n), nbb = 0.725 / Math.pow(n, 0.2), ncb = nbb, rgbAFactors = [Math.pow(fl * rgbD[0] * rW / 100, 0.42), Math.pow(fl * rgbD[1] * gW / 100, 0.42), Math.pow(fl * rgbD[2] * bW / 100, 0.42)], rgbA = [400 * rgbAFactors[0] / (rgbAFactors[0] + 27.13), 400 * rgbAFactors[1] / (rgbAFactors[1] + 27.13), 400 * rgbAFactors[2] / (rgbAFactors[2] + 27.13)];
    return new ViewingConditions(n, (2 * rgbA[0] + rgbA[1] + 0.05 * rgbA[2]) * nbb, nbb, ncb, c, nc, rgbD, fl, Math.pow(fl, 0.25), z);
  }
  constructor(n, aw, nbb, ncb, c, nc, rgbD, fl, fLRoot, z) {
    this.n = n, this.aw = aw, this.nbb = nbb, this.ncb = ncb, this.c = c, this.nc = nc, this.rgbD = rgbD, this.fl = fl, this.fLRoot = fLRoot, this.z = z;
  }
}
ViewingConditions.DEFAULT = ViewingConditions.make();
class Cam16 {
  constructor(hue, chroma, j, q, m, s, jstar, astar, bstar) {
    this.hue = hue, this.chroma = chroma, this.j = j, this.q = q, this.m = m, this.s = s, this.jstar = jstar, this.astar = astar, this.bstar = bstar;
  }
  distance(other) {
    const dJ = this.jstar - other.jstar, dA = this.astar - other.astar, dB = this.bstar - other.bstar, dEPrime = Math.sqrt(dJ * dJ + dA * dA + dB * dB);
    return 1.41 * Math.pow(dEPrime, 0.63);
  }
  static fromInt(argb) {
    return Cam16.fromIntInViewingConditions(argb, ViewingConditions.DEFAULT);
  }
  static fromIntInViewingConditions(argb, viewingConditions) {
    const green2 = (65280 & argb) >> 8, blue = 255 & argb, redL = linearized((16711680 & argb) >> 16), greenL = linearized(green2), blueL = linearized(blue), x = 0.41233895 * redL + 0.35762064 * greenL + 0.18051042 * blueL, y = 0.2126 * redL + 0.7152 * greenL + 0.0722 * blueL, z = 0.01932141 * redL + 0.11916382 * greenL + 0.95034478 * blueL, rC = 0.401288 * x + 0.650173 * y - 0.051461 * z, gC = -0.250268 * x + 1.204414 * y + 0.045854 * z, bC = -2079e-6 * x + 0.048952 * y + 0.953127 * z, rD = viewingConditions.rgbD[0] * rC, gD = viewingConditions.rgbD[1] * gC, bD = viewingConditions.rgbD[2] * bC, rAF = Math.pow(viewingConditions.fl * Math.abs(rD) / 100, 0.42), gAF = Math.pow(viewingConditions.fl * Math.abs(gD) / 100, 0.42), bAF = Math.pow(viewingConditions.fl * Math.abs(bD) / 100, 0.42), rA = 400 * signum(rD) * rAF / (rAF + 27.13), gA = 400 * signum(gD) * gAF / (gAF + 27.13), bA = 400 * signum(bD) * bAF / (bAF + 27.13), a = (11 * rA + -12 * gA + bA) / 11, b = (rA + gA - 2 * bA) / 9, u = (20 * rA + 20 * gA + 21 * bA) / 20, p2 = (40 * rA + 20 * gA + bA) / 20, atanDegrees = 180 * Math.atan2(b, a) / Math.PI, hue = atanDegrees < 0 ? atanDegrees + 360 : atanDegrees >= 360 ? atanDegrees - 360 : atanDegrees, hueRadians = hue * Math.PI / 180, ac = p2 * viewingConditions.nbb, j = 100 * Math.pow(ac / viewingConditions.aw, viewingConditions.c * viewingConditions.z), q = 4 / viewingConditions.c * Math.sqrt(j / 100) * (viewingConditions.aw + 4) * viewingConditions.fLRoot, huePrime = hue < 20.14 ? hue + 360 : hue, t = 5e4 / 13 * (0.25 * (Math.cos(huePrime * Math.PI / 180 + 2) + 3.8)) * viewingConditions.nc * viewingConditions.ncb * Math.sqrt(a * a + b * b) / (u + 0.305), alpha = Math.pow(t, 0.9) * Math.pow(1.64 - Math.pow(0.29, viewingConditions.n), 0.73), c = alpha * Math.sqrt(j / 100), m = c * viewingConditions.fLRoot, s = 50 * Math.sqrt(alpha * viewingConditions.c / (viewingConditions.aw + 4)), jstar = (1 + 100 * 7e-3) * j / (1 + 7e-3 * j), mstar = 1 / 0.0228 * Math.log(1 + 0.0228 * m), astar = mstar * Math.cos(hueRadians), bstar = mstar * Math.sin(hueRadians);
    return new Cam16(hue, c, j, q, m, s, jstar, astar, bstar);
  }
  static fromJch(j, c, h) {
    return Cam16.fromJchInViewingConditions(j, c, h, ViewingConditions.DEFAULT);
  }
  static fromJchInViewingConditions(j, c, h, viewingConditions) {
    const q = 4 / viewingConditions.c * Math.sqrt(j / 100) * (viewingConditions.aw + 4) * viewingConditions.fLRoot, m = c * viewingConditions.fLRoot, alpha = c / Math.sqrt(j / 100), s = 50 * Math.sqrt(alpha * viewingConditions.c / (viewingConditions.aw + 4)), hueRadians = h * Math.PI / 180, jstar = (1 + 100 * 7e-3) * j / (1 + 7e-3 * j), mstar = 1 / 0.0228 * Math.log(1 + 0.0228 * m), astar = mstar * Math.cos(hueRadians), bstar = mstar * Math.sin(hueRadians);
    return new Cam16(h, c, j, q, m, s, jstar, astar, bstar);
  }
  static fromUcs(jstar, astar, bstar) {
    return Cam16.fromUcsInViewingConditions(jstar, astar, bstar, ViewingConditions.DEFAULT);
  }
  static fromUcsInViewingConditions(jstar, astar, bstar, viewingConditions) {
    const a = astar, b = bstar, m = Math.sqrt(a * a + b * b), c = (Math.exp(0.0228 * m) - 1) / 0.0228 / viewingConditions.fLRoot;
    let h = Math.atan2(b, a) * (180 / Math.PI);
    h < 0 && (h += 360);
    const j = jstar / (1 - 7e-3 * (jstar - 100));
    return Cam16.fromJchInViewingConditions(j, c, h, viewingConditions);
  }
  toInt() {
    return this.viewed(ViewingConditions.DEFAULT);
  }
  viewed(viewingConditions) {
    const alpha = 0 === this.chroma || 0 === this.j ? 0 : this.chroma / Math.sqrt(this.j / 100), t = Math.pow(alpha / Math.pow(1.64 - Math.pow(0.29, viewingConditions.n), 0.73), 1 / 0.9), hRad = this.hue * Math.PI / 180, eHue = 0.25 * (Math.cos(hRad + 2) + 3.8), ac = viewingConditions.aw * Math.pow(this.j / 100, 1 / viewingConditions.c / viewingConditions.z), p1 = eHue * (5e4 / 13) * viewingConditions.nc * viewingConditions.ncb, p2 = ac / viewingConditions.nbb, hSin = Math.sin(hRad), hCos = Math.cos(hRad), gamma = 23 * (p2 + 0.305) * t / (23 * p1 + 11 * t * hCos + 108 * t * hSin), a = gamma * hCos, b = gamma * hSin, rA = (460 * p2 + 451 * a + 288 * b) / 1403, gA = (460 * p2 - 891 * a - 261 * b) / 1403, bA = (460 * p2 - 220 * a - 6300 * b) / 1403, rCBase = Math.max(0, 27.13 * Math.abs(rA) / (400 - Math.abs(rA))), rC = signum(rA) * (100 / viewingConditions.fl) * Math.pow(rCBase, 1 / 0.42), gCBase = Math.max(0, 27.13 * Math.abs(gA) / (400 - Math.abs(gA))), gC = signum(gA) * (100 / viewingConditions.fl) * Math.pow(gCBase, 1 / 0.42), bCBase = Math.max(0, 27.13 * Math.abs(bA) / (400 - Math.abs(bA))), bC = signum(bA) * (100 / viewingConditions.fl) * Math.pow(bCBase, 1 / 0.42), rF = rC / viewingConditions.rgbD[0], gF = gC / viewingConditions.rgbD[1], bF = bC / viewingConditions.rgbD[2];
    return argbFromXyz(1.86206786 * rF - 1.01125463 * gF + 0.14918677 * bF, 0.38752654 * rF + 0.62144744 * gF - 897398e-8 * bF, -0.0158415 * rF - 0.03412294 * gF + 1.04996444 * bF);
  }
  static fromXyzInViewingConditions(x, y, z, viewingConditions) {
    const rC = 0.401288 * x + 0.650173 * y - 0.051461 * z, gC = -0.250268 * x + 1.204414 * y + 0.045854 * z, bC = -2079e-6 * x + 0.048952 * y + 0.953127 * z, rD = viewingConditions.rgbD[0] * rC, gD = viewingConditions.rgbD[1] * gC, bD = viewingConditions.rgbD[2] * bC, rAF = Math.pow(viewingConditions.fl * Math.abs(rD) / 100, 0.42), gAF = Math.pow(viewingConditions.fl * Math.abs(gD) / 100, 0.42), bAF = Math.pow(viewingConditions.fl * Math.abs(bD) / 100, 0.42), rA = 400 * signum(rD) * rAF / (rAF + 27.13), gA = 400 * signum(gD) * gAF / (gAF + 27.13), bA = 400 * signum(bD) * bAF / (bAF + 27.13), a = (11 * rA + -12 * gA + bA) / 11, b = (rA + gA - 2 * bA) / 9, u = (20 * rA + 20 * gA + 21 * bA) / 20, p2 = (40 * rA + 20 * gA + bA) / 20, atanDegrees = 180 * Math.atan2(b, a) / Math.PI, hue = atanDegrees < 0 ? atanDegrees + 360 : atanDegrees >= 360 ? atanDegrees - 360 : atanDegrees, hueRadians = hue * Math.PI / 180, ac = p2 * viewingConditions.nbb, J = 100 * Math.pow(ac / viewingConditions.aw, viewingConditions.c * viewingConditions.z), Q = 4 / viewingConditions.c * Math.sqrt(J / 100) * (viewingConditions.aw + 4) * viewingConditions.fLRoot, huePrime = hue < 20.14 ? hue + 360 : hue, t = 5e4 / 13 * (1 / 4 * (Math.cos(huePrime * Math.PI / 180 + 2) + 3.8)) * viewingConditions.nc * viewingConditions.ncb * Math.sqrt(a * a + b * b) / (u + 0.305), alpha = Math.pow(t, 0.9) * Math.pow(1.64 - Math.pow(0.29, viewingConditions.n), 0.73), C = alpha * Math.sqrt(J / 100), M = C * viewingConditions.fLRoot, s = 50 * Math.sqrt(alpha * viewingConditions.c / (viewingConditions.aw + 4)), jstar = (1 + 100 * 7e-3) * J / (1 + 7e-3 * J), mstar = Math.log(1 + 0.0228 * M) / 0.0228, astar = mstar * Math.cos(hueRadians), bstar = mstar * Math.sin(hueRadians);
    return new Cam16(hue, C, J, Q, M, s, jstar, astar, bstar);
  }
  xyzInViewingConditions(viewingConditions) {
    const alpha = 0 === this.chroma || 0 === this.j ? 0 : this.chroma / Math.sqrt(this.j / 100), t = Math.pow(alpha / Math.pow(1.64 - Math.pow(0.29, viewingConditions.n), 0.73), 1 / 0.9), hRad = this.hue * Math.PI / 180, eHue = 0.25 * (Math.cos(hRad + 2) + 3.8), ac = viewingConditions.aw * Math.pow(this.j / 100, 1 / viewingConditions.c / viewingConditions.z), p1 = eHue * (5e4 / 13) * viewingConditions.nc * viewingConditions.ncb, p2 = ac / viewingConditions.nbb, hSin = Math.sin(hRad), hCos = Math.cos(hRad), gamma = 23 * (p2 + 0.305) * t / (23 * p1 + 11 * t * hCos + 108 * t * hSin), a = gamma * hCos, b = gamma * hSin, rA = (460 * p2 + 451 * a + 288 * b) / 1403, gA = (460 * p2 - 891 * a - 261 * b) / 1403, bA = (460 * p2 - 220 * a - 6300 * b) / 1403, rCBase = Math.max(0, 27.13 * Math.abs(rA) / (400 - Math.abs(rA))), rC = signum(rA) * (100 / viewingConditions.fl) * Math.pow(rCBase, 1 / 0.42), gCBase = Math.max(0, 27.13 * Math.abs(gA) / (400 - Math.abs(gA))), gC = signum(gA) * (100 / viewingConditions.fl) * Math.pow(gCBase, 1 / 0.42), bCBase = Math.max(0, 27.13 * Math.abs(bA) / (400 - Math.abs(bA))), bC = signum(bA) * (100 / viewingConditions.fl) * Math.pow(bCBase, 1 / 0.42), rF = rC / viewingConditions.rgbD[0], gF = gC / viewingConditions.rgbD[1], bF = bC / viewingConditions.rgbD[2];
    return [1.86206786 * rF - 1.01125463 * gF + 0.14918677 * bF, 0.38752654 * rF + 0.62144744 * gF - 897398e-8 * bF, -0.0158415 * rF - 0.03412294 * gF + 1.04996444 * bF];
  }
}
class HctSolver {
  static sanitizeRadians(angle) {
    return (angle + 8 * Math.PI) % (2 * Math.PI);
  }
  static trueDelinearized(rgbComponent) {
    const normalized = rgbComponent / 100;
    let delinearized2 = 0;
    return delinearized2 = normalized <= 31308e-7 ? 12.92 * normalized : 1.055 * Math.pow(normalized, 1 / 2.4) - 0.055, 255 * delinearized2;
  }
  static chromaticAdaptation(component) {
    const af = Math.pow(Math.abs(component), 0.42);
    return 400 * signum(component) * af / (af + 27.13);
  }
  static hueOf(linrgb) {
    const scaledDiscount = matrixMultiply(linrgb, HctSolver.SCALED_DISCOUNT_FROM_LINRGB), rA = HctSolver.chromaticAdaptation(scaledDiscount[0]), gA = HctSolver.chromaticAdaptation(scaledDiscount[1]), bA = HctSolver.chromaticAdaptation(scaledDiscount[2]), a = (11 * rA + -12 * gA + bA) / 11, b = (rA + gA - 2 * bA) / 9;
    return Math.atan2(b, a);
  }
  static areInCyclicOrder(a, b, c) {
    return HctSolver.sanitizeRadians(b - a) < HctSolver.sanitizeRadians(c - a);
  }
  static intercept(source, mid, target) {
    return (mid - source) / (target - source);
  }
  static lerpPoint(source, t, target) {
    return [source[0] + (target[0] - source[0]) * t, source[1] + (target[1] - source[1]) * t, source[2] + (target[2] - source[2]) * t];
  }
  static setCoordinate(source, coordinate, target, axis) {
    const t = HctSolver.intercept(source[axis], coordinate, target[axis]);
    return HctSolver.lerpPoint(source, t, target);
  }
  static isBounded(x) {
    return 0 <= x && x <= 100;
  }
  static nthVertex(y, n) {
    const kR = HctSolver.Y_FROM_LINRGB[0], kG = HctSolver.Y_FROM_LINRGB[1], kB = HctSolver.Y_FROM_LINRGB[2], coordA = n % 4 <= 1 ? 0 : 100, coordB = n % 2 == 0 ? 0 : 100;
    if (n < 4) {
      const g = coordA, b = coordB, r = (y - g * kG - b * kB) / kR;
      return HctSolver.isBounded(r) ? [r, g, b] : [-1, -1, -1];
    }
    if (n < 8) {
      const b = coordA, r = coordB, g = (y - r * kR - b * kB) / kG;
      return HctSolver.isBounded(g) ? [r, g, b] : [-1, -1, -1];
    }
    {
      const r = coordA, g = coordB, b = (y - r * kR - g * kG) / kB;
      return HctSolver.isBounded(b) ? [r, g, b] : [-1, -1, -1];
    }
  }
  static bisectToSegment(y, targetHue) {
    let left = [-1, -1, -1], right = left, leftHue = 0, rightHue = 0, initialized = false, uncut = true;
    for (let n = 0; n < 12; n++) {
      const mid = HctSolver.nthVertex(y, n);
      if (mid[0] < 0) continue;
      const midHue = HctSolver.hueOf(mid);
      initialized ? (uncut || HctSolver.areInCyclicOrder(leftHue, midHue, rightHue)) && (uncut = false, HctSolver.areInCyclicOrder(leftHue, targetHue, midHue) ? (right = mid, rightHue = midHue) : (left = mid, leftHue = midHue)) : (left = mid, right = mid, leftHue = midHue, rightHue = midHue, initialized = true);
    }
    return [left, right];
  }
  static midpoint(a, b) {
    return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2];
  }
  static criticalPlaneBelow(x) {
    return Math.floor(x - 0.5);
  }
  static criticalPlaneAbove(x) {
    return Math.ceil(x - 0.5);
  }
  static bisectToLimit(y, targetHue) {
    const segment = HctSolver.bisectToSegment(y, targetHue);
    let left = segment[0], leftHue = HctSolver.hueOf(left), right = segment[1];
    for (let axis = 0; axis < 3; axis++) if (left[axis] !== right[axis]) {
      let lPlane = -1, rPlane = 255;
      left[axis] < right[axis] ? (lPlane = HctSolver.criticalPlaneBelow(HctSolver.trueDelinearized(left[axis])), rPlane = HctSolver.criticalPlaneAbove(HctSolver.trueDelinearized(right[axis]))) : (lPlane = HctSolver.criticalPlaneAbove(HctSolver.trueDelinearized(left[axis])), rPlane = HctSolver.criticalPlaneBelow(HctSolver.trueDelinearized(right[axis])));
      for (let i = 0; i < 8 && !(Math.abs(rPlane - lPlane) <= 1); i++) {
        const mPlane = Math.floor((lPlane + rPlane) / 2), midPlaneCoordinate = HctSolver.CRITICAL_PLANES[mPlane], mid = HctSolver.setCoordinate(left, midPlaneCoordinate, right, axis), midHue = HctSolver.hueOf(mid);
        HctSolver.areInCyclicOrder(leftHue, targetHue, midHue) ? (right = mid, rPlane = mPlane) : (left = mid, leftHue = midHue, lPlane = mPlane);
      }
    }
    return HctSolver.midpoint(left, right);
  }
  static inverseChromaticAdaptation(adapted) {
    const adaptedAbs = Math.abs(adapted), base = Math.max(0, 27.13 * adaptedAbs / (400 - adaptedAbs));
    return signum(adapted) * Math.pow(base, 1 / 0.42);
  }
  static findResultByJ(hueRadians, chroma, y) {
    let j = 11 * Math.sqrt(y);
    const viewingConditions = ViewingConditions.DEFAULT, tInnerCoeff = 1 / Math.pow(1.64 - Math.pow(0.29, viewingConditions.n), 0.73), p1 = 0.25 * (Math.cos(hueRadians + 2) + 3.8) * (5e4 / 13) * viewingConditions.nc * viewingConditions.ncb, hSin = Math.sin(hueRadians), hCos = Math.cos(hueRadians);
    for (let iterationRound = 0; iterationRound < 5; iterationRound++) {
      const jNormalized = j / 100, alpha = 0 === chroma || 0 === j ? 0 : chroma / Math.sqrt(jNormalized), t = Math.pow(alpha * tInnerCoeff, 1 / 0.9), p2 = viewingConditions.aw * Math.pow(jNormalized, 1 / viewingConditions.c / viewingConditions.z) / viewingConditions.nbb, gamma = 23 * (p2 + 0.305) * t / (23 * p1 + 11 * t * hCos + 108 * t * hSin), a = gamma * hCos, b = gamma * hSin, rA = (460 * p2 + 451 * a + 288 * b) / 1403, gA = (460 * p2 - 891 * a - 261 * b) / 1403, bA = (460 * p2 - 220 * a - 6300 * b) / 1403, linrgb = matrixMultiply([HctSolver.inverseChromaticAdaptation(rA), HctSolver.inverseChromaticAdaptation(gA), HctSolver.inverseChromaticAdaptation(bA)], HctSolver.LINRGB_FROM_SCALED_DISCOUNT);
      if (linrgb[0] < 0 || linrgb[1] < 0 || linrgb[2] < 0) return 0;
      const kR = HctSolver.Y_FROM_LINRGB[0], kG = HctSolver.Y_FROM_LINRGB[1], kB = HctSolver.Y_FROM_LINRGB[2], fnj = kR * linrgb[0] + kG * linrgb[1] + kB * linrgb[2];
      if (fnj <= 0) return 0;
      if (4 === iterationRound || Math.abs(fnj - y) < 2e-3) return linrgb[0] > 100.01 || linrgb[1] > 100.01 || linrgb[2] > 100.01 ? 0 : argbFromLinrgb(linrgb);
      j -= (fnj - y) * j / (2 * fnj);
    }
    return 0;
  }
  static solveToInt(hueDegrees, chroma, lstar) {
    if (chroma < 1e-4 || lstar < 1e-4 || lstar > 99.9999) return argbFromLstar(lstar);
    const hueRadians = (hueDegrees = sanitizeDegreesDouble(hueDegrees)) / 180 * Math.PI, y = yFromLstar(lstar), exactAnswer = HctSolver.findResultByJ(hueRadians, chroma, y);
    if (0 !== exactAnswer) return exactAnswer;
    return argbFromLinrgb(HctSolver.bisectToLimit(y, hueRadians));
  }
  static solveToCam(hueDegrees, chroma, lstar) {
    return Cam16.fromInt(HctSolver.solveToInt(hueDegrees, chroma, lstar));
  }
}
HctSolver.SCALED_DISCOUNT_FROM_LINRGB = [[0.001200833568784504, 0.002389694492170889, 2795742885861124e-19], [5891086651375999e-19, 0.0029785502573438758, 3270666104008398e-19], [10146692491640572e-20, 5364214359186694e-19, 0.0032979401770712076]], HctSolver.LINRGB_FROM_SCALED_DISCOUNT = [[1373.2198709594231, -1100.4251190754821, -7.278681089101213], [-271.815969077903, 559.6580465940733, -32.46047482791194], [1.9622899599665666, -57.173814538844006, 308.7233197812385]], HctSolver.Y_FROM_LINRGB = [0.2126, 0.7152, 0.0722], HctSolver.CRITICAL_PLANES = [0.015176349177441876, 0.045529047532325624, 0.07588174588720938, 0.10623444424209313, 0.13658714259697685, 0.16693984095186062, 0.19729253930674434, 0.2276452376616281, 0.2579979360165119, 0.28835063437139563, 0.3188300904430532, 0.350925934958123, 0.3848314933096426, 0.42057480301049466, 0.458183274052838, 0.4976837250274023, 0.5391024159806381, 0.5824650784040898, 0.6277969426914107, 0.6751227633498623, 0.7244668422128921, 0.775853049866786, 0.829304845476233, 0.8848452951698498, 0.942497089126609, 1.0022825574869039, 1.0642236851973577, 1.1283421258858297, 1.1946592148522128, 1.2631959812511864, 1.3339731595349034, 1.407011200216447, 1.4823302800086415, 1.5599503113873272, 1.6398909516233677, 1.7221716113234105, 1.8068114625156377, 1.8938294463134073, 1.9832442801866852, 2.075074464868551, 2.1693382909216234, 2.2660538449872063, 2.36523901573795, 2.4669114995532007, 2.5710888059345764, 2.6777882626779785, 2.7870270208169257, 2.898822059350997, 3.0131901897720907, 3.1301480604002863, 3.2497121605402226, 3.3718988244681087, 3.4967242352587946, 3.624204428461639, 3.754355295633311, 3.887192587735158, 4.022731918402185, 4.160988767090289, 4.301978482107941, 4.445716283538092, 4.592217266055746, 4.741496401646282, 4.893568542229298, 5.048448422192488, 5.20615066083972, 5.3666897647573375, 5.5300801301023865, 5.696336044816294, 5.865471690767354, 6.037501145825082, 6.212438385869475, 6.390297286737924, 6.571091626112461, 6.7548350853498045, 6.941541251256611, 7.131223617812143, 7.323895587840543, 7.5195704746346665, 7.7182615035334345, 7.919981813454504, 8.124744458384042, 8.332562408825165, 8.543448553206703, 8.757415699253682, 8.974476575321063, 9.194643831691977, 9.417930041841839, 9.644347703669503, 9.873909240696694, 10.106627003236781, 10.342513269534024, 10.58158024687427, 10.8238400726681, 11.069304815507364, 11.317986476196008, 11.569896988756009, 11.825048221409341, 12.083451977536606, 12.345119996613247, 12.610063955123938, 12.878295467455942, 13.149826086772048, 13.42466730586372, 13.702830557985108, 13.984327217668513, 14.269168601521828, 14.55736596900856, 14.848930523210871, 15.143873411576273, 15.44220572664832, 15.743938506781891, 16.04908273684337, 16.35764934889634, 16.66964922287304, 16.985093187232053, 17.30399201960269, 17.62635644741625, 17.95219714852476, 18.281524751807332, 18.614349837764564, 18.95068293910138, 19.290534541298456, 19.633915083172692, 19.98083495742689, 20.331304511189067, 20.685334046541502, 21.042933821039977, 21.404114048223256, 21.76888489811322, 22.137256497705877, 22.50923893145328, 22.884842241736916, 23.264076429332462, 23.6469514538663, 24.033477234264016, 24.42366364919083, 24.817520537484558, 25.21505769858089, 25.61628489293138, 26.021211842414342, 26.429848230738664, 26.842203703840827, 27.258287870275353, 27.678110301598522, 28.10168053274597, 28.529008062403893, 28.96010235337422, 29.39497283293396, 29.83362889318845, 30.276079891419332, 30.722335150426627, 31.172403958865512, 31.62629557157785, 32.08401920991837, 32.54558406207592, 33.010999283389665, 33.4802739966603, 33.953417292456834, 34.430438229418264, 34.911345834551085, 35.39614910352207, 35.88485700094671, 36.37747846067349, 36.87402238606382, 37.37449765026789, 37.87891309649659, 38.38727753828926, 38.89959975977785, 39.41588851594697, 39.93615253289054, 40.460400508064545, 40.98864111053629, 41.520882981230194, 42.05713473317016, 42.597404951718396, 43.141702194811224, 43.6900349931913, 44.24241185063697, 44.798841244188324, 45.35933162437017, 45.92389141541209, 46.49252901546552, 47.065252796817916, 47.64207110610409, 48.22299226451468, 48.808024568002054, 49.3971762874833, 49.9904556690408, 50.587870934119984, 51.189430279724725, 51.79514187861014, 52.40501387947288, 53.0190544071392, 53.637271562750364, 54.259673423945976, 54.88626804504493, 55.517063457223934, 56.15206766869424, 56.79128866487574, 57.43473440856916, 58.08241284012621, 58.734331877617365, 59.39049941699807, 60.05092333227251, 60.715611475655585, 61.38457167773311, 62.057811747619894, 62.7353394731159, 63.417162620860914, 64.10328893648692, 64.79372614476921, 65.48848194977529, 66.18756403501224, 66.89098006357258, 67.59873767827808, 68.31084450182222, 69.02730813691093, 69.74813616640164, 70.47333615344107, 71.20291564160104, 71.93688215501312, 72.67524319850172, 73.41800625771542, 74.16517879925733, 74.9167682708136, 75.67278210128072, 76.43322770089146, 77.1981124613393, 77.96744375590167, 78.74122893956174, 79.51947534912904, 80.30219030335869, 81.08938110306934, 81.88105503125999, 82.67721935322541, 83.4778813166706, 84.28304815182372, 85.09272707154808, 85.90692527145302, 86.72564993000343, 87.54890820862819, 88.3767072518277, 89.2090541872801, 90.04595612594655, 90.88742016217518, 91.73345337380438, 92.58406282226491, 93.43925555268066, 94.29903859396902, 95.16341895893969, 96.03240364439274, 96.9059996312159, 97.78421388448044, 98.6670533535366, 99.55452497210776];
class Hct {
  static from(hue, chroma, tone) {
    return new Hct(HctSolver.solveToInt(hue, chroma, tone));
  }
  static fromInt(argb) {
    return new Hct(argb);
  }
  toInt() {
    return this.argb;
  }
  get hue() {
    return this.internalHue;
  }
  set hue(newHue) {
    this.setInternalState(HctSolver.solveToInt(newHue, this.internalChroma, this.internalTone));
  }
  get chroma() {
    return this.internalChroma;
  }
  set chroma(newChroma) {
    this.setInternalState(HctSolver.solveToInt(this.internalHue, newChroma, this.internalTone));
  }
  get tone() {
    return this.internalTone;
  }
  set tone(newTone) {
    this.setInternalState(HctSolver.solveToInt(this.internalHue, this.internalChroma, newTone));
  }
  constructor(argb) {
    this.argb = argb;
    const cam = Cam16.fromInt(argb);
    this.internalHue = cam.hue, this.internalChroma = cam.chroma, this.internalTone = lstarFromArgb(argb), this.argb = argb;
  }
  setInternalState(argb) {
    const cam = Cam16.fromInt(argb);
    this.internalHue = cam.hue, this.internalChroma = cam.chroma, this.internalTone = lstarFromArgb(argb), this.argb = argb;
  }
  inViewingConditions(vc) {
    const viewedInVc = Cam16.fromInt(this.toInt()).xyzInViewingConditions(vc), recastInVc = Cam16.fromXyzInViewingConditions(viewedInVc[0], viewedInVc[1], viewedInVc[2], ViewingConditions.make());
    return Hct.from(recastInVc.hue, recastInVc.chroma, lstarFromY(viewedInVc[1]));
  }
}
class Blend {
  static harmonize(designColor, sourceColor) {
    const fromHct = Hct.fromInt(designColor), toHct = Hct.fromInt(sourceColor), differenceDegrees$1 = differenceDegrees(fromHct.hue, toHct.hue), rotationDegrees = Math.min(0.5 * differenceDegrees$1, 15), outputHue = sanitizeDegreesDouble(fromHct.hue + rotationDegrees * rotationDirection(fromHct.hue, toHct.hue));
    return Hct.from(outputHue, fromHct.chroma, fromHct.tone).toInt();
  }
  static hctHue(from, to, amount) {
    const ucs = Blend.cam16Ucs(from, to, amount), ucsCam = Cam16.fromInt(ucs), fromCam = Cam16.fromInt(from);
    return Hct.from(ucsCam.hue, fromCam.chroma, lstarFromArgb(from)).toInt();
  }
  static cam16Ucs(from, to, amount) {
    const fromCam = Cam16.fromInt(from), toCam = Cam16.fromInt(to), fromJ = fromCam.jstar, fromA = fromCam.astar, fromB = fromCam.bstar, jstar = fromJ + (toCam.jstar - fromJ) * amount, astar = fromA + (toCam.astar - fromA) * amount, bstar = fromB + (toCam.bstar - fromB) * amount;
    return Cam16.fromUcs(jstar, astar, bstar).toInt();
  }
}
class Contrast {
  static ratioOfTones(toneA, toneB) {
    return toneA = clampDouble(0, 100, toneA), toneB = clampDouble(0, 100, toneB), Contrast.ratioOfYs(yFromLstar(toneA), yFromLstar(toneB));
  }
  static ratioOfYs(y1, y2) {
    const lighter = y1 > y2 ? y1 : y2;
    return (lighter + 5) / ((lighter === y2 ? y1 : y2) + 5);
  }
  static lighter(tone, ratio) {
    if (tone < 0 || tone > 100) return -1;
    const darkY = yFromLstar(tone), lightY = ratio * (darkY + 5) - 5, realContrast = Contrast.ratioOfYs(lightY, darkY), delta = Math.abs(realContrast - ratio);
    if (realContrast < ratio && delta > 0.04) return -1;
    const returnValue = lstarFromY(lightY) + 0.4;
    return returnValue < 0 || returnValue > 100 ? -1 : returnValue;
  }
  static darker(tone, ratio) {
    if (tone < 0 || tone > 100) return -1;
    const lightY = yFromLstar(tone), darkY = (lightY + 5) / ratio - 5, realContrast = Contrast.ratioOfYs(lightY, darkY), delta = Math.abs(realContrast - ratio);
    if (realContrast < ratio && delta > 0.04) return -1;
    const returnValue = lstarFromY(darkY) - 0.4;
    return returnValue < 0 || returnValue > 100 ? -1 : returnValue;
  }
  static lighterUnsafe(tone, ratio) {
    const lighterSafe = Contrast.lighter(tone, ratio);
    return lighterSafe < 0 ? 100 : lighterSafe;
  }
  static darkerUnsafe(tone, ratio) {
    const darkerSafe = Contrast.darker(tone, ratio);
    return darkerSafe < 0 ? 0 : darkerSafe;
  }
}
class DislikeAnalyzer {
  static isDisliked(hct) {
    const huePasses = Math.round(hct.hue) >= 90 && Math.round(hct.hue) <= 111, chromaPasses = Math.round(hct.chroma) > 16, tonePasses = Math.round(hct.tone) < 65;
    return huePasses && chromaPasses && tonePasses;
  }
  static fixIfDisliked(hct) {
    return DislikeAnalyzer.isDisliked(hct) ? Hct.from(hct.hue, hct.chroma, 70) : hct;
  }
}
class DynamicColor {
  static fromPalette(args) {
    return new DynamicColor(args.name ?? "", args.palette, args.tone, args.isBackground ?? false, args.background, args.secondBackground, args.contrastCurve, args.toneDeltaPair);
  }
  constructor(name2, palette, tone, isBackground, background2, secondBackground, contrastCurve, toneDeltaPair) {
    if (this.name = name2, this.palette = palette, this.tone = tone, this.isBackground = isBackground, this.background = background2, this.secondBackground = secondBackground, this.contrastCurve = contrastCurve, this.toneDeltaPair = toneDeltaPair, this.hctCache = /* @__PURE__ */ new Map(), !background2 && secondBackground) throw new Error(`Color ${name2} has secondBackgrounddefined, but background is not defined.`);
    if (!background2 && contrastCurve) throw new Error(`Color ${name2} has contrastCurvedefined, but background is not defined.`);
    if (background2 && !contrastCurve) throw new Error(`Color ${name2} has backgrounddefined, but contrastCurve is not defined.`);
  }
  getArgb(scheme) {
    return this.getHct(scheme).toInt();
  }
  getHct(scheme) {
    const cachedAnswer = this.hctCache.get(scheme);
    if (null != cachedAnswer) return cachedAnswer;
    const tone = this.getTone(scheme), answer = this.palette(scheme).getHct(tone);
    return this.hctCache.size > 4 && this.hctCache.clear(), this.hctCache.set(scheme, answer), answer;
  }
  getTone(scheme) {
    const decreasingContrast = scheme.contrastLevel < 0;
    if (this.toneDeltaPair) {
      const toneDeltaPair = this.toneDeltaPair(scheme), roleA = toneDeltaPair.roleA, roleB = toneDeltaPair.roleB, delta = toneDeltaPair.delta, polarity = toneDeltaPair.polarity, stayTogether = toneDeltaPair.stayTogether, bgTone = this.background(scheme).getTone(scheme), aIsNearer = "nearer" === polarity || "lighter" === polarity && !scheme.isDark || "darker" === polarity && scheme.isDark, nearer = aIsNearer ? roleA : roleB, farther = aIsNearer ? roleB : roleA, amNearer = this.name === nearer.name, expansionDir = scheme.isDark ? 1 : -1, nContrast = nearer.contrastCurve.getContrast(scheme.contrastLevel), fContrast = farther.contrastCurve.getContrast(scheme.contrastLevel), nInitialTone = nearer.tone(scheme);
      let nTone = Contrast.ratioOfTones(bgTone, nInitialTone) >= nContrast ? nInitialTone : DynamicColor.foregroundTone(bgTone, nContrast);
      const fInitialTone = farther.tone(scheme);
      let fTone = Contrast.ratioOfTones(bgTone, fInitialTone) >= fContrast ? fInitialTone : DynamicColor.foregroundTone(bgTone, fContrast);
      return decreasingContrast && (nTone = DynamicColor.foregroundTone(bgTone, nContrast), fTone = DynamicColor.foregroundTone(bgTone, fContrast)), (fTone - nTone) * expansionDir >= delta || (fTone = clampDouble(0, 100, nTone + delta * expansionDir), (fTone - nTone) * expansionDir >= delta || (nTone = clampDouble(0, 100, fTone - delta * expansionDir))), 50 <= nTone && nTone < 60 ? expansionDir > 0 ? (nTone = 60, fTone = Math.max(fTone, nTone + delta * expansionDir)) : (nTone = 49, fTone = Math.min(fTone, nTone + delta * expansionDir)) : 50 <= fTone && fTone < 60 && (stayTogether ? expansionDir > 0 ? (nTone = 60, fTone = Math.max(fTone, nTone + delta * expansionDir)) : (nTone = 49, fTone = Math.min(fTone, nTone + delta * expansionDir)) : fTone = expansionDir > 0 ? 60 : 49), amNearer ? nTone : fTone;
    }
    {
      let answer = this.tone(scheme);
      if (null == this.background) return answer;
      const bgTone = this.background(scheme).getTone(scheme), desiredRatio = this.contrastCurve.getContrast(scheme.contrastLevel);
      if (Contrast.ratioOfTones(bgTone, answer) >= desiredRatio || (answer = DynamicColor.foregroundTone(bgTone, desiredRatio)), decreasingContrast && (answer = DynamicColor.foregroundTone(bgTone, desiredRatio)), this.isBackground && 50 <= answer && answer < 60 && (answer = Contrast.ratioOfTones(49, bgTone) >= desiredRatio ? 49 : 60), this.secondBackground) {
        const [bg1, bg2] = [this.background, this.secondBackground], [bgTone1, bgTone2] = [bg1(scheme).getTone(scheme), bg2(scheme).getTone(scheme)], [upper, lower] = [Math.max(bgTone1, bgTone2), Math.min(bgTone1, bgTone2)];
        if (Contrast.ratioOfTones(upper, answer) >= desiredRatio && Contrast.ratioOfTones(lower, answer) >= desiredRatio) return answer;
        const lightOption = Contrast.lighter(upper, desiredRatio), darkOption = Contrast.darker(lower, desiredRatio), availables = [];
        -1 !== lightOption && availables.push(lightOption), -1 !== darkOption && availables.push(darkOption);
        return DynamicColor.tonePrefersLightForeground(bgTone1) || DynamicColor.tonePrefersLightForeground(bgTone2) ? lightOption < 0 ? 100 : lightOption : 1 === availables.length ? availables[0] : darkOption < 0 ? 0 : darkOption;
      }
      return answer;
    }
  }
  static foregroundTone(bgTone, ratio) {
    const lighterTone = Contrast.lighterUnsafe(bgTone, ratio), darkerTone = Contrast.darkerUnsafe(bgTone, ratio), lighterRatio = Contrast.ratioOfTones(lighterTone, bgTone), darkerRatio = Contrast.ratioOfTones(darkerTone, bgTone);
    if (DynamicColor.tonePrefersLightForeground(bgTone)) {
      const negligibleDifference = Math.abs(lighterRatio - darkerRatio) < 0.1 && lighterRatio < ratio && darkerRatio < ratio;
      return lighterRatio >= ratio || lighterRatio >= darkerRatio || negligibleDifference ? lighterTone : darkerTone;
    }
    return darkerRatio >= ratio || darkerRatio >= lighterRatio ? darkerTone : lighterTone;
  }
  static tonePrefersLightForeground(tone) {
    return Math.round(tone) < 60;
  }
  static toneAllowsLightForeground(tone) {
    return Math.round(tone) <= 49;
  }
  static enableLightForeground(tone) {
    return DynamicColor.tonePrefersLightForeground(tone) && !DynamicColor.toneAllowsLightForeground(tone) ? 49 : tone;
  }
}
var Variant;
!function(Variant2) {
  Variant2[Variant2.MONOCHROME = 0] = "MONOCHROME", Variant2[Variant2.NEUTRAL = 1] = "NEUTRAL", Variant2[Variant2.TONAL_SPOT = 2] = "TONAL_SPOT", Variant2[Variant2.VIBRANT = 3] = "VIBRANT", Variant2[Variant2.EXPRESSIVE = 4] = "EXPRESSIVE", Variant2[Variant2.FIDELITY = 5] = "FIDELITY", Variant2[Variant2.CONTENT = 6] = "CONTENT", Variant2[Variant2.RAINBOW = 7] = "RAINBOW", Variant2[Variant2.FRUIT_SALAD = 8] = "FRUIT_SALAD";
}(Variant || (Variant = {}));
class ContrastCurve {
  constructor(low, normal, medium, high) {
    this.low = low, this.normal = normal, this.medium = medium, this.high = high;
  }
  getContrast(contrastLevel) {
    return contrastLevel <= -1 ? this.low : contrastLevel < 0 ? lerp(this.low, this.normal, (contrastLevel - -1) / 1) : contrastLevel < 0.5 ? lerp(this.normal, this.medium, (contrastLevel - 0) / 0.5) : contrastLevel < 1 ? lerp(this.medium, this.high, (contrastLevel - 0.5) / 0.5) : this.high;
  }
}
class ToneDeltaPair {
  constructor(roleA, roleB, delta, polarity, stayTogether) {
    this.roleA = roleA, this.roleB = roleB, this.delta = delta, this.polarity = polarity, this.stayTogether = stayTogether;
  }
}
function isFidelity(scheme) {
  return scheme.variant === Variant.FIDELITY || scheme.variant === Variant.CONTENT;
}
function isMonochrome(scheme) {
  return scheme.variant === Variant.MONOCHROME;
}
function findDesiredChromaByTone(hue, chroma, tone, byDecreasingTone) {
  let answer = tone, closestToChroma = Hct.from(hue, chroma, tone);
  if (closestToChroma.chroma < chroma) {
    let chromaPeak = closestToChroma.chroma;
    for (; closestToChroma.chroma < chroma; ) {
      answer += byDecreasingTone ? -1 : 1;
      const potentialSolution = Hct.from(hue, chroma, answer);
      if (chromaPeak > potentialSolution.chroma) break;
      if (Math.abs(potentialSolution.chroma - chroma) < 0.4) break;
      Math.abs(potentialSolution.chroma - chroma) < Math.abs(closestToChroma.chroma - chroma) && (closestToChroma = potentialSolution), chromaPeak = Math.max(chromaPeak, potentialSolution.chroma);
    }
  }
  return answer;
}
function viewingConditionsForAlbers(scheme) {
  return ViewingConditions.make(void 0, void 0, scheme.isDark ? 30 : 80, void 0, void 0);
}
function performAlbers(prealbers, scheme) {
  const albersd = prealbers.inViewingConditions(viewingConditionsForAlbers(scheme));
  return DynamicColor.tonePrefersLightForeground(prealbers.tone) && !DynamicColor.toneAllowsLightForeground(albersd.tone) ? DynamicColor.enableLightForeground(prealbers.tone) : DynamicColor.enableLightForeground(albersd.tone);
}
class MaterialDynamicColors {
  static highestSurface(s) {
    return s.isDark ? MaterialDynamicColors.surfaceBright : MaterialDynamicColors.surfaceDim;
  }
}
MaterialDynamicColors.contentAccentToneDelta = 15, MaterialDynamicColors.primaryPaletteKeyColor = DynamicColor.fromPalette({
  name: "primary_palette_key_color",
  palette: (s) => s.primaryPalette,
  tone: (s) => s.primaryPalette.keyColor.tone
}), MaterialDynamicColors.secondaryPaletteKeyColor = DynamicColor.fromPalette({
  name: "secondary_palette_key_color",
  palette: (s) => s.secondaryPalette,
  tone: (s) => s.secondaryPalette.keyColor.tone
}), MaterialDynamicColors.tertiaryPaletteKeyColor = DynamicColor.fromPalette({
  name: "tertiary_palette_key_color",
  palette: (s) => s.tertiaryPalette,
  tone: (s) => s.tertiaryPalette.keyColor.tone
}), MaterialDynamicColors.neutralPaletteKeyColor = DynamicColor.fromPalette({
  name: "neutral_palette_key_color",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.neutralPalette.keyColor.tone
}), MaterialDynamicColors.neutralVariantPaletteKeyColor = DynamicColor.fromPalette({
  name: "neutral_variant_palette_key_color",
  palette: (s) => s.neutralVariantPalette,
  tone: (s) => s.neutralVariantPalette.keyColor.tone
}), MaterialDynamicColors.background = DynamicColor.fromPalette({
  name: "background",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 6 : 98,
  isBackground: true
}), MaterialDynamicColors.onBackground = DynamicColor.fromPalette({
  name: "on_background",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 90 : 10,
  background: (s) => MaterialDynamicColors.background,
  contrastCurve: new ContrastCurve(3, 3, 4.5, 7)
}), MaterialDynamicColors.surface = DynamicColor.fromPalette({
  name: "surface",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 6 : 98,
  isBackground: true
}), MaterialDynamicColors.surfaceDim = DynamicColor.fromPalette({
  name: "surface_dim",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 6 : 87,
  isBackground: true
}), MaterialDynamicColors.surfaceBright = DynamicColor.fromPalette({
  name: "surface_bright",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 24 : 98,
  isBackground: true
}), MaterialDynamicColors.surfaceContainerLowest = DynamicColor.fromPalette({
  name: "surface_container_lowest",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 4 : 100,
  isBackground: true
}), MaterialDynamicColors.surfaceContainerLow = DynamicColor.fromPalette({
  name: "surface_container_low",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 10 : 96,
  isBackground: true
}), MaterialDynamicColors.surfaceContainer = DynamicColor.fromPalette({
  name: "surface_container",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 12 : 94,
  isBackground: true
}), MaterialDynamicColors.surfaceContainerHigh = DynamicColor.fromPalette({
  name: "surface_container_high",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 17 : 92,
  isBackground: true
}), MaterialDynamicColors.surfaceContainerHighest = DynamicColor.fromPalette({
  name: "surface_container_highest",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 22 : 90,
  isBackground: true
}), MaterialDynamicColors.onSurface = DynamicColor.fromPalette({
  name: "on_surface",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 90 : 10,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.surfaceVariant = DynamicColor.fromPalette({
  name: "surface_variant",
  palette: (s) => s.neutralVariantPalette,
  tone: (s) => s.isDark ? 30 : 90,
  isBackground: true
}), MaterialDynamicColors.onSurfaceVariant = DynamicColor.fromPalette({
  name: "on_surface_variant",
  palette: (s) => s.neutralVariantPalette,
  tone: (s) => s.isDark ? 80 : 30,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(3, 4.5, 7, 11)
}), MaterialDynamicColors.inverseSurface = DynamicColor.fromPalette({
  name: "inverse_surface",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 90 : 20
}), MaterialDynamicColors.inverseOnSurface = DynamicColor.fromPalette({
  name: "inverse_on_surface",
  palette: (s) => s.neutralPalette,
  tone: (s) => s.isDark ? 20 : 95,
  background: (s) => MaterialDynamicColors.inverseSurface,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.outline = DynamicColor.fromPalette({
  name: "outline",
  palette: (s) => s.neutralVariantPalette,
  tone: (s) => s.isDark ? 60 : 50,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1.5, 3, 4.5, 7)
}), MaterialDynamicColors.outlineVariant = DynamicColor.fromPalette({
  name: "outline_variant",
  palette: (s) => s.neutralVariantPalette,
  tone: (s) => s.isDark ? 30 : 80,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1, 1, 3, 7)
}), MaterialDynamicColors.shadow = DynamicColor.fromPalette({
  name: "shadow",
  palette: (s) => s.neutralPalette,
  tone: (s) => 0
}), MaterialDynamicColors.scrim = DynamicColor.fromPalette({
  name: "scrim",
  palette: (s) => s.neutralPalette,
  tone: (s) => 0
}), MaterialDynamicColors.surfaceTint = DynamicColor.fromPalette({
  name: "surface_tint",
  palette: (s) => s.primaryPalette,
  tone: (s) => s.isDark ? 80 : 40,
  isBackground: true
}), MaterialDynamicColors.primary = DynamicColor.fromPalette({
  name: "primary",
  palette: (s) => s.primaryPalette,
  tone: (s) => isMonochrome(s) ? s.isDark ? 100 : 0 : s.isDark ? 80 : 40,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(3, 4.5, 7, 11),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.primaryContainer, MaterialDynamicColors.primary, 15, "nearer", false)
}), MaterialDynamicColors.onPrimary = DynamicColor.fromPalette({
  name: "on_primary",
  palette: (s) => s.primaryPalette,
  tone: (s) => isMonochrome(s) ? s.isDark ? 10 : 90 : s.isDark ? 20 : 100,
  background: (s) => MaterialDynamicColors.primary,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.primaryContainer = DynamicColor.fromPalette({
  name: "primary_container",
  palette: (s) => s.primaryPalette,
  tone: (s) => isFidelity(s) ? performAlbers(s.sourceColorHct, s) : isMonochrome(s) ? s.isDark ? 85 : 25 : s.isDark ? 30 : 90,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1, 1, 3, 7),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.primaryContainer, MaterialDynamicColors.primary, 15, "nearer", false)
}), MaterialDynamicColors.onPrimaryContainer = DynamicColor.fromPalette({
  name: "on_primary_container",
  palette: (s) => s.primaryPalette,
  tone: (s) => isFidelity(s) ? DynamicColor.foregroundTone(MaterialDynamicColors.primaryContainer.tone(s), 4.5) : isMonochrome(s) ? s.isDark ? 0 : 100 : s.isDark ? 90 : 10,
  background: (s) => MaterialDynamicColors.primaryContainer,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.inversePrimary = DynamicColor.fromPalette({
  name: "inverse_primary",
  palette: (s) => s.primaryPalette,
  tone: (s) => s.isDark ? 40 : 80,
  background: (s) => MaterialDynamicColors.inverseSurface,
  contrastCurve: new ContrastCurve(3, 4.5, 7, 11)
}), MaterialDynamicColors.secondary = DynamicColor.fromPalette({
  name: "secondary",
  palette: (s) => s.secondaryPalette,
  tone: (s) => s.isDark ? 80 : 40,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(3, 4.5, 7, 11),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.secondaryContainer, MaterialDynamicColors.secondary, 15, "nearer", false)
}), MaterialDynamicColors.onSecondary = DynamicColor.fromPalette({
  name: "on_secondary",
  palette: (s) => s.secondaryPalette,
  tone: (s) => isMonochrome(s) ? s.isDark ? 10 : 100 : s.isDark ? 20 : 100,
  background: (s) => MaterialDynamicColors.secondary,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.secondaryContainer = DynamicColor.fromPalette({
  name: "secondary_container",
  palette: (s) => s.secondaryPalette,
  tone: (s) => {
    const initialTone = s.isDark ? 30 : 90;
    if (isMonochrome(s)) return s.isDark ? 30 : 85;
    if (!isFidelity(s)) return initialTone;
    let answer = findDesiredChromaByTone(s.secondaryPalette.hue, s.secondaryPalette.chroma, initialTone, !s.isDark);
    return answer = performAlbers(s.secondaryPalette.getHct(answer), s), answer;
  },
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1, 1, 3, 7),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.secondaryContainer, MaterialDynamicColors.secondary, 15, "nearer", false)
}), MaterialDynamicColors.onSecondaryContainer = DynamicColor.fromPalette({
  name: "on_secondary_container",
  palette: (s) => s.secondaryPalette,
  tone: (s) => isFidelity(s) ? DynamicColor.foregroundTone(MaterialDynamicColors.secondaryContainer.tone(s), 4.5) : s.isDark ? 90 : 10,
  background: (s) => MaterialDynamicColors.secondaryContainer,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.tertiary = DynamicColor.fromPalette({
  name: "tertiary",
  palette: (s) => s.tertiaryPalette,
  tone: (s) => isMonochrome(s) ? s.isDark ? 90 : 25 : s.isDark ? 80 : 40,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(3, 4.5, 7, 11),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.tertiaryContainer, MaterialDynamicColors.tertiary, 15, "nearer", false)
}), MaterialDynamicColors.onTertiary = DynamicColor.fromPalette({
  name: "on_tertiary",
  palette: (s) => s.tertiaryPalette,
  tone: (s) => isMonochrome(s) ? s.isDark ? 10 : 90 : s.isDark ? 20 : 100,
  background: (s) => MaterialDynamicColors.tertiary,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.tertiaryContainer = DynamicColor.fromPalette({
  name: "tertiary_container",
  palette: (s) => s.tertiaryPalette,
  tone: (s) => {
    if (isMonochrome(s)) return s.isDark ? 60 : 49;
    if (!isFidelity(s)) return s.isDark ? 30 : 90;
    const albersTone = performAlbers(s.tertiaryPalette.getHct(s.sourceColorHct.tone), s), proposedHct = s.tertiaryPalette.getHct(albersTone);
    return DislikeAnalyzer.fixIfDisliked(proposedHct).tone;
  },
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1, 1, 3, 7),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.tertiaryContainer, MaterialDynamicColors.tertiary, 15, "nearer", false)
}), MaterialDynamicColors.onTertiaryContainer = DynamicColor.fromPalette({
  name: "on_tertiary_container",
  palette: (s) => s.tertiaryPalette,
  tone: (s) => isMonochrome(s) ? s.isDark ? 0 : 100 : isFidelity(s) ? DynamicColor.foregroundTone(MaterialDynamicColors.tertiaryContainer.tone(s), 4.5) : s.isDark ? 90 : 10,
  background: (s) => MaterialDynamicColors.tertiaryContainer,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.error = DynamicColor.fromPalette({
  name: "error",
  palette: (s) => s.errorPalette,
  tone: (s) => s.isDark ? 80 : 40,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(3, 4.5, 7, 11),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.errorContainer, MaterialDynamicColors.error, 15, "nearer", false)
}), MaterialDynamicColors.onError = DynamicColor.fromPalette({
  name: "on_error",
  palette: (s) => s.errorPalette,
  tone: (s) => s.isDark ? 20 : 100,
  background: (s) => MaterialDynamicColors.error,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.errorContainer = DynamicColor.fromPalette({
  name: "error_container",
  palette: (s) => s.errorPalette,
  tone: (s) => s.isDark ? 30 : 90,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1, 1, 3, 7),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.errorContainer, MaterialDynamicColors.error, 15, "nearer", false)
}), MaterialDynamicColors.onErrorContainer = DynamicColor.fromPalette({
  name: "on_error_container",
  palette: (s) => s.errorPalette,
  tone: (s) => s.isDark ? 90 : 10,
  background: (s) => MaterialDynamicColors.errorContainer,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.primaryFixed = DynamicColor.fromPalette({
  name: "primary_fixed",
  palette: (s) => s.primaryPalette,
  tone: (s) => isMonochrome(s) ? 40 : 90,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1, 1, 3, 7),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.primaryFixed, MaterialDynamicColors.primaryFixedDim, 10, "lighter", true)
}), MaterialDynamicColors.primaryFixedDim = DynamicColor.fromPalette({
  name: "primary_fixed_dim",
  palette: (s) => s.primaryPalette,
  tone: (s) => isMonochrome(s) ? 30 : 80,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1, 1, 3, 7),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.primaryFixed, MaterialDynamicColors.primaryFixedDim, 10, "lighter", true)
}), MaterialDynamicColors.onPrimaryFixed = DynamicColor.fromPalette({
  name: "on_primary_fixed",
  palette: (s) => s.primaryPalette,
  tone: (s) => isMonochrome(s) ? 100 : 10,
  background: (s) => MaterialDynamicColors.primaryFixedDim,
  secondBackground: (s) => MaterialDynamicColors.primaryFixed,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.onPrimaryFixedVariant = DynamicColor.fromPalette({
  name: "on_primary_fixed_variant",
  palette: (s) => s.primaryPalette,
  tone: (s) => isMonochrome(s) ? 90 : 30,
  background: (s) => MaterialDynamicColors.primaryFixedDim,
  secondBackground: (s) => MaterialDynamicColors.primaryFixed,
  contrastCurve: new ContrastCurve(3, 4.5, 7, 11)
}), MaterialDynamicColors.secondaryFixed = DynamicColor.fromPalette({
  name: "secondary_fixed",
  palette: (s) => s.secondaryPalette,
  tone: (s) => isMonochrome(s) ? 80 : 90,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1, 1, 3, 7),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.secondaryFixed, MaterialDynamicColors.secondaryFixedDim, 10, "lighter", true)
}), MaterialDynamicColors.secondaryFixedDim = DynamicColor.fromPalette({
  name: "secondary_fixed_dim",
  palette: (s) => s.secondaryPalette,
  tone: (s) => isMonochrome(s) ? 70 : 80,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1, 1, 3, 7),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.secondaryFixed, MaterialDynamicColors.secondaryFixedDim, 10, "lighter", true)
}), MaterialDynamicColors.onSecondaryFixed = DynamicColor.fromPalette({
  name: "on_secondary_fixed",
  palette: (s) => s.secondaryPalette,
  tone: (s) => 10,
  background: (s) => MaterialDynamicColors.secondaryFixedDim,
  secondBackground: (s) => MaterialDynamicColors.secondaryFixed,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.onSecondaryFixedVariant = DynamicColor.fromPalette({
  name: "on_secondary_fixed_variant",
  palette: (s) => s.secondaryPalette,
  tone: (s) => isMonochrome(s) ? 25 : 30,
  background: (s) => MaterialDynamicColors.secondaryFixedDim,
  secondBackground: (s) => MaterialDynamicColors.secondaryFixed,
  contrastCurve: new ContrastCurve(3, 4.5, 7, 11)
}), MaterialDynamicColors.tertiaryFixed = DynamicColor.fromPalette({
  name: "tertiary_fixed",
  palette: (s) => s.tertiaryPalette,
  tone: (s) => isMonochrome(s) ? 40 : 90,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1, 1, 3, 7),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.tertiaryFixed, MaterialDynamicColors.tertiaryFixedDim, 10, "lighter", true)
}), MaterialDynamicColors.tertiaryFixedDim = DynamicColor.fromPalette({
  name: "tertiary_fixed_dim",
  palette: (s) => s.tertiaryPalette,
  tone: (s) => isMonochrome(s) ? 30 : 80,
  isBackground: true,
  background: (s) => MaterialDynamicColors.highestSurface(s),
  contrastCurve: new ContrastCurve(1, 1, 3, 7),
  toneDeltaPair: (s) => new ToneDeltaPair(MaterialDynamicColors.tertiaryFixed, MaterialDynamicColors.tertiaryFixedDim, 10, "lighter", true)
}), MaterialDynamicColors.onTertiaryFixed = DynamicColor.fromPalette({
  name: "on_tertiary_fixed",
  palette: (s) => s.tertiaryPalette,
  tone: (s) => isMonochrome(s) ? 100 : 10,
  background: (s) => MaterialDynamicColors.tertiaryFixedDim,
  secondBackground: (s) => MaterialDynamicColors.tertiaryFixed,
  contrastCurve: new ContrastCurve(4.5, 7, 11, 21)
}), MaterialDynamicColors.onTertiaryFixedVariant = DynamicColor.fromPalette({
  name: "on_tertiary_fixed_variant",
  palette: (s) => s.tertiaryPalette,
  tone: (s) => isMonochrome(s) ? 90 : 30,
  background: (s) => MaterialDynamicColors.tertiaryFixedDim,
  secondBackground: (s) => MaterialDynamicColors.tertiaryFixed,
  contrastCurve: new ContrastCurve(3, 4.5, 7, 11)
});
class TonalPalette {
  static fromInt(argb) {
    const hct = Hct.fromInt(argb);
    return TonalPalette.fromHct(hct);
  }
  static fromHct(hct) {
    return new TonalPalette(hct.hue, hct.chroma, hct);
  }
  static fromHueAndChroma(hue, chroma) {
    return new TonalPalette(hue, chroma, TonalPalette.createKeyColor(hue, chroma));
  }
  constructor(hue, chroma, keyColor) {
    this.hue = hue, this.chroma = chroma, this.keyColor = keyColor, this.cache = /* @__PURE__ */ new Map();
  }
  static createKeyColor(hue, chroma) {
    let smallestDeltaHct = Hct.from(hue, chroma, 50), smallestDelta = Math.abs(smallestDeltaHct.chroma - chroma);
    for (let delta = 1; delta < 50; delta += 1) {
      if (Math.round(chroma) === Math.round(smallestDeltaHct.chroma)) return smallestDeltaHct;
      const hctAdd = Hct.from(hue, chroma, 50 + delta), hctAddDelta = Math.abs(hctAdd.chroma - chroma);
      hctAddDelta < smallestDelta && (smallestDelta = hctAddDelta, smallestDeltaHct = hctAdd);
      const hctSubtract = Hct.from(hue, chroma, 50 - delta), hctSubtractDelta = Math.abs(hctSubtract.chroma - chroma);
      hctSubtractDelta < smallestDelta && (smallestDelta = hctSubtractDelta, smallestDeltaHct = hctSubtract);
    }
    return smallestDeltaHct;
  }
  tone(tone) {
    let argb = this.cache.get(tone);
    return void 0 === argb && (argb = Hct.from(this.hue, this.chroma, tone).toInt(), this.cache.set(tone, argb)), argb;
  }
  getHct(tone) {
    return Hct.fromInt(this.tone(tone));
  }
}
class CorePalette {
  static of(argb) {
    return new CorePalette(argb, false);
  }
  static contentOf(argb) {
    return new CorePalette(argb, true);
  }
  static fromColors(colors2) {
    return CorePalette.createPaletteFromColors(false, colors2);
  }
  static contentFromColors(colors2) {
    return CorePalette.createPaletteFromColors(true, colors2);
  }
  static createPaletteFromColors(content, colors2) {
    const palette = new CorePalette(colors2.primary, content);
    if (colors2.secondary) {
      const p = new CorePalette(colors2.secondary, content);
      palette.a2 = p.a1;
    }
    if (colors2.tertiary) {
      const p = new CorePalette(colors2.tertiary, content);
      palette.a3 = p.a1;
    }
    if (colors2.error) {
      const p = new CorePalette(colors2.error, content);
      palette.error = p.a1;
    }
    if (colors2.neutral) {
      const p = new CorePalette(colors2.neutral, content);
      palette.n1 = p.n1;
    }
    if (colors2.neutralVariant) {
      const p = new CorePalette(colors2.neutralVariant, content);
      palette.n2 = p.n2;
    }
    return palette;
  }
  constructor(argb, isContent) {
    const hct = Hct.fromInt(argb), hue = hct.hue, chroma = hct.chroma;
    isContent ? (this.a1 = TonalPalette.fromHueAndChroma(hue, chroma), this.a2 = TonalPalette.fromHueAndChroma(hue, chroma / 3), this.a3 = TonalPalette.fromHueAndChroma(hue + 60, chroma / 2), this.n1 = TonalPalette.fromHueAndChroma(hue, Math.min(chroma / 12, 4)), this.n2 = TonalPalette.fromHueAndChroma(hue, Math.min(chroma / 6, 8))) : (this.a1 = TonalPalette.fromHueAndChroma(hue, Math.max(48, chroma)), this.a2 = TonalPalette.fromHueAndChroma(hue, 16), this.a3 = TonalPalette.fromHueAndChroma(hue + 60, 24), this.n1 = TonalPalette.fromHueAndChroma(hue, 4), this.n2 = TonalPalette.fromHueAndChroma(hue, 8)), this.error = TonalPalette.fromHueAndChroma(25, 84);
  }
}
class Scheme {
  get primary() {
    return this.props.primary;
  }
  get onPrimary() {
    return this.props.onPrimary;
  }
  get primaryContainer() {
    return this.props.primaryContainer;
  }
  get onPrimaryContainer() {
    return this.props.onPrimaryContainer;
  }
  get secondary() {
    return this.props.secondary;
  }
  get onSecondary() {
    return this.props.onSecondary;
  }
  get secondaryContainer() {
    return this.props.secondaryContainer;
  }
  get onSecondaryContainer() {
    return this.props.onSecondaryContainer;
  }
  get tertiary() {
    return this.props.tertiary;
  }
  get onTertiary() {
    return this.props.onTertiary;
  }
  get tertiaryContainer() {
    return this.props.tertiaryContainer;
  }
  get onTertiaryContainer() {
    return this.props.onTertiaryContainer;
  }
  get error() {
    return this.props.error;
  }
  get onError() {
    return this.props.onError;
  }
  get errorContainer() {
    return this.props.errorContainer;
  }
  get onErrorContainer() {
    return this.props.onErrorContainer;
  }
  get background() {
    return this.props.background;
  }
  get onBackground() {
    return this.props.onBackground;
  }
  get surface() {
    return this.props.surface;
  }
  get onSurface() {
    return this.props.onSurface;
  }
  get surfaceVariant() {
    return this.props.surfaceVariant;
  }
  get onSurfaceVariant() {
    return this.props.onSurfaceVariant;
  }
  get outline() {
    return this.props.outline;
  }
  get outlineVariant() {
    return this.props.outlineVariant;
  }
  get shadow() {
    return this.props.shadow;
  }
  get scrim() {
    return this.props.scrim;
  }
  get inverseSurface() {
    return this.props.inverseSurface;
  }
  get inverseOnSurface() {
    return this.props.inverseOnSurface;
  }
  get inversePrimary() {
    return this.props.inversePrimary;
  }
  static light(argb) {
    return Scheme.lightFromCorePalette(CorePalette.of(argb));
  }
  static dark(argb) {
    return Scheme.darkFromCorePalette(CorePalette.of(argb));
  }
  static lightContent(argb) {
    return Scheme.lightFromCorePalette(CorePalette.contentOf(argb));
  }
  static darkContent(argb) {
    return Scheme.darkFromCorePalette(CorePalette.contentOf(argb));
  }
  static lightFromCorePalette(core) {
    return new Scheme({
      primary: core.a1.tone(40),
      onPrimary: core.a1.tone(100),
      primaryContainer: core.a1.tone(90),
      onPrimaryContainer: core.a1.tone(10),
      secondary: core.a2.tone(40),
      onSecondary: core.a2.tone(100),
      secondaryContainer: core.a2.tone(90),
      onSecondaryContainer: core.a2.tone(10),
      tertiary: core.a3.tone(40),
      onTertiary: core.a3.tone(100),
      tertiaryContainer: core.a3.tone(90),
      onTertiaryContainer: core.a3.tone(10),
      error: core.error.tone(40),
      onError: core.error.tone(100),
      errorContainer: core.error.tone(90),
      onErrorContainer: core.error.tone(10),
      background: core.n1.tone(99),
      onBackground: core.n1.tone(10),
      surface: core.n1.tone(99),
      onSurface: core.n1.tone(10),
      surfaceVariant: core.n2.tone(90),
      onSurfaceVariant: core.n2.tone(30),
      outline: core.n2.tone(50),
      outlineVariant: core.n2.tone(80),
      shadow: core.n1.tone(0),
      scrim: core.n1.tone(0),
      inverseSurface: core.n1.tone(20),
      inverseOnSurface: core.n1.tone(95),
      inversePrimary: core.a1.tone(80)
    });
  }
  static darkFromCorePalette(core) {
    return new Scheme({
      primary: core.a1.tone(80),
      onPrimary: core.a1.tone(20),
      primaryContainer: core.a1.tone(30),
      onPrimaryContainer: core.a1.tone(90),
      secondary: core.a2.tone(80),
      onSecondary: core.a2.tone(20),
      secondaryContainer: core.a2.tone(30),
      onSecondaryContainer: core.a2.tone(90),
      tertiary: core.a3.tone(80),
      onTertiary: core.a3.tone(20),
      tertiaryContainer: core.a3.tone(30),
      onTertiaryContainer: core.a3.tone(90),
      error: core.error.tone(80),
      onError: core.error.tone(20),
      errorContainer: core.error.tone(30),
      onErrorContainer: core.error.tone(80),
      background: core.n1.tone(10),
      onBackground: core.n1.tone(90),
      surface: core.n1.tone(10),
      onSurface: core.n1.tone(90),
      surfaceVariant: core.n2.tone(30),
      onSurfaceVariant: core.n2.tone(80),
      outline: core.n2.tone(60),
      outlineVariant: core.n2.tone(30),
      shadow: core.n1.tone(0),
      scrim: core.n1.tone(0),
      inverseSurface: core.n1.tone(90),
      inverseOnSurface: core.n1.tone(20),
      inversePrimary: core.a1.tone(40)
    });
  }
  constructor(props) {
    this.props = props;
  }
  toJSON() {
    return {
      ...this.props
    };
  }
}
function hexFromArgb(argb) {
  const r = redFromArgb(argb), g = greenFromArgb(argb), b = blueFromArgb(argb), outParts = [r.toString(16), g.toString(16), b.toString(16)];
  for (const [i, part] of outParts.entries()) 1 === part.length && (outParts[i] = "0" + part);
  return "#" + outParts.join("");
}
function argbFromHex(hex) {
  const isThree = 3 === (hex = hex.replace("#", "")).length, isSix = 6 === hex.length, isEight = 8 === hex.length;
  if (!isThree && !isSix && !isEight) throw new Error("unexpected hex " + hex);
  let r = 0, g = 0, b = 0;
  return isThree ? (r = parseIntHex(hex.slice(0, 1).repeat(2)), g = parseIntHex(hex.slice(1, 2).repeat(2)), b = parseIntHex(hex.slice(2, 3).repeat(2))) : isSix ? (r = parseIntHex(hex.slice(0, 2)), g = parseIntHex(hex.slice(2, 4)), b = parseIntHex(hex.slice(4, 6))) : isEight && (r = parseIntHex(hex.slice(2, 4)), g = parseIntHex(hex.slice(4, 6)), b = parseIntHex(hex.slice(6, 8))), (255 << 24 | (255 & r) << 16 | (255 & g) << 8 | 255 & b) >>> 0;
}
function parseIntHex(value2) {
  return parseInt(value2, 16);
}
function themeFromSourceColor(source, customColors) {
  if (customColors === void 0) {
    customColors = [];
  }
  const palette = CorePalette.of(source);
  return {
    source,
    schemes: {
      light: Scheme.light(source),
      dark: Scheme.dark(source)
    },
    palettes: {
      primary: palette.a1,
      secondary: palette.a2,
      tertiary: palette.a3,
      neutral: palette.n1,
      neutralVariant: palette.n2,
      error: palette.error
    },
    customColors: customColors.map((c) => customColor(source, c))
  };
}
function customColor(source, color) {
  let value2 = color.value;
  const from = value2, to = source;
  color.blend && (value2 = Blend.harmonize(from, to));
  const tones = CorePalette.of(value2).a1;
  return {
    color,
    value: value2,
    light: {
      color: tones.tone(40),
      onColor: tones.tone(100),
      colorContainer: tones.tone(90),
      onColorContainer: tones.tone(10)
    },
    dark: {
      color: tones.tone(80),
      onColor: tones.tone(20),
      colorContainer: tones.tone(30),
      onColorContainer: tones.tone(90)
    }
  };
}
function toRGBA(d) {
  const r = Math.round;
  const l = d.length;
  const rgba = {};
  if (d.slice(0, 3).toLowerCase() === "rgb") {
    d = d.replace(" ", "").split(",");
    rgba[0] = parseInt(d[0].slice(d[3].toLowerCase() === "a" ? 5 : 4), 10);
    rgba[1] = parseInt(d[1], 10);
    rgba[2] = parseInt(d[2], 10);
    rgba[3] = d[3] ? parseFloat(d[3]) : -1;
  } else {
    if (l < 6) d = parseInt(String(d[1]) + d[1] + d[2] + d[2] + d[3] + d[3] + (l > 4 ? String(d[4]) + d[4] : ""), 16);
    else d = parseInt(d.slice(1), 16);
    rgba[0] = d >> 16 & 255;
    rgba[1] = d >> 8 & 255;
    rgba[2] = d & 255;
    rgba[3] = l === 9 || l === 5 ? r((d >> 24 & 255) / 255 * 1e4) / 1e4 : -1;
  }
  return rgba;
}
function blend(from, to, p) {
  if (p === void 0) {
    p = 0.5;
  }
  const r = Math.round;
  from = from.trim();
  to = to.trim();
  const b = p < 0;
  p = b ? p * -1 : p;
  const f = toRGBA(from);
  const t = toRGBA(to);
  if (to[0] === "r") {
    return "rgb" + (to[3] === "a" ? "a(" : "(") + r((t[0] - f[0]) * p + f[0]) + "," + r((t[1] - f[1]) * p + f[1]) + "," + r((t[2] - f[2]) * p + f[2]) + (f[3] < 0 && t[3] < 0 ? "" : "," + (f[3] > -1 && t[3] > -1 ? r(((t[3] - f[3]) * p + f[3]) * 1e4) / 1e4 : t[3] < 0 ? f[3] : t[3])) + ")";
  }
  return "#" + (4294967296 + (f[3] > -1 && t[3] > -1 ? r(((t[3] - f[3]) * p + f[3]) * 255) : t[3] > -1 ? r(t[3] * 255) : f[3] > -1 ? r(f[3] * 255) : 255) * 16777216 + r((t[0] - f[0]) * p + f[0]) * 65536 + r((t[1] - f[1]) * p + f[1]) * 256 + r((t[2] - f[2]) * p + f[2])).toString(16).slice(f[3] > -1 || t[3] > -1 ? 1 : 3);
}
const materialColors = function(hexColor) {
  if (hexColor === void 0) {
    hexColor = "";
  }
  const theme2 = themeFromSourceColor(argbFromHex(`#${hexColor.replace("#", "")}`));
  [0.05, 0.08, 0.11, 0.12, 0.14].forEach((amount, index2) => {
    theme2.schemes.light.props[`surface${index2 + 1}`] = argbFromHex(blend(hexFromArgb(theme2.schemes.light.props.surface), hexFromArgb(theme2.schemes.light.props.primary), amount));
    theme2.schemes.dark.props[`surface${index2 + 1}`] = argbFromHex(blend(hexFromArgb(theme2.schemes.dark.props.surface), hexFromArgb(theme2.schemes.dark.props.primary), amount));
  });
  const name2 = (n) => {
    return n.split("").map((char) => char.toUpperCase() === char && char !== "-" && char !== "7" ? `-${char.toLowerCase()}` : char).join("");
  };
  const shouldSkip = (prop2) => {
    const skip = ["tertiary", "shadow", "scrim", "error", "background"];
    return skip.filter((v) => prop2.toLowerCase().includes(v)).length > 0;
  };
  const light = {};
  const dark = {};
  Object.keys(theme2.schemes.light.props).forEach((prop2) => {
    if (shouldSkip(prop2)) return;
    light[name2(`--f7-md-${prop2}`)] = hexFromArgb(theme2.schemes.light.props[prop2]);
  });
  Object.keys(theme2.schemes.dark.props).forEach((prop2) => {
    if (shouldSkip(prop2)) return;
    dark[name2(`--f7-md-${prop2}`)] = hexFromArgb(theme2.schemes.dark.props[prop2]);
  });
  return {
    light,
    dark
  };
};
let uniqueNum = 0;
function uniqueNumber() {
  uniqueNum += 1;
  return uniqueNum;
}
function id(mask, map) {
  if (mask === void 0) {
    mask = "xxxxxxxxxx";
  }
  if (map === void 0) {
    map = "0123456789abcdef";
  }
  const length = map.length;
  return mask.replace(/x/g, () => map[Math.floor(Math.random() * length)]);
}
const mdPreloaderContent = `
  <span class="preloader-inner">
    <svg viewBox="0 0 36 36">
      <circle cx="18" cy="18" r="16"></circle>
    </svg>
  </span>
`.trim();
const iosPreloaderContent = `
  <span class="preloader-inner">
    ${[0, 1, 2, 3, 4, 5, 6, 7].map(() => '<span class="preloader-inner-line"></span>').join("")}
  </span>
`.trim();
function eventNameToColonCase(eventName) {
  let hasColon;
  return eventName.split("").map((char, index2) => {
    if (char.match(/[A-Z]/) && index2 !== 0 && !hasColon) {
      hasColon = true;
      return `:${char.toLowerCase()}`;
    }
    return char.toLowerCase();
  }).join("");
}
function deleteProps(obj) {
  const object = obj;
  Object.keys(object).forEach((key) => {
    try {
      object[key] = null;
    } catch (e) {
    }
    try {
      delete object[key];
    } catch (e) {
    }
  });
}
function requestAnimationFrame(callback) {
  const window2 = getWindow();
  return window2.requestAnimationFrame(callback);
}
function cancelAnimationFrame(frameId) {
  const window2 = getWindow();
  return window2.cancelAnimationFrame(frameId);
}
function nextTick(callback, delay) {
  if (delay === void 0) {
    delay = 0;
  }
  return setTimeout(callback, delay);
}
function nextFrame(callback) {
  return requestAnimationFrame(() => {
    requestAnimationFrame(callback);
  });
}
function now$1() {
  return Date.now();
}
function parseUrlQuery(url) {
  const window2 = getWindow();
  const query = {};
  let urlToParse = url || window2.location.href;
  let i;
  let params;
  let param;
  let length;
  if (typeof urlToParse === "string" && urlToParse.length) {
    urlToParse = urlToParse.indexOf("?") > -1 ? urlToParse.replace(/\S*\?/, "") : "";
    params = urlToParse.split("&").filter((paramsPart) => paramsPart !== "");
    length = params.length;
    for (i = 0; i < length; i += 1) {
      param = params[i].replace(/#\S+/g, "").split("=");
      query[decodeURIComponent(param[0])] = typeof param[1] === "undefined" ? void 0 : decodeURIComponent(param.slice(1).join("=")) || "";
    }
  }
  return query;
}
function getTranslate(el, axis) {
  if (axis === void 0) {
    axis = "x";
  }
  const window2 = getWindow();
  let matrix;
  let curTransform;
  let transformMatrix;
  const curStyle = window2.getComputedStyle(el, null);
  if (window2.WebKitCSSMatrix) {
    curTransform = curStyle.transform || curStyle.webkitTransform;
    if (curTransform.split(",").length > 6) {
      curTransform = curTransform.split(", ").map((a) => a.replace(",", ".")).join(", ");
    }
    transformMatrix = new window2.WebKitCSSMatrix(curTransform === "none" ? "" : curTransform);
  } else {
    transformMatrix = curStyle.MozTransform || curStyle.OTransform || curStyle.MsTransform || curStyle.msTransform || curStyle.transform || curStyle.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,");
    matrix = transformMatrix.toString().split(",");
  }
  if (axis === "x") {
    if (window2.WebKitCSSMatrix) curTransform = transformMatrix.m41;
    else if (matrix.length === 16) curTransform = parseFloat(matrix[12]);
    else curTransform = parseFloat(matrix[4]);
  }
  if (axis === "y") {
    if (window2.WebKitCSSMatrix) curTransform = transformMatrix.m42;
    else if (matrix.length === 16) curTransform = parseFloat(matrix[13]);
    else curTransform = parseFloat(matrix[5]);
  }
  return curTransform || 0;
}
function serializeObject(obj, parents2) {
  if (parents2 === void 0) {
    parents2 = [];
  }
  if (typeof obj === "string") return obj;
  const resultArray = [];
  const separator = "&";
  let newParents;
  function varName(name2) {
    if (parents2.length > 0) {
      let parentParts = "";
      for (let j = 0; j < parents2.length; j += 1) {
        if (j === 0) parentParts += parents2[j];
        else parentParts += `[${encodeURIComponent(parents2[j])}]`;
      }
      return `${parentParts}[${encodeURIComponent(name2)}]`;
    }
    return encodeURIComponent(name2);
  }
  function varValue(value2) {
    return encodeURIComponent(value2);
  }
  Object.keys(obj).forEach((prop2) => {
    let toPush;
    if (Array.isArray(obj[prop2])) {
      toPush = [];
      for (let i = 0; i < obj[prop2].length; i += 1) {
        if (!Array.isArray(obj[prop2][i]) && typeof obj[prop2][i] === "object") {
          newParents = parents2.slice();
          newParents.push(prop2);
          newParents.push(String(i));
          toPush.push(serializeObject(obj[prop2][i], newParents));
        } else {
          toPush.push(`${varName(prop2)}[]=${varValue(obj[prop2][i])}`);
        }
      }
      if (toPush.length > 0) resultArray.push(toPush.join(separator));
    } else if (obj[prop2] === null || obj[prop2] === "") {
      resultArray.push(`${varName(prop2)}=`);
    } else if (typeof obj[prop2] === "object") {
      newParents = parents2.slice();
      newParents.push(prop2);
      toPush = serializeObject(obj[prop2], newParents);
      if (toPush !== "") resultArray.push(toPush);
    } else if (typeof obj[prop2] !== "undefined" && obj[prop2] !== "") {
      resultArray.push(`${varName(prop2)}=${varValue(obj[prop2])}`);
    } else if (obj[prop2] === "") resultArray.push(varName(prop2));
  });
  return resultArray.join(separator);
}
function isObject$1(o) {
  return typeof o === "object" && o !== null && o.constructor && o.constructor === Object;
}
function merge() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }
  const to = args[0];
  args.splice(0, 1);
  const from = args;
  for (let i = 0; i < from.length; i += 1) {
    const nextSource = args[i];
    if (nextSource !== void 0 && nextSource !== null) {
      const keysArray = Object.keys(Object(nextSource));
      for (let nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex += 1) {
        const nextKey = keysArray[nextIndex];
        const desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
        if (desc !== void 0 && desc.enumerable) {
          to[nextKey] = nextSource[nextKey];
        }
      }
    }
  }
  return to;
}
function extend$1() {
  let deep = true;
  let to;
  let from;
  for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    args[_key2] = arguments[_key2];
  }
  if (typeof args[0] === "boolean") {
    deep = args[0];
    to = args[1];
    args.splice(0, 2);
    from = args;
  } else {
    to = args[0];
    args.splice(0, 1);
    from = args;
  }
  for (let i = 0; i < from.length; i += 1) {
    const nextSource = args[i];
    if (nextSource !== void 0 && nextSource !== null) {
      const keysArray = Object.keys(Object(nextSource));
      for (let nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex += 1) {
        const nextKey = keysArray[nextIndex];
        const desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
        if (desc !== void 0 && desc.enumerable) {
          if (!deep) {
            to[nextKey] = nextSource[nextKey];
          } else if (isObject$1(to[nextKey]) && isObject$1(nextSource[nextKey])) {
            extend$1(to[nextKey], nextSource[nextKey]);
          } else if (!isObject$1(to[nextKey]) && isObject$1(nextSource[nextKey])) {
            to[nextKey] = {};
            extend$1(to[nextKey], nextSource[nextKey]);
          } else {
            to[nextKey] = nextSource[nextKey];
          }
        }
      }
    }
  }
  return to;
}
function colorHexToRgb(hex) {
  const h = hex.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, (m, r, g, b) => r + r + g + g + b + b);
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(h);
  return result ? result.slice(1).map((n) => parseInt(n, 16)) : null;
}
function colorRgbToHex(r, g, b) {
  const result = [r, g, b].map((n) => {
    const hex = n.toString(16);
    return hex.length === 1 ? `0${hex}` : hex;
  }).join("");
  return `#${result}`;
}
function colorRgbToHsl(r, g, b) {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  let h;
  if (d === 0) h = 0;
  else if (max === r) h = (g - b) / d % 6;
  else if (max === g) h = (b - r) / d + 2;
  else if (max === b) h = (r - g) / d + 4;
  const l = (min + max) / 2;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  if (h < 0) h = 360 / 60 + h;
  return [h * 60, s, l];
}
function colorHslToRgb(h, s, l) {
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const hp = h / 60;
  const x = c * (1 - Math.abs(hp % 2 - 1));
  let rgb1;
  if (Number.isNaN(h) || typeof h === "undefined") {
    rgb1 = [0, 0, 0];
  } else if (hp <= 1) rgb1 = [c, x, 0];
  else if (hp <= 2) rgb1 = [x, c, 0];
  else if (hp <= 3) rgb1 = [0, c, x];
  else if (hp <= 4) rgb1 = [0, x, c];
  else if (hp <= 5) rgb1 = [x, 0, c];
  else if (hp <= 6) rgb1 = [c, 0, x];
  const m = l - c / 2;
  return rgb1.map((n) => Math.max(0, Math.min(255, Math.round(255 * (n + m)))));
}
function colorHsbToHsl(h, s, b) {
  const HSL = {
    h,
    s: 0,
    l: 0
  };
  const HSB = {
    h,
    s,
    b
  };
  HSL.l = (2 - HSB.s) * HSB.b / 2;
  HSL.s = HSL.l && HSL.l < 1 ? HSB.s * HSB.b / (HSL.l < 0.5 ? HSL.l * 2 : 2 - HSL.l * 2) : HSL.s;
  return [HSL.h, HSL.s, HSL.l];
}
function colorHslToHsb(h, s, l) {
  const HSB = {
    h,
    s: 0,
    b: 0
  };
  const HSL = {
    h,
    s,
    l
  };
  const t = HSL.s * (HSL.l < 0.5 ? HSL.l : 1 - HSL.l);
  HSB.b = HSL.l + t;
  HSB.s = HSL.l > 0 ? 2 * t / HSB.b : HSB.s;
  return [HSB.h, HSB.s, HSB.b];
}
const getShadeTintColors = (rgb) => {
  const hsl = colorRgbToHsl(...rgb);
  const hslShade = [hsl[0], hsl[1], Math.max(0, hsl[2] - 0.08)];
  const hslTint = [hsl[0], hsl[1], Math.max(0, hsl[2] + 0.08)];
  const shade = colorRgbToHex(...colorHslToRgb(...hslShade));
  const tint = colorRgbToHex(...colorHslToRgb(...hslTint));
  return {
    shade,
    tint
  };
};
function colorThemeCSSProperties() {
  let hex;
  let rgb;
  for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    args[_key3] = arguments[_key3];
  }
  if (args.length === 1) {
    hex = args[0];
    rgb = colorHexToRgb(hex);
  } else if (args.length === 3) {
    rgb = args;
    hex = colorRgbToHex(...rgb);
  }
  if (!rgb) return {};
  const {
    light,
    dark
  } = materialColors(hex);
  const shadeTintIos = getShadeTintColors(rgb);
  const shadeTintMdLight = getShadeTintColors(colorHexToRgb(light["--f7-md-primary"]));
  const shadeTintMdDark = getShadeTintColors(colorHexToRgb(dark["--f7-md-primary"]));
  Object.keys(light).forEach((key) => {
    if (key.includes("surface-")) {
      light[`${key}-rgb`] = colorHexToRgb(light[key]);
    }
  });
  Object.keys(dark).forEach((key) => {
    if (key.includes("surface-")) {
      dark[`${key}-rgb`] = colorHexToRgb(dark[key]);
    }
  });
  return {
    ios: {
      "--f7-theme-color": "var(--f7-ios-primary)",
      "--f7-theme-color-rgb": "var(--f7-ios-primary-rgb)",
      "--f7-theme-color-shade": "var(--f7-ios-primary-shade)",
      "--f7-theme-color-tint": "var(--f7-ios-primary-tint)"
    },
    md: {
      "--f7-theme-color": "var(--f7-md-primary)",
      "--f7-theme-color-rgb": "var(--f7-md-primary-rgb)",
      "--f7-theme-color-shade": "var(--f7-md-primary-shade)",
      "--f7-theme-color-tint": "var(--f7-md-primary-tint)"
    },
    light: {
      "--f7-ios-primary": hex,
      "--f7-ios-primary-shade": shadeTintIos.shade,
      "--f7-ios-primary-tint": shadeTintIos.tint,
      "--f7-ios-primary-rgb": rgb.join(", "),
      "--f7-md-primary-shade": shadeTintMdLight.shade,
      "--f7-md-primary-tint": shadeTintMdLight.tint,
      "--f7-md-primary-rgb": colorHexToRgb(light["--f7-md-primary"]).join(", "),
      ...light
    },
    dark: {
      "--f7-md-primary-shade": shadeTintMdDark.shade,
      "--f7-md-primary-tint": shadeTintMdDark.tint,
      "--f7-md-primary-rgb": colorHexToRgb(dark["--f7-md-primary"]).join(", "),
      ...dark
    }
  };
}
function bindMethods(instance, obj) {
  Object.keys(obj).forEach((key) => {
    if (isObject$1(obj[key])) {
      Object.keys(obj[key]).forEach((subKey) => {
        if (typeof obj[key][subKey] === "function") {
          obj[key][subKey] = obj[key][subKey].bind(instance);
        }
      });
    }
    instance[key] = obj[key];
  });
}
function flattenArray$1() {
  const arr = [];
  for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
    args[_key4] = arguments[_key4];
  }
  args.forEach((arg) => {
    if (Array.isArray(arg)) arr.push(...flattenArray$1(...arg));
    else arr.push(arg);
  });
  return arr;
}
function colorThemeCSSStyles(colors2) {
  if (colors2 === void 0) {
    colors2 = {};
  }
  const stringifyObject = (obj) => {
    let res = "";
    Object.keys(obj).forEach((key) => {
      res += `${key}:${obj[key]};`;
    });
    return res;
  };
  const colorVars = colorThemeCSSProperties(colors2.primary);
  const primary2 = [`:root{`, stringifyObject(colorVars.light), `--swiper-theme-color:var(--f7-theme-color);`, ...Object.keys(colors2).map((colorName) => `--f7-color-${colorName}: ${colors2[colorName]};`), `}`, `.dark{`, stringifyObject(colorVars.dark), `}`, `.ios, .ios .dark{`, stringifyObject(colorVars.ios), "}", `.md, .md .dark{`, stringifyObject(colorVars.md), "}"].join("");
  const restVars = {};
  Object.keys(colors2).forEach((colorName) => {
    const colorValue = colors2[colorName];
    restVars[colorName] = colorThemeCSSProperties(colorValue);
  });
  let rest = "";
  Object.keys(colors2).forEach((colorName) => {
    const {
      light,
      dark,
      ios,
      md
    } = restVars[colorName];
    const whiteColorVars = `
    --f7-ios-primary: #ffffff;
    --f7-ios-primary-shade: #ebebeb;
    --f7-ios-primary-tint: #ffffff;
    --f7-ios-primary-rgb: 255, 255, 255;
    --f7-md-primary-shade: #eee;
    --f7-md-primary-tint: #fff;
    --f7-md-primary-rgb: 255, 255, 255;
    --f7-md-primary: #fff;
    --f7-md-on-primary: #000;
    --f7-md-primary-container: #fff;
    --f7-md-on-primary-container: #000;
    --f7-md-secondary: #fff;
    --f7-md-on-secondary: #000;
    --f7-md-secondary-container: #555;
    --f7-md-on-secondary-container: #fff;
    --f7-md-surface: #fff;
    --f7-md-on-surface: #000;
    --f7-md-surface-variant: #333;
    --f7-md-on-surface-variant: #fff;
    --f7-md-outline: #fff;
    --f7-md-outline-variant: #fff;
    --f7-md-inverse-surface: #000;
    --f7-md-inverse-on-surface: #fff;
    --f7-md-inverse-primary: #000;
    --f7-md-surface-1: #f8f8f8;
    --f7-md-surface-2: #f1f1f1;
    --f7-md-surface-3: #e7e7e7;
    --f7-md-surface-4: #e1e1e1;
    --f7-md-surface-5: #d7d7d7;
    --f7-md-surface-variant-rgb: 51, 51, 51;
    --f7-md-on-surface-variant-rgb: 255, 255, 255;
    --f7-md-surface-1-rgb: 248, 248, 248;
    --f7-md-surface-2-rgb: 241, 241, 241;
    --f7-md-surface-3-rgb: 231, 231, 231;
    --f7-md-surface-4-rgb: 225, 225, 225;
    --f7-md-surface-5-rgb: 215, 215, 215;
    `;
    const blackColorVars = `
    --f7-ios-primary: #000;
    --f7-ios-primary-shade: #000;
    --f7-ios-primary-tint: #232323;
    --f7-ios-primary-rgb: 0, 0, 0;
    --f7-md-primary-shade: #000;
    --f7-md-primary-tint: #232323;
    --f7-md-primary-rgb: 0, 0, 0;
    --f7-md-primary: #000;
    --f7-md-on-primary: #fff;
    --f7-md-primary-container: #000;
    --f7-md-on-primary-container: #fff;
    --f7-md-secondary: #000;
    --f7-md-on-secondary: #fff;
    --f7-md-secondary-container: #aaa;
    --f7-md-on-secondary-container: #000;
    --f7-md-surface: #000;
    --f7-md-on-surface: #fff;
    --f7-md-surface-variant: #ccc;
    --f7-md-on-surface-variant: #000;
    --f7-md-outline: #000;
    --f7-md-outline-variant: #000;
    --f7-md-inverse-surface: #fff;
    --f7-md-inverse-on-surface: #000;
    --f7-md-inverse-primary: #fff;
    --f7-md-surface-1: #070707;
    --f7-md-surface-2: #161616;
    --f7-md-surface-3: #232323;
    --f7-md-surface-4: #303030;
    --f7-md-surface-5: #373737;
    --f7-md-surface-variant-rgb: 204, 204, 204;
    --f7-md-on-surface-variant-rgb: 0, 0, 0;
    --f7-md-surface-1-rgb: 7, 7, 7;
    --f7-md-surface-2-rgb: 22, 22, 22;
    --f7-md-surface-3-rgb: 35, 35, 35;
    --f7-md-surface-4-rgb: 48, 48, 48;
    --f7-md-surface-5-rgb: 55, 55, 55;
    `;
    const lightString = colorName === "white" ? whiteColorVars : colorName === "black" ? blackColorVars : stringifyObject(light);
    const darkString = colorName === "white" ? whiteColorVars : colorName === "black" ? blackColorVars : stringifyObject(dark);
    rest += [
      `.color-${colorName} {`,
      lightString,
      `--swiper-theme-color: var(--f7-theme-color);`,
      `}`,
      `.color-${colorName}.dark, .color-${colorName} .dark, .dark .color-${colorName} {`,
      darkString,
      `--swiper-theme-color: var(--f7-theme-color);`,
      `}`,
      `.ios .color-${colorName}, .ios.color-${colorName}, .ios .dark .color-${colorName}, .ios .dark.color-${colorName} {`,
      stringifyObject(ios),
      `}`,
      `.md .color-${colorName}, .md.color-${colorName}, .md .dark .color-${colorName}, .md .dark.color-${colorName} {`,
      stringifyObject(md),
      `}`,
      // text color
      `.text-color-${colorName} {`,
      `--f7-theme-color-text-color: ${colors2[colorName]};`,
      `}`,
      // bg color
      `.bg-color-${colorName} {`,
      `--f7-theme-color-bg-color: ${colors2[colorName]};`,
      `}`,
      // border color
      `.border-color-${colorName} {`,
      `--f7-theme-color-border-color: ${colors2[colorName]};`,
      `}`,
      // ripple color
      `.ripple-color-${colorName} {`,
      `--f7-theme-color-ripple-color: rgba(${light["--f7-ios-primary-rgb"]}, 0.3);`,
      `}`
    ].join("");
  });
  return `${primary2}${rest}`;
}
const utils = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  bindMethods,
  cancelAnimationFrame,
  colorHexToRgb,
  colorHsbToHsl,
  colorHslToHsb,
  colorHslToRgb,
  colorRgbToHex,
  colorRgbToHsl,
  colorThemeCSSProperties,
  colorThemeCSSStyles,
  deleteProps,
  eventNameToColonCase,
  extend: extend$1,
  flattenArray: flattenArray$1,
  getTranslate,
  id,
  iosPreloaderContent,
  isObject: isObject$1,
  mdPreloaderContent,
  merge,
  nextFrame,
  nextTick,
  now: now$1,
  parseUrlQuery,
  requestAnimationFrame,
  serializeObject,
  uniqueNumber
}, Symbol.toStringTag, { value: "Module" }));
let support;
function calcSupport() {
  const window2 = getWindow();
  const document2 = getDocument();
  return {
    touch: !!("ontouchstart" in window2 || window2.DocumentTouch && document2 instanceof window2.DocumentTouch),
    pointerEvents: !!window2.PointerEvent && "maxTouchPoints" in window2.navigator && window2.navigator.maxTouchPoints >= 0,
    passiveListener: function checkPassiveListener() {
      let supportsPassive = false;
      try {
        const opts = Object.defineProperty({}, "passive", {
          // eslint-disable-next-line
          get() {
            supportsPassive = true;
          }
        });
        window2.addEventListener("testPassiveListener", null, opts);
      } catch (e) {
      }
      return supportsPassive;
    }(),
    intersectionObserver: function checkObserver() {
      return "IntersectionObserver" in window2;
    }()
  };
}
function getSupport() {
  if (!support) {
    support = calcSupport();
  }
  return support;
}
let deviceCalculated;
function calcDevice(_temp) {
  let {
    userAgent
  } = _temp === void 0 ? {} : _temp;
  const support2 = getSupport();
  const window2 = getWindow();
  const platform = window2.navigator.platform;
  const ua = userAgent || window2.navigator.userAgent;
  const device = {
    ios: false,
    android: false,
    androidChrome: false,
    desktop: false,
    iphone: false,
    ipod: false,
    ipad: false,
    edge: false,
    ie: false,
    firefox: false,
    macos: false,
    windows: false,
    cordova: !!window2.cordova,
    electron: false,
    capacitor: !!window2.Capacitor,
    nwjs: false
  };
  const screenWidth = window2.screen.width;
  const screenHeight = window2.screen.height;
  const android = ua.match(/(Android);?[\s\/]+([\d.]+)?/);
  let ipad = ua.match(/(iPad).*OS\s([\d_]+)/);
  const ipod = ua.match(/(iPod)(.*OS\s([\d_]+))?/);
  const iphone = !ipad && ua.match(/(iPhone\sOS|iOS|iPhone;\sCPU\sOS)\s([\d_]+)/);
  const ie = ua.indexOf("MSIE ") >= 0 || ua.indexOf("Trident/") >= 0;
  const edge = ua.indexOf("Edge/") >= 0;
  const firefox = ua.indexOf("Gecko/") >= 0 && ua.indexOf("Firefox/") >= 0;
  const windows = platform === "Win32";
  const electron = ua.toLowerCase().indexOf("electron") >= 0;
  const nwjs = typeof nw !== "undefined" && typeof process !== "undefined" && typeof process.versions !== "undefined" && typeof process.versions.nw !== "undefined";
  let macos = platform === "MacIntel";
  const iPadScreens = ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"];
  if (!ipad && macos && support2.touch && iPadScreens.indexOf(`${screenWidth}x${screenHeight}`) >= 0) {
    ipad = ua.match(/(Version)\/([\d.]+)/);
    if (!ipad) ipad = [0, 1, "13_0_0"];
    macos = false;
  }
  device.ie = ie;
  device.edge = edge;
  device.firefox = firefox;
  if (android) {
    device.os = "android";
    device.osVersion = android[2];
    device.android = true;
    device.androidChrome = ua.toLowerCase().indexOf("chrome") >= 0;
  }
  if (ipad || iphone || ipod) {
    device.os = "ios";
    device.ios = true;
  }
  if (iphone && !ipod) {
    device.osVersion = iphone[2].replace(/_/g, ".");
    device.iphone = true;
  }
  if (ipad) {
    device.osVersion = ipad[2].replace(/_/g, ".");
    device.ipad = true;
  }
  if (ipod) {
    device.osVersion = ipod[3] ? ipod[3].replace(/_/g, ".") : null;
    device.ipod = true;
  }
  if (device.ios && device.osVersion && ua.indexOf("Version/") >= 0) {
    if (device.osVersion.split(".")[0] === "10") {
      device.osVersion = ua.toLowerCase().split("version/")[1].split(" ")[0];
    }
  }
  device.webView = !!((iphone || ipad || ipod) && (ua.match(/.*AppleWebKit(?!.*Safari)/i) || window2.navigator.standalone)) || window2.matchMedia && window2.matchMedia("(display-mode: standalone)").matches;
  device.webview = device.webView;
  device.standalone = device.webView;
  device.desktop = !(device.ios || device.android) || electron || nwjs;
  if (device.desktop) {
    device.electron = electron;
    device.nwjs = nwjs;
    device.macos = macos;
    device.windows = windows;
    if (device.macos) {
      device.os = "macos";
    }
    if (device.windows) {
      device.os = "windows";
    }
  }
  device.pixelRatio = window2.devicePixelRatio || 1;
  const DARK = "(prefers-color-scheme: dark)";
  const LIGHT = "(prefers-color-scheme: light)";
  device.prefersColorScheme = function prefersColorTheme() {
    let theme2;
    if (window2.matchMedia && window2.matchMedia(LIGHT).matches) {
      theme2 = "light";
    }
    if (window2.matchMedia && window2.matchMedia(DARK).matches) {
      theme2 = "dark";
    }
    return theme2;
  };
  return device;
}
const IS_BROWSER = (() => {
  const document2 = getDocument();
  try {
    return Boolean(document2 && document2.body && document2.body.getBoundingClientRect && document2.body.getBoundingClientRect().width > 0);
  } catch (e) {
    return false;
  }
})();
function getDevice(overrides, reset) {
  if (overrides === void 0) {
    overrides = {};
  }
  if (reset === void 0) {
    reset = IS_BROWSER;
  }
  if (!deviceCalculated || reset) {
    deviceCalculated = calcDevice(overrides);
  }
  return deviceCalculated;
}
class EventsClass {
  constructor(parents2) {
    if (parents2 === void 0) {
      parents2 = [];
    }
    const self = this;
    self.eventsParents = parents2;
    self.eventsListeners = {};
  }
  on(events, handler, priority) {
    const self = this;
    if (typeof handler !== "function") return self;
    const method = priority ? "unshift" : "push";
    events.split(" ").forEach((event) => {
      if (!self.eventsListeners[event]) self.eventsListeners[event] = [];
      self.eventsListeners[event][method](handler);
    });
    return self;
  }
  once(events, handler, priority) {
    const self = this;
    if (typeof handler !== "function") return self;
    function onceHandler() {
      self.off(events, onceHandler);
      if (onceHandler.f7proxy) {
        delete onceHandler.f7proxy;
      }
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      handler.apply(self, args);
    }
    onceHandler.f7proxy = handler;
    return self.on(events, onceHandler, priority);
  }
  off(events, handler) {
    const self = this;
    if (!self.eventsListeners) return self;
    events.split(" ").forEach((event) => {
      if (typeof handler === "undefined") {
        self.eventsListeners[event] = [];
      } else if (self.eventsListeners[event]) {
        self.eventsListeners[event].forEach((eventHandler, index2) => {
          if (eventHandler === handler || eventHandler.f7proxy && eventHandler.f7proxy === handler) {
            self.eventsListeners[event].splice(index2, 1);
          }
        });
      }
    });
    return self;
  }
  emit() {
    const self = this;
    if (!self.eventsListeners) return self;
    let events;
    let data2;
    let context;
    let eventsParents;
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    if (typeof args[0] === "string" || Array.isArray(args[0])) {
      events = args[0];
      data2 = args.slice(1, args.length);
      context = self;
      eventsParents = self.eventsParents;
    } else {
      events = args[0].events;
      data2 = args[0].data;
      context = args[0].context || self;
      eventsParents = args[0].local ? [] : args[0].parents || self.eventsParents;
    }
    const eventsArray = Array.isArray(events) ? events : events.split(" ");
    const localEvents = eventsArray.map((eventName) => eventName.replace("local::", ""));
    const parentEvents = eventsArray.filter((eventName) => eventName.indexOf("local::") < 0);
    localEvents.forEach((event) => {
      if (self.eventsListeners && self.eventsListeners[event]) {
        const handlers = [];
        self.eventsListeners[event].forEach((eventHandler) => {
          handlers.push(eventHandler);
        });
        handlers.forEach((eventHandler) => {
          eventHandler.apply(context, data2);
        });
      }
    });
    if (eventsParents && eventsParents.length > 0) {
      eventsParents.forEach((eventsParent) => {
        eventsParent.emit(parentEvents, ...data2);
      });
    }
    return self;
  }
}
class Framework7Class extends EventsClass {
  constructor(params, parents2) {
    if (params === void 0) {
      params = {};
    }
    if (parents2 === void 0) {
      parents2 = [];
    }
    super(parents2);
    const self = this;
    self.params = params;
    if (self.params && self.params.on) {
      Object.keys(self.params.on).forEach((eventName) => {
        self.on(eventName, self.params.on[eventName]);
      });
    }
  }
  // eslint-disable-next-line
  useModuleParams(module, instanceParams) {
    if (module.params) {
      const originalParams = {};
      Object.keys(module.params).forEach((paramKey) => {
        if (typeof instanceParams[paramKey] === "undefined") return;
        originalParams[paramKey] = extend$1({}, instanceParams[paramKey]);
      });
      extend$1(instanceParams, module.params);
      Object.keys(originalParams).forEach((paramKey) => {
        extend$1(instanceParams[paramKey], originalParams[paramKey]);
      });
    }
  }
  useModulesParams(instanceParams) {
    const instance = this;
    if (!instance.modules) return;
    Object.keys(instance.modules).forEach((moduleName) => {
      const module = instance.modules[moduleName];
      if (module.params) {
        extend$1(instanceParams, module.params);
      }
    });
  }
  useModule(moduleName, moduleParams) {
    if (moduleName === void 0) {
      moduleName = "";
    }
    if (moduleParams === void 0) {
      moduleParams = {};
    }
    const instance = this;
    if (!instance.modules) return;
    const module = typeof moduleName === "string" ? instance.modules[moduleName] : moduleName;
    if (!module) return;
    if (module.instance) {
      Object.keys(module.instance).forEach((modulePropName) => {
        const moduleProp = module.instance[modulePropName];
        if (typeof moduleProp === "function") {
          instance[modulePropName] = moduleProp.bind(instance);
        } else {
          instance[modulePropName] = moduleProp;
        }
      });
    }
    if (module.on && instance.on) {
      Object.keys(module.on).forEach((moduleEventName) => {
        instance.on(moduleEventName, module.on[moduleEventName]);
      });
    }
    if (module.vnode) {
      if (!instance.vnodeHooks) instance.vnodeHooks = {};
      Object.keys(module.vnode).forEach((vnodeId) => {
        Object.keys(module.vnode[vnodeId]).forEach((hookName) => {
          const handler = module.vnode[vnodeId][hookName];
          if (!instance.vnodeHooks[hookName]) instance.vnodeHooks[hookName] = {};
          if (!instance.vnodeHooks[hookName][vnodeId]) instance.vnodeHooks[hookName][vnodeId] = [];
          instance.vnodeHooks[hookName][vnodeId].push(handler.bind(instance));
        });
      });
    }
    if (module.create) {
      module.create.bind(instance)(moduleParams);
    }
  }
  useModules(modulesParams) {
    if (modulesParams === void 0) {
      modulesParams = {};
    }
    const instance = this;
    if (!instance.modules) return;
    Object.keys(instance.modules).forEach((moduleName) => {
      const moduleParams = modulesParams[moduleName] || {};
      instance.useModule(moduleName, moduleParams);
    });
  }
  static set components(components) {
    const Class = this;
    if (!Class.use) return;
    Class.use(components);
  }
  static installModule(module) {
    const Class = this;
    if (!Class.prototype.modules) Class.prototype.modules = {};
    const name2 = module.name || `${Object.keys(Class.prototype.modules).length}_${now$1()}`;
    Class.prototype.modules[name2] = module;
    if (module.proto) {
      Object.keys(module.proto).forEach((key) => {
        Class.prototype[key] = module.proto[key];
      });
    }
    if (module.static) {
      Object.keys(module.static).forEach((key) => {
        Class[key] = module.static[key];
      });
    }
    if (module.install) {
      for (var _len = arguments.length, params = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        params[_key - 1] = arguments[_key];
      }
      module.install.apply(Class, params);
    }
    return Class;
  }
  static use(module) {
    const Class = this;
    if (Array.isArray(module)) {
      module.forEach((m) => Class.installModule(m));
      return Class;
    }
    for (var _len2 = arguments.length, params = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
      params[_key2 - 1] = arguments[_key2];
    }
    return Class.installModule(module, ...params);
  }
}
function ConstructorMethods(parameters) {
  if (parameters === void 0) {
    parameters = {};
  }
  const {
    defaultSelector,
    constructor: Constructor,
    domProp,
    app,
    addMethods
  } = parameters;
  const methods2 = {
    create() {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      if (app) return new Constructor(app, ...args);
      return new Constructor(...args);
    },
    get(el) {
      if (el === void 0) {
        el = defaultSelector;
      }
      if (el instanceof Constructor) return el;
      const $el = $(el);
      if ($el.length === 0) return void 0;
      return $el[0][domProp];
    },
    destroy(el) {
      const instance = methods2.get(el);
      if (instance && instance.destroy) return instance.destroy();
      return void 0;
    }
  };
  if (addMethods && Array.isArray(addMethods)) {
    addMethods.forEach((methodName) => {
      methods2[methodName] = function(el) {
        if (el === void 0) {
          el = defaultSelector;
        }
        const instance = methods2.get(el);
        for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
          args[_key2 - 1] = arguments[_key2];
        }
        if (instance && instance[methodName]) return instance[methodName](...args);
        return void 0;
      };
    });
  }
  return methods2;
}
function ModalMethods(parameters) {
  if (parameters === void 0) {
    parameters = {};
  }
  const {
    defaultSelector,
    constructor: Constructor,
    app
  } = parameters;
  const methods2 = extend$1(ConstructorMethods({
    defaultSelector,
    constructor: Constructor,
    app,
    domProp: "f7Modal"
  }), {
    open(el, animate2, targetEl) {
      let $el = $(el);
      if ($el.length > 1 && targetEl) {
        const $targetPage = $(targetEl).parents(".page");
        if ($targetPage.length) {
          $el.each((modalEl) => {
            const $modalEl = $(modalEl);
            if ($modalEl.parents($targetPage)[0] === $targetPage[0]) {
              $el = $modalEl;
            }
          });
        }
      }
      if ($el.length > 1) {
        $el = $el.eq($el.length - 1);
      }
      if (!$el.length) return void 0;
      let instance = $el[0].f7Modal;
      if (!instance) {
        const params = $el.dataset();
        instance = new Constructor(app, {
          el: $el,
          ...params
        });
      }
      return instance.open(animate2);
    },
    close(el, animate2, targetEl) {
      if (el === void 0) {
        el = defaultSelector;
      }
      let $el = $(el);
      if (!$el.length) return void 0;
      if ($el.length > 1) {
        let $parentEl;
        if (targetEl) {
          const $targetEl = $(targetEl);
          if ($targetEl.length) {
            $parentEl = $targetEl.parents($el);
          }
        }
        if ($parentEl && $parentEl.length > 0) {
          $el = $parentEl;
        } else {
          $el = $el.eq($el.length - 1);
        }
      }
      let instance = $el[0].f7Modal;
      if (!instance) {
        const params = $el.dataset();
        instance = new Constructor(app, {
          el: $el,
          ...params
        });
      }
      return instance.close(animate2);
    }
  });
  return methods2;
}
const fetchedModules = [];
function loadModule(moduleToLoad) {
  const Framework72 = this;
  const window2 = getWindow();
  const document2 = getDocument();
  return new Promise((resolve, reject) => {
    const app = Framework72.instance;
    let modulePath;
    let moduleObj;
    let moduleFunc;
    if (!moduleToLoad) {
      reject(new Error("Framework7: Lazy module must be specified"));
      return;
    }
    function install(module) {
      Framework72.use(module);
      if (app) {
        app.useModuleParams(module, app.params);
        app.useModule(module);
      }
    }
    if (typeof moduleToLoad === "string") {
      const matchNamePattern = moduleToLoad.match(/([a-z0-9-]*)/i);
      if (moduleToLoad.indexOf(".") < 0 && matchNamePattern && matchNamePattern[0].length === moduleToLoad.length) {
        if (!app || app && !app.params.lazyModulesPath) {
          reject(new Error('Framework7: "lazyModulesPath" app parameter must be specified to fetch module by name'));
          return;
        }
        modulePath = `${app.params.lazyModulesPath}/${moduleToLoad}/${moduleToLoad}.lazy.js`;
      } else {
        modulePath = moduleToLoad;
      }
    } else if (typeof moduleToLoad === "function") {
      moduleFunc = moduleToLoad;
    } else {
      moduleObj = moduleToLoad;
    }
    if (moduleFunc) {
      const module = moduleFunc(Framework72, false);
      if (!module) {
        reject(new Error("Framework7: Can't find Framework7 component in specified component function"));
        return;
      }
      if (Framework72.prototype.modules && Framework72.prototype.modules[module.name]) {
        resolve();
        return;
      }
      install(module);
      resolve();
    }
    if (moduleObj) {
      const module = moduleObj;
      if (!module) {
        reject(new Error("Framework7: Can't find Framework7 component in specified component"));
        return;
      }
      if (Framework72.prototype.modules && Framework72.prototype.modules[module.name]) {
        resolve();
        return;
      }
      install(module);
      resolve();
    }
    if (modulePath) {
      if (fetchedModules.indexOf(modulePath) >= 0) {
        resolve();
        return;
      }
      fetchedModules.push(modulePath);
      const scriptLoad = new Promise((resolveScript, rejectScript) => {
        fetch(modulePath).then((res) => res.text()).then((scriptContent) => {
          const callbackId = id();
          const callbackLoadName = `f7_component_loader_callback_${callbackId}`;
          const scriptEl = document2.createElement("script");
          scriptEl.innerHTML = `window.${callbackLoadName} = function (Framework7, Framework7AutoInstallComponent) {return ${scriptContent.trim()}}`;
          $("head").append(scriptEl);
          const componentLoader = window2[callbackLoadName];
          delete window2[callbackLoadName];
          $(scriptEl).remove();
          const module = componentLoader(Framework72, false);
          if (!module) {
            rejectScript(new Error(`Framework7: Can't find Framework7 component in ${modulePath} file`));
            return;
          }
          if (Framework72.prototype.modules && Framework72.prototype.modules[module.name]) {
            resolveScript();
            return;
          }
          install(module);
          resolveScript();
        }).catch((err) => {
          rejectScript(err);
        });
      });
      const styleLoad = new Promise((resolveStyle) => {
        fetch(modulePath.replace(".lazy.js", app.rtl ? ".rtl.css" : ".css").replace(".js", app.rtl ? ".rtl.css" : ".css")).then((res) => res.text()).then((styleContent) => {
          const styleEl = document2.createElement("style");
          styleEl.innerHTML = styleContent;
          $("head").append(styleEl);
          resolveStyle();
        }).catch(() => {
          resolveStyle();
        });
      });
      Promise.all([scriptLoad, styleLoad]).then(() => {
        resolve();
      }).catch((err) => {
        reject(err);
      });
    }
  });
}
const $jsx = function(tag, props) {
  const attrs = props || {};
  for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
    args[_key - 2] = arguments[_key];
  }
  const children2 = args || [];
  const attrsString = Object.keys(attrs).map((attr2) => {
    if (attr2[0] === "_") {
      if (attrs[attr2]) return attr2.replace("_", "");
      return "";
    }
    return `${attr2}="${attrs[attr2]}"`;
  }).filter((attr2) => !!attr2).join(" ");
  if (["path", "img", "circle", "polygon", "line", "input"].indexOf(tag) >= 0) {
    return `<${tag} ${attrsString} />`.trim();
  }
  const childrenContent = children2.filter((c) => !!c).map((c) => Array.isArray(c) ? c.join("") : c).join("");
  return `<${tag} ${attrsString}>${childrenContent}</${tag}>`.trim();
};
class Framework7 extends Framework7Class {
  constructor(params) {
    if (params === void 0) {
      params = {};
    }
    super(params);
    if (Framework7.instance && typeof window !== "undefined") {
      throw new Error("Framework7 is already initialized and can't be initialized more than once");
    }
    const device = getDevice({
      userAgent: params.userAgent || void 0
    });
    const support2 = getSupport();
    const passedParams = extend$1({}, params);
    const app = this;
    app.device = device;
    app.support = support2;
    const w = getWindow();
    const d = getDocument();
    Framework7.instance = app;
    const defaults = {
      el: "body",
      theme: "auto",
      routes: [],
      name: "Framework7",
      lazyModulesPath: null,
      initOnDeviceReady: true,
      init: true,
      darkMode: void 0,
      iosTranslucentBars: true,
      iosTranslucentModals: true,
      component: void 0,
      componentUrl: void 0,
      userAgent: null,
      url: null,
      colors: {
        primary: "#007aff",
        red: "#ff3b30",
        green: "#4cd964",
        blue: "#2196f3",
        pink: "#ff2d55",
        yellow: "#ffcc00",
        orange: "#ff9500",
        purple: "#9c27b0",
        deeppurple: "#673ab7",
        lightblue: "#5ac8fa",
        teal: "#009688",
        lime: "#cddc39",
        deeporange: "#ff6b22",
        white: "#ffffff",
        black: "#000000"
      }
    };
    app.useModulesParams(defaults);
    app.params = extend$1(defaults, params);
    extend$1(app, {
      // App Name
      name: app.params.name,
      // Routes
      routes: app.params.routes,
      // Theme
      theme: function getTheme() {
        if (app.params.theme === "auto") {
          if (device.ios) return "ios";
          return "md";
        }
        return app.params.theme;
      }(),
      // Initially passed parameters
      passedParams,
      online: w.navigator.onLine,
      colors: app.params.colors,
      darkMode: app.params.darkMode
    });
    if (params.store) app.params.store = params.store;
    if (app.$el && app.$el[0]) {
      app.$el[0].f7 = app;
    }
    app.useModules();
    app.initStore();
    if (app.params.init) {
      if (device.cordova && app.params.initOnDeviceReady) {
        $(d).on("deviceready", () => {
          app.init();
        });
      } else {
        app.init();
      }
    }
    return app;
  }
  setColorTheme(color) {
    if (!color) return;
    const app = this;
    app.colors.primary = color;
    app.setColors();
  }
  setColors() {
    const app = this;
    const document2 = getDocument();
    if (!app.colorsStyleEl) {
      app.colorsStyleEl = document2.createElement("style");
      document2.head.prepend(app.colorsStyleEl);
    }
    app.colorsStyleEl.textContent = app.utils.colorThemeCSSStyles(app.colors);
  }
  mount(rootEl) {
    const app = this;
    const window2 = getWindow();
    const document2 = getDocument();
    const $rootEl = $(rootEl || app.params.el).eq(0);
    app.$el = $rootEl;
    if (app.$el && app.$el[0]) {
      app.el = app.$el[0];
      app.el.f7 = app;
      app.rtl = $rootEl.css("direction") === "rtl";
    }
    const DARK = "(prefers-color-scheme: dark)";
    const LIGHT = "(prefers-color-scheme: light)";
    app.mq = {};
    if (window2.matchMedia) {
      app.mq.dark = window2.matchMedia(DARK);
      app.mq.light = window2.matchMedia(LIGHT);
    }
    app.colorSchemeListener = function colorSchemeListener(_ref) {
      let {
        matches,
        media
      } = _ref;
      if (!matches) {
        return;
      }
      const html2 = document2.querySelector("html");
      if (media === DARK) {
        html2.classList.add("dark");
        app.darkMode = true;
        app.emit("darkModeChange", true);
      } else if (media === LIGHT) {
        html2.classList.remove("dark");
        app.darkMode = false;
        app.emit("darkModeChange", false);
      }
    };
    app.emit("mount");
  }
  initStore() {
    const app = this;
    if (typeof app.params.store !== "undefined" && app.params.store.__store) {
      app.store = app.params.store;
    } else {
      app.store = app.createStore(app.params.store);
    }
  }
  enableAutoDarkMode() {
    const window2 = getWindow();
    const document2 = getDocument();
    if (!window2.matchMedia) return;
    const app = this;
    const html2 = document2.querySelector("html");
    if (app.mq.dark && app.mq.light) {
      app.mq.dark.addEventListener("change", app.colorSchemeListener);
      app.mq.light.addEventListener("change", app.colorSchemeListener);
    }
    if (app.mq.dark && app.mq.dark.matches) {
      html2.classList.add("dark");
      app.darkMode = true;
      app.emit("darkModeChange", true);
    } else if (app.mq.light && app.mq.light.matches) {
      html2.classList.remove("dark");
      app.darkMode = false;
      app.emit("darkModeChange", false);
    }
  }
  disableAutoDarkMode() {
    const window2 = getWindow();
    if (!window2.matchMedia) return;
    const app = this;
    if (app.mq.dark) app.mq.dark.removeEventListener("change", app.colorSchemeListener);
    if (app.mq.light) app.mq.light.removeEventListener("change", app.colorSchemeListener);
  }
  setDarkMode(mode) {
    const app = this;
    if (mode === "auto") {
      app.enableAutoDarkMode();
    } else {
      app.disableAutoDarkMode();
      $("html")[mode ? "addClass" : "removeClass"]("dark");
      app.darkMode = mode;
    }
  }
  initAppComponent(callback) {
    const app = this;
    app.router.componentLoader(app.params.component, app.params.componentUrl, {
      componentOptions: {
        el: app.$el[0]
      }
    }, (el) => {
      app.$el = $(el);
      app.$el[0].f7 = app;
      app.$elComponent = el.f7Component;
      app.el = app.$el[0];
      if (callback) callback();
    }, () => {
    });
  }
  init(rootEl) {
    const app = this;
    app.setColors();
    app.mount(rootEl);
    const init = () => {
      if (app.initialized) return;
      app.$el.addClass("framework7-initializing");
      if (app.rtl) {
        $("html").attr("dir", "rtl");
      }
      if (typeof app.params.darkMode === "undefined") {
        app.darkMode = $("html").hasClass("dark");
      } else {
        app.setDarkMode(app.params.darkMode);
      }
      const window2 = getWindow();
      window2.addEventListener("offline", () => {
        app.online = false;
        app.emit("offline");
        app.emit("connection", false);
      });
      window2.addEventListener("online", () => {
        app.online = true;
        app.emit("online");
        app.emit("connection", true);
      });
      app.$el.addClass("framework7-root");
      $("html").removeClass("ios md").addClass(app.theme);
      if (app.params.iosTranslucentBars && app.theme === "ios") {
        $("html").addClass("ios-translucent-bars");
      }
      if (app.params.iosTranslucentModals && app.theme === "ios") {
        $("html").addClass("ios-translucent-modals");
      }
      nextFrame(() => {
        app.$el.removeClass("framework7-initializing");
      });
      app.initialized = true;
      app.emit("init");
    };
    if (app.params.component || app.params.componentUrl) {
      app.initAppComponent(() => {
        init();
      });
    } else {
      init();
    }
    return app;
  }
  // eslint-disable-next-line
  loadModule() {
    return Framework7.loadModule(...arguments);
  }
  // eslint-disable-next-line
  loadModules() {
    return Framework7.loadModules(...arguments);
  }
  getVnodeHooks(hook, id2) {
    const app = this;
    if (!app.vnodeHooks || !app.vnodeHooks[hook]) return [];
    return app.vnodeHooks[hook][id2] || [];
  }
  // eslint-disable-next-line
  get $() {
    return $;
  }
  static get Dom7() {
    return $;
  }
  static get $() {
    return $;
  }
  static get device() {
    return getDevice();
  }
  static get support() {
    return getSupport();
  }
  static get Class() {
    return Framework7Class;
  }
  static get Events() {
    return EventsClass;
  }
}
Framework7.$jsx = $jsx;
Framework7.ModalMethods = ModalMethods;
Framework7.ConstructorMethods = ConstructorMethods;
Framework7.loadModule = loadModule;
Framework7.loadModules = function loadModules(modules) {
  return Promise.all(modules.map((module) => Framework7.loadModule(module)));
};
const DeviceModule = {
  name: "device",
  static: {
    getDevice
  },
  on: {
    init() {
      const document2 = getDocument();
      const device = getDevice();
      const classNames2 = [];
      const html2 = document2.querySelector("html");
      const metaStatusbar = document2.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]');
      if (!html2) return;
      if (device.standalone && device.ios && metaStatusbar && metaStatusbar.content === "black-translucent") {
        classNames2.push("device-full-viewport");
      }
      classNames2.push(`device-pixel-ratio-${Math.floor(device.pixelRatio)}`);
      if (device.os && !device.desktop) {
        classNames2.push(`device-${device.os}`);
      } else if (device.desktop) {
        classNames2.push("device-desktop");
        if (device.os) {
          classNames2.push(`device-${device.os}`);
        }
      }
      if (device.cordova) {
        classNames2.push("device-cordova");
      }
      if (device.capacitor) {
        classNames2.push("device-capacitor");
      }
      classNames2.forEach((className) => {
        html2.classList.add(className);
      });
    }
  }
};
const SupportModule = {
  name: "support",
  static: {
    getSupport
  }
};
const UtilsModule = {
  name: "utils",
  proto: {
    utils
  },
  static: {
    utils
  }
};
const ResizeModule = {
  name: "resize",
  create() {
    const app = this;
    app.getSize = () => {
      if (!app.el) return {
        width: 0,
        height: 0,
        left: 0,
        top: 0
      };
      const offset2 = app.$el.offset();
      const [width2, height2, left, top] = [app.el.offsetWidth, app.el.offsetHeight, offset2.left, offset2.top];
      app.width = width2;
      app.height = height2;
      app.left = left;
      app.top = top;
      return {
        width: width2,
        height: height2,
        left,
        top
      };
    };
  },
  on: {
    init() {
      const app = this;
      const window2 = getWindow();
      app.getSize();
      window2.addEventListener("resize", () => {
        app.emit("resize");
      }, false);
      window2.addEventListener("orientationchange", () => {
        app.emit("orientationchange");
      });
    },
    orientationchange() {
      const document2 = getDocument();
      const device = getDevice();
      if (device.ipad) {
        document2.body.scrollLeft = 0;
        setTimeout(() => {
          document2.body.scrollLeft = 0;
        }, 0);
      }
    },
    resize() {
      const app = this;
      app.getSize();
    }
  }
};
function initTouch() {
  const app = this;
  const device = getDevice();
  const support2 = getSupport();
  const window2 = getWindow();
  const document2 = getDocument();
  const params = app.params.touch;
  const useRipple = params[`${app.theme}TouchRipple`];
  if (device.ios && device.webView) {
    window2.addEventListener("touchstart", () => {
    });
  }
  let touchStartX;
  let touchStartY;
  let targetElement;
  let isMoved;
  let tapHoldFired;
  let tapHoldTimeout;
  let preventClick;
  let activableElement;
  let activeTimeout;
  let rippleWave;
  let rippleTarget;
  let rippleTimeout;
  function findActivableElement(el) {
    const target = $(el);
    const parents2 = target.parents(params.activeStateElements);
    if (target.closest(".no-active-state").length) {
      return null;
    }
    let activable;
    if (target.is(params.activeStateElements)) {
      activable = target;
    }
    if (parents2.length > 0) {
      activable = activable ? activable.add(parents2) : parents2;
    }
    if (activable && activable.length > 1) {
      const newActivable = [];
      let preventPropagation;
      for (let i = 0; i < activable.length; i += 1) {
        if (!preventPropagation) {
          newActivable.push(activable[i]);
          if (activable.eq(i).hasClass("prevent-active-state-propagation") || activable.eq(i).hasClass("no-active-state-propagation")) {
            preventPropagation = true;
          }
        }
      }
      activable = $(newActivable);
    }
    return activable || target;
  }
  function isInsideScrollableView(el) {
    const pageContent = el.parents(".page-content");
    return pageContent.length > 0;
  }
  function addActive() {
    if (!activableElement) return;
    activableElement.addClass("active-state");
  }
  function removeActive() {
    if (!activableElement) return;
    activableElement.removeClass("active-state");
    activableElement = null;
  }
  function findRippleElement(el) {
    const rippleElements = params.touchRippleElements;
    const $el = $(el);
    if ($el.is(rippleElements)) {
      if ($el.hasClass("no-ripple")) {
        return false;
      }
      return $el;
    }
    if ($el.parents(rippleElements).length > 0) {
      const rippleParent = $el.parents(rippleElements).eq(0);
      if (rippleParent.hasClass("no-ripple")) {
        return false;
      }
      return rippleParent;
    }
    return false;
  }
  function createRipple($el, x, y) {
    if (!$el) return;
    rippleWave = app.touchRipple.create(app, $el, x, y);
  }
  function removeRipple() {
    if (!rippleWave) return;
    rippleWave.remove();
    rippleWave = void 0;
    rippleTarget = void 0;
  }
  function rippleTouchStart(el) {
    rippleTarget = findRippleElement(el);
    if (!rippleTarget || rippleTarget.length === 0) {
      rippleTarget = void 0;
      return;
    }
    const inScrollable = isInsideScrollableView(rippleTarget);
    if (!inScrollable) {
      removeRipple();
      createRipple(rippleTarget, touchStartX, touchStartY);
    } else {
      clearTimeout(rippleTimeout);
      rippleTimeout = setTimeout(() => {
        removeRipple();
        createRipple(rippleTarget, touchStartX, touchStartY);
      }, 80);
    }
  }
  function rippleTouchMove() {
    clearTimeout(rippleTimeout);
    removeRipple();
  }
  function rippleTouchEnd() {
    if (!rippleWave && rippleTarget && !isMoved) {
      clearTimeout(rippleTimeout);
      createRipple(rippleTarget, touchStartX, touchStartY);
      setTimeout(removeRipple, 0);
    } else {
      removeRipple();
    }
  }
  function handleMouseDown(e) {
    const $activableEl = findActivableElement(e.target);
    if ($activableEl) {
      $activableEl.addClass("active-state");
      if ("which" in e && e.which === 3) {
        setTimeout(() => {
          $(".active-state").removeClass("active-state");
        }, 0);
      }
    }
    if (useRipple) {
      touchStartX = e.pageX;
      touchStartY = e.pageY;
      rippleTouchStart(e.target);
    }
  }
  function handleMouseMove() {
    if (!params.activeStateOnMouseMove) {
      $(".active-state").removeClass("active-state");
    }
    if (useRipple) {
      rippleTouchMove();
    }
  }
  function handleMouseUp() {
    $(".active-state").removeClass("active-state");
    if (useRipple) {
      rippleTouchEnd();
    }
  }
  function handleTouchCancel() {
    targetElement = null;
    clearTimeout(activeTimeout);
    clearTimeout(tapHoldTimeout);
    if (params.activeState) {
      removeActive();
    }
    if (useRipple) {
      rippleTouchEnd();
    }
  }
  let isScrolling;
  let isSegmentedStrong = false;
  let segmentedStrongEl = null;
  const touchMoveActivableIos = ".dialog-button, .actions-button";
  let isTouchMoveActivable = false;
  let touchmoveActivableEl = null;
  function handleTouchStart(e) {
    if (!e.isTrusted) return true;
    isMoved = false;
    tapHoldFired = false;
    preventClick = false;
    isScrolling = void 0;
    if (e.targetTouches.length > 1) {
      if (activableElement) removeActive();
      return true;
    }
    if (e.touches.length > 1 && activableElement) {
      removeActive();
    }
    if (params.tapHold) {
      if (tapHoldTimeout) clearTimeout(tapHoldTimeout);
      tapHoldTimeout = setTimeout(() => {
        if (e && e.touches && e.touches.length > 1) return;
        tapHoldFired = true;
        e.preventDefault();
        preventClick = true;
        $(e.target).trigger("taphold", e);
        app.emit("taphold", e);
      }, params.tapHoldDelay);
    }
    targetElement = e.target;
    touchStartX = e.targetTouches[0].pageX;
    touchStartY = e.targetTouches[0].pageY;
    isSegmentedStrong = e.target.closest(".segmented-strong .button-active, .segmented-strong .tab-link-active");
    isTouchMoveActivable = app.theme === "ios" && e.target.closest(touchMoveActivableIos);
    if (isSegmentedStrong) {
      segmentedStrongEl = isSegmentedStrong.closest(".segmented-strong");
    }
    if (params.activeState) {
      activableElement = findActivableElement(targetElement);
      if (activableElement && !isInsideScrollableView(activableElement)) {
        addActive();
      } else if (activableElement) {
        activeTimeout = setTimeout(addActive, 80);
      }
    }
    if (useRipple) {
      rippleTouchStart(targetElement);
    }
    return true;
  }
  function handleTouchMove(e) {
    if (!e.isTrusted) return;
    let touch;
    let distance;
    let shouldRemoveActive = true;
    if (e.type === "touchmove") {
      touch = e.targetTouches[0];
      distance = params.touchClicksDistanceThreshold;
    }
    const touchCurrentX = e.targetTouches[0].pageX;
    const touchCurrentY = e.targetTouches[0].pageY;
    if (typeof isScrolling === "undefined") {
      isScrolling = !!(isScrolling || Math.abs(touchCurrentY - touchStartY) > Math.abs(touchCurrentX - touchStartX));
    }
    if (isTouchMoveActivable || !isScrolling && isSegmentedStrong && segmentedStrongEl) {
      if (e.cancelable) e.preventDefault();
    }
    if (!isScrolling && isSegmentedStrong && segmentedStrongEl) {
      const elementFromPoint = document2.elementFromPoint(e.targetTouches[0].clientX, e.targetTouches[0].clientY);
      const buttonEl = elementFromPoint.closest(".segmented-strong .button:not(.button-active):not(.tab-link-active)");
      if (buttonEl && segmentedStrongEl.contains(buttonEl)) {
        $(buttonEl).trigger("click", "f7Segmented");
        targetElement = buttonEl;
      }
    }
    if (distance && touch) {
      const pageX = touch.pageX;
      const pageY = touch.pageY;
      if (Math.abs(pageX - touchStartX) > distance || Math.abs(pageY - touchStartY) > distance) {
        isMoved = true;
      }
    } else {
      isMoved = true;
    }
    if (isMoved) {
      preventClick = true;
      if (isTouchMoveActivable) {
        const elementFromPoint = document2.elementFromPoint(e.targetTouches[0].clientX, e.targetTouches[0].clientY);
        touchmoveActivableEl = elementFromPoint.closest(touchMoveActivableIos);
        if (touchmoveActivableEl && activableElement && activableElement[0] === touchmoveActivableEl) {
          shouldRemoveActive = false;
        } else if (touchmoveActivableEl) {
          setTimeout(() => {
            activableElement = findActivableElement(touchmoveActivableEl);
            addActive();
          });
        }
      }
      if (params.tapHold) {
        clearTimeout(tapHoldTimeout);
      }
      if (params.activeState && shouldRemoveActive) {
        clearTimeout(activeTimeout);
        removeActive();
      }
      if (useRipple) {
        rippleTouchMove();
      }
    }
  }
  function handleTouchEnd(e) {
    if (!e.isTrusted) return true;
    isScrolling = void 0;
    isSegmentedStrong = false;
    segmentedStrongEl = null;
    isTouchMoveActivable = false;
    clearTimeout(activeTimeout);
    clearTimeout(tapHoldTimeout);
    if (touchmoveActivableEl) {
      $(touchmoveActivableEl).trigger("click", "f7TouchMoveActivable");
      touchmoveActivableEl = null;
    }
    if (document2.activeElement === e.target) {
      if (params.activeState) removeActive();
      if (useRipple) {
        rippleTouchEnd();
      }
      return true;
    }
    if (params.activeState) {
      addActive();
      setTimeout(removeActive, 0);
    }
    if (useRipple) {
      rippleTouchEnd();
    }
    if (params.tapHoldPreventClicks && tapHoldFired || preventClick) {
      if (e.cancelable) e.preventDefault();
      preventClick = true;
      return false;
    }
    return true;
  }
  function handleClick(e) {
    const isOverswipe = e && e.detail && e.detail === "f7Overswipe";
    const isSegmented = e && e.detail && e.detail === "f7Segmented";
    const isTouchMoveActivable2 = e && e.detail && e.detail === "f7TouchMoveActivable";
    let localPreventClick = preventClick;
    if (targetElement && e.target !== targetElement) {
      if (isOverswipe || isSegmented || isTouchMoveActivable2) {
        localPreventClick = false;
      } else {
        localPreventClick = true;
      }
    } else if (isTouchMoveActivable2) {
      localPreventClick = false;
    }
    if (params.tapHold && params.tapHoldPreventClicks && tapHoldFired) {
      localPreventClick = true;
    }
    if (localPreventClick) {
      e.stopImmediatePropagation();
      e.stopPropagation();
      e.preventDefault();
    }
    if (params.tapHold) {
      tapHoldTimeout = setTimeout(() => {
        tapHoldFired = false;
      }, device.ios || device.androidChrome ? 100 : 400);
    }
    preventClick = false;
    targetElement = null;
    return !localPreventClick;
  }
  function emitAppTouchEvent(name2, e) {
    app.emit({
      events: name2,
      data: [e]
    });
  }
  function appClick(e) {
    emitAppTouchEvent("click", e);
  }
  function appTouchStartActive(e) {
    emitAppTouchEvent("touchstart touchstart:active", e);
  }
  function appTouchMoveActive(e) {
    emitAppTouchEvent("touchmove touchmove:active", e);
  }
  function appTouchEndActive(e) {
    emitAppTouchEvent("touchend touchend:active", e);
  }
  function appTouchStartPassive(e) {
    emitAppTouchEvent("touchstart:passive", e);
  }
  function appTouchMovePassive(e) {
    emitAppTouchEvent("touchmove:passive", e);
  }
  function appTouchEndPassive(e) {
    emitAppTouchEvent("touchend:passive", e);
  }
  const passiveListener = support2.passiveListener ? {
    passive: true
  } : false;
  const passiveListenerCapture = support2.passiveListener ? {
    passive: true,
    capture: true
  } : true;
  const activeListener = support2.passiveListener ? {
    passive: false
  } : false;
  const activeListenerCapture = support2.passiveListener ? {
    passive: false,
    capture: true
  } : true;
  document2.addEventListener("click", appClick, true);
  if (support2.passiveListener) {
    document2.addEventListener(app.touchEvents.start, appTouchStartActive, activeListenerCapture);
    document2.addEventListener(app.touchEvents.move, appTouchMoveActive, activeListener);
    document2.addEventListener(app.touchEvents.end, appTouchEndActive, activeListener);
    document2.addEventListener(app.touchEvents.start, appTouchStartPassive, passiveListenerCapture);
    document2.addEventListener(app.touchEvents.move, appTouchMovePassive, passiveListener);
    document2.addEventListener(app.touchEvents.end, appTouchEndPassive, passiveListener);
  } else {
    document2.addEventListener(app.touchEvents.start, (e) => {
      appTouchStartActive(e);
      appTouchStartPassive(e);
    }, true);
    document2.addEventListener(app.touchEvents.move, (e) => {
      appTouchMoveActive(e);
      appTouchMovePassive(e);
    }, false);
    document2.addEventListener(app.touchEvents.end, (e) => {
      appTouchEndActive(e);
      appTouchEndPassive(e);
    }, false);
  }
  if (support2.touch) {
    app.on("click", handleClick);
    app.on("touchstart", handleTouchStart);
    app.on("touchmove", handleTouchMove);
    app.on("touchend", handleTouchEnd);
    document2.addEventListener("touchcancel", handleTouchCancel, {
      passive: true
    });
  } else if (params.activeState) {
    app.on("touchstart", handleMouseDown);
    app.on("touchmove", handleMouseMove);
    app.on("touchend", handleMouseUp);
    document2.addEventListener("pointercancel", handleMouseUp, {
      passive: true
    });
  }
  document2.addEventListener("contextmenu", (e) => {
    if (params.disableContextMenu && (device.ios || device.android || device.cordova || window2.Capacitor && window2.Capacitor.isNative)) {
      e.preventDefault();
    }
    if (useRipple) {
      if (activableElement) removeActive();
      rippleTouchEnd();
    }
  });
}
const TouchModule = {
  name: "touch",
  params: {
    touch: {
      // Clicks
      touchClicksDistanceThreshold: 5,
      // ContextMenu
      disableContextMenu: false,
      // Tap Hold
      tapHold: false,
      tapHoldDelay: 750,
      tapHoldPreventClicks: true,
      // Active State
      activeState: true,
      activeStateElements: "a, button, label, span, .actions-button, .stepper-button, .stepper-button-plus, .stepper-button-minus, .card-expandable, .link, .item-link, .accordion-item-toggle",
      activeStateOnMouseMove: false,
      mdTouchRipple: true,
      iosTouchRipple: false,
      touchRippleElements: ".ripple, .link, .item-link, .list label.item-content, .list-button, .links-list a, .button, button, .input-clear-button, .dialog-button, .tab-link, .item-radio, .item-checkbox, .actions-button, .searchbar-disable-button, .fab a, .checkbox, .radio, .data-table .sortable-cell:not(.input-cell), .notification-close-button, .stepper-button, .stepper-button-minus, .stepper-button-plus, .list.accordion-list .accordion-item-toggle",
      touchRippleInsetElements: ".ripple-inset, .icon-only, .searchbar-disable-button, .input-clear-button, .notification-close-button, .md .navbar .link.back"
    }
  },
  create() {
    const app = this;
    const support2 = getSupport();
    extend$1(app, {
      touchEvents: {
        start: support2.touch ? "touchstart" : support2.pointerEvents ? "pointerdown" : "mousedown",
        move: support2.touch ? "touchmove" : support2.pointerEvents ? "pointermove" : "mousemove",
        end: support2.touch ? "touchend" : support2.pointerEvents ? "pointerup" : "mouseup"
      }
    });
  },
  on: {
    init: initTouch
  }
};
function lexer(str) {
  var tokens = [];
  var i = 0;
  while (i < str.length) {
    var char = str[i];
    if (char === "*" || char === "+" || char === "?") {
      tokens.push({ type: "MODIFIER", index: i, value: str[i++] });
      continue;
    }
    if (char === "\\") {
      tokens.push({ type: "ESCAPED_CHAR", index: i++, value: str[i++] });
      continue;
    }
    if (char === "{") {
      tokens.push({ type: "OPEN", index: i, value: str[i++] });
      continue;
    }
    if (char === "}") {
      tokens.push({ type: "CLOSE", index: i, value: str[i++] });
      continue;
    }
    if (char === ":") {
      var name2 = "";
      var j = i + 1;
      while (j < str.length) {
        var code = str.charCodeAt(j);
        if (
          // `0-9`
          code >= 48 && code <= 57 || // `A-Z`
          code >= 65 && code <= 90 || // `a-z`
          code >= 97 && code <= 122 || // `_`
          code === 95
        ) {
          name2 += str[j++];
          continue;
        }
        break;
      }
      if (!name2)
        throw new TypeError("Missing parameter name at ".concat(i));
      tokens.push({ type: "NAME", index: i, value: name2 });
      i = j;
      continue;
    }
    if (char === "(") {
      var count = 1;
      var pattern = "";
      var j = i + 1;
      if (str[j] === "?") {
        throw new TypeError('Pattern cannot start with "?" at '.concat(j));
      }
      while (j < str.length) {
        if (str[j] === "\\") {
          pattern += str[j++] + str[j++];
          continue;
        }
        if (str[j] === ")") {
          count--;
          if (count === 0) {
            j++;
            break;
          }
        } else if (str[j] === "(") {
          count++;
          if (str[j + 1] !== "?") {
            throw new TypeError("Capturing groups are not allowed at ".concat(j));
          }
        }
        pattern += str[j++];
      }
      if (count)
        throw new TypeError("Unbalanced pattern at ".concat(i));
      if (!pattern)
        throw new TypeError("Missing pattern at ".concat(i));
      tokens.push({ type: "PATTERN", index: i, value: pattern });
      i = j;
      continue;
    }
    tokens.push({ type: "CHAR", index: i, value: str[i++] });
  }
  tokens.push({ type: "END", index: i, value: "" });
  return tokens;
}
function parse(str, options) {
  if (options === void 0) {
    options = {};
  }
  var tokens = lexer(str);
  var _a = options.prefixes, prefixes = _a === void 0 ? "./" : _a, _b = options.delimiter, delimiter = _b === void 0 ? "/#?" : _b;
  var result = [];
  var key = 0;
  var i = 0;
  var path = "";
  var tryConsume = function(type) {
    if (i < tokens.length && tokens[i].type === type)
      return tokens[i++].value;
  };
  var mustConsume = function(type) {
    var value3 = tryConsume(type);
    if (value3 !== void 0)
      return value3;
    var _a2 = tokens[i], nextType = _a2.type, index2 = _a2.index;
    throw new TypeError("Unexpected ".concat(nextType, " at ").concat(index2, ", expected ").concat(type));
  };
  var consumeText = function() {
    var result2 = "";
    var value3;
    while (value3 = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR")) {
      result2 += value3;
    }
    return result2;
  };
  var isSafe = function(value3) {
    for (var _i = 0, delimiter_1 = delimiter; _i < delimiter_1.length; _i++) {
      var char2 = delimiter_1[_i];
      if (value3.indexOf(char2) > -1)
        return true;
    }
    return false;
  };
  var safePattern = function(prefix2) {
    var prev2 = result[result.length - 1];
    var prevText = prefix2 || (prev2 && typeof prev2 === "string" ? prev2 : "");
    if (prev2 && !prevText) {
      throw new TypeError('Must have text between two parameters, missing text after "'.concat(prev2.name, '"'));
    }
    if (!prevText || isSafe(prevText))
      return "[^".concat(escapeString(delimiter), "]+?");
    return "(?:(?!".concat(escapeString(prevText), ")[^").concat(escapeString(delimiter), "])+?");
  };
  while (i < tokens.length) {
    var char = tryConsume("CHAR");
    var name2 = tryConsume("NAME");
    var pattern = tryConsume("PATTERN");
    if (name2 || pattern) {
      var prefix = char || "";
      if (prefixes.indexOf(prefix) === -1) {
        path += prefix;
        prefix = "";
      }
      if (path) {
        result.push(path);
        path = "";
      }
      result.push({
        name: name2 || key++,
        prefix,
        suffix: "",
        pattern: pattern || safePattern(prefix),
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    var value2 = char || tryConsume("ESCAPED_CHAR");
    if (value2) {
      path += value2;
      continue;
    }
    if (path) {
      result.push(path);
      path = "";
    }
    var open = tryConsume("OPEN");
    if (open) {
      var prefix = consumeText();
      var name_1 = tryConsume("NAME") || "";
      var pattern_1 = tryConsume("PATTERN") || "";
      var suffix = consumeText();
      mustConsume("CLOSE");
      result.push({
        name: name_1 || (pattern_1 ? key++ : ""),
        pattern: name_1 && !pattern_1 ? safePattern(prefix) : pattern_1,
        prefix,
        suffix,
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    mustConsume("END");
  }
  return result;
}
function compile(str, options) {
  return tokensToFunction(parse(str, options), options);
}
function tokensToFunction(tokens, options) {
  if (options === void 0) {
    options = {};
  }
  var reFlags = flags(options);
  var _a = options.encode, encode = _a === void 0 ? function(x) {
    return x;
  } : _a, _b = options.validate, validate = _b === void 0 ? true : _b;
  var matches = tokens.map(function(token) {
    if (typeof token === "object") {
      return new RegExp("^(?:".concat(token.pattern, ")$"), reFlags);
    }
  });
  return function(data2) {
    var path = "";
    for (var i = 0; i < tokens.length; i++) {
      var token = tokens[i];
      if (typeof token === "string") {
        path += token;
        continue;
      }
      var value2 = data2 ? data2[token.name] : void 0;
      var optional = token.modifier === "?" || token.modifier === "*";
      var repeat = token.modifier === "*" || token.modifier === "+";
      if (Array.isArray(value2)) {
        if (!repeat) {
          throw new TypeError('Expected "'.concat(token.name, '" to not repeat, but got an array'));
        }
        if (value2.length === 0) {
          if (optional)
            continue;
          throw new TypeError('Expected "'.concat(token.name, '" to not be empty'));
        }
        for (var j = 0; j < value2.length; j++) {
          var segment = encode(value2[j], token);
          if (validate && !matches[i].test(segment)) {
            throw new TypeError('Expected all "'.concat(token.name, '" to match "').concat(token.pattern, '", but got "').concat(segment, '"'));
          }
          path += token.prefix + segment + token.suffix;
        }
        continue;
      }
      if (typeof value2 === "string" || typeof value2 === "number") {
        var segment = encode(String(value2), token);
        if (validate && !matches[i].test(segment)) {
          throw new TypeError('Expected "'.concat(token.name, '" to match "').concat(token.pattern, '", but got "').concat(segment, '"'));
        }
        path += token.prefix + segment + token.suffix;
        continue;
      }
      if (optional)
        continue;
      var typeOfMessage = repeat ? "an array" : "a string";
      throw new TypeError('Expected "'.concat(token.name, '" to be ').concat(typeOfMessage));
    }
    return path;
  };
}
function escapeString(str) {
  return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
function flags(options) {
  return options && options.sensitive ? "" : "i";
}
function regexpToRegexp(path, keys) {
  if (!keys)
    return path;
  var groupsRegex = /\((?:\?<(.*?)>)?(?!\?)/g;
  var index2 = 0;
  var execResult = groupsRegex.exec(path.source);
  while (execResult) {
    keys.push({
      // Use parenthesized substring match if available, index otherwise
      name: execResult[1] || index2++,
      prefix: "",
      suffix: "",
      modifier: "",
      pattern: ""
    });
    execResult = groupsRegex.exec(path.source);
  }
  return path;
}
function arrayToRegexp(paths, keys, options) {
  var parts = paths.map(function(path) {
    return pathToRegexp(path, keys, options).source;
  });
  return new RegExp("(?:".concat(parts.join("|"), ")"), flags(options));
}
function stringToRegexp(path, keys, options) {
  return tokensToRegexp(parse(path, options), keys, options);
}
function tokensToRegexp(tokens, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.strict, strict = _a === void 0 ? false : _a, _b = options.start, start = _b === void 0 ? true : _b, _c = options.end, end = _c === void 0 ? true : _c, _d = options.encode, encode = _d === void 0 ? function(x) {
    return x;
  } : _d, _e = options.delimiter, delimiter = _e === void 0 ? "/#?" : _e, _f = options.endsWith, endsWith = _f === void 0 ? "" : _f;
  var endsWithRe = "[".concat(escapeString(endsWith), "]|$");
  var delimiterRe = "[".concat(escapeString(delimiter), "]");
  var route = start ? "^" : "";
  for (var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++) {
    var token = tokens_1[_i];
    if (typeof token === "string") {
      route += escapeString(encode(token));
    } else {
      var prefix = escapeString(encode(token.prefix));
      var suffix = escapeString(encode(token.suffix));
      if (token.pattern) {
        if (keys)
          keys.push(token);
        if (prefix || suffix) {
          if (token.modifier === "+" || token.modifier === "*") {
            var mod = token.modifier === "*" ? "?" : "";
            route += "(?:".concat(prefix, "((?:").concat(token.pattern, ")(?:").concat(suffix).concat(prefix, "(?:").concat(token.pattern, "))*)").concat(suffix, ")").concat(mod);
          } else {
            route += "(?:".concat(prefix, "(").concat(token.pattern, ")").concat(suffix, ")").concat(token.modifier);
          }
        } else {
          if (token.modifier === "+" || token.modifier === "*") {
            throw new TypeError('Can not repeat "'.concat(token.name, '" without a prefix and suffix'));
          }
          route += "(".concat(token.pattern, ")").concat(token.modifier);
        }
      } else {
        route += "(?:".concat(prefix).concat(suffix, ")").concat(token.modifier);
      }
    }
  }
  if (end) {
    if (!strict)
      route += "".concat(delimiterRe, "?");
    route += !options.endsWith ? "$" : "(?=".concat(endsWithRe, ")");
  } else {
    var endToken = tokens[tokens.length - 1];
    var isEndDelimited = typeof endToken === "string" ? delimiterRe.indexOf(endToken[endToken.length - 1]) > -1 : endToken === void 0;
    if (!strict) {
      route += "(?:".concat(delimiterRe, "(?=").concat(endsWithRe, "))?");
    }
    if (!isEndDelimited) {
      route += "(?=".concat(delimiterRe, "|").concat(endsWithRe, ")");
    }
  }
  return new RegExp(route, flags(options));
}
function pathToRegexp(path, keys, options) {
  if (path instanceof RegExp)
    return regexpToRegexp(path, keys);
  if (Array.isArray(path))
    return arrayToRegexp(path, keys, options);
  return stringToRegexp(path, keys, options);
}
const History = {
  queue: [],
  clearQueue() {
    if (History.queue.length === 0) return;
    const currentQueue = History.queue.shift();
    currentQueue();
  },
  routerQueue: [],
  clearRouterQueue() {
    if (History.routerQueue.length === 0) return;
    const currentQueue = History.routerQueue.pop();
    const {
      router,
      stateUrl,
      action
    } = currentQueue;
    let animate2 = router.params.animate;
    if (router.params.browserHistoryAnimate === false) animate2 = false;
    if (action === "back") {
      router.back({
        animate: animate2,
        browserHistory: false
      });
    }
    if (action === "load") {
      router.navigate(stateUrl, {
        animate: animate2,
        browserHistory: false
      });
    }
  },
  handle(e) {
    if (History.blockPopstate) return;
    const app = this;
    let state = e.state;
    History.previousState = History.state;
    History.state = state;
    History.allowChange = true;
    History.clearQueue();
    state = History.state;
    if (!state) state = {};
    app.views.forEach((view) => {
      const router = view.router;
      let viewState = state[view.id];
      if (!viewState && view.params.browserHistory) {
        viewState = {
          url: view.router.history[0]
        };
      }
      if (!viewState) return;
      const stateUrl = viewState.url || void 0;
      let animate2 = router.params.animate;
      if (router.params.browserHistoryAnimate === false) animate2 = false;
      if (stateUrl !== router.url) {
        if (router.history.indexOf(stateUrl) >= 0) {
          if (router.allowPageChange) {
            router.back({
              animate: animate2,
              browserHistory: false
            });
          } else {
            History.routerQueue.push({
              action: "back",
              router
            });
          }
        } else if (router.allowPageChange) {
          router.navigate(stateUrl, {
            animate: animate2,
            browserHistory: false
          });
        } else {
          History.routerQueue.unshift({
            action: "load",
            stateUrl,
            router
          });
        }
      }
    });
  },
  initViewState(viewId, viewState) {
    const window2 = getWindow();
    const newState = extend$1({}, History.state || {}, {
      [viewId]: viewState
    });
    History.state = newState;
    window2.history.replaceState(newState, "");
  },
  push(viewId, viewState, url) {
    const window2 = getWindow();
    const document2 = getDocument();
    if (url.substr(-3) === "#!/") {
      url = url.replace("#!/", "");
      if (url === "") {
        url = document2.location.href;
        if (url.includes("#!/")) {
          url = document2.location.href.split("#!/")[0];
        }
      }
    }
    if (!History.allowChange) {
      History.queue.push(() => {
        History.push(viewId, viewState, url);
      });
      return;
    }
    History.previousState = History.state;
    const newState = extend$1({}, History.previousState || {}, {
      [viewId]: viewState
    });
    History.state = newState;
    window2.history.pushState(newState, "", url);
  },
  replace(viewId, viewState, url) {
    const window2 = getWindow();
    if (url.substr(-3) === "#!/") {
      url = url.replace("#!/", "");
    }
    if (!History.allowChange) {
      History.queue.push(() => {
        History.replace(viewId, viewState, url);
      });
      return;
    }
    History.previousState = History.state;
    const newState = extend$1({}, History.previousState || {}, {
      [viewId]: viewState
    });
    History.state = newState;
    window2.history.replaceState(newState, "", url);
  },
  go(index2) {
    const window2 = getWindow();
    History.allowChange = false;
    window2.history.go(index2);
  },
  back() {
    const window2 = getWindow();
    History.allowChange = false;
    window2.history.back();
  },
  allowChange: true,
  previousState: {},
  state: {},
  blockPopstate: true,
  init(app) {
    const window2 = getWindow();
    const document2 = getDocument();
    History.state = window2.history.state;
    $(window2).on("load", () => {
      setTimeout(() => {
        History.blockPopstate = false;
      }, 0);
    });
    if (document2.readyState && document2.readyState === "complete") {
      History.blockPopstate = false;
    }
    $(window2).on("popstate", History.handle.bind(app));
  }
};
function SwipeBack(r) {
  const router = r;
  const {
    $el,
    $navbarsEl,
    app,
    params
  } = router;
  const support2 = getSupport();
  const device = getDevice();
  let isTouched = false;
  let isMoved = false;
  const touchesStart = {};
  let isScrolling;
  let $currentPageEl = [];
  let $previousPageEl = [];
  let viewContainerWidth;
  let touchesDiff;
  let allowViewTouchMove = true;
  let touchStartTime;
  let $currentNavbarEl = [];
  let $previousNavbarEl = [];
  let dynamicNavbar;
  let $pageShadowEl;
  let $pageOpacityEl;
  let animatableNavEls;
  const paramsSwipeBackAnimateShadow = params[`${app.theme}SwipeBackAnimateShadow`];
  const paramsSwipeBackAnimateOpacity = params[`${app.theme}SwipeBackAnimateOpacity`];
  const paramsSwipeBackActiveArea = params[`${app.theme}SwipeBackActiveArea`];
  const paramsSwipeBackThreshold = params[`${app.theme}SwipeBackThreshold`];
  const transformOrigin = app.rtl ? "right center" : "left center";
  const transformOriginTitleLarge = app.rtl ? "calc(100% - var(--f7-navbar-large-title-padding-left) - var(--f7-safe-area-left)) center" : "calc(var(--f7-navbar-large-title-padding-left) + var(--f7-safe-area-left)) center";
  function animatableNavElements() {
    const els = [];
    const inverter = app.rtl ? -1 : 1;
    const currentNavIsTransparent = $currentNavbarEl.hasClass("navbar-transparent") && !$currentNavbarEl.hasClass("navbar-large") && !$currentNavbarEl.hasClass("navbar-transparent-visible");
    const currentNavIsLarge = $currentNavbarEl.hasClass("navbar-large");
    const currentNavIsCollapsed = $currentNavbarEl.hasClass("navbar-large-collapsed");
    const currentNavIsLargeTransparent = $currentNavbarEl.hasClass("navbar-large-transparent") || $currentNavbarEl.hasClass("navbar-large") && $currentNavbarEl.hasClass("navbar-transparent");
    const previousNavIsTransparent = $previousNavbarEl.hasClass("navbar-transparent") && !$previousNavbarEl.hasClass("navbar-large") && !$previousNavbarEl.hasClass("navbar-transparent-visible");
    const previousNavIsLarge = $previousNavbarEl.hasClass("navbar-large");
    const previousNavIsCollapsed = $previousNavbarEl.hasClass("navbar-large-collapsed");
    const previousNavIsLargeTransparent = $previousNavbarEl.hasClass("navbar-large-transparent") || $previousNavbarEl.hasClass("navbar-large") && $previousNavbarEl.hasClass("navbar-transparent");
    const fromLarge = currentNavIsLarge && !currentNavIsCollapsed;
    const toLarge = previousNavIsLarge && !previousNavIsCollapsed;
    const $currentNavElements = $currentNavbarEl.find(".left, .title, .right, .subnavbar, .fading, .title-large, .navbar-bg");
    const $previousNavElements = $previousNavbarEl.find(".left, .title, .right, .subnavbar, .fading, .title-large, .navbar-bg");
    let activeNavBackIconText;
    let previousNavBackIconText;
    if (params.iosAnimateNavbarBackIcon) {
      if ($currentNavbarEl.hasClass("sliding") || $currentNavbarEl.find(".navbar-inner.sliding").length) {
        activeNavBackIconText = $currentNavbarEl.find(".left").find(".back .icon + span").eq(0);
      } else {
        activeNavBackIconText = $currentNavbarEl.find(".left.sliding").find(".back .icon + span").eq(0);
      }
      if ($previousNavbarEl.hasClass("sliding") || $previousNavbarEl.find(".navbar-inner.sliding").length) {
        previousNavBackIconText = $previousNavbarEl.find(".left").find(".back .icon + span").eq(0);
      } else {
        previousNavBackIconText = $previousNavbarEl.find(".left.sliding").find(".back .icon + span").eq(0);
      }
      if (activeNavBackIconText.length) {
        $previousNavElements.each((el) => {
          if (!$(el).hasClass("title")) return;
          el.f7NavbarLeftOffset += activeNavBackIconText.prev(".icon")[0].offsetWidth;
        });
      }
    }
    $currentNavElements.each((navEl) => {
      const $navEl = $(navEl);
      const isSubnavbar = $navEl.hasClass("subnavbar");
      const isLeft = $navEl.hasClass("left");
      const isTitle = $navEl.hasClass("title");
      const isBg = $navEl.hasClass("navbar-bg");
      if ((isTitle || isBg) && currentNavIsTransparent) return;
      if (!fromLarge && $navEl.hasClass(".title-large")) return;
      const el = {
        el: navEl
      };
      if (fromLarge) {
        if (isTitle) return;
        if ($navEl.hasClass("title-large")) {
          if (els.indexOf(el) < 0) els.push(el);
          el.overflow = "visible";
          $navEl.find(".title-large-text").each((subNavEl) => {
            els.push({
              el: subNavEl,
              transform: (progress) => `translateX(${progress * 100 * inverter}%)`
            });
          });
          return;
        }
      }
      if (toLarge) {
        if (!fromLarge) {
          if ($navEl.hasClass("title-large")) {
            if (els.indexOf(el) < 0) els.push(el);
            el.opacity = 0;
          }
        }
        if (isLeft) {
          if (els.indexOf(el) < 0) els.push(el);
          el.opacity = (progress) => 1 - progress ** 0.33;
          $navEl.find(".back span").each((subNavEl) => {
            els.push({
              el: subNavEl,
              "transform-origin": transformOrigin,
              transform: (progress) => `translateX(calc(${progress} * (var(--f7-navbarTitleLargeOffset) - var(--f7-navbarLeftTextOffset)))) translateY(calc(${progress} * (var(--f7-navbar-large-title-height) - var(--f7-navbar-large-title-padding-vertical) / 2))) scale(${1 + 1 * progress})`
            });
          });
          return;
        }
      }
      if (isBg) {
        if (els.indexOf(el) < 0) els.push(el);
        if (!fromLarge && !toLarge) {
          if (currentNavIsCollapsed) {
            if (currentNavIsLargeTransparent) {
              el.className = "ios-swipeback-navbar-bg-large";
            }
            el.transform = (progress) => `translateX(${100 * progress * inverter}%) translateY(calc(-1 * var(--f7-navbar-large-title-height)))`;
          } else {
            el.transform = (progress) => `translateX(${100 * progress * inverter}%)`;
          }
        }
        if (!fromLarge && toLarge) {
          el.className = "ios-swipeback-navbar-bg-large";
          el.transform = (progress) => `translateX(${100 * progress * inverter}%) translateY(calc(-1 * ${1 - progress} * var(--f7-navbar-large-title-height)))`;
        }
        if (fromLarge && toLarge) {
          el.transform = (progress) => `translateX(${100 * progress * inverter}%)`;
        }
        if (fromLarge && !toLarge) {
          el.transform = (progress) => `translateX(${100 * progress * inverter}%) translateY(calc(-${progress} * var(--f7-navbar-large-title-height)))`;
        }
        return;
      }
      if ($navEl.hasClass("title-large")) return;
      const isSliding = $navEl.hasClass("sliding") || $navEl.parents(".navbar-inner.sliding").length;
      if (els.indexOf(el) < 0) els.push(el);
      if (!isSubnavbar || isSubnavbar && !isSliding) {
        el.opacity = (progress) => 1 - progress ** 0.33;
      }
      if (isSliding) {
        let transformTarget = el;
        if (isLeft && activeNavBackIconText.length && params.iosAnimateNavbarBackIcon) {
          const textEl = {
            el: activeNavBackIconText[0]
          };
          transformTarget = textEl;
          els.push(textEl);
        }
        transformTarget.transform = (progress) => {
          let activeNavTranslate = progress * transformTarget.el.f7NavbarRightOffset;
          if (device.pixelRatio === 1) activeNavTranslate = Math.round(activeNavTranslate);
          if (isSubnavbar && currentNavIsLarge) {
            return `translate3d(${activeNavTranslate}px, calc(-1 * var(--f7-navbar-large-collapse-progress) * var(--f7-navbar-large-title-height)), 0)`;
          }
          return `translate3d(${activeNavTranslate}px,0,0)`;
        };
      }
    });
    $previousNavElements.each((navEl) => {
      const $navEl = $(navEl);
      const isSubnavbar = $navEl.hasClass("subnavbar");
      const isLeft = $navEl.hasClass("left");
      const isTitle = $navEl.hasClass("title");
      const isBg = $navEl.hasClass("navbar-bg");
      if ((isTitle || isBg) && previousNavIsTransparent) return;
      const el = {
        el: navEl
      };
      if (toLarge) {
        if (isTitle) return;
        if (els.indexOf(el) < 0) els.push(el);
        if ($navEl.hasClass("title-large")) {
          el.opacity = 1;
          el.overflow = "visible";
          $navEl.find(".title-large-text").each((subNavEl) => {
            els.push({
              el: subNavEl,
              "transform-origin": transformOriginTitleLarge,
              opacity: (progress) => progress ** 3,
              transform: (progress) => `translateX(calc(${1 - progress} * (var(--f7-navbarLeftTextOffset) - var(--f7-navbarTitleLargeOffset)))) translateY(calc(${progress - 1} * var(--f7-navbar-large-title-height) + ${1 - progress} * var(--f7-navbar-large-title-padding-vertical))) scale(${0.5 + progress * 0.5})`
            });
          });
          return;
        }
      }
      if (isBg) {
        if (els.indexOf(el) < 0) els.push(el);
        if (!fromLarge && !toLarge) {
          if (previousNavIsCollapsed) {
            if (previousNavIsLargeTransparent) {
              el.className = "ios-swipeback-navbar-bg-large";
            }
            el.transform = (progress) => `translateX(${(-100 + 100 * progress) * inverter}%) translateY(calc(-1 * var(--f7-navbar-large-title-height)))`;
          } else {
            el.transform = (progress) => `translateX(${(-100 + 100 * progress) * inverter}%)`;
          }
        }
        if (!fromLarge && toLarge) {
          el.transform = (progress) => `translateX(${(-100 + 100 * progress) * inverter}%) translateY(calc(-1 * ${1 - progress} * var(--f7-navbar-large-title-height)))`;
        }
        if (fromLarge && !toLarge) {
          el.className = "ios-swipeback-navbar-bg-large";
          el.transform = (progress) => `translateX(${(-100 + 100 * progress) * inverter}%) translateY(calc(-${progress} * var(--f7-navbar-large-title-height)))`;
        }
        if (fromLarge && toLarge) {
          el.transform = (progress) => `translateX(${(-100 + 100 * progress) * inverter}%)`;
        }
        return;
      }
      if ($navEl.hasClass("title-large")) return;
      const isSliding = $navEl.hasClass("sliding") || $previousNavbarEl.children(".navbar-inner.sliding").length;
      if (els.indexOf(el) < 0) els.push(el);
      if (!isSubnavbar || isSubnavbar && !isSliding) {
        el.opacity = (progress) => progress ** 3;
      }
      if (isSliding) {
        let transformTarget = el;
        if (isLeft && previousNavBackIconText.length && params.iosAnimateNavbarBackIcon) {
          const textEl = {
            el: previousNavBackIconText[0]
          };
          transformTarget = textEl;
          els.push(textEl);
        }
        transformTarget.transform = (progress) => {
          let previousNavTranslate = transformTarget.el.f7NavbarLeftOffset * (1 - progress);
          if (device.pixelRatio === 1) previousNavTranslate = Math.round(previousNavTranslate);
          if (isSubnavbar && previousNavIsLarge) {
            return `translate3d(${previousNavTranslate}px, calc(-1 * var(--f7-navbar-large-collapse-progress) * var(--f7-navbar-large-title-height)), 0)`;
          }
          return `translate3d(${previousNavTranslate}px,0,0)`;
        };
      }
    });
    return els;
  }
  function setAnimatableNavElements(_temp) {
    let {
      progress,
      reset,
      transition: transition2,
      reflow
    } = _temp === void 0 ? {} : _temp;
    const styles2 = ["overflow", "transform", "transform-origin", "opacity"];
    if (transition2 === true || transition2 === false) {
      for (let i = 0; i < animatableNavEls.length; i += 1) {
        const el = animatableNavEls[i];
        if (el && el.el) {
          if (transition2 === true) el.el.classList.add("navbar-page-transitioning");
          if (transition2 === false) el.el.classList.remove("navbar-page-transitioning");
        }
      }
    }
    if (reflow && animatableNavEls.length && animatableNavEls[0] && animatableNavEls[0].el) {
      animatableNavEls[0].el._clientLeft = animatableNavEls[0].el.clientLeft;
    }
    for (let i = 0; i < animatableNavEls.length; i += 1) {
      const el = animatableNavEls[i];
      if (el && el.el) {
        if (el.className && !el.classNameSet && !reset) {
          el.el.classList.add(el.className);
          el.classNameSet = true;
        }
        if (el.className && reset) {
          el.el.classList.remove(el.className);
        }
        for (let j = 0; j < styles2.length; j += 1) {
          const styleProp = styles2[j];
          if (el[styleProp]) {
            if (reset) {
              el.el.style[styleProp] = "";
            } else if (typeof el[styleProp] === "function") {
              el.el.style[styleProp] = el[styleProp](progress);
            } else {
              el.el.style[styleProp] = el[styleProp];
            }
          }
        }
      }
    }
  }
  function handleTouchStart(e) {
    if (!e.isTrusted) return;
    const swipeBackEnabled = params[`${app.theme}SwipeBack`];
    if (!allowViewTouchMove || !swipeBackEnabled || isTouched || app.swipeout && app.swipeout.el || !router.allowPageChange) return;
    if ($(e.target).closest(".range-slider, .calendar-months").length > 0) return;
    if ($(e.target).closest(".page-master, .page-master-detail").length > 0 && params.masterDetailBreakpoint > 0 && app.width >= params.masterDetailBreakpoint) return;
    isMoved = false;
    isTouched = true;
    isScrolling = void 0;
    touchesStart.x = e.type === "touchstart" ? e.targetTouches[0].pageX : e.pageX;
    touchesStart.y = e.type === "touchstart" ? e.targetTouches[0].pageY : e.pageY;
    touchStartTime = now$1();
    dynamicNavbar = router.dynamicNavbar;
  }
  function handleTouchMove(e) {
    if (!e.isTrusted) return;
    if (!isTouched) return;
    const pageX = e.type === "touchmove" ? e.targetTouches[0].pageX : e.pageX;
    const pageY = e.type === "touchmove" ? e.targetTouches[0].pageY : e.pageY;
    if (typeof isScrolling === "undefined") {
      isScrolling = !!(isScrolling || Math.abs(pageY - touchesStart.y) > Math.abs(pageX - touchesStart.x)) || pageX < touchesStart.x && !app.rtl || pageX > touchesStart.x && app.rtl;
    }
    if (isScrolling || e.f7PreventSwipeBack || app.preventSwipeBack) {
      isTouched = false;
      return;
    }
    if (!isMoved) {
      let cancel = false;
      const target = $(e.target);
      const swipeout = target.closest(".swipeout");
      if (swipeout.length > 0) {
        if (!app.rtl && swipeout.find(".swipeout-actions-left").length > 0) cancel = true;
        if (app.rtl && swipeout.find(".swipeout-actions-right").length > 0) cancel = true;
      }
      $currentPageEl = target.closest(".page");
      if ($currentPageEl.hasClass("no-swipeback") || target.closest(".no-swipeback, .card-opened").length > 0) cancel = true;
      $previousPageEl = $el.find(".page-previous");
      if ($previousPageEl.length > 1) {
        $previousPageEl = $previousPageEl.eq($previousPageEl.length - 1);
      }
      let notFromBorder = touchesStart.x - $el.offset().left > paramsSwipeBackActiveArea;
      viewContainerWidth = $el.width();
      if (app.rtl) {
        notFromBorder = touchesStart.x < $el.offset().left - $el[0].scrollLeft + (viewContainerWidth - paramsSwipeBackActiveArea);
      } else {
        notFromBorder = touchesStart.x - $el.offset().left > paramsSwipeBackActiveArea;
      }
      if (notFromBorder) cancel = true;
      if ($previousPageEl.length === 0 || $currentPageEl.length === 0) cancel = true;
      if (cancel) {
        isTouched = false;
        return;
      }
      if (paramsSwipeBackAnimateShadow) {
        $pageShadowEl = $currentPageEl.find(".page-shadow-effect");
        if ($pageShadowEl.length === 0) {
          $pageShadowEl = $('<div class="page-shadow-effect"></div>');
          $currentPageEl.append($pageShadowEl);
        }
      }
      if (paramsSwipeBackAnimateOpacity) {
        $pageOpacityEl = $previousPageEl.find(".page-opacity-effect");
        if ($pageOpacityEl.length === 0) {
          $pageOpacityEl = $('<div class="page-opacity-effect"></div>');
          $previousPageEl.append($pageOpacityEl);
        }
      }
      if (dynamicNavbar) {
        $currentNavbarEl = $navbarsEl.find(".navbar-current");
        $previousNavbarEl = $navbarsEl.find(".navbar-previous");
        if ($previousNavbarEl.length > 1) {
          $previousNavbarEl = $previousNavbarEl.eq($previousNavbarEl.length - 1);
        }
        animatableNavEls = animatableNavElements();
      }
      if ($(".sheet.modal-in").length > 0 && app.sheet) {
        app.sheet.close($(".sheet.modal-in"));
      }
    }
    e.f7PreventSwipePanel = true;
    isMoved = true;
    app.preventSwipePanelBySwipeBack = true;
    e.preventDefault();
    const inverter = app.rtl ? -1 : 1;
    touchesDiff = (pageX - touchesStart.x - paramsSwipeBackThreshold) * inverter;
    if (touchesDiff < 0) touchesDiff = 0;
    const percentage = Math.min(Math.max(touchesDiff / viewContainerWidth, 0), 1);
    const callbackData = {
      percentage,
      progress: percentage,
      currentPageEl: $currentPageEl[0],
      previousPageEl: $previousPageEl[0],
      currentNavbarEl: $currentNavbarEl[0],
      previousNavbarEl: $previousNavbarEl[0]
    };
    $el.trigger("swipeback:move", callbackData);
    router.emit("swipebackMove", callbackData);
    let currentPageTranslate = touchesDiff * inverter;
    let previousPageTranslate = (touchesDiff / 5 - viewContainerWidth / 5) * inverter;
    if (!app.rtl) {
      currentPageTranslate = Math.min(currentPageTranslate, viewContainerWidth);
      previousPageTranslate = Math.min(previousPageTranslate, 0);
    } else {
      currentPageTranslate = Math.max(currentPageTranslate, -viewContainerWidth);
      previousPageTranslate = Math.max(previousPageTranslate, 0);
    }
    if (device.pixelRatio === 1) {
      currentPageTranslate = Math.round(currentPageTranslate);
      previousPageTranslate = Math.round(previousPageTranslate);
    }
    router.swipeBackActive = true;
    $([$currentPageEl[0], $previousPageEl[0]]).addClass("page-swipeback-active");
    $currentPageEl.transform(`translate3d(${currentPageTranslate}px,0,0)`);
    if (paramsSwipeBackAnimateShadow) $pageShadowEl[0].style.opacity = 1 - 1 * percentage;
    if (app.theme === "ios") {
      $previousPageEl.transform(`translate3d(${previousPageTranslate}px,0,0)`);
    }
    if (paramsSwipeBackAnimateOpacity) $pageOpacityEl[0].style.opacity = 1 - 1 * percentage;
    if (!dynamicNavbar) return;
    setAnimatableNavElements({
      progress: percentage
    });
  }
  function handleTouchEnd(e) {
    if (!e.isTrusted) return;
    app.preventSwipePanelBySwipeBack = false;
    if (!isTouched || !isMoved) {
      isTouched = false;
      isMoved = false;
      return;
    }
    isTouched = false;
    isMoved = false;
    router.swipeBackActive = false;
    const $pages = $([$currentPageEl[0], $previousPageEl[0]]);
    $pages.removeClass("page-swipeback-active");
    if (touchesDiff === 0) {
      $pages.transform("");
      if ($pageShadowEl && $pageShadowEl.length > 0) $pageShadowEl.remove();
      if ($pageOpacityEl && $pageOpacityEl.length > 0) $pageOpacityEl.remove();
      if (dynamicNavbar) {
        setAnimatableNavElements({
          reset: true
        });
      }
      return;
    }
    const timeDiff = now$1() - touchStartTime;
    let pageChanged = false;
    if (timeDiff < 300 && touchesDiff > 10 || timeDiff >= 300 && touchesDiff > viewContainerWidth / 2) {
      $currentPageEl.removeClass("page-current").addClass(`page-next${app.theme !== "ios" ? " page-next-on-right" : ""}`);
      $previousPageEl.removeClass("page-previous").addClass("page-current").removeAttr("aria-hidden");
      if ($pageShadowEl) $pageShadowEl[0].style.opacity = "";
      if ($pageOpacityEl) $pageOpacityEl[0].style.opacity = "";
      if (dynamicNavbar) {
        router.setNavbarPosition($currentNavbarEl, "next");
        router.setNavbarPosition($previousNavbarEl, "current", false);
      }
      pageChanged = true;
    }
    $pages.addClass("page-transitioning page-transitioning-swipeback");
    if (device.ios) {
      $currentPageEl[0]._clientLeft = $currentPageEl[0].clientLeft;
    }
    $pages.transform("");
    if (dynamicNavbar) {
      setAnimatableNavElements({
        progress: pageChanged ? 1 : 0,
        transition: true,
        reflow: !!device.ios
      });
    }
    allowViewTouchMove = false;
    router.allowPageChange = false;
    const callbackData = {
      currentPageEl: $currentPageEl[0],
      previousPageEl: $previousPageEl[0],
      currentNavbarEl: $currentNavbarEl[0],
      previousNavbarEl: $previousNavbarEl[0]
    };
    if (pageChanged) {
      router.currentRoute = $previousPageEl[0].f7Page.route;
      router.currentPage = $previousPageEl[0];
      router.pageCallback("beforeOut", $currentPageEl, $currentNavbarEl, "current", "next", {
        route: $currentPageEl[0].f7Page.route,
        swipeBack: true
      });
      router.pageCallback("beforeIn", $previousPageEl, $previousNavbarEl, "previous", "current", {
        route: $previousPageEl[0].f7Page.route,
        swipeBack: true
      }, $currentPageEl[0]);
      $el.trigger("swipeback:beforechange", callbackData);
      router.emit("swipebackBeforeChange", callbackData);
    } else {
      $el.trigger("swipeback:beforereset", callbackData);
      router.emit("swipebackBeforeReset", callbackData);
    }
    $currentPageEl.transitionEnd(() => {
      $pages.removeClass("page-transitioning page-transitioning-swipeback");
      if (dynamicNavbar) {
        setAnimatableNavElements({
          reset: true,
          transition: false
        });
      }
      allowViewTouchMove = true;
      router.allowPageChange = true;
      if (pageChanged) {
        if (router.history.length === 1) {
          router.history.unshift(router.url);
        }
        router.history.pop();
        router.saveHistory();
        if (params.browserHistory) {
          History.back();
        }
        router.pageCallback("afterOut", $currentPageEl, $currentNavbarEl, "current", "next", {
          route: $currentPageEl[0].f7Page.route,
          swipeBack: true
        });
        router.pageCallback("afterIn", $previousPageEl, $previousNavbarEl, "previous", "current", {
          route: $previousPageEl[0].f7Page.route,
          swipeBack: true
        });
        router.pageCallback("beforeRemove", $currentPageEl, $currentNavbarEl, "next", {
          swipeBack: true
        });
        router.removePage($currentPageEl);
        if (dynamicNavbar) {
          router.removeNavbar($currentNavbarEl);
        }
        $el.trigger("swipeback:afterchange", callbackData);
        router.emit("swipebackAfterChange", callbackData);
        router.emit("routeChanged", router.currentRoute, router.previousRoute, router);
        if (params.preloadPreviousPage) {
          router.back(router.history[router.history.length - 2], {
            preload: true
          });
        }
      } else {
        $el.trigger("swipeback:afterreset", callbackData);
        router.emit("swipebackAfterReset", callbackData);
      }
      if ($pageShadowEl && $pageShadowEl.length > 0) $pageShadowEl.remove();
      if ($pageOpacityEl && $pageOpacityEl.length > 0) $pageOpacityEl.remove();
    });
  }
  function attachEvents() {
    const passiveListener = app.touchEvents.start === "touchstart" && support2.passiveListener ? {
      passive: true,
      capture: false
    } : false;
    $el.on(app.touchEvents.start, handleTouchStart, passiveListener);
    app.on("touchmove:active", handleTouchMove);
    app.on("touchend:passive", handleTouchEnd);
  }
  function detachEvents() {
    const passiveListener = app.touchEvents.start === "touchstart" && support2.passiveListener ? {
      passive: true,
      capture: false
    } : false;
    $el.off(app.touchEvents.start, handleTouchStart, passiveListener);
    app.off("touchmove:active", handleTouchMove);
    app.off("touchend:passive", handleTouchEnd);
  }
  attachEvents();
  router.on("routerDestroy", detachEvents);
}
function redirect(direction, route, options) {
  const router = this;
  const r = route.route.redirect;
  const method = direction === "forward" ? "navigate" : "back";
  if (options.initial && router.params.browserHistory) {
    options.replaceState = true;
    options.history = true;
  }
  function redirectResolve(redirectUrl, redirectOptions) {
    if (redirectOptions === void 0) {
      redirectOptions = {};
    }
    router.allowPageChange = true;
    router[method](redirectUrl, extend$1({}, options, redirectOptions));
  }
  function redirectReject() {
    router.allowPageChange = true;
  }
  if (typeof r === "function") {
    router.allowPageChange = false;
    const redirectUrl = r.call(router, {
      router,
      to: route,
      resolve: redirectResolve,
      reject: redirectReject,
      direction,
      app: router.app
    });
    if (redirectUrl && typeof redirectUrl === "string") {
      router.allowPageChange = true;
      return router[method](redirectUrl, options);
    }
    return router;
  }
  return router[method](r, options);
}
function processQueue(router, routerQueue, routeQueue, to, from, resolve, reject, direction) {
  const queue = [];
  if (Array.isArray(routeQueue)) {
    queue.push(...routeQueue);
  } else if (routeQueue && typeof routeQueue === "function") {
    queue.push(routeQueue);
  }
  if (routerQueue) {
    if (Array.isArray(routerQueue)) {
      queue.push(...routerQueue);
    } else {
      queue.push(routerQueue);
    }
  }
  function next2() {
    if (queue.length === 0) {
      resolve();
      return;
    }
    const queueItem = queue.shift();
    queueItem.call(router, {
      router,
      to,
      from,
      resolve() {
        next2();
      },
      reject() {
        reject();
      },
      direction,
      app: router.app
    });
  }
  next2();
}
function processRouteQueue(to, from, resolve, reject, direction) {
  const router = this;
  function enterNextRoute() {
    if (to && to.route && (router.params.routesBeforeEnter || to.route.beforeEnter)) {
      router.allowPageChange = false;
      processQueue(router, router.params.routesBeforeEnter, to.route.beforeEnter, to, from, () => {
        router.allowPageChange = true;
        resolve();
      }, () => {
        reject();
      }, direction);
    } else {
      resolve();
    }
  }
  function leaveCurrentRoute() {
    if (from && from.route && (router.params.routesBeforeLeave || from.route.beforeLeave)) {
      router.allowPageChange = false;
      processQueue(router, router.params.routesBeforeLeave, from.route.beforeLeave, to, from, () => {
        router.allowPageChange = true;
        enterNextRoute();
      }, () => {
        reject();
      }, direction);
    } else {
      enterNextRoute();
    }
  }
  leaveCurrentRoute();
}
function appRouterCheck(router, method) {
  if (!router.view) {
    throw new Error(`Framework7: it is not allowed to use router methods on global app router. Use router methods only on related View, e.g. app.views.main.router.${method}(...)`);
  }
}
function asyncComponent(router, component, resolve, reject) {
  function resolvePromise(componentPromise) {
    componentPromise.then((c) => {
      resolve({
        component: c.default || c._default || c
      });
    }).catch((err) => {
      reject();
      throw new Error(err, {
        cause: err
      });
    });
  }
  if (component instanceof Promise) {
    resolvePromise(component);
    return;
  }
  const asyncComponentResult = component.call(router);
  if (asyncComponentResult instanceof Promise) {
    resolvePromise(asyncComponentResult);
  } else {
    resolve({
      component: asyncComponentResult
    });
  }
}
function refreshPage(props) {
  if (props === void 0) {
    props = {};
  }
  const router = this;
  appRouterCheck(router, "refreshPage");
  return router.navigate(router.currentRoute.url, {
    ignoreCache: true,
    reloadCurrent: true,
    props
  });
}
function forward(router, el, forwardOptions) {
  if (forwardOptions === void 0) {
    forwardOptions = {};
  }
  const document2 = getDocument();
  const $el = $(el);
  const app = router.app;
  const view = router.view;
  const options = extend$1(false, {
    animate: router.params.animate,
    browserHistory: true,
    replaceState: false,
    history: true,
    reloadCurrent: router.params.reloadPages,
    reloadPrevious: false,
    reloadAll: false,
    clearPreviousHistory: false,
    reloadDetail: router.params.reloadDetail,
    on: {}
  }, forwardOptions);
  const masterDetailEnabled = router.params.masterDetailBreakpoint > 0;
  const isMaster = masterDetailEnabled && options.route && options.route.route && (options.route.route.master === true || typeof options.route.route.master === "function" && options.route.route.master(app, router));
  let masterPageEl;
  let otherDetailPageEl;
  let detailsInBetweenRemoved = 0;
  let currentRouteIsModal = router.currentRoute.modal;
  let modalType;
  if (!currentRouteIsModal) {
    "popup popover sheet loginScreen actions customModal panel".split(" ").forEach((modalLoadProp) => {
      if (router.currentRoute && router.currentRoute.route && router.currentRoute.route[modalLoadProp]) {
        currentRouteIsModal = true;
        modalType = modalLoadProp;
      }
    });
  }
  if (currentRouteIsModal) {
    const modalToClose = router.currentRoute.modal || router.currentRoute.route.modalInstance || app[modalType].get();
    const previousUrl = router.history[router.history.length - 2];
    let previousRoute = router.findMatchingRoute(previousUrl);
    if (!previousRoute && previousUrl) {
      previousRoute = {
        url: previousUrl,
        path: previousUrl.split("?")[0],
        query: parseUrlQuery(previousUrl),
        route: {
          path: previousUrl.split("?")[0],
          url: previousUrl
        }
      };
    }
    router.modalRemove(modalToClose);
  }
  const dynamicNavbar = router.dynamicNavbar;
  const $viewEl = router.$el;
  const $newPage = $el;
  const reload = options.reloadPrevious || options.reloadCurrent || options.reloadAll;
  let $oldPage;
  let $navbarsEl;
  let $newNavbarEl;
  let $oldNavbarEl;
  router.allowPageChange = false;
  if ($newPage.length === 0) {
    router.allowPageChange = true;
    return router;
  }
  if ($newPage.length) {
    router.removeThemeElements($newPage);
  }
  if (dynamicNavbar) {
    $newNavbarEl = $newPage.children(".navbar");
    $navbarsEl = router.$navbarsEl;
    if ($newNavbarEl.length === 0 && $newPage[0] && $newPage[0].f7Page) {
      $newNavbarEl = $newPage[0].f7Page.$navbarEl;
    }
  }
  if (options.route && options.route.route && options.route.route.keepAlive && !options.route.route.keepAliveData) {
    options.route.route.keepAliveData = {
      pageEl: $el[0]
    };
  }
  const $pagesInView = $viewEl.children(".page").filter((pageInView) => pageInView !== $newPage[0]);
  let $navbarsInView;
  if (dynamicNavbar) {
    $navbarsInView = $navbarsEl.children(".navbar").filter((navbarInView) => navbarInView !== $newNavbarEl[0]);
  }
  if (options.reloadPrevious && $pagesInView.length < 2) {
    router.allowPageChange = true;
    return router;
  }
  let isDetail;
  let reloadDetail;
  let isDetailRoot;
  if (masterDetailEnabled && !options.reloadAll) {
    for (let i = 0; i < $pagesInView.length; i += 1) {
      if (!masterPageEl && $pagesInView[i].classList.contains("page-master")) {
        masterPageEl = $pagesInView[i];
        continue;
      }
    }
    isDetail = !isMaster && masterPageEl;
    if (isDetail) {
      if (masterPageEl) {
        for (let i = 0; i < $pagesInView.length; i += 1) {
          if ($pagesInView[i].classList.contains("page-master-detail")) {
            otherDetailPageEl = $pagesInView[i];
            continue;
          }
        }
      }
    }
    reloadDetail = isDetail && options.reloadDetail && app.width >= router.params.masterDetailBreakpoint && masterPageEl;
  }
  if (isDetail) {
    isDetailRoot = !otherDetailPageEl || reloadDetail || options.reloadAll || options.reloadCurrent;
  }
  let newPagePosition = "next";
  if (options.reloadCurrent || options.reloadAll || reloadDetail) {
    newPagePosition = "current";
  } else if (options.reloadPrevious) {
    newPagePosition = "previous";
  }
  $newPage.removeClass("page-previous page-current page-next").addClass(`page-${newPagePosition}${isMaster ? " page-master" : ""}${isDetail ? " page-master-detail" : ""}${isDetailRoot ? " page-master-detail-root" : ""}`).trigger("page:unstack").trigger("page:position", {
    position: newPagePosition
  });
  router.emit("pageUnstack", $newPage[0]);
  router.emit("pagePosition", $newPage[0], newPagePosition);
  if (isMaster || isDetail) {
    $newPage.trigger("page:role", {
      role: isMaster ? "master" : "detail",
      root: !!isDetailRoot
    });
    router.emit("pageRole", $newPage[0], {
      role: isMaster ? "master" : "detail",
      detailRoot: !!isDetailRoot
    });
  }
  if (dynamicNavbar && $newNavbarEl.length) {
    $newNavbarEl.removeClass("navbar-previous navbar-current navbar-next").addClass(`navbar-${newPagePosition}${isMaster ? " navbar-master" : ""}${isDetail ? " navbar-master-detail" : ""}${isDetailRoot ? " navbar-master-detail-root" : ""}`);
    $newNavbarEl.trigger("navbar:position", {
      position: newPagePosition
    });
    router.emit("navbarPosition", $newNavbarEl[0], newPagePosition);
    if (isMaster || isDetail) {
      router.emit("navbarRole", $newNavbarEl[0], {
        role: isMaster ? "master" : "detail",
        detailRoot: !!isDetailRoot
      });
    }
  }
  if (options.reloadCurrent || reloadDetail) {
    if (reloadDetail) {
      $oldPage = $pagesInView.filter((pageEl) => !pageEl.classList.contains("page-master"));
      if (dynamicNavbar) {
        $oldNavbarEl = $($oldPage.map((pageEl) => app.navbar.getElByPage(pageEl)));
      }
      if ($oldPage.length > 1 && masterPageEl) {
        detailsInBetweenRemoved = $oldPage.length - 1;
        $(masterPageEl).removeClass("page-master-stacked").trigger("page:masterunstack");
        router.emit("pageMasterUnstack", masterPageEl);
        if (dynamicNavbar) {
          $(app.navbar.getElByPage(masterPageEl)).removeClass("navbar-master-stacked");
          router.emit("navbarMasterUnstack", app.navbar.getElByPage(masterPageEl));
        }
      }
    } else {
      $oldPage = $pagesInView.eq($pagesInView.length - 1);
      if (dynamicNavbar) {
        $oldNavbarEl = $(app.navbar.getElByPage($oldPage));
      }
    }
  } else if (options.reloadPrevious) {
    $oldPage = $pagesInView.eq($pagesInView.length - 2);
    if (dynamicNavbar) {
      $oldNavbarEl = $(app.navbar.getElByPage($oldPage));
    }
  } else if (options.reloadAll) {
    $oldPage = $pagesInView.filter((pageEl) => pageEl !== $newPage[0]);
    if (dynamicNavbar) {
      $oldNavbarEl = $navbarsInView.filter((navbarEl) => navbarEl !== $newNavbarEl[0]);
    }
  } else {
    let removedPageEls = [];
    let removedNavbarEls = [];
    if ($pagesInView.length > 1) {
      let i = 0;
      for (i = 0; i < $pagesInView.length - 1; i += 1) {
        if (masterPageEl && $pagesInView[i] === masterPageEl) {
          $pagesInView.eq(i).addClass("page-master-stacked");
          $pagesInView.eq(i).trigger("page:masterstack");
          router.emit("pageMasterStack", $pagesInView[i]);
          if (dynamicNavbar) {
            $(app.navbar.getElByPage(masterPageEl)).addClass("navbar-master-stacked");
            router.emit("navbarMasterStack", app.navbar.getElByPage(masterPageEl));
          }
          continue;
        }
        const oldNavbarEl = app.navbar.getElByPage($pagesInView.eq(i));
        removedPageEls.push($pagesInView[i]);
        router.pageCallback("beforeRemove", $pagesInView[i], $navbarsInView && $navbarsInView[i], "previous", void 0, options);
        router.removePage($pagesInView[i]);
        if (dynamicNavbar && oldNavbarEl) {
          removedNavbarEls.push(oldNavbarEl);
          router.removeNavbar(oldNavbarEl);
        }
      }
    }
    $oldPage = $viewEl.children(".page").filter((pageEl) => pageEl !== $newPage[0] && removedPageEls.indexOf(pageEl) < 0);
    if (dynamicNavbar) {
      $oldNavbarEl = $navbarsEl.children(".navbar").filter((navbarEl) => navbarEl !== $newNavbarEl[0] && removedNavbarEls.indexOf(removedNavbarEls) < 0);
    }
    removedPageEls = [];
    removedNavbarEls = [];
  }
  if (isDetail && !options.reloadAll) {
    if ($oldPage.length > 1 || reloadDetail) {
      $oldPage = $oldPage.filter((pageEl) => !pageEl.classList.contains("page-master"));
    }
    if ($oldNavbarEl && ($oldNavbarEl.length > 1 || reloadDetail)) {
      $oldNavbarEl = $oldNavbarEl.filter((navbarEl) => !navbarEl.classList.contains("navbar-master"));
    }
  }
  if (router.params.browserHistory && (options.browserHistory || options.replaceState) && !options.reloadPrevious) {
    const browserHistoryRoot = router.params.browserHistoryRoot || "";
    History[options.reloadCurrent || reloadDetail && otherDetailPageEl || options.reloadAll || options.replaceState ? "replace" : "push"](view.id, {
      url: options.route.url
    }, browserHistoryRoot + router.params.browserHistorySeparator + options.route.url);
  }
  if (!options.reloadPrevious) {
    router.currentPageEl = $newPage[0];
    if (dynamicNavbar && $newNavbarEl.length) {
      router.currentNavbarEl = $newNavbarEl[0];
    } else {
      delete router.currentNavbarEl;
    }
    router.currentRoute = options.route;
  }
  const url = options.route.url;
  if (options.history) {
    if (((options.reloadCurrent || reloadDetail && otherDetailPageEl) && router.history.length) > 0 || options.replaceState) {
      if (reloadDetail && detailsInBetweenRemoved > 0) {
        router.history = router.history.slice(0, router.history.length - detailsInBetweenRemoved);
        router.propsHistory = router.propsHistory.slice(0, router.propsHistory.length - detailsInBetweenRemoved);
      }
      router.history[router.history.length - (options.reloadPrevious ? 2 : 1)] = url;
      router.propsHistory[router.propsHistory.length - (options.reloadPrevious ? 2 : 1)] = options.props || {};
    } else if (options.reloadPrevious) {
      router.history[router.history.length - 2] = url;
      router.propsHistory[router.propsHistory.length - 2] = options.props || {};
    } else if (options.reloadAll) {
      router.history = [url];
      router.propsHistory = [options.props || {}];
    } else {
      router.history.push(url);
      router.propsHistory.push(options.props || {});
    }
  }
  router.saveHistory();
  const newPageInDom = $newPage.parents(document2).length > 0;
  const f7Component = $newPage[0].f7Component;
  if (options.reloadPrevious) {
    if (f7Component && !newPageInDom) {
      f7Component.mount((componentEl) => {
        $(componentEl).insertBefore($oldPage);
      });
    } else {
      $newPage.insertBefore($oldPage);
    }
    if (dynamicNavbar && $newNavbarEl.length) {
      if ($newNavbarEl.find(".title-large").length) {
        $newNavbarEl.addClass("navbar-large");
      }
      if ($oldNavbarEl.length) {
        $newNavbarEl.insertBefore($oldNavbarEl);
      } else {
        if (!router.$navbarsEl.parents(document2).length) {
          router.$el.prepend(router.$navbarsEl);
        }
        $navbarsEl.append($newNavbarEl);
      }
    }
  } else {
    if ($oldPage.next(".page")[0] !== $newPage[0]) {
      if (f7Component && !newPageInDom) {
        f7Component.mount((componentEl) => {
          $viewEl.append(componentEl);
        });
      } else {
        $viewEl.append($newPage[0]);
      }
    }
    if (dynamicNavbar && $newNavbarEl.length) {
      if ($newNavbarEl.find(".title-large").length) {
        $newNavbarEl.addClass("navbar-large");
      }
      if (!router.$navbarsEl.parents(document2).length) {
        router.$el.prepend(router.$navbarsEl);
      }
      $navbarsEl.append($newNavbarEl[0]);
    }
  }
  if (!newPageInDom) {
    router.pageCallback("mounted", $newPage, $newNavbarEl, newPagePosition, reload ? newPagePosition : "current", options, $oldPage);
  } else if (options.route && options.route.route && options.route.route.keepAlive && !$newPage[0].f7PageMounted) {
    $newPage[0].f7PageMounted = true;
    router.pageCallback("mounted", $newPage, $newNavbarEl, newPagePosition, reload ? newPagePosition : "current", options, $oldPage);
  }
  if ((options.reloadCurrent || reloadDetail) && $oldPage.length > 0) {
    router.pageCallback("beforeOut", $oldPage, $oldNavbarEl, "current", void 0, options);
    router.pageCallback("afterOut", $oldPage, $oldNavbarEl, "current", void 0, options);
    router.pageCallback("beforeRemove", $oldPage, $oldNavbarEl, "current", void 0, options);
    router.removePage($oldPage);
    if (dynamicNavbar && $oldNavbarEl && $oldNavbarEl.length) {
      router.removeNavbar($oldNavbarEl);
    }
  } else if (options.reloadAll) {
    $oldPage.each((pageEl, index2) => {
      const $oldPageEl = $(pageEl);
      const $oldNavbarElEl = $(app.navbar.getElByPage($oldPageEl));
      if ($oldPageEl.hasClass("page-current")) {
        router.pageCallback("beforeOut", $oldPage, $oldNavbarEl, "current", void 0, options);
        router.pageCallback("afterOut", $oldPage, $oldNavbarEl, "current", void 0, options);
      }
      router.pageCallback("beforeRemove", $oldPageEl, $oldNavbarEl && $oldNavbarEl.eq(index2), "previous", void 0, options);
      router.removePage($oldPageEl);
      if (dynamicNavbar && $oldNavbarElEl.length) {
        router.removeNavbar($oldNavbarElEl);
      }
    });
  } else if (options.reloadPrevious) {
    router.pageCallback("beforeRemove", $oldPage, $oldNavbarEl, "previous", void 0, options);
    router.removePage($oldPage);
    if (dynamicNavbar && $oldNavbarEl && $oldNavbarEl.length) {
      router.removeNavbar($oldNavbarEl);
    }
  }
  if (options.route.route.tab) {
    router.tabLoad(options.route.route.tab, extend$1({}, options, {
      history: false,
      browserHistory: false
    }));
  }
  if (masterDetailEnabled) {
    view.checkMasterDetailBreakpoint();
  }
  router.pageCallback("init", $newPage, $newNavbarEl, newPagePosition, reload ? newPagePosition : "current", options, $oldPage);
  if (options.reloadCurrent || options.reloadAll || reloadDetail) {
    router.allowPageChange = true;
    router.pageCallback("beforeIn", $newPage, $newNavbarEl, newPagePosition, "current", options);
    $newPage.removeAttr("aria-hidden");
    if (dynamicNavbar && $newNavbarEl) {
      $newNavbarEl.removeAttr("aria-hidden");
    }
    router.pageCallback("afterIn", $newPage, $newNavbarEl, newPagePosition, "current", options);
    if (options.reloadCurrent && options.clearPreviousHistory) router.clearPreviousHistory();
    if (reloadDetail) {
      router.setPagePosition($(masterPageEl), "previous");
      if (masterPageEl.f7Page && masterPageEl.f7Page.navbarEl) {
        router.setNavbarPosition($(masterPageEl.f7Page.navbarEl), "previous");
      }
    }
    return router;
  }
  if (options.reloadPrevious) {
    router.allowPageChange = true;
    return router;
  }
  router.pageCallback("beforeOut", $oldPage, $oldNavbarEl, "current", "previous", options);
  router.pageCallback("beforeIn", $newPage, $newNavbarEl, "next", "current", options);
  function afterAnimation() {
    router.setPagePosition($newPage, "current", false);
    router.setPagePosition($oldPage, "previous", !$oldPage.hasClass("page-master"));
    if (dynamicNavbar) {
      router.setNavbarPosition($newNavbarEl, "current", false);
      router.setNavbarPosition($oldNavbarEl, "previous", !$oldNavbarEl.hasClass("navbar-master"));
    }
    router.allowPageChange = true;
    router.pageCallback("afterOut", $oldPage, $oldNavbarEl, "current", "previous", options);
    router.pageCallback("afterIn", $newPage, $newNavbarEl, "next", "current", options);
    let keepOldPage = (router.params.preloadPreviousPage || router.params[`${app.theme}SwipeBack`]) && !isMaster;
    if (!keepOldPage) {
      if ($newPage.hasClass("smart-select-page") || $newPage.hasClass("photo-browser-page") || $newPage.hasClass("autocomplete-page") || $newPage.hasClass("color-picker-page")) {
        keepOldPage = true;
      }
    }
    if (!keepOldPage) {
      if (!($newPage.attr("data-name") && $newPage.attr("data-name") === "smart-select-page")) {
        router.pageCallback("beforeRemove", $oldPage, $oldNavbarEl, "previous", void 0, options);
        router.removePage($oldPage);
        if (dynamicNavbar && $oldNavbarEl.length) {
          router.removeNavbar($oldNavbarEl);
        }
      }
    }
    if (options.clearPreviousHistory) router.clearPreviousHistory();
    router.emit("routeChanged", router.currentRoute, router.previousRoute, router);
    if (router.params.browserHistory) {
      History.clearRouterQueue();
    }
  }
  function setPositionClasses() {
    router.setPagePosition($oldPage, "current", false);
    router.setPagePosition($newPage, "next", false);
    if (dynamicNavbar) {
      router.setNavbarPosition($oldNavbarEl, "current", false);
      router.setNavbarPosition($newNavbarEl, "next", false);
    }
  }
  if (options.animate && !(isMaster && app.width >= router.params.masterDetailBreakpoint)) {
    const delay = router.params[`${router.app.theme}PageLoadDelay`];
    let transition2 = router.params.transition;
    if (options.transition) transition2 = options.transition;
    if (!transition2 && router.currentRoute && router.currentRoute.route) {
      transition2 = router.currentRoute.route.transition;
    }
    if (!transition2 && router.currentRoute && router.currentRoute.route.options) {
      transition2 = router.currentRoute.route.options.transition;
    }
    if (transition2) {
      $newPage[0].f7PageTransition = transition2;
    }
    if (delay) {
      setTimeout(() => {
        setPositionClasses();
        router.animate($oldPage, $newPage, $oldNavbarEl, $newNavbarEl, "forward", transition2, () => {
          afterAnimation();
        });
      }, delay);
    } else {
      setPositionClasses();
      router.animate($oldPage, $newPage, $oldNavbarEl, $newNavbarEl, "forward", transition2, () => {
        afterAnimation();
      });
    }
  } else {
    afterAnimation();
  }
  return router;
}
function load(router, loadParams, loadOptions, ignorePageChange) {
  if (loadParams === void 0) {
    loadParams = {};
  }
  if (loadOptions === void 0) {
    loadOptions = {};
  }
  if (!router.allowPageChange && !ignorePageChange) return router;
  const params = loadParams;
  const options = loadOptions;
  const {
    url,
    content,
    el,
    pageName,
    component,
    componentUrl
  } = params;
  if (!options.reloadCurrent && options.route && options.route.route && options.route.route.parentPath && router.currentRoute.route && router.currentRoute.route.parentPath === options.route.route.parentPath) {
    if (options.route.url === router.url) {
      router.allowPageChange = true;
      return false;
    }
    let sameParams = Object.keys(options.route.params).length === Object.keys(router.currentRoute.params).length;
    if (sameParams) {
      Object.keys(options.route.params).forEach((paramName) => {
        if (!(paramName in router.currentRoute.params) || router.currentRoute.params[paramName] !== options.route.params[paramName]) {
          sameParams = false;
        }
      });
    }
    if (sameParams) {
      if (options.route.route.tab) {
        return router.tabLoad(options.route.route.tab, options);
      }
      return false;
    }
    if (!sameParams && options.route.route.tab && router.currentRoute.route.tab && router.currentRoute.parentPath === options.route.parentPath) {
      return router.tabLoad(options.route.route.tab, options);
    }
  }
  if (options.route && options.route.url && router.url === options.route.url && !(options.reloadCurrent || options.reloadPrevious) && !router.params.allowDuplicateUrls) {
    router.allowPageChange = true;
    return false;
  }
  if (!options.route && url) {
    options.route = router.parseRouteUrl(url);
    extend$1(options.route, {
      route: {
        url,
        path: url
      }
    });
  }
  function resolve(pageEl, newOptions) {
    return forward(router, pageEl, extend$1(options, newOptions));
  }
  function reject() {
    router.allowPageChange = true;
    return router;
  }
  if (url || componentUrl || component) {
    router.allowPageChange = false;
  }
  if (content) {
    forward(router, router.getPageEl(content), options);
  } else if (el) {
    forward(router, router.getPageEl(el), options);
  } else if (pageName) {
    forward(router, router.$el.children(`.page[data-name="${pageName}"]`).eq(0), options);
  } else if (component || componentUrl) {
    try {
      router.pageComponentLoader({
        routerEl: router.el,
        component,
        componentUrl,
        options,
        resolve,
        reject
      });
    } catch (err) {
      router.allowPageChange = true;
      throw err;
    }
  } else if (url) {
    if (router.xhrAbortController) {
      router.xhrAbortController.abort();
      router.xhrAbortController = false;
    }
    router.xhrRequest(url, options).then((pageContent) => {
      forward(router, router.getPageEl(pageContent), options);
    }).catch(() => {
      router.allowPageChange = true;
    });
  }
  return router;
}
function navigate(navigateParams, navigateOptions) {
  if (navigateOptions === void 0) {
    navigateOptions = {};
  }
  const router = this;
  if (router.swipeBackActive) return router;
  let url;
  let createRoute;
  let name2;
  let path;
  let query;
  let params;
  let route;
  if (typeof navigateParams === "string") {
    url = navigateParams;
  } else {
    url = navigateParams.url;
    createRoute = navigateParams.route;
    name2 = navigateParams.name;
    path = navigateParams.path;
    query = navigateParams.query;
    params = navigateParams.params;
  }
  if (name2 || path) {
    url = router.generateUrl({
      path,
      name: name2,
      params,
      query
    });
    if (url) {
      return router.navigate(url, navigateOptions);
    }
    return router;
  }
  const app = router.app;
  appRouterCheck(router, "navigate");
  if (url === "#" || url === "") {
    return router;
  }
  let navigateUrl = url.replace("./", "");
  if (navigateUrl[0] !== "/" && navigateUrl.indexOf("#") !== 0) {
    const currentPath = router.currentRoute.parentPath || router.currentRoute.path;
    navigateUrl = ((currentPath ? `${currentPath}/` : "/") + navigateUrl).replace("///", "/").replace("//", "/");
  }
  if (createRoute) {
    route = extend$1(router.parseRouteUrl(navigateUrl), {
      route: extend$1({}, createRoute)
    });
  } else {
    route = router.findMatchingRoute(navigateUrl);
  }
  if (!route) {
    return router;
  }
  if (route.route && route.route.viewName) {
    const anotherViewName = route.route.viewName;
    const anotherView = app.views[anotherViewName];
    if (!anotherView) {
      throw new Error(`Framework7: There is no View with "${anotherViewName}" name that was specified in this route`);
    }
    if (anotherView !== router.view) {
      return anotherView.router.navigate(navigateParams, navigateOptions);
    }
  }
  if (route.route.redirect) {
    return redirect.call(router, "forward", route, navigateOptions);
  }
  const options = {};
  if (route.route.options) {
    extend$1(options, route.route.options, navigateOptions);
  } else {
    extend$1(options, navigateOptions);
  }
  if (options.openIn && (!router.params.ignoreOpenIn || router.params.ignoreOpenIn && router.history.length > 0)) {
    return router.openIn(router, navigateUrl, options);
  }
  options.route = route;
  function resolve() {
    let routerLoaded = false;
    "popup popover sheet loginScreen actions customModal panel".split(" ").forEach((modalLoadProp) => {
      if (route.route[modalLoadProp] && !routerLoaded) {
        routerLoaded = true;
        router.modalLoad(modalLoadProp, route, options, "forward");
      }
    });
    if (route.route.keepAlive && route.route.keepAliveData) {
      load(router, {
        el: route.route.keepAliveData.pageEl
      }, options, false);
      routerLoaded = true;
    }
    "url content component pageName el componentUrl".split(" ").forEach((pageLoadProp) => {
      if (route.route[pageLoadProp] && !routerLoaded) {
        routerLoaded = true;
        load(router, {
          [pageLoadProp]: route.route[pageLoadProp]
        }, options, false);
      }
    });
    if (routerLoaded) return;
    function asyncResolve(resolveParams, resolveOptions) {
      router.allowPageChange = false;
      let resolvedAsModal = false;
      "popup popover sheet loginScreen actions customModal panel".split(" ").forEach((modalLoadProp) => {
        if (resolveParams[modalLoadProp]) {
          resolvedAsModal = true;
          const modalRoute = extend$1({}, route, {
            route: resolveParams
          });
          router.allowPageChange = true;
          router.modalLoad(modalLoadProp, modalRoute, extend$1(options, resolveOptions), "forward");
        }
      });
      if (resolvedAsModal) return;
      load(router, resolveParams, extend$1(options, resolveOptions), true);
    }
    function asyncReject() {
      router.allowPageChange = true;
    }
    if (route.route.async) {
      router.allowPageChange = false;
      route.route.async.call(router, {
        router,
        to: options.route,
        from: router.currentRoute,
        resolve: asyncResolve,
        reject: asyncReject,
        direction: "forward",
        app
      });
    }
    if (route.route.asyncComponent) {
      asyncComponent(router, route.route.asyncComponent, asyncResolve, asyncReject);
    }
  }
  function reject() {
    router.allowPageChange = true;
  }
  if (router.params.masterDetailBreakpoint > 0 && route.route.masterRoute) {
    let preloadMaster = true;
    let masterLoaded = false;
    if (router.currentRoute && router.currentRoute.route) {
      if ((router.currentRoute.route.master === true || typeof router.currentRoute.route.master === "function" && router.currentRoute.route.master(app, router)) && (router.currentRoute.route === route.route.masterRoute || router.currentRoute.route.path === route.route.masterRoute.path)) {
        preloadMaster = false;
      }
      if (router.currentRoute.route.masterRoute && (router.currentRoute.route.masterRoute === route.route.masterRoute || router.currentRoute.route.masterRoute.path === route.route.masterRoute.path)) {
        preloadMaster = false;
        masterLoaded = true;
      }
    }
    if (preloadMaster || masterLoaded && navigateOptions.reloadAll) {
      router.navigate({
        path: route.route.masterRoute.path,
        params: route.params || {}
      }, {
        animate: false,
        reloadAll: navigateOptions.reloadAll,
        reloadCurrent: navigateOptions.reloadCurrent,
        reloadPrevious: navigateOptions.reloadPrevious,
        browserHistory: !navigateOptions.initial,
        history: !navigateOptions.initial,
        once: {
          pageAfterIn() {
            router.navigate(navigateParams, extend$1({}, navigateOptions, {
              animate: false,
              reloadAll: false,
              reloadCurrent: false,
              reloadPrevious: false,
              history: !navigateOptions.initial,
              browserHistory: !navigateOptions.initial
            }));
          }
        }
      });
      return router;
    }
  }
  processRouteQueue.call(router, route, router.currentRoute, () => {
    if (route.route.modules) {
      app.loadModules(Array.isArray(route.route.modules) ? route.route.modules : [route.route.modules]).then(() => {
        resolve();
      }).catch(() => {
        reject();
      });
    } else {
      resolve();
    }
  }, () => {
    reject();
  }, "forward");
  return router;
}
function tabLoad(tabRoute, loadOptions) {
  if (loadOptions === void 0) {
    loadOptions = {};
  }
  const router = this;
  const options = extend$1({
    animate: router.params.animate,
    browserHistory: true,
    history: true,
    parentPageEl: null,
    preload: false,
    on: {}
  }, loadOptions);
  let currentRoute;
  let previousRoute;
  if (options.route) {
    if (!options.preload && options.route !== router.currentRoute) {
      previousRoute = router.previousRoute;
      router.currentRoute = options.route;
    }
    if (options.preload) {
      currentRoute = options.route;
      previousRoute = router.currentRoute;
    } else {
      currentRoute = router.currentRoute;
      if (!previousRoute) previousRoute = router.previousRoute;
    }
    if (router.params.browserHistory && options.browserHistory && !options.reloadPrevious) {
      History[router.params.browserHistoryTabs](router.view.id, {
        url: options.route.url
      }, (router.params.browserHistoryRoot || "") + router.params.browserHistorySeparator + options.route.url);
    }
    if (options.history) {
      router.history[Math.max(router.history.length - 1, 0)] = options.route.url;
      router.saveHistory();
    }
  }
  const $parentPageEl = $(options.parentPageEl || router.currentPageEl);
  let tabEl;
  if ($parentPageEl.length && $parentPageEl.find(`#${tabRoute.id}`).length) {
    tabEl = $parentPageEl.find(`#${tabRoute.id}`).eq(0);
  } else if (router.view.selector) {
    tabEl = `${router.view.selector} #${tabRoute.id}`;
  } else {
    tabEl = `#${tabRoute.id}`;
  }
  const tabShowResult = router.app.tab.show({
    tabEl,
    animate: options.animate,
    tabRoute: options.route
  });
  const {
    $newTabEl,
    $oldTabEl,
    animated,
    onTabsChanged
  } = tabShowResult;
  if ($newTabEl && $newTabEl.parents(".page").length > 0 && options.route) {
    const tabParentPageData = $newTabEl.parents(".page")[0].f7Page;
    if (tabParentPageData && options.route) {
      tabParentPageData.route = options.route;
    }
  }
  function onTabLoaded(contentEl) {
    router.removeThemeElements($newTabEl);
    let tabEventTarget = $newTabEl;
    if (typeof contentEl !== "string") tabEventTarget = $(contentEl);
    tabEventTarget.trigger("tab:init tab:mounted", tabRoute);
    router.emit("tabInit tabMounted", $newTabEl[0], tabRoute);
    if ($oldTabEl && $oldTabEl.length) {
      if (animated) {
        onTabsChanged(() => {
          router.emit("routeChanged", router.currentRoute, router.previousRoute, router);
          if (router.params.unloadTabContent) {
            router.tabRemove($oldTabEl, $newTabEl, tabRoute);
          }
        });
      } else {
        router.emit("routeChanged", router.currentRoute, router.previousRoute, router);
        if (router.params.unloadTabContent) {
          router.tabRemove($oldTabEl, $newTabEl, tabRoute);
        }
      }
    }
  }
  if ($newTabEl[0].f7RouterTabLoaded) {
    if (!$oldTabEl || !$oldTabEl.length) return router;
    if (animated) {
      onTabsChanged(() => {
        router.emit("routeChanged", router.currentRoute, router.previousRoute, router);
      });
    } else {
      router.emit("routeChanged", router.currentRoute, router.previousRoute, router);
    }
    return router;
  }
  function loadTab(loadTabParams, loadTabOptions) {
    const {
      url,
      content,
      el,
      component,
      componentUrl
    } = loadTabParams;
    function resolve(contentEl) {
      router.allowPageChange = true;
      if (!contentEl) return;
      if (typeof contentEl === "string") {
        $newTabEl.html(contentEl);
      } else {
        $newTabEl.html("");
        if (contentEl.f7Component) {
          contentEl.f7Component.mount((componentEl) => {
            $newTabEl.append(componentEl);
          });
        } else {
          $newTabEl.append(contentEl);
        }
      }
      $newTabEl[0].f7RouterTabLoaded = true;
      onTabLoaded(contentEl);
    }
    function reject() {
      router.allowPageChange = true;
      return router;
    }
    if (content) {
      resolve(content);
    } else if (el) {
      resolve(el);
    } else if (component || componentUrl) {
      try {
        router.tabComponentLoader({
          tabEl: $newTabEl[0],
          component,
          componentUrl,
          options: loadTabOptions,
          resolve,
          reject
        });
      } catch (err) {
        router.allowPageChange = true;
        throw err;
      }
    } else if (url) {
      if (router.xhrAbortController) {
        router.xhrAbortController.abort();
        router.xhrAbortController = false;
      }
      router.xhrRequest(url, loadTabOptions).then((tabContent) => {
        resolve(tabContent);
      }).catch(() => {
        router.allowPageChange = true;
      });
    }
  }
  let hasContentLoadProp;
  "url content component el componentUrl".split(" ").forEach((tabLoadProp) => {
    if (tabRoute[tabLoadProp]) {
      hasContentLoadProp = true;
      loadTab({
        [tabLoadProp]: tabRoute[tabLoadProp]
      }, options);
    }
  });
  function asyncResolve(resolveParams, resolveOptions) {
    loadTab(resolveParams, extend$1(options, resolveOptions));
  }
  function asyncReject() {
    router.allowPageChange = true;
  }
  if (tabRoute.async) {
    tabRoute.async.call(router, {
      router,
      to: currentRoute,
      from: previousRoute,
      resolve: asyncResolve,
      reject: asyncReject,
      app: router.app
    });
  } else if (tabRoute.asyncComponent) {
    asyncComponent(router, tabRoute.asyncComponent, asyncResolve, asyncReject);
  } else if (!hasContentLoadProp) {
    router.allowPageChange = true;
  }
  return router;
}
function tabRemove($oldTabEl, $newTabEl, tabRoute) {
  const router = this;
  let hasTabComponentChild;
  if ($oldTabEl[0]) {
    $oldTabEl[0].f7RouterTabLoaded = false;
    delete $oldTabEl[0].f7RouterTabLoaded;
  }
  $oldTabEl.children().each((tabChild) => {
    if (tabChild.f7Component) {
      hasTabComponentChild = true;
      $(tabChild).trigger("tab:beforeremove", tabRoute);
      tabChild.f7Component.destroy();
    }
  });
  if (!hasTabComponentChild) {
    $oldTabEl.trigger("tab:beforeremove", tabRoute);
  }
  router.emit("tabBeforeRemove", $oldTabEl[0], $newTabEl[0], tabRoute);
  router.removeTabContent($oldTabEl[0], tabRoute);
}
function modalLoad(modalType, route, loadOptions, direction) {
  if (loadOptions === void 0) {
    loadOptions = {};
  }
  const router = this;
  const app = router.app;
  const isPanel = modalType === "panel";
  const modalOrPanel = isPanel ? "panel" : "modal";
  const options = extend$1({
    animate: router.params.animate,
    browserHistory: true,
    history: true,
    on: {},
    once: {}
  }, loadOptions);
  const modalParams = extend$1({}, route.route[modalType]);
  const modalRoute = route.route;
  const routeCallback = (modal, name2) => {
    const {
      on: on2,
      once: once2
    } = options;
    let callback;
    if (name2 === "open") {
      callback = on2.modalOpen || once2.modalOpen || on2.panelOpen || once2.panelOpen;
    }
    if (name2 === "close") {
      callback = on2.modalClose || once2.modalClose || on2.panelClose || once2.panelClose;
    }
    if (name2 === "closed") {
      callback = on2.modalClosed || once2.modalClosed || on2.panelClosed || once2.panelClosed;
    }
    if (callback) callback(modal);
  };
  function onModalLoaded() {
    const modal = app[modalType].create(modalParams);
    modalRoute.modalInstance = modal;
    const hasEl = modal.el;
    function closeOnSwipeBack() {
      modal.close();
    }
    modal.on(`${modalOrPanel}Open`, () => {
      if (!hasEl) {
        router.removeThemeElements(modal.el);
        modal.$el.trigger(`${modalType.toLowerCase()}:init ${modalType.toLowerCase()}:mounted`, route, modal);
        router.emit(`${!isPanel ? "modalInit" : ""} ${modalType}Init ${modalType}Mounted`, modal.el, route, modal);
      }
      router.once("swipeBackMove", closeOnSwipeBack);
      routeCallback(modal, "open");
    });
    modal.on(`${modalOrPanel}Close`, () => {
      router.off("swipeBackMove", closeOnSwipeBack);
      if (!modal.closeByRouter) {
        router.back();
      }
      routeCallback(modal, "close");
    });
    modal.on(`${modalOrPanel}Closed`, () => {
      modal.$el.trigger(`${modalType.toLowerCase()}:beforeremove`, route, modal);
      modal.emit(`${!isPanel ? "modalBeforeRemove " : ""}${modalType}BeforeRemove`, modal.el, route, modal);
      const modalComponent = modal.el.f7Component;
      routeCallback(modal, "closed");
      if (modalComponent) {
        modalComponent.destroy();
      }
      nextTick(() => {
        if (modalComponent || modalParams.component || modalParams.asyncComponent || modalParams.async) {
          router.removeModal(modal.el);
        }
        modal.destroy();
        delete modal.route;
        delete modalRoute.modalInstance;
      });
    });
    if (options.route) {
      if (router.params.browserHistory && options.browserHistory) {
        History.push(router.view.id, {
          url: options.route.url,
          modal: modalType
        }, (router.params.browserHistoryRoot || "") + router.params.browserHistorySeparator + options.route.url);
      }
      if (options.route !== router.currentRoute) {
        modal.route = extend$1(options.route, {
          modal
        });
        router.currentRoute = modal.route;
      }
      if (options.history && !options.reloadCurrent) {
        router.history.push(options.route.url);
        router.saveHistory();
      }
    }
    if (hasEl) {
      router.removeThemeElements(modal.el);
      modal.$el.trigger(`${modalType.toLowerCase()}:init ${modalType.toLowerCase()}:mounted`, route, modal);
      router.emit(`${modalOrPanel}Init ${modalType}Init ${modalType}Mounted`, modal.el, route, modal);
    }
    modal.open(options.animate === false || options.animate === true ? options.animate : void 0);
  }
  function loadModal(loadModalParams, loadModalOptions) {
    const {
      url,
      content,
      component,
      componentUrl
    } = loadModalParams;
    function resolve(contentEl) {
      if (contentEl) {
        if (typeof contentEl === "string") {
          modalParams.content = contentEl;
        } else if (contentEl.f7Component) {
          contentEl.f7Component.mount((componentEl) => {
            modalParams.el = componentEl;
            app.$el.append(componentEl);
          });
        } else {
          modalParams.el = contentEl;
        }
        onModalLoaded();
      }
    }
    function reject() {
      router.allowPageChange = true;
      return router;
    }
    if (content) {
      resolve(content);
    } else if (component || componentUrl) {
      try {
        router.modalComponentLoader({
          rootEl: app.el,
          component,
          componentUrl,
          options: loadModalOptions,
          resolve,
          reject
        });
      } catch (err) {
        router.allowPageChange = true;
        throw err;
      }
    } else if (url) {
      if (router.xhrAbortController) {
        router.xhrAbortController.abort();
        router.xhrAbortController = false;
      }
      router.xhrRequest(url, loadModalOptions).then((modalContent) => {
        modalParams.content = modalContent;
        onModalLoaded();
      }).catch(() => {
        router.allowPageChange = true;
      });
    } else {
      onModalLoaded();
    }
  }
  let foundLoadProp;
  "url content component el componentUrl template".split(" ").forEach((modalLoadProp) => {
    if (modalParams[modalLoadProp] && !foundLoadProp) {
      foundLoadProp = true;
      loadModal({
        [modalLoadProp]: modalParams[modalLoadProp]
      }, options);
    }
  });
  if (!foundLoadProp && modalType === "actions") {
    onModalLoaded();
  }
  function asyncResolve(resolveParams, resolveOptions) {
    loadModal(resolveParams, extend$1(options, resolveOptions));
  }
  function asyncReject() {
    router.allowPageChange = true;
  }
  if (modalParams.async) {
    modalParams.async.call(router, {
      router,
      to: options.route,
      from: router.currentRoute,
      resolve: asyncResolve,
      reject: asyncReject,
      direction,
      app
    });
  }
  if (modalParams.asyncComponent) {
    asyncComponent(router, modalParams.asyncComponent, asyncResolve, asyncReject);
  }
  return router;
}
function modalRemove(modal) {
  extend$1(modal, {
    closeByRouter: true
  });
  modal.close();
}
function backward(router, el, backwardOptions) {
  const device = getDevice();
  const document2 = getDocument();
  const $el = $(el);
  const app = router.app;
  const view = router.view;
  const options = extend$1(false, {
    animate: router.params.animate,
    browserHistory: true,
    replaceState: false
  }, backwardOptions);
  const masterDetailEnabled = router.params.masterDetailBreakpoint > 0;
  const isMaster = masterDetailEnabled && options.route && options.route.route && (options.route.route.master === true || typeof options.route.route.master === "function" && options.route.route.master(app, router));
  let masterPageEl;
  let masterPageRemoved;
  const dynamicNavbar = router.dynamicNavbar;
  const $newPage = $el;
  const $oldPage = router.$el.children(".page-current");
  const initialPreload = $oldPage.length === 0 && options.preload;
  const currentIsMaster = masterDetailEnabled && $oldPage.hasClass("page-master");
  if ($newPage.length) {
    router.removeThemeElements($newPage);
  }
  let $navbarsEl;
  let $newNavbarEl;
  let $oldNavbarEl;
  if (dynamicNavbar) {
    $newNavbarEl = $newPage.children(".navbar");
    $navbarsEl = router.$navbarsEl;
    if ($newNavbarEl.length === 0 && $newPage[0] && $newPage[0].f7Page) {
      $newNavbarEl = $newPage[0].f7Page.$navbarEl;
    }
    $oldNavbarEl = $navbarsEl.find(".navbar-current");
  }
  router.allowPageChange = false;
  if ($newPage.length === 0 || $oldPage.length === 0 && !options.preload) {
    router.allowPageChange = true;
    return router;
  }
  router.removeThemeElements($newPage);
  if (options.route && options.route.route && options.route.route.keepAlive && !options.route.route.keepAliveData) {
    options.route.route.keepAliveData = {
      pageEl: $el[0]
    };
  }
  let isDetail;
  let isDetailRoot;
  if (masterDetailEnabled) {
    const $pagesInView = router.$el.children(".page").filter((pageInView) => pageInView !== $newPage[0]);
    for (let i = 0; i < $pagesInView.length; i += 1) {
      if (!masterPageEl && $pagesInView[i].classList.contains("page-master")) {
        masterPageEl = $pagesInView[i];
        continue;
      }
    }
    isDetail = !isMaster && masterPageEl && router.history.indexOf(options.route.url) > router.history.indexOf(masterPageEl.f7Page.route.url);
    if (!isDetail && !isMaster && masterPageEl && masterPageEl.f7Page && options.route.route.masterRoute) {
      isDetail = options.route.route.masterRoute.path === masterPageEl.f7Page.route.route.path;
    }
  }
  if (isDetail && masterPageEl && masterPageEl.f7Page) {
    isDetailRoot = router.history.indexOf(options.route.url) - router.history.indexOf(masterPageEl.f7Page.route.url) === 1;
  }
  $newPage.addClass(`page-${initialPreload ? "current" : "previous"}${isMaster ? " page-master" : ""}${isDetail ? " page-master-detail" : ""}${isDetailRoot ? " page-master-detail-root" : ""}`).removeAttr("aria-hidden").trigger("page:unstack").trigger("page:position", {
    position: initialPreload ? "current" : "previous"
  });
  router.emit("pageUnstack", $newPage[0]);
  router.emit("pagePosition", $newPage[0], initialPreload ? "current" : "previous");
  if (isMaster || isDetail) {
    $newPage.trigger("page:role", {
      role: isMaster ? "master" : "detail",
      root: !!isDetailRoot
    });
    router.emit("pageRole", $newPage[0], {
      role: isMaster ? "master" : "detail",
      detailRoot: !!isDetailRoot
    });
  }
  if (dynamicNavbar && $newNavbarEl.length > 0) {
    $newNavbarEl.addClass(`navbar-${initialPreload ? "current" : "previous"}${isMaster ? " navbar-master" : ""}${isDetail ? " navbar-master-detail" : ""}${isDetailRoot ? " navbar-master-detail-root" : ""}`).removeAttr("aria-hidden");
    $newNavbarEl.trigger("navbar:position", {
      position: initialPreload ? "current" : "previous"
    });
    router.emit("navbarPosition", $newNavbarEl[0], initialPreload ? "current" : "previous");
    if (isMaster || isDetailRoot) {
      router.emit("navbarRole", $newNavbarEl[0], {
        role: isMaster ? "master" : "detail",
        detailRoot: !!isDetailRoot
      });
    }
  }
  let backIndex;
  if (options.force) {
    if ($oldPage.prev(".page-previous").length >= 0) {
      if (router.history.indexOf(options.route.url) >= 0) {
        backIndex = router.history.length - router.history.indexOf(options.route.url) - 1;
        router.history = router.history.slice(0, router.history.indexOf(options.route.url) + 2);
        router.propsHistory = router.propsHistory.slice(0, router.history.indexOf(options.route.url) + 2);
        view.history = router.history;
      } else if (router.history[[router.history.length - 2]]) {
        router.propsHistory[router.propsHistory.length - 2] = options.props || {};
      } else {
        router.history.unshift(router.url);
        router.propsHistory.unshift(options.props || {});
      }
      const $pageToRemove = $oldPage.prev(".page-previous");
      let $navbarToRemove;
      if (dynamicNavbar) {
        $navbarToRemove = $(app.navbar.getElByPage($pageToRemove));
      }
      if ($pageToRemove.length > 0) {
        router.pageCallback("beforeRemove", $pageToRemove, $navbarToRemove, "previous", void 0, options);
        if ($pageToRemove[0] === masterPageEl) {
          masterPageRemoved = true;
        }
        router.removePage($pageToRemove);
        if (dynamicNavbar && $navbarToRemove.length) {
          router.removeNavbar($navbarToRemove);
        }
      }
    }
  }
  const newPageInDom = $newPage.parents(document2).length > 0;
  const f7Component = $newPage[0].f7Component;
  function insertPage() {
    if (initialPreload) {
      if (!newPageInDom && f7Component) {
        f7Component.mount((componentEl) => {
          router.$el.append(componentEl);
        });
      } else {
        router.$el.append($newPage);
      }
    }
    if ($newPage.next($oldPage).length === 0) {
      if (!newPageInDom && f7Component) {
        f7Component.mount((componentEl) => {
          $(componentEl).insertBefore($oldPage);
        });
      } else {
        $newPage.insertBefore($oldPage);
      }
    }
    if (dynamicNavbar && $newNavbarEl.length) {
      if ($newNavbarEl.find(".title-large").length) {
        $newNavbarEl.addClass("navbar-large");
      }
      $newNavbarEl.insertBefore($oldNavbarEl);
      if ($oldNavbarEl.length > 0) {
        $newNavbarEl.insertBefore($oldNavbarEl);
      } else {
        if (!router.$navbarsEl.parents(document2).length) {
          router.$el.prepend(router.$navbarsEl);
        }
        $navbarsEl.append($newNavbarEl);
      }
    }
    if (!newPageInDom) {
      router.pageCallback("mounted", $newPage, $newNavbarEl, "previous", "current", options, $oldPage);
    } else if (options.route && options.route.route && options.route.route.keepAlive && !$newPage[0].f7PageMounted) {
      $newPage[0].f7PageMounted = true;
      router.pageCallback("mounted", $newPage, $newNavbarEl, "previous", "current", options, $oldPage);
    }
  }
  if (options.preload) {
    insertPage();
    if (options.route.route.tab) {
      router.tabLoad(options.route.route.tab, extend$1({}, options, {
        history: false,
        browserHistory: false,
        preload: true
      }));
    }
    if (isMaster) {
      $newPage.removeClass("page-master-stacked").trigger("page:masterunstack");
      router.emit("pageMasterUnstack", $newPage[0]);
      if (dynamicNavbar) {
        $(app.navbar.getElByPage($newPage)).removeClass("navbar-master-stacked");
        router.emit("navbarMasterUnstack", app.navbar.getElByPage($newPage));
      }
    }
    router.pageCallback("init", $newPage, $newNavbarEl, "previous", "current", options, $oldPage);
    if (initialPreload) {
      router.pageCallback("beforeIn", $newPage, $newNavbarEl, "current", void 0, options);
      router.pageCallback("afterIn", $newPage, $newNavbarEl, "current", void 0, options);
    }
    const $previousPages = $newPage.prevAll(".page-previous:not(.page-master)");
    if ($previousPages.length > 0) {
      $previousPages.each((pageToRemove) => {
        const $pageToRemove = $(pageToRemove);
        let $navbarToRemove;
        if (dynamicNavbar) {
          $navbarToRemove = $(app.navbar.getElByPage($pageToRemove));
        }
        router.pageCallback("beforeRemove", $pageToRemove, $navbarToRemove, "previous", void 0);
        router.removePage($pageToRemove);
        if (dynamicNavbar && $navbarToRemove.length) {
          router.removeNavbar($navbarToRemove);
        }
      });
    }
    router.allowPageChange = true;
    return router;
  }
  if (!(device.ie || device.edge || device.firefox && !device.ios)) {
    if (router.params.browserHistory && options.browserHistory) {
      if (options.replaceState) {
        const browserHistoryRoot = router.params.browserHistoryRoot || "";
        History.replace(view.id, {
          url: options.route.url
        }, browserHistoryRoot + router.params.browserHistorySeparator + options.route.url);
      } else if (backIndex) {
        History.go(-backIndex);
      } else {
        History.back();
      }
    }
  }
  if (options.replaceState) {
    router.history[router.history.length - 1] = options.route.url;
    router.propsHistory[router.propsHistory.length - 1] = options.props || {};
  } else {
    if (router.history.length === 1) {
      router.history.unshift(router.url);
      router.propsHistory.unshift(options.props || {});
    }
    router.history.pop();
    router.propsHistory.pop();
  }
  router.saveHistory();
  router.currentPageEl = $newPage[0];
  if (dynamicNavbar && $newNavbarEl.length) {
    router.currentNavbarEl = $newNavbarEl[0];
  } else {
    delete router.currentNavbarEl;
  }
  router.currentRoute = options.route;
  if (device.ie || device.edge || device.firefox && !device.ios) {
    if (router.params.browserHistory && options.browserHistory) {
      if (options.replaceState) {
        const browserHistoryRoot = router.params.browserHistoryRoot || "";
        History.replace(view.id, {
          url: options.route.url
        }, browserHistoryRoot + router.params.browserHistorySeparator + options.route.url);
      } else if (backIndex) {
        History.go(-backIndex);
      } else {
        History.back();
      }
    }
  }
  insertPage();
  if (options.route.route.tab) {
    router.tabLoad(options.route.route.tab, extend$1({}, options, {
      history: false,
      browserHistory: false
    }));
  }
  if (masterDetailEnabled && (currentIsMaster || masterPageRemoved)) {
    view.checkMasterDetailBreakpoint(false);
  }
  router.pageCallback("init", $newPage, $newNavbarEl, "previous", "current", options, $oldPage);
  router.pageCallback("beforeOut", $oldPage, $oldNavbarEl, "current", "next", options);
  router.pageCallback("beforeIn", $newPage, $newNavbarEl, "previous", "current", options);
  function afterAnimation() {
    router.setPagePosition($newPage, "current", false);
    router.setPagePosition($oldPage, "next", true);
    if (dynamicNavbar) {
      router.setNavbarPosition($newNavbarEl, "current", false);
      router.setNavbarPosition($oldNavbarEl, "next", true);
    }
    router.pageCallback("afterOut", $oldPage, $oldNavbarEl, "current", "next", options);
    router.pageCallback("afterIn", $newPage, $newNavbarEl, "previous", "current", options);
    router.pageCallback("beforeRemove", $oldPage, $oldNavbarEl, "next", void 0, options);
    router.removePage($oldPage);
    if (dynamicNavbar && $oldNavbarEl.length) {
      router.removeNavbar($oldNavbarEl);
    }
    router.allowPageChange = true;
    router.emit("routeChanged", router.currentRoute, router.previousRoute, router);
    const preloadPreviousPage = router.params.preloadPreviousPage || router.params[`${app.theme}SwipeBack`];
    if (preloadPreviousPage && router.history[router.history.length - 2] && !isMaster) {
      router.back(router.history[router.history.length - 2], {
        preload: true,
        props: router.propsHistory[router.propsHistory.length - 2] || {}
      });
    }
    if (router.params.browserHistory) {
      History.clearRouterQueue();
    }
  }
  function setPositionClasses() {
    router.setPagePosition($oldPage, "current");
    router.setPagePosition($newPage, "previous", false);
    if (dynamicNavbar) {
      router.setNavbarPosition($oldNavbarEl, "current");
      router.setNavbarPosition($newNavbarEl, "previous", false);
    }
  }
  if (options.animate && !(currentIsMaster && app.width >= router.params.masterDetailBreakpoint)) {
    let transition2 = router.params.transition;
    if ($oldPage[0] && $oldPage[0].f7PageTransition) {
      transition2 = $oldPage[0].f7PageTransition;
      delete $oldPage[0].f7PageTransition;
    }
    if (options.transition) transition2 = options.transition;
    if (!transition2 && router.previousRoute && router.previousRoute.route) {
      transition2 = router.previousRoute.route.transition;
    }
    if (!transition2 && router.previousRoute && router.previousRoute.route && router.previousRoute.route.options) {
      transition2 = router.previousRoute.route.options.transition;
    }
    setPositionClasses();
    router.animate($oldPage, $newPage, $oldNavbarEl, $newNavbarEl, "backward", transition2, () => {
      afterAnimation();
    });
  } else {
    afterAnimation();
  }
  return router;
}
function loadBack(router, backParams, backOptions, ignorePageChange) {
  if (!router.allowPageChange && !ignorePageChange) return router;
  const params = backParams;
  const options = backOptions;
  const {
    url,
    content,
    el,
    pageName,
    component,
    componentUrl
  } = params;
  if (options.route.url && router.url === options.route.url && !(options.reloadCurrent || options.reloadPrevious) && !router.params.allowDuplicateUrls) {
    router.allowPageChange = true;
    return false;
  }
  if (!options.route && url) {
    options.route = router.parseRouteUrl(url);
  }
  function resolve(pageEl, newOptions) {
    return backward(router, pageEl, extend$1(options, newOptions));
  }
  function reject() {
    router.allowPageChange = true;
    return router;
  }
  if (url || componentUrl || component) {
    router.allowPageChange = false;
  }
  if (content) {
    backward(router, router.getPageEl(content), options);
  } else if (el) {
    backward(router, router.getPageEl(el), options);
  } else if (pageName) {
    backward(router, router.$el.children(`.page[data-name="${pageName}"]`).eq(0), options);
  } else if (component || componentUrl) {
    try {
      router.pageComponentLoader({
        routerEl: router.el,
        component,
        componentUrl,
        options,
        resolve,
        reject
      });
    } catch (err) {
      router.allowPageChange = true;
      throw err;
    }
  } else if (url) {
    if (router.xhrAbortController) {
      router.xhrAbortController.abort();
      router.xhrAbortController = false;
    }
    router.xhrRequest(url, options).then((pageContent) => {
      backward(router, router.getPageEl(pageContent), options);
    }).catch(() => {
      router.allowPageChange = true;
    });
  }
  return router;
}
function back() {
  const router = this;
  const device = getDevice();
  if (router.swipeBackActive) return router;
  let navigateUrl;
  let navigateOptions;
  let navigateProps;
  let route;
  if (typeof (arguments.length <= 0 ? void 0 : arguments[0]) === "object") {
    navigateOptions = (arguments.length <= 0 ? void 0 : arguments[0]) || {};
  } else {
    navigateUrl = arguments.length <= 0 ? void 0 : arguments[0];
    navigateOptions = (arguments.length <= 1 ? void 0 : arguments[1]) || {};
  }
  const {
    name: name2,
    params,
    query
  } = navigateOptions;
  if (name2) {
    navigateUrl = router.generateUrl({
      name: name2,
      params,
      query
    });
    if (navigateUrl) {
      return router.back(navigateUrl, extend$1({}, navigateOptions, {
        name: null,
        params: null,
        query: null
      }));
    }
    return router;
  }
  const app = router.app;
  appRouterCheck(router, "back");
  let currentRouteIsModal = router.currentRoute.modal;
  let modalType;
  if (!currentRouteIsModal) {
    "popup popover sheet loginScreen actions customModal panel".split(" ").forEach((modalLoadProp) => {
      if (router.currentRoute.route[modalLoadProp]) {
        currentRouteIsModal = true;
        modalType = modalLoadProp;
      }
    });
  }
  if (currentRouteIsModal && !navigateOptions.preload) {
    const modalToClose = router.currentRoute.modal || router.currentRoute.route.modalInstance || app[modalType].get();
    const previousUrl = router.history[router.history.length - 2];
    let previousRoute;
    if (modalToClose && modalToClose.$el) {
      const prevOpenedModals = modalToClose.$el.prevAll(".modal-in");
      if (prevOpenedModals.length && prevOpenedModals[0].f7Modal) {
        const modalEl = prevOpenedModals[0];
        if (!router.$el.parents(modalEl).length) {
          previousRoute = modalEl.f7Modal.route;
        }
      }
    }
    if (!previousRoute) {
      previousRoute = router.findMatchingRoute(previousUrl);
    }
    if (!previousRoute && previousUrl) {
      previousRoute = {
        url: previousUrl,
        path: previousUrl.split("?")[0],
        query: parseUrlQuery(previousUrl),
        route: {
          path: previousUrl.split("?")[0],
          url: previousUrl
        }
      };
    }
    if (!navigateUrl || navigateUrl.replace(/[# ]/g, "").trim().length === 0) {
      if (!previousRoute || !modalToClose) {
        return router;
      }
    }
    const forceOtherUrl = navigateOptions.force && previousRoute && navigateUrl;
    if (previousRoute && modalToClose) {
      const isBrokenBrowserHistory = device.ie || device.edge || device.firefox && !device.ios;
      const needHistoryBack = router.params.browserHistory && navigateOptions.browserHistory !== false;
      const currentRouteWithoutBrowserHistory = router.currentRoute && router.currentRoute.route && router.currentRoute.route.options && router.currentRoute.route.options.browserHistory === false;
      if (needHistoryBack && !isBrokenBrowserHistory && !currentRouteWithoutBrowserHistory) {
        History.back();
      }
      router.currentRoute = previousRoute;
      router.history.pop();
      router.propsHistory.pop();
      router.saveHistory();
      if (needHistoryBack && isBrokenBrowserHistory && !currentRouteWithoutBrowserHistory) {
        History.back();
      }
      router.modalRemove(modalToClose);
      if (forceOtherUrl) {
        router.navigate(navigateUrl, {
          reloadCurrent: true
        });
      }
    } else if (modalToClose) {
      router.modalRemove(modalToClose);
      if (navigateUrl) {
        router.navigate(navigateUrl, {
          reloadCurrent: true
        });
      }
    }
    return router;
  }
  let $previousPage = router.$el.children(".page-current").prevAll(".page-previous:not(.page-master)").eq(0);
  let skipMaster;
  if (router.params.masterDetailBreakpoint > 0) {
    router.$el.children(".page").each((pageEl) => {
    });
    const $previousMaster = router.$el.children(".page-current").prevAll(".page-master").eq(0);
    if ($previousMaster.length) {
      const expectedPreviousPageUrl = router.history[router.history.length - 2];
      const expectedPreviousPageRoute = router.findMatchingRoute(expectedPreviousPageUrl);
      if (expectedPreviousPageRoute && $previousMaster[0].f7Page && expectedPreviousPageRoute.route === $previousMaster[0].f7Page.route.route) {
        $previousPage = $previousMaster;
        if (!navigateOptions.preload) {
          skipMaster = app.width >= router.params.masterDetailBreakpoint;
        }
      }
    }
  }
  if (!navigateOptions.force && $previousPage.length && !skipMaster) {
    const previousPageObj = $previousPage[0].f7Page;
    if (router.params.browserHistory && previousPageObj && router.history[router.history.length - 2] !== previousPageObj.route.url) {
      router.back(router.history[router.history.length - 2], extend$1(navigateOptions, {
        force: true,
        props: router.propsHistory[router.propsHistory.length - 2] || {}
      }));
      return router;
    }
    if (previousPageObj) {
      const previousPageRoute = previousPageObj.route;
      processRouteQueue.call(router, previousPageRoute, router.currentRoute, () => {
        loadBack(router, {
          el: $previousPage
        }, extend$1(navigateOptions, {
          route: previousPageRoute
        }));
      }, () => {
      }, "backward");
      return router;
    }
  }
  if (navigateUrl === "#") {
    navigateUrl = void 0;
  }
  if (navigateUrl && navigateUrl[0] !== "/" && navigateUrl.indexOf("#") !== 0) {
    navigateUrl = ((router.path || "/") + navigateUrl).replace("//", "/");
  }
  if (!navigateUrl && router.history.length > 1) {
    navigateUrl = router.history[router.history.length - 2];
    navigateProps = router.propsHistory[router.propsHistory.length - 2] || {};
  }
  if (skipMaster && !navigateOptions.force && router.history[router.history.length - 3]) {
    return router.back(router.history[router.history.length - 3], extend$1({}, navigateOptions || {}, {
      force: true,
      animate: false,
      props: router.propsHistory[router.propsHistory.length - 3] || {}
    }));
  }
  if (skipMaster && !navigateOptions.force) {
    return router;
  }
  route = router.findMatchingRoute(navigateUrl);
  if (!route) {
    if (navigateUrl) {
      route = {
        url: navigateUrl,
        path: navigateUrl.split("?")[0],
        query: parseUrlQuery(navigateUrl),
        route: {
          path: navigateUrl.split("?")[0],
          url: navigateUrl
        }
      };
    }
  }
  if (!route) {
    return router;
  }
  if (route.route.redirect) {
    return redirect.call(router, "backward", route, navigateOptions);
  }
  const options = {};
  if (route.route.options) {
    extend$1(options, route.route.options, navigateOptions, {
      props: navigateProps || {}
    });
  } else {
    extend$1(options, navigateOptions, {
      props: navigateProps || {}
    });
  }
  options.route = route;
  function resolve() {
    let routerLoaded = false;
    if (route.route.keepAlive && route.route.keepAliveData) {
      loadBack(router, {
        el: route.route.keepAliveData.pageEl
      }, options);
      routerLoaded = true;
    }
    "url content component pageName el componentUrl".split(" ").forEach((pageLoadProp) => {
      if (route.route[pageLoadProp] && !routerLoaded) {
        routerLoaded = true;
        loadBack(router, {
          [pageLoadProp]: route.route[pageLoadProp]
        }, options);
      }
    });
    if (routerLoaded) return;
    function asyncResolve(resolveParams, resolveOptions) {
      router.allowPageChange = false;
      loadBack(router, resolveParams, extend$1(options, resolveOptions), true);
    }
    function asyncReject() {
      router.allowPageChange = true;
    }
    if (route.route.async) {
      router.allowPageChange = false;
      route.route.async.call(router, {
        router,
        to: route,
        from: router.currentRoute,
        resolve: asyncResolve,
        reject: asyncReject,
        direction: "backward",
        app
      });
    }
    if (route.route.asyncComponent) {
      asyncComponent(router, route.route.asyncComponent, asyncResolve, asyncReject);
    }
  }
  function reject() {
    router.allowPageChange = true;
  }
  if (options.preload) {
    resolve();
  } else {
    processRouteQueue.call(router, route, router.currentRoute, () => {
      if (route.route.modules) {
        app.loadModules(Array.isArray(route.route.modules) ? route.route.modules : [route.route.modules]).then(() => {
          resolve();
        }).catch(() => {
          reject();
        });
      } else {
        resolve();
      }
    }, () => {
      reject();
    }, "backward");
  }
  return router;
}
function clearPreviousPages(router) {
  appRouterCheck(router, "clearPreviousPages");
  const app = router.app;
  const dynamicNavbar = router.dynamicNavbar;
  const $pagesToRemove = router.$el.children(".page").filter((pageInView) => {
    if (router.currentRoute && (router.currentRoute.modal || router.currentRoute.panel)) return true;
    return pageInView !== router.currentPageEl;
  });
  $pagesToRemove.each((pageEl) => {
    const $oldPageEl = $(pageEl);
    const $oldNavbarEl = $(app.navbar.getElByPage($oldPageEl));
    router.pageCallback("beforeRemove", $oldPageEl, $oldNavbarEl, "previous", void 0, {});
    router.removePage($oldPageEl);
    if (dynamicNavbar && $oldNavbarEl.length) {
      router.removeNavbar($oldNavbarEl);
    }
  });
}
function clearPreviousHistory() {
  const router = this;
  appRouterCheck(router, "clearPreviousHistory");
  const url = router.history[router.history.length - 1];
  clearPreviousPages(router);
  router.history = [url];
  router.view.history = [url];
  router.saveHistory();
}
class Router extends Framework7Class {
  constructor(app, view) {
    super({}, [typeof view === "undefined" ? app : view]);
    const router = this;
    router.isAppRouter = typeof view === "undefined";
    if (router.isAppRouter) {
      extend$1(false, router, {
        app,
        params: app.params.view,
        routes: app.routes || [],
        cache: app.cache
      });
    } else {
      extend$1(false, router, {
        app,
        view,
        viewId: view.id,
        id: view.params.routerId,
        params: view.params,
        routes: view.routes,
        history: view.history,
        propsHistory: [],
        scrollHistory: view.scrollHistory,
        cache: app.cache,
        dynamicNavbar: app.theme === "ios" && view.params.iosDynamicNavbar,
        initialPages: [],
        initialNavbars: []
      });
    }
    router.useModules();
    router.allowPageChange = true;
    let currentRoute = {};
    let previousRoute = {};
    Object.defineProperty(router, "currentRoute", {
      enumerable: true,
      configurable: true,
      set(newRoute) {
        if (newRoute === void 0) {
          newRoute = {};
        }
        previousRoute = extend$1({}, currentRoute);
        currentRoute = newRoute;
        if (!currentRoute) return;
        router.url = currentRoute.url;
        router.emit("routeChange", newRoute, previousRoute, router);
      },
      get() {
        return currentRoute;
      }
    });
    Object.defineProperty(router, "previousRoute", {
      enumerable: true,
      configurable: true,
      get() {
        return previousRoute;
      },
      set(newRoute) {
        previousRoute = newRoute;
      }
    });
    return router;
  }
  mount() {
    const router = this;
    const view = router.view;
    const document2 = getDocument();
    extend$1(false, router, {
      tempDom: document2.createElement("div"),
      $el: view.$el,
      el: view.el,
      $navbarsEl: view.$navbarsEl,
      navbarsEl: view.navbarsEl
    });
    router.emit("local::mount routerMount", router);
  }
  animatableNavElements($newNavbarEl, $oldNavbarEl, toLarge, fromLarge, direction) {
    const router = this;
    const dynamicNavbar = router.dynamicNavbar;
    const animateIcon = router.params.iosAnimateNavbarBackIcon;
    let newNavEls;
    let oldNavEls;
    function animatableNavEl($el, $navbarInner) {
      const isSliding = $el.hasClass("sliding") || $navbarInner.hasClass("sliding");
      const isSubnavbar = $el.hasClass("subnavbar");
      const needsOpacityTransition = isSliding ? !isSubnavbar : true;
      const $iconEl = $el.find(".back .icon");
      let isIconLabel;
      if (isSliding && animateIcon && $el.hasClass("left") && $iconEl.length > 0 && $iconEl.next("span").length) {
        $el = $iconEl.next("span");
        isIconLabel = true;
      }
      return {
        $el,
        isIconLabel,
        leftOffset: $el[0].f7NavbarLeftOffset,
        rightOffset: $el[0].f7NavbarRightOffset,
        isSliding,
        isSubnavbar,
        needsOpacityTransition
      };
    }
    if (dynamicNavbar) {
      newNavEls = [];
      oldNavEls = [];
      $newNavbarEl.children(".navbar-inner").children(".left, .right, .title, .subnavbar").each((navEl) => {
        const $navEl = $(navEl);
        if ($navEl.hasClass("left") && fromLarge && direction === "forward") return;
        if ($navEl.hasClass("title") && toLarge) return;
        newNavEls.push(animatableNavEl($navEl, $newNavbarEl.children(".navbar-inner")));
      });
      if (!($oldNavbarEl.hasClass("navbar-master") && router.params.masterDetailBreakpoint > 0 && router.app.width >= router.params.masterDetailBreakpoint)) {
        $oldNavbarEl.children(".navbar-inner").children(".left, .right, .title, .subnavbar").each((navEl) => {
          const $navEl = $(navEl);
          if ($navEl.hasClass("left") && toLarge && !fromLarge && direction === "forward") return;
          if ($navEl.hasClass("left") && toLarge && direction === "backward") return;
          if ($navEl.hasClass("title") && fromLarge) {
            return;
          }
          oldNavEls.push(animatableNavEl($navEl, $oldNavbarEl.children(".navbar-inner")));
        });
      }
      [oldNavEls, newNavEls].forEach((navEls) => {
        navEls.forEach((navEl) => {
          const n = navEl;
          const {
            isSliding,
            $el
          } = navEl;
          const otherEls = navEls === oldNavEls ? newNavEls : oldNavEls;
          if (!(isSliding && $el.hasClass("title") && otherEls)) return;
          otherEls.forEach((otherNavEl) => {
            if (otherNavEl.isIconLabel) {
              const iconTextEl = otherNavEl.$el[0];
              n.leftOffset += iconTextEl ? iconTextEl.offsetLeft || 0 : 0;
            }
          });
        });
      });
    }
    return {
      newNavEls,
      oldNavEls
    };
  }
  animate($oldPageEl, $newPageEl, $oldNavbarEl, $newNavbarEl, direction, transition2, callback) {
    const router = this;
    if (router.params.animateCustom) {
      router.params.animateCustom.apply(router, [$oldPageEl, $newPageEl, $oldNavbarEl, $newNavbarEl, direction, callback]);
      return;
    }
    const dynamicNavbar = router.dynamicNavbar;
    const ios = router.app.theme === "ios";
    if (transition2) {
      const routerCustomTransitionClass = `router-transition-custom router-transition-${transition2}-${direction}`;
      const onCustomTransitionDone = () => {
        router.$el.removeClass(routerCustomTransitionClass);
        if (dynamicNavbar && router.$navbarsEl.length) {
          if ($newNavbarEl) {
            router.$navbarsEl.prepend($newNavbarEl);
          }
          if ($oldNavbarEl) {
            router.$navbarsEl.prepend($oldNavbarEl);
          }
        }
        if (callback) callback();
      };
      (direction === "forward" ? $newPageEl : $oldPageEl).animationEnd(onCustomTransitionDone);
      if (dynamicNavbar) {
        if ($newNavbarEl && $newPageEl) {
          router.setNavbarPosition($newNavbarEl, "");
          $newNavbarEl.removeClass("navbar-next navbar-previous navbar-current");
          $newPageEl.prepend($newNavbarEl);
        }
        if ($oldNavbarEl && $oldPageEl) {
          router.setNavbarPosition($oldNavbarEl, "");
          $oldNavbarEl.removeClass("navbar-next navbar-previous navbar-current");
          $oldPageEl.prepend($oldNavbarEl);
        }
      }
      router.$el.addClass(routerCustomTransitionClass);
      return;
    }
    const routerTransitionClass = `router-transition-${direction} router-transition`;
    let newNavEls;
    let oldNavEls;
    let fromLarge;
    let toLarge;
    let toDifferent;
    let oldIsLarge;
    let newIsLarge;
    if (ios && dynamicNavbar) {
      const betweenMasterAndDetail = router.params.masterDetailBreakpoint > 0 && router.app.width >= router.params.masterDetailBreakpoint && ($oldNavbarEl.hasClass("navbar-master") && $newNavbarEl.hasClass("navbar-master-detail") || $oldNavbarEl.hasClass("navbar-master-detail") && $newNavbarEl.hasClass("navbar-master"));
      if (!betweenMasterAndDetail) {
        oldIsLarge = $oldNavbarEl && $oldNavbarEl.hasClass("navbar-large");
        newIsLarge = $newNavbarEl && $newNavbarEl.hasClass("navbar-large");
        fromLarge = oldIsLarge && !$oldNavbarEl.hasClass("navbar-large-collapsed");
        toLarge = newIsLarge && !$newNavbarEl.hasClass("navbar-large-collapsed");
        toDifferent = fromLarge && !toLarge || toLarge && !fromLarge;
      }
      const navEls = router.animatableNavElements($newNavbarEl, $oldNavbarEl, toLarge, fromLarge, direction);
      newNavEls = navEls.newNavEls;
      oldNavEls = navEls.oldNavEls;
    }
    function animateNavbars(progress) {
      if (!(ios && dynamicNavbar)) return;
      if (progress === 1) {
        if (toLarge) {
          $newNavbarEl.addClass("router-navbar-transition-to-large");
          $oldNavbarEl.addClass("router-navbar-transition-to-large");
        }
        if (fromLarge) {
          $newNavbarEl.addClass("router-navbar-transition-from-large");
          $oldNavbarEl.addClass("router-navbar-transition-from-large");
        }
      }
      newNavEls.forEach((navEl) => {
        const $el = navEl.$el;
        const offset2 = direction === "forward" ? navEl.rightOffset : navEl.leftOffset;
        if (navEl.isSliding) {
          if (navEl.isSubnavbar && newIsLarge) {
            $el[0].style.setProperty("transform", `translate3d(${offset2 * (1 - progress)}px, calc(-1 * var(--f7-navbar-large-collapse-progress) * var(--f7-navbar-large-title-height)), 0)`, "important");
          } else {
            $el.transform(`translate3d(${offset2 * (1 - progress)}px,0,0)`);
          }
        }
      });
      oldNavEls.forEach((navEl) => {
        const $el = navEl.$el;
        const offset2 = direction === "forward" ? navEl.leftOffset : navEl.rightOffset;
        if (navEl.isSliding) {
          if (navEl.isSubnavbar && oldIsLarge) {
            $el.transform(`translate3d(${offset2 * progress}px, calc(-1 * var(--f7-navbar-large-collapse-progress) * var(--f7-navbar-large-title-height)), 0)`);
          } else {
            $el.transform(`translate3d(${offset2 * progress}px,0,0)`);
          }
        }
      });
    }
    function onDone() {
      if (router.dynamicNavbar) {
        if ($newNavbarEl) {
          $newNavbarEl.removeClass("router-navbar-transition-to-large router-navbar-transition-from-large");
          $newNavbarEl.addClass("navbar-no-title-large-transition");
          nextFrame(() => {
            $newNavbarEl.removeClass("navbar-no-title-large-transition");
          });
        }
        if ($oldNavbarEl) {
          $oldNavbarEl.removeClass("router-navbar-transition-to-large router-navbar-transition-from-large");
        }
        if ($newNavbarEl.hasClass("sliding") || $newNavbarEl.children(".navbar-inner.sliding").length) {
          $newNavbarEl.find(".title, .left, .right, .left .icon, .subnavbar").transform("");
        } else {
          $newNavbarEl.find(".sliding").transform("");
        }
        if ($oldNavbarEl.hasClass("sliding") || $oldNavbarEl.children(".navbar-inner.sliding").length) {
          $oldNavbarEl.find(".title, .left, .right, .left .icon, .subnavbar").transform("");
        } else {
          $oldNavbarEl.find(".sliding").transform("");
        }
      }
      router.$el.removeClass(routerTransitionClass);
      if (callback) callback();
    }
    (direction === "forward" ? $newPageEl : ios ? $oldPageEl : $newPageEl).animationEnd(() => {
      onDone();
    });
    if (dynamicNavbar) {
      animateNavbars(0);
      nextFrame(() => {
        router.$el.addClass(routerTransitionClass);
        if (toDifferent) {
          router.el._clientLeft = router.el.clientLeft;
        }
        animateNavbars(1);
      });
    } else {
      router.$el.addClass(routerTransitionClass);
    }
  }
  removeModal(modalEl) {
    const router = this;
    router.removeEl(modalEl);
  }
  // eslint-disable-next-line
  removeTabContent(tabEl) {
    const $tabEl = $(tabEl);
    $tabEl.html("");
  }
  removeNavbar(el) {
    const router = this;
    router.removeEl(el);
  }
  removePage(el) {
    const $el = $(el);
    const f7Page = $el && $el[0] && $el[0].f7Page;
    const router = this;
    if (f7Page && f7Page.route && f7Page.route.route && f7Page.route.route.keepAlive) {
      $el.remove();
      return;
    }
    router.removeEl(el);
  }
  removeEl(el) {
    if (!el) return;
    const router = this;
    const $el = $(el);
    if ($el.length === 0) return;
    $el.find(".tab").each((tabEl) => {
      $(tabEl).children().each((tabChild) => {
        if (tabChild.f7Component) {
          $(tabChild).trigger("tab:beforeremove");
          tabChild.f7Component.destroy();
        }
      });
    });
    if ($el[0].f7Component && $el[0].f7Component.destroy) {
      $el[0].f7Component.destroy();
    }
    if (!router.params.removeElements) {
      return;
    }
    if (router.params.removeElementsWithTimeout) {
      setTimeout(() => {
        $el.remove();
      }, router.params.removeElementsTimeout);
    } else {
      $el.remove();
    }
  }
  getPageEl(content) {
    const router = this;
    if (typeof content === "string") {
      router.tempDom.innerHTML = content;
    } else {
      if ($(content).hasClass("page")) {
        return content;
      }
      router.tempDom.innerHTML = "";
      $(router.tempDom).append(content);
    }
    return router.findElement(".page", router.tempDom);
  }
  findElement(stringSelector, container2) {
    const router = this;
    const view = router.view;
    const app = router.app;
    const modalsSelector = ".popup, .dialog, .popover, .actions-modal, .sheet-modal, .login-screen, .page";
    const $container = $(container2);
    const selector = stringSelector;
    let found = $container.find(selector).filter((el) => $(el).parents(modalsSelector).length === 0);
    if (found.length > 1) {
      if (typeof view.selector === "string") {
        found = $container.find(`${view.selector} ${selector}`);
      }
      if (found.length > 1) {
        found = $container.find(`.${app.params.viewMainClass} ${selector}`);
      }
    }
    if (found.length === 1) return found;
    found = router.findElement(selector, $container);
    if (found && found.length === 1) return found;
    if (found && found.length > 1) return $(found[0]);
    return void 0;
  }
  flattenRoutes(routes) {
    if (routes === void 0) {
      routes = this.routes;
    }
    const router = this;
    let flattenedRoutes = [];
    routes.forEach((route) => {
      let hasTabRoutes = false;
      if ("tabs" in route && route.tabs) {
        const mergedPathsRoutes = route.tabs.map((tabRoute) => {
          const tRoute = extend$1({}, route, {
            path: `${route.path}/${tabRoute.path}`.replace("///", "/").replace("//", "/"),
            parentPath: route.path,
            tab: tabRoute
          });
          delete tRoute.tabs;
          delete tRoute.routes;
          return tRoute;
        });
        hasTabRoutes = true;
        flattenedRoutes = flattenedRoutes.concat(router.flattenRoutes(mergedPathsRoutes));
      }
      if ("detailRoutes" in route) {
        const mergedPathsRoutes = route.detailRoutes.map((detailRoute) => {
          const dRoute = extend$1({}, detailRoute);
          dRoute.masterRoute = route;
          dRoute.masterRoutePath = route.path;
          return dRoute;
        });
        flattenedRoutes = flattenedRoutes.concat(route, router.flattenRoutes(mergedPathsRoutes));
      }
      if ("routes" in route) {
        const mergedPathsRoutes = route.routes.map((childRoute) => {
          const cRoute = extend$1({}, childRoute);
          cRoute.path = `${route.path}/${cRoute.path}`.replace("///", "/").replace("//", "/");
          return cRoute;
        });
        if (hasTabRoutes) {
          flattenedRoutes = flattenedRoutes.concat(router.flattenRoutes(mergedPathsRoutes));
        } else {
          flattenedRoutes = flattenedRoutes.concat(route, router.flattenRoutes(mergedPathsRoutes));
        }
      }
      if (!("routes" in route) && !("tabs" in route && route.tabs) && !("detailRoutes" in route)) {
        flattenedRoutes.push(route);
      }
    });
    return flattenedRoutes;
  }
  // eslint-disable-next-line
  parseRouteUrl(url) {
    if (!url) return {};
    const query = parseUrlQuery(url);
    const hash = url.split("#")[1];
    const params = {};
    const path = url.split("#")[0].split("?")[0];
    return {
      query,
      hash,
      params,
      url,
      path
    };
  }
  generateUrl(parameters) {
    if (parameters === void 0) {
      parameters = {};
    }
    if (typeof parameters === "string") {
      return parameters;
    }
    const {
      name: name2,
      path,
      params,
      query
    } = parameters;
    if (!name2 && !path) {
      throw new Error('Framework7: "name" or "path" parameter is required');
    }
    const router = this;
    const route = name2 ? router.findRouteByKey("name", name2) : router.findRouteByKey("path", path);
    if (!route) {
      if (name2) {
        throw new Error(`Framework7: route with name "${name2}" not found`);
      } else {
        throw new Error(`Framework7: route with path "${path}" not found`);
      }
    }
    const url = router.constructRouteUrl(route, {
      params,
      query
    });
    if (url === "") {
      return "/";
    }
    if (!url) {
      throw new Error(`Framework7: can't construct URL for route with name "${name2}"`);
    }
    return url;
  }
  // eslint-disable-next-line
  constructRouteUrl(route, _temp) {
    let {
      params,
      query
    } = _temp === void 0 ? {} : _temp;
    const {
      path
    } = route;
    const toUrl = compile(path);
    let url;
    try {
      url = toUrl(params || {});
    } catch (error) {
      throw new Error(`Framework7: error constructing route URL from passed params:
Route: ${path}
${error.toString()}`);
    }
    if (query) {
      if (typeof query === "string") url += `?${query}`;
      else if (Object.keys(query).length) url += `?${serializeObject(query)}`;
    }
    return url;
  }
  findTabRouteUrl(tabEl) {
    const router = this;
    const $tabEl = $(tabEl);
    const parentPath = router.currentRoute.route.parentPath;
    const tabId = $tabEl.attr("id");
    const flattenedRoutes = router.flattenRoutes(router.routes);
    let foundTabRouteUrl;
    flattenedRoutes.forEach((route) => {
      if (route.parentPath === parentPath && route.tab && route.tab.id === tabId) {
        if (router.currentRoute.params && Object.keys(router.currentRoute.params).length > 0) {
          foundTabRouteUrl = router.constructRouteUrl(route, {
            params: router.currentRoute.params,
            query: router.currentRoute.query
          });
        } else {
          foundTabRouteUrl = route.path;
        }
      }
    });
    return foundTabRouteUrl;
  }
  findRouteByKey(key, value2) {
    const router = this;
    const routes = router.routes;
    const flattenedRoutes = router.flattenRoutes(routes);
    let matchingRoute;
    flattenedRoutes.forEach((route) => {
      if (matchingRoute) return;
      if (route[key] === value2) {
        matchingRoute = route;
      }
    });
    return matchingRoute;
  }
  findMatchingRoute(url) {
    if (!url) return void 0;
    const router = this;
    const routes = router.routes;
    const flattenedRoutes = router.flattenRoutes(routes);
    const {
      path,
      query,
      hash,
      params
    } = router.parseRouteUrl(url);
    let matchingRoute;
    flattenedRoutes.forEach((route) => {
      if (matchingRoute) return;
      const keys = [];
      const pathsToMatch = [route.path || "/"];
      if (route.alias) {
        if (typeof route.alias === "string") pathsToMatch.push(route.alias);
        else if (Array.isArray(route.alias)) {
          route.alias.forEach((aliasPath) => {
            pathsToMatch.push(aliasPath);
          });
        }
      }
      let matched;
      pathsToMatch.forEach((pathToMatch) => {
        if (matched) return;
        matched = pathToRegexp(pathToMatch, keys).exec(path || "/");
      });
      if (matched) {
        keys.forEach((keyObj, index2) => {
          if (typeof keyObj.name === "number") return;
          const paramValue = matched[index2 + 1];
          if (typeof paramValue === "undefined" || paramValue === null) {
            params[keyObj.name] = paramValue;
          } else {
            params[keyObj.name] = decodeURIComponent(paramValue);
          }
        });
        let parentPath;
        if (route.parentPath) {
          parentPath = (path || "/").split("/").slice(0, route.parentPath.split("/").length - 1).join("/");
        }
        matchingRoute = {
          query,
          hash,
          params,
          url,
          path: path || "/",
          parentPath,
          route,
          name: route.name
        };
      }
    });
    return matchingRoute;
  }
  // eslint-disable-next-line
  replaceRequestUrlParams(url, options) {
    if (url === void 0) {
      url = "";
    }
    if (options === void 0) {
      options = {};
    }
    let compiledUrl = url;
    if (typeof compiledUrl === "string" && compiledUrl.indexOf("{{") >= 0 && options && options.route && options.route.params && Object.keys(options.route.params).length) {
      Object.keys(options.route.params).forEach((paramName) => {
        const regExp = new RegExp(`{{${paramName}}}`, "g");
        compiledUrl = compiledUrl.replace(regExp, options.route.params[paramName] || "");
      });
    }
    return compiledUrl;
  }
  removeFromXhrCache(url) {
    const router = this;
    const xhrCache = router.cache.xhr;
    let index2 = false;
    for (let i = 0; i < xhrCache.length; i += 1) {
      if (xhrCache[i].url === url) index2 = i;
    }
    if (index2 !== false) xhrCache.splice(index2, 1);
  }
  xhrRequest(requestUrl, options) {
    const router = this;
    const params = router.params;
    const {
      ignoreCache
    } = options;
    let url = requestUrl;
    let hasQuery = url.indexOf("?") >= 0;
    if (params.passRouteQueryToRequest && options && options.route && options.route.query && Object.keys(options.route.query).length) {
      url += `${hasQuery ? "&" : "?"}${serializeObject(options.route.query)}`;
      hasQuery = true;
    }
    if (params.passRouteParamsToRequest && options && options.route && options.route.params && Object.keys(options.route.params).length) {
      url += `${hasQuery ? "&" : "?"}${serializeObject(options.route.params)}`;
      hasQuery = true;
    }
    if (url.indexOf("{{") >= 0) {
      url = router.replaceRequestUrlParams(url, options);
    }
    if (params.xhrCacheIgnoreGetParameters && url.indexOf("?") >= 0) {
      url = url.split("?")[0];
    }
    return new Promise((resolve, reject) => {
      if (params.xhrCache && !ignoreCache && url.indexOf("nocache") < 0 && params.xhrCacheIgnore.indexOf(url) < 0) {
        for (let i = 0; i < router.cache.xhr.length; i += 1) {
          const cachedUrl = router.cache.xhr[i];
          if (cachedUrl.url === url) {
            if (now$1() - cachedUrl.time < params.xhrCacheDuration) {
              resolve(cachedUrl.content);
              return;
            }
          }
        }
      }
      router.xhrAbortController = new AbortController();
      let fetchRes;
      fetch(url, {
        signal: router.xhrAbortController.signal,
        method: "GET"
      }).then((res) => {
        fetchRes = res;
        return res.text();
      }).then((responseText) => {
        const {
          status
        } = fetchRes;
        router.emit("routerAjaxComplete", fetchRes);
        if (status !== "error" && status !== "timeout" && status >= 200 && status < 300 || status === 0) {
          if (params.xhrCache && responseText !== "") {
            router.removeFromXhrCache(url);
            router.cache.xhr.push({
              url,
              time: now$1(),
              content: responseText
            });
          }
          router.emit("routerAjaxSuccess", fetchRes, options);
          resolve(responseText);
        } else {
          router.emit("routerAjaxError", fetchRes, options);
          reject(fetchRes);
        }
      }).catch((err) => {
        reject(err);
      });
    });
  }
  setNavbarPosition($el, position, ariaHidden) {
    const router = this;
    $el.removeClass("navbar-previous navbar-current navbar-next");
    if (position) {
      $el.addClass(`navbar-${position}`);
    }
    if (ariaHidden === false) {
      $el.removeAttr("aria-hidden");
    } else if (ariaHidden === true) {
      $el.attr("aria-hidden", "true");
    }
    $el.trigger("navbar:position", {
      position
    });
    router.emit("navbarPosition", $el[0], position);
  }
  setPagePosition($el, position, ariaHidden) {
    const router = this;
    $el.removeClass("page-previous page-current page-next");
    $el.addClass(`page-${position}`);
    if (ariaHidden === false) {
      $el.removeAttr("aria-hidden");
    } else if (ariaHidden === true) {
      $el.attr("aria-hidden", "true");
    }
    $el.trigger("page:position", {
      position
    });
    router.emit("pagePosition", $el[0], position);
  }
  // Remove theme elements
  removeThemeElements(el) {
    const router = this;
    const theme2 = router.app.theme;
    let toRemove;
    if (theme2 === "ios") {
      toRemove = ".md-only, .if-md, .if-not-ios, .not-ios";
    } else if (theme2 === "md") {
      toRemove = ".ios-only, .if-ios, .if-not-md, .not-md";
    }
    $(el).find(toRemove).remove();
  }
  getPageData(pageEl, navbarEl, from, to, route, pageFromEl) {
    if (route === void 0) {
      route = {};
    }
    const router = this;
    const $pageEl = $(pageEl).eq(0);
    const $navbarEl = $(navbarEl).eq(0);
    const currentPage = $pageEl[0].f7Page || {};
    let direction;
    let pageFrom;
    if (from === "next" && to === "current" || from === "current" && to === "previous") direction = "forward";
    if (from === "current" && to === "next" || from === "previous" && to === "current") direction = "backward";
    if (currentPage && !currentPage.fromPage) {
      const $pageFromEl = $(pageFromEl);
      if ($pageFromEl.length) {
        pageFrom = $pageFromEl[0].f7Page;
      }
    }
    pageFrom = currentPage.pageFrom || pageFrom;
    if (pageFrom && pageFrom.pageFrom) {
      pageFrom.pageFrom = null;
    }
    const page = {
      app: router.app,
      view: router.view,
      router,
      $el: $pageEl,
      el: $pageEl[0],
      $pageEl,
      pageEl: $pageEl[0],
      $navbarEl,
      navbarEl: $navbarEl[0],
      name: $pageEl.attr("data-name"),
      position: from,
      from,
      to,
      direction,
      route: currentPage.route ? currentPage.route : route,
      pageFrom
    };
    $pageEl[0].f7Page = page;
    return page;
  }
  // Callbacks
  pageCallback(callback, pageEl, navbarEl, from, to, options, pageFromEl) {
    if (options === void 0) {
      options = {};
    }
    if (!pageEl) return;
    const router = this;
    const $pageEl = $(pageEl);
    if (!$pageEl.length) return;
    const $navbarEl = $(navbarEl);
    const {
      route
    } = options;
    const restoreScrollTopOnBack = router.params.restoreScrollTopOnBack && !(router.params.masterDetailBreakpoint > 0 && $pageEl.hasClass("page-master") && router.app.width >= router.params.masterDetailBreakpoint);
    const keepAlive = $pageEl[0].f7Page && $pageEl[0].f7Page.route && $pageEl[0].f7Page.route.route && $pageEl[0].f7Page.route.route.keepAlive;
    if (callback === "beforeRemove" && keepAlive) {
      callback = "beforeUnmount";
    }
    const camelName = `page${callback[0].toUpperCase() + callback.slice(1, callback.length)}`;
    const colonName = `page:${callback.toLowerCase()}`;
    let page = {};
    if (callback === "beforeRemove" && $pageEl[0].f7Page) {
      page = extend$1($pageEl[0].f7Page, {
        from,
        to,
        position: from
      });
    } else {
      page = router.getPageData($pageEl[0], $navbarEl[0], from, to, route, pageFromEl);
    }
    page.swipeBack = !!options.swipeBack;
    const {
      on: on2 = {},
      once: once2 = {}
    } = options.route ? options.route.route : {};
    if (options.on) {
      extend$1(on2, options.on);
    }
    if (options.once) {
      extend$1(once2, options.once);
    }
    function attachEvents() {
      if ($pageEl[0].f7RouteEventsAttached) return;
      $pageEl[0].f7RouteEventsAttached = true;
      if (on2 && Object.keys(on2).length > 0) {
        $pageEl[0].f7RouteEventsOn = on2;
        Object.keys(on2).forEach((eventName) => {
          on2[eventName] = on2[eventName].bind(router);
          $pageEl.on(eventNameToColonCase(eventName), on2[eventName]);
        });
      }
      if (once2 && Object.keys(once2).length > 0) {
        $pageEl[0].f7RouteEventsOnce = once2;
        Object.keys(once2).forEach((eventName) => {
          once2[eventName] = once2[eventName].bind(router);
          $pageEl.once(eventNameToColonCase(eventName), once2[eventName]);
        });
      }
    }
    function detachEvents() {
      if (!$pageEl[0].f7RouteEventsAttached) return;
      if ($pageEl[0].f7RouteEventsOn) {
        Object.keys($pageEl[0].f7RouteEventsOn).forEach((eventName) => {
          $pageEl.off(eventNameToColonCase(eventName), $pageEl[0].f7RouteEventsOn[eventName]);
        });
      }
      if ($pageEl[0].f7RouteEventsOnce) {
        Object.keys($pageEl[0].f7RouteEventsOnce).forEach((eventName) => {
          $pageEl.off(eventNameToColonCase(eventName), $pageEl[0].f7RouteEventsOnce[eventName]);
        });
      }
      $pageEl[0].f7RouteEventsAttached = null;
      $pageEl[0].f7RouteEventsOn = null;
      $pageEl[0].f7RouteEventsOnce = null;
      delete $pageEl[0].f7RouteEventsAttached;
      delete $pageEl[0].f7RouteEventsOn;
      delete $pageEl[0].f7RouteEventsOnce;
    }
    if (callback === "mounted") {
      attachEvents();
    }
    if (callback === "init") {
      if (restoreScrollTopOnBack && (from === "previous" || !from) && to === "current" && router.scrollHistory[page.route.url] && !$pageEl.hasClass("no-restore-scroll")) {
        let $pageContent = $pageEl.find(".page-content");
        if ($pageContent.length > 0) {
          $pageContent = $pageContent.filter((pageContentEl) => {
            return $(pageContentEl).parents(".tab:not(.tab-active)").length === 0 && !$(pageContentEl).is(".tab:not(.tab-active)");
          });
        }
        $pageContent.scrollTop(router.scrollHistory[page.route.url]);
      }
      attachEvents();
      if ($pageEl[0].f7PageInitialized) {
        $pageEl.trigger("page:reinit", page);
        router.emit("pageReinit", page);
        return;
      }
      $pageEl[0].f7PageInitialized = true;
    }
    if (restoreScrollTopOnBack && callback === "beforeOut" && from === "current" && to === "previous") {
      let $pageContent = $pageEl.find(".page-content");
      if ($pageContent.length > 0) {
        $pageContent = $pageContent.filter((pageContentEl) => {
          return $(pageContentEl).parents(".tab:not(.tab-active)").length === 0 && !$(pageContentEl).is(".tab:not(.tab-active)");
        });
      }
      router.scrollHistory[page.route.url] = $pageContent.scrollTop();
    }
    if (restoreScrollTopOnBack && callback === "beforeOut" && from === "current" && to === "next") {
      delete router.scrollHistory[page.route.url];
    }
    $pageEl.trigger(colonName, page);
    router.emit(camelName, page);
    if (callback === "beforeRemove" || callback === "beforeUnmount") {
      detachEvents();
      if (!keepAlive) {
        if ($pageEl[0].f7Page && $pageEl[0].f7Page.navbarEl) {
          delete $pageEl[0].f7Page.navbarEl.f7Page;
        }
        $pageEl[0].f7Page = null;
      }
    }
  }
  saveHistory() {
    const router = this;
    const window2 = getWindow();
    router.view.history = router.history;
    if (router.params.browserHistory && router.params.browserHistoryStoreHistory && window2.localStorage) {
      window2.localStorage[`f7router-${router.view.id}-history`] = JSON.stringify(router.history);
    }
  }
  restoreHistory() {
    const router = this;
    const window2 = getWindow();
    if (router.params.browserHistory && router.params.browserHistoryStoreHistory && window2.localStorage && window2.localStorage[`f7router-${router.view.id}-history`]) {
      router.history = JSON.parse(window2.localStorage[`f7router-${router.view.id}-history`]);
      router.view.history = router.history;
    }
  }
  clearHistory() {
    const router = this;
    router.history = [];
    if (router.view) router.view.history = [];
    router.saveHistory();
  }
  updateCurrentUrl(newUrl) {
    const router = this;
    appRouterCheck(router, "updateCurrentUrl");
    if (router.history.length) {
      router.history[router.history.length - 1] = newUrl;
    } else {
      router.history.push(newUrl);
    }
    const {
      query,
      hash,
      params,
      url,
      path
    } = router.parseRouteUrl(newUrl);
    if (router.currentRoute) {
      extend$1(router.currentRoute, {
        query,
        hash,
        params,
        url,
        path
      });
    }
    if (router.params.browserHistory) {
      const browserHistoryRoot = router.params.browserHistoryRoot || "";
      History.replace(router.view.id, {
        url: newUrl
      }, browserHistoryRoot + router.params.browserHistorySeparator + newUrl);
    }
    router.saveHistory();
    router.emit("routeUrlUpdate", router.currentRoute, router);
  }
  getInitialUrl() {
    const router = this;
    if (router.initialUrl) {
      return {
        initialUrl: router.initialUrl,
        historyRestored: router.historyRestored
      };
    }
    const {
      app,
      view
    } = router;
    const document2 = getDocument();
    const window2 = getWindow();
    const location = app.params.url && typeof app.params.url === "string" && typeof URL !== "undefined" ? new URL(app.params.url) : document2.location;
    let initialUrl = router.params.url;
    let documentUrl = location.href.split(location.origin)[1];
    let historyRestored;
    const {
      browserHistory,
      browserHistoryOnLoad,
      browserHistorySeparator
    } = router.params;
    let {
      browserHistoryRoot
    } = router.params;
    if ((window2.cordova || window2.Capacitor && window2.Capacitor.isNative) && browserHistory && !browserHistorySeparator && !browserHistoryRoot && location.pathname.indexOf("index.html")) {
      console.warn("Framework7: wrong or not complete browserHistory configuration, trying to guess browserHistoryRoot");
      browserHistoryRoot = location.pathname.split("index.html")[0];
    }
    if (!browserHistory || !browserHistoryOnLoad) {
      if (!initialUrl) {
        initialUrl = documentUrl;
      }
      if (location.search && initialUrl.indexOf("?") < 0) {
        initialUrl += location.search;
      }
      if (location.hash && initialUrl.indexOf("#") < 0) {
        initialUrl += location.hash;
      }
    } else {
      if (browserHistoryRoot && documentUrl.indexOf(browserHistoryRoot) >= 0) {
        documentUrl = documentUrl.substring(documentUrl.indexOf(browserHistoryRoot) + browserHistoryRoot.length);
        if (documentUrl === "") documentUrl = "/";
      }
      if (browserHistorySeparator.length > 0 && documentUrl.indexOf(browserHistorySeparator) >= 0) {
        initialUrl = documentUrl.substring(documentUrl.indexOf(browserHistorySeparator) + browserHistorySeparator.length);
      } else {
        initialUrl = documentUrl;
      }
      router.restoreHistory();
      if (router.history.indexOf(initialUrl) >= 0) {
        router.history = router.history.slice(0, router.history.indexOf(initialUrl) + 1);
      } else if (router.params.url === initialUrl) {
        router.history = [initialUrl];
      } else if (History.state && History.state[view.id] && History.state[view.id].url === router.history[router.history.length - 1]) {
        initialUrl = router.history[router.history.length - 1];
      } else {
        router.history = [documentUrl.split(browserHistorySeparator)[0] || "/", initialUrl];
      }
      if (router.history.length > 1) {
        historyRestored = true;
      } else {
        router.history = [];
      }
      router.saveHistory();
    }
    router.initialUrl = initialUrl;
    router.historyRestored = historyRestored;
    return {
      initialUrl,
      historyRestored
    };
  }
  init() {
    const router = this;
    const {
      app,
      view
    } = router;
    const document2 = getDocument();
    router.mount();
    const {
      initialUrl,
      historyRestored
    } = router.getInitialUrl();
    if (view && router.params.iosSwipeBack && app.theme === "ios" || view && router.params.mdSwipeBack && app.theme === "md") {
      SwipeBack(router);
    }
    const {
      browserHistory,
      browserHistoryOnLoad,
      browserHistoryAnimateOnLoad,
      browserHistoryInitialMatch
    } = router.params;
    let currentRoute;
    if (router.history.length > 1) {
      const initUrl = browserHistoryInitialMatch ? initialUrl : router.history[0];
      currentRoute = router.findMatchingRoute(initUrl);
      if (!currentRoute) {
        currentRoute = extend$1(router.parseRouteUrl(initUrl), {
          route: {
            url: initUrl,
            path: initUrl.split("?")[0]
          }
        });
      }
    } else {
      currentRoute = router.findMatchingRoute(initialUrl);
      if (!currentRoute) {
        currentRoute = extend$1(router.parseRouteUrl(initialUrl), {
          route: {
            url: initialUrl,
            path: initialUrl.split("?")[0]
          }
        });
      }
    }
    if (router.$el.children(".page").length === 0 && initialUrl && router.params.loadInitialPage) {
      router.navigate(initialUrl, {
        initial: true,
        reloadCurrent: true,
        browserHistory: false,
        animate: false,
        once: {
          modalOpen() {
            if (!historyRestored) return;
            const preloadPreviousPage = router.params.preloadPreviousPage || router.params[`${app.theme}SwipeBack`];
            if (preloadPreviousPage && router.history.length > 1) {
              router.back({
                preload: true
              });
            }
          },
          pageAfterIn() {
            if (!historyRestored) return;
            const preloadPreviousPage = router.params.preloadPreviousPage || router.params[`${app.theme}SwipeBack`];
            if (preloadPreviousPage && router.history.length > 1) {
              router.back({
                preload: true
              });
            }
          }
        }
      });
    } else if (router.$el.children(".page").length) {
      let hasTabRoute;
      router.currentRoute = currentRoute;
      router.$el.children(".page").each((pageEl) => {
        const $pageEl = $(pageEl);
        let $navbarEl;
        router.setPagePosition($pageEl, "current");
        if (router.dynamicNavbar) {
          $navbarEl = $pageEl.children(".navbar");
          if ($navbarEl.length > 0) {
            if (!router.$navbarsEl.parents(document2).length) {
              router.$el.prepend(router.$navbarsEl);
            }
            router.setNavbarPosition($navbarEl, "current");
            router.$navbarsEl.append($navbarEl);
            if ($navbarEl.children(".title-large").length) {
              $navbarEl.addClass("navbar-large");
            }
            $pageEl.children(".navbar").remove();
          } else {
            router.$navbarsEl.addClass("navbar-hidden");
            if ($navbarEl.children(".title-large").length) {
              router.$navbarsEl.addClass("navbar-hidden navbar-large-hidden");
            }
          }
        }
        if (router.currentRoute && router.currentRoute.route && (router.currentRoute.route.master === true || typeof router.currentRoute.route.master === "function" && router.currentRoute.route.master(app, router)) && router.params.masterDetailBreakpoint > 0) {
          $pageEl.addClass("page-master");
          $pageEl.trigger("page:role", {
            role: "master"
          });
          if ($navbarEl && $navbarEl.length) {
            $navbarEl.addClass("navbar-master");
          }
          view.checkMasterDetailBreakpoint();
        }
        const initOptions = {
          route: router.currentRoute
        };
        if (router.currentRoute && router.currentRoute.route && router.currentRoute.route.options) {
          extend$1(initOptions, router.currentRoute.route.options);
        }
        router.currentPageEl = $pageEl[0];
        if (router.dynamicNavbar && $navbarEl.length) {
          router.currentNavbarEl = $navbarEl[0];
        }
        router.removeThemeElements($pageEl);
        if (router.dynamicNavbar && $navbarEl.length) {
          router.removeThemeElements($navbarEl);
        }
        if (initOptions.route.route.tab) {
          hasTabRoute = true;
          router.tabLoad(initOptions.route.route.tab, extend$1({}, initOptions));
        }
        router.pageCallback("init", $pageEl, $navbarEl, "current", void 0, initOptions);
        router.pageCallback("beforeIn", $pageEl, $navbarEl, "current", void 0, initOptions);
        router.pageCallback("afterIn", $pageEl, $navbarEl, "current", void 0, initOptions);
      });
      if (historyRestored) {
        if (browserHistoryInitialMatch) {
          const preloadPreviousPage = router.params.preloadPreviousPage || router.params[`${app.theme}SwipeBack`];
          if (preloadPreviousPage && router.history.length > 1) {
            router.back({
              preload: true
            });
          }
        } else {
          router.navigate(initialUrl, {
            initial: true,
            browserHistory: false,
            history: false,
            animate: browserHistoryAnimateOnLoad,
            once: {
              pageAfterIn() {
                const preloadPreviousPage = router.params.preloadPreviousPage || router.params[`${app.theme}SwipeBack`];
                if (preloadPreviousPage && router.history.length > 2) {
                  router.back({
                    preload: true
                  });
                }
              }
            }
          });
        }
      }
      if (!historyRestored && !hasTabRoute) {
        router.history.push(initialUrl);
        router.saveHistory();
      }
    }
    if (initialUrl && browserHistory && browserHistoryOnLoad && (!History.state || !History.state[view.id])) {
      History.initViewState(view.id, {
        url: initialUrl
      });
    }
    router.emit("local::init routerInit", router);
  }
  destroy() {
    let router = this;
    router.emit("local::destroy routerDestroy", router);
    Object.keys(router).forEach((routerProp) => {
      router[routerProp] = null;
      delete router[routerProp];
    });
    router = null;
  }
}
Router.prototype.navigate = navigate;
Router.prototype.refreshPage = refreshPage;
Router.prototype.tabLoad = tabLoad;
Router.prototype.tabRemove = tabRemove;
Router.prototype.modalLoad = modalLoad;
Router.prototype.modalRemove = modalRemove;
Router.prototype.back = back;
Router.prototype.clearPreviousHistory = clearPreviousHistory;
const RouterModule = {
  name: "router",
  static: {
    Router
  },
  instance: {
    cache: {
      xhr: [],
      templates: [],
      components: []
    }
  },
  create() {
    const instance = this;
    if (instance.app) {
      if (instance.params.router) {
        instance.router = new Router(instance.app, instance);
      }
    } else {
      instance.router = new Router(instance);
    }
  }
};
function resizableView(view) {
  const app = view.app;
  const support2 = getSupport();
  if (view.resizableInitialized) return;
  extend$1(view, {
    resizable: true,
    resizableWidth: null,
    resizableInitialized: true
  });
  const $htmlEl = $("html");
  const {
    $el
  } = view;
  if (!$el) return;
  let $resizeHandlerEl;
  let isTouched;
  let isMoved;
  const touchesStart = {};
  let touchesDiff;
  let width2;
  let minWidth;
  let maxWidth;
  function transformCSSWidth(v) {
    if (!v) return null;
    if (v.indexOf("%") >= 0 || v.indexOf("vw") >= 0) {
      return parseInt(v, 10) / 100 * app.width;
    }
    const newV = parseInt(v, 10);
    if (Number.isNaN(newV)) return null;
    return newV;
  }
  function isResizable() {
    return view.resizable && $el.hasClass("view-resizable") && $el.hasClass("view-master-detail");
  }
  function handleTouchStart(e) {
    if (!isResizable()) return;
    touchesStart.x = e.type === "touchstart" ? e.targetTouches[0].pageX : e.pageX;
    touchesStart.y = e.type === "touchstart" ? e.targetTouches[0].pageY : e.pageY;
    isMoved = false;
    isTouched = true;
    const $pageMasterEl = $el.children(".page-master");
    minWidth = transformCSSWidth($pageMasterEl.css("min-width"));
    maxWidth = transformCSSWidth($pageMasterEl.css("max-width"));
  }
  function handleTouchMove(e) {
    if (!isTouched) return;
    e.f7PreventSwipePanel = true;
    const pageX = e.type === "touchmove" ? e.targetTouches[0].pageX : e.pageX;
    if (!isMoved) {
      width2 = $resizeHandlerEl[0].offsetLeft + $resizeHandlerEl[0].offsetWidth;
      $el.addClass("view-resizing");
      $htmlEl.css("cursor", "col-resize");
    }
    isMoved = true;
    e.preventDefault();
    touchesDiff = pageX - touchesStart.x;
    let newWidth = width2 + touchesDiff;
    if (minWidth && !Number.isNaN(minWidth)) {
      newWidth = Math.max(newWidth, minWidth);
    }
    if (maxWidth && !Number.isNaN(maxWidth)) {
      newWidth = Math.min(newWidth, maxWidth);
    }
    newWidth = Math.min(Math.max(newWidth, 0), app.width);
    view.resizableWidth = newWidth;
    $htmlEl[0].style.setProperty("--f7-page-master-width", `${newWidth}px`);
    $el.trigger("view:resize", newWidth);
    view.emit("local::resize viewResize", view, newWidth);
  }
  function handleTouchEnd() {
    $("html").css("cursor", "");
    if (!isTouched || !isMoved) {
      isTouched = false;
      isMoved = false;
      return;
    }
    isTouched = false;
    isMoved = false;
    $htmlEl[0].style.setProperty("--f7-page-master-width", `${view.resizableWidth}px`);
    $el.removeClass("view-resizing");
  }
  function handleResize() {
    if (!view.resizableWidth) return;
    minWidth = transformCSSWidth($resizeHandlerEl.css("min-width"));
    maxWidth = transformCSSWidth($resizeHandlerEl.css("max-width"));
    if (minWidth && !Number.isNaN(minWidth) && view.resizableWidth < minWidth) {
      view.resizableWidth = Math.max(view.resizableWidth, minWidth);
    }
    if (maxWidth && !Number.isNaN(maxWidth) && view.resizableWidth > maxWidth) {
      view.resizableWidth = Math.min(view.resizableWidth, maxWidth);
    }
    view.resizableWidth = Math.min(Math.max(view.resizableWidth, 0), app.width);
    $htmlEl[0].style.setProperty("--f7-page-master-width", `${view.resizableWidth}px`);
  }
  $resizeHandlerEl = view.$el.children(".view-resize-handler");
  if (!$resizeHandlerEl.length) {
    view.$el.append('<div class="view-resize-handler"></div>');
    $resizeHandlerEl = view.$el.children(".view-resize-handler");
  }
  view.$resizeHandlerEl = $resizeHandlerEl;
  $el.addClass("view-resizable");
  const passive = support2.passiveListener ? {
    passive: true
  } : false;
  view.$el.on(app.touchEvents.start, ".view-resize-handler", handleTouchStart, passive);
  app.on("touchmove:active", handleTouchMove);
  app.on("touchend:passive", handleTouchEnd);
  app.on("resize", handleResize);
  view.on("beforeOpen", handleResize);
  view.once("viewDestroy", () => {
    $el.removeClass("view-resizable");
    view.$resizeHandlerEl.remove();
    view.$el.off(app.touchEvents.start, ".view-resize-handler", handleTouchStart, passive);
    app.off("touchmove:active", handleTouchMove);
    app.off("touchend:passive", handleTouchEnd);
    app.off("resize", handleResize);
    view.off("beforeOpen", handleResize);
  });
}
let View$2 = class View extends Framework7Class {
  constructor(app, el, viewParams) {
    if (viewParams === void 0) {
      viewParams = {};
    }
    super(viewParams, [app]);
    const view = this;
    const ssr = view.params.routerId;
    const defaults = {
      routes: [],
      routesAdd: []
    };
    if (!ssr) {
      const $el = $(el);
      if (!$el.length) {
        let message = "Framework7: can't create a View instance because ";
        message += typeof el === "string" ? `the selector "${el}" didn't match any element` : "el must be an HTMLElement or Dom7 object";
        throw new Error(message);
      }
    }
    view.params = extend$1({
      el
    }, defaults, app.params.view, viewParams);
    if (view.params.routes.length > 0) {
      view.routes = view.params.routes;
    } else {
      view.routes = [].concat(app.routes, view.params.routesAdd);
    }
    extend$1(false, view, {
      app,
      name: view.params.name,
      main: view.params.main,
      history: [],
      scrollHistory: {}
    });
    view.useModules();
    app.views.push(view);
    if (view.main) {
      app.views.main = view;
    }
    if (view.name) {
      app.views[view.name] = view;
    }
    view.index = app.views.indexOf(view);
    let viewId;
    if (view.name) {
      viewId = `view_${view.name}`;
    } else if (view.main) {
      viewId = "view_main";
    } else {
      viewId = `view_${view.index}`;
    }
    view.id = viewId;
    if (!view.params.init) {
      return view;
    }
    if (app.initialized) {
      view.init();
    } else {
      app.on("init", () => {
        view.init();
      });
    }
    return view;
  }
  destroy() {
    let view = this;
    const app = view.app;
    view.$el.trigger("view:beforedestroy");
    view.emit("local::beforeDestroy viewBeforeDestroy", view);
    app.off("resize", view.checkMasterDetailBreakpoint);
    if (view.main) {
      app.views.main = null;
      delete app.views.main;
    } else if (view.name) {
      app.views[view.name] = null;
      delete app.views[view.name];
    }
    view.$el[0].f7View = null;
    delete view.$el[0].f7View;
    app.views.splice(app.views.indexOf(view), 1);
    if (view.params.router && view.router) {
      view.router.destroy();
    }
    view.emit("local::destroy viewDestroy", view);
    Object.keys(view).forEach((viewProp) => {
      view[viewProp] = null;
      delete view[viewProp];
    });
    view = null;
  }
  checkMasterDetailBreakpoint(force) {
    const view = this;
    const app = view.app;
    const wasMasterDetail = view.$el.hasClass("view-master-detail");
    const isMasterDetail = app.width >= view.params.masterDetailBreakpoint && view.$el.children(".page-master").length;
    if (typeof force === "undefined" && isMasterDetail || force === true) {
      view.$el.addClass("view-master-detail");
      if (!wasMasterDetail) {
        view.emit("local::masterDetailBreakpoint viewMasterDetailBreakpoint", view);
        view.$el.trigger("view:masterDetailBreakpoint");
      }
    } else {
      view.$el.removeClass("view-master-detail");
      if (wasMasterDetail) {
        view.emit("local::masterDetailBreakpoint viewMasterDetailBreakpoint", view);
        view.$el.trigger("view:masterDetailBreakpoint");
      }
    }
  }
  initMasterDetail() {
    const view = this;
    const app = view.app;
    view.checkMasterDetailBreakpoint = view.checkMasterDetailBreakpoint.bind(view);
    view.checkMasterDetailBreakpoint();
    if (view.params.masterDetailResizable) {
      resizableView(view);
    }
    app.on("resize", view.checkMasterDetailBreakpoint);
  }
  mount(viewEl) {
    const view = this;
    const app = view.app;
    const el = view.params.el || viewEl;
    const $el = $(el);
    let selector;
    if (typeof el === "string") selector = el;
    else {
      selector = ($el.attr("id") ? `#${$el.attr("id")}` : "") + ($el.attr("class") ? `.${$el.attr("class").replace(/ /g, ".").replace(".active", "")}` : "");
    }
    let $navbarsEl;
    if (app.theme === "ios" && view.params.iosDynamicNavbar) {
      $navbarsEl = $el.children(".navbars").eq(0);
      if ($navbarsEl.length === 0) {
        $navbarsEl = $('<div class="navbars"></div>');
      }
    }
    extend$1(view, {
      $el,
      el: $el[0],
      main: view.main || $el.hasClass("view-main"),
      $navbarsEl,
      navbarsEl: $navbarsEl ? $navbarsEl[0] : void 0,
      selector
    });
    if (view.main) {
      app.views.main = view;
    }
    if ($el && $el[0]) {
      $el[0].f7View = view;
    }
    view.emit("local::mount viewMount", view);
  }
  init(viewEl) {
    const view = this;
    view.mount(viewEl);
    if (view.params.router) {
      if (view.params.masterDetailBreakpoint > 0) {
        view.initMasterDetail();
      }
      if (view.params.initRouterOnTabShow && view.$el.hasClass("tab") && !view.$el.hasClass("tab-active")) {
        view.$el.once("tab:show", () => {
          view.router.init();
        });
      } else {
        view.router.init();
      }
      view.$el.trigger("view:init");
      view.emit("local::init viewInit", view);
    }
  }
};
View$2.use(RouterModule);
function initClicks(app) {
  function handleClicks(e) {
    const window2 = getWindow();
    const $clickedEl = $(e.target);
    const $clickedLinkEl = $clickedEl.closest("a");
    const isLink = $clickedLinkEl.length > 0;
    const url = isLink && $clickedLinkEl.attr("href");
    if (isLink) {
      if ($clickedLinkEl.is(app.params.clicks.externalLinks) || // eslint-disable-next-line
      url && url.indexOf("javascript:") >= 0) {
        const target = $clickedLinkEl.attr("target");
        if (url && window2.cordova && window2.cordova.InAppBrowser && (target === "_system" || target === "_blank")) {
          e.preventDefault();
          window2.cordova.InAppBrowser.open(url, target);
        } else if (url && window2.Capacitor && window2.Capacitor.Plugins && window2.Capacitor.Plugins.Browser && (target === "_system" || target === "_blank")) {
          e.preventDefault();
          window2.Capacitor.Plugins.Browser.open({
            url
          });
        }
        return;
      }
    }
    Object.keys(app.modules).forEach((moduleName) => {
      const moduleClicks = app.modules[moduleName].clicks;
      if (!moduleClicks) return;
      if (e.preventF7Router) return;
      Object.keys(moduleClicks).forEach((clickSelector) => {
        const matchingClickedElement = $clickedEl.closest(clickSelector).eq(0);
        if (matchingClickedElement.length > 0) {
          moduleClicks[clickSelector].call(app, matchingClickedElement, matchingClickedElement.dataset(), e);
        }
      });
    });
    let clickedLinkData = {};
    if (isLink) {
      e.preventDefault();
      clickedLinkData = $clickedLinkEl.dataset();
    }
    clickedLinkData.clickedEl = $clickedLinkEl[0];
    if (e.preventF7Router) return;
    if ($clickedLinkEl.hasClass("prevent-router") || $clickedLinkEl.hasClass("router-prevent")) return;
    const validUrl = url && url.length > 0 && url[0] !== "#";
    if (validUrl || $clickedLinkEl.hasClass("back")) {
      let view;
      if (clickedLinkData.view && clickedLinkData.view === "current") {
        view = app.views.current;
      } else if (clickedLinkData.view) {
        view = $(clickedLinkData.view)[0].f7View;
      } else {
        view = $clickedEl.parents(".view")[0] && $clickedEl.parents(".view")[0].f7View;
        if (view && view.params.linksView && (!$clickedLinkEl.hasClass("back") || $clickedLinkEl.hasClass("back") && view.router.history.length === 1)) {
          if (typeof view.params.linksView === "string") view = $(view.params.linksView)[0].f7View;
          else if (view.params.linksView instanceof View$2) view = view.params.linksView;
        }
      }
      if (!view) {
        if (app.views.main) view = app.views.main;
      }
      if (!view || !view.router) return;
      if ($clickedLinkEl[0].f7RouteProps) {
        clickedLinkData.props = $clickedLinkEl[0].f7RouteProps;
      }
      if ($clickedLinkEl.hasClass("back")) view.router.back(url, clickedLinkData);
      else view.router.navigate(url, clickedLinkData);
    }
  }
  app.on("click", handleClicks);
}
const ClicksModule = {
  name: "clicks",
  params: {
    clicks: {
      // External Links
      externalLinks: ".external"
    }
  },
  on: {
    init() {
      const app = this;
      initClicks(app);
    }
  }
};
const HistoryModule = {
  name: "history",
  static: {
    history: History
  },
  on: {
    init() {
      History.init(this);
    }
  }
};
const SW = {
  registrations: [],
  register(path, scope) {
    const app = this;
    const window2 = getWindow();
    if (!("serviceWorker" in window2.navigator) || !app.serviceWorker.container) {
      return new Promise((resolve, reject) => {
        reject(new Error("Service worker is not supported"));
      });
    }
    return new Promise((resolve, reject) => {
      app.serviceWorker.container.register(path, scope ? {
        scope
      } : {}).then((reg) => {
        SW.registrations.push(reg);
        app.emit("serviceWorkerRegisterSuccess", reg);
        resolve(reg);
      }).catch((error) => {
        app.emit("serviceWorkerRegisterError", error);
        reject(error);
      });
    });
  },
  unregister(registration) {
    const app = this;
    const window2 = getWindow();
    if (!("serviceWorker" in window2.navigator) || !app.serviceWorker.container) {
      return new Promise((resolve, reject) => {
        reject(new Error("Service worker is not supported"));
      });
    }
    let registrations;
    if (!registration) registrations = SW.registrations;
    else if (Array.isArray(registration)) registrations = registration;
    else registrations = [registration];
    return Promise.all(registrations.map((reg) => new Promise((resolve, reject) => {
      reg.unregister().then(() => {
        if (SW.registrations.indexOf(reg) >= 0) {
          SW.registrations.splice(SW.registrations.indexOf(reg), 1);
        }
        app.emit("serviceWorkerUnregisterSuccess", reg);
        resolve();
      }).catch((error) => {
        app.emit("serviceWorkerUnregisterError", reg, error);
        reject(error);
      });
    })));
  }
};
const ServiceWorkerModule = {
  name: "sw",
  params: {
    serviceWorker: {
      path: void 0,
      scope: void 0
    }
  },
  create() {
    const app = this;
    const window2 = getWindow();
    extend$1(app, {
      serviceWorker: {
        container: "serviceWorker" in window2.navigator ? window2.navigator.serviceWorker : void 0,
        registrations: SW.registrations,
        register: SW.register.bind(app),
        unregister: SW.unregister.bind(app)
      }
    });
  },
  on: {
    init() {
      const window2 = getWindow();
      if (!("serviceWorker" in window2.navigator)) return;
      const app = this;
      if (app.device.cordova || window2.Capacitor && window2.Capacitor.isNative) return;
      if (!app.serviceWorker.container) return;
      const paths = app.params.serviceWorker.path;
      const scope = app.params.serviceWorker.scope;
      if (!paths || Array.isArray(paths) && !paths.length) return;
      const toRegister = Array.isArray(paths) ? paths : [paths];
      toRegister.forEach((path) => {
        app.serviceWorker.register(path, scope);
      });
    }
  }
};
function createStore(storeParams) {
  if (storeParams === void 0) {
    storeParams = {};
  }
  const store = {
    __store: true
  };
  const originalState = {
    ...storeParams.state || {}
  };
  const actions = {
    ...storeParams.actions || {}
  };
  const getters = {
    ...storeParams.getters || {}
  };
  const state = extend$1({}, originalState);
  let propsQueue = [];
  const gettersDependencies = {};
  const gettersCallbacks = {};
  Object.keys(getters).forEach((getterKey) => {
    gettersDependencies[getterKey] = [];
    gettersCallbacks[getterKey] = [];
  });
  const getGetterValue = (getterKey) => {
    return getters[getterKey]({
      state: store.state
    });
  };
  const addGetterDependencies = (getterKey, deps) => {
    if (!gettersDependencies[getterKey]) gettersDependencies[getterKey] = [];
    deps.forEach((dep) => {
      if (gettersDependencies[getterKey].indexOf(dep) < 0) {
        gettersDependencies[getterKey].push(dep);
      }
    });
  };
  const addGetterCallback = (getterKey, callback) => {
    if (!gettersCallbacks[getterKey]) gettersCallbacks[getterKey] = [];
    gettersCallbacks[getterKey].push(callback);
  };
  const runGetterCallbacks = (stateKey) => {
    const keys = Object.keys(gettersDependencies).filter((getterKey) => {
      return gettersDependencies[getterKey].indexOf(stateKey) >= 0;
    });
    keys.forEach((getterKey) => {
      if (!gettersCallbacks[getterKey] || !gettersCallbacks[getterKey].length) return;
      gettersCallbacks[getterKey].forEach((callback) => {
        callback(getGetterValue(getterKey));
      });
    });
  };
  const removeGetterCallback = (callback) => {
    Object.keys(gettersCallbacks).forEach((stateKey) => {
      const callbacks = gettersCallbacks[stateKey];
      if (callbacks.indexOf(callback) >= 0) {
        callbacks.splice(callbacks.indexOf(callback), 1);
      }
    });
  };
  store.__removeCallback = (callback) => {
    removeGetterCallback(callback);
  };
  const getterValue = function(getterKey, addCallback) {
    if (addCallback === void 0) {
      addCallback = true;
    }
    if (getterKey === "constructor") return void 0;
    propsQueue = [];
    const value2 = getGetterValue(getterKey);
    addGetterDependencies(getterKey, propsQueue);
    const onUpdated = (callback2) => {
      addGetterCallback(getterKey, callback2);
    };
    const obj = {
      value: value2,
      onUpdated
    };
    if (!addCallback) {
      return obj;
    }
    const callback = (v) => {
      obj.value = v;
    };
    obj.__callback = callback;
    addGetterCallback(getterKey, callback);
    return obj;
  };
  store.state = new Proxy(state, {
    set: (target, prop2, value2) => {
      target[prop2] = value2;
      runGetterCallbacks(prop2);
      return true;
    },
    get: (target, prop2) => {
      propsQueue.push(prop2);
      return target[prop2];
    }
  });
  store.getters = new Proxy(getters, {
    set: () => false,
    get: (target, prop2) => {
      if (!target[prop2]) {
        return void 0;
      }
      return getterValue(prop2, true);
    }
  });
  store._gettersPlain = new Proxy(getters, {
    set: () => false,
    get: (target, prop2) => {
      if (!target[prop2]) {
        return void 0;
      }
      return getterValue(prop2, false);
    }
  });
  store.dispatch = (actionName, data2) => {
    return new Promise((resolve, reject) => {
      if (!actions[actionName]) {
        reject();
        throw new Error(`Framework7: Store action "${actionName}" is not found`);
      }
      const result = actions[actionName]({
        state: store.state,
        dispatch: store.dispatch
      }, data2);
      resolve(result);
    });
  };
  return store;
}
const StoreModule = {
  name: "store",
  static: {
    createStore
  },
  proto: {
    createStore
  }
};
const isCapacitor = () => {
  const window2 = getWindow();
  return window2.Capacitor && window2.Capacitor.isNative && window2.Capacitor.Plugins && window2.Capacitor.Plugins.StatusBar;
};
const Statusbar = {
  hide() {
    const window2 = getWindow();
    const device = getDevice();
    if (device.cordova && window2.StatusBar) {
      window2.StatusBar.hide();
    }
    if (isCapacitor()) {
      window2.Capacitor.Plugins.StatusBar.hide();
    }
  },
  show() {
    const window2 = getWindow();
    const device = getDevice();
    if (device.cordova && window2.StatusBar) {
      window2.StatusBar.show();
    }
    if (isCapacitor()) {
      window2.Capacitor.Plugins.StatusBar.show();
    }
  },
  onClick() {
    const app = this;
    let pageContent;
    if ($(".popup.modal-in").length > 0) {
      pageContent = $(".popup.modal-in").find(".page:not(.page-previous):not(.page-next):not(.cached)").find(".page-content");
    } else if ($(".panel.panel-in").length > 0) {
      pageContent = $(".panel.panel-in").find(".page:not(.page-previous):not(.page-next):not(.cached)").find(".page-content");
    } else if ($(".views > .view.tab-active").length > 0) {
      pageContent = $(".views > .view.tab-active").find(".page:not(.page-previous):not(.page-next):not(.cached)").find(".page-content");
    } else if ($(".views").length > 0) {
      pageContent = $(".views").find(".page:not(.page-previous):not(.page-next):not(.cached)").find(".page-content");
    } else {
      pageContent = app.$el.children(".view").find(".page:not(.page-previous):not(.page-next):not(.cached)").find(".page-content");
    }
    if (pageContent && pageContent.length > 0) {
      if (pageContent.hasClass("tab")) {
        pageContent = pageContent.parent(".tabs").children(".page-content.tab-active");
      }
      if (pageContent.length > 0) pageContent.scrollTop(0, 300);
    }
  },
  setTextColor(color) {
    const window2 = getWindow();
    const device = getDevice();
    if (device.cordova && window2.StatusBar) {
      if (color === "white") {
        window2.StatusBar.styleLightContent();
      } else {
        window2.StatusBar.styleDefault();
      }
    }
    if (isCapacitor()) {
      if (color === "white") {
        window2.Capacitor.Plugins.StatusBar.setStyle({
          style: "DARK"
        });
      } else {
        window2.Capacitor.Plugins.StatusBar.setStyle({
          style: "LIGHT"
        });
      }
    }
  },
  setBackgroundColor(color) {
    const window2 = getWindow();
    const device = getDevice();
    if (device.cordova && window2.StatusBar) {
      window2.StatusBar.backgroundColorByHexString(color);
    }
    if (isCapacitor()) {
      window2.Capacitor.Plugins.StatusBar.setBackgroundColor({
        color
      });
    }
  },
  isVisible() {
    const window2 = getWindow();
    const device = getDevice();
    return new Promise((resolve) => {
      if (device.cordova && window2.StatusBar) {
        resolve(window2.StatusBar.isVisible);
      }
      if (isCapacitor()) {
        window2.Capacitor.Plugins.StatusBar.getInfo().then((info) => {
          resolve(info.visible);
        });
      }
      resolve(false);
    });
  },
  overlaysWebView(overlays) {
    if (overlays === void 0) {
      overlays = true;
    }
    const window2 = getWindow();
    const device = getDevice();
    if (device.cordova && window2.StatusBar) {
      window2.StatusBar.overlaysWebView(overlays);
    }
    if (isCapacitor()) {
      window2.Capacitor.Plugins.StatusBar.setOverlaysWebView({
        overlay: overlays
      });
    }
  },
  init() {
    const app = this;
    const window2 = getWindow();
    const device = getDevice();
    const params = app.params.statusbar;
    if (!params.enabled) return;
    const isCordova = device.cordova && window2.StatusBar;
    const isCap = isCapacitor();
    if (isCordova || isCap) {
      if (params.scrollTopOnClick) {
        $(window2).on("statusTap", Statusbar.onClick.bind(app));
      }
      if (device.ios) {
        if (params.iosOverlaysWebView) {
          Statusbar.overlaysWebView(true);
        } else {
          Statusbar.overlaysWebView(false);
        }
        if (params.iosTextColor === "white") {
          Statusbar.setTextColor("white");
        } else {
          Statusbar.setTextColor("black");
        }
      }
      if (device.android) {
        if (params.androidOverlaysWebView) {
          Statusbar.overlaysWebView(true);
        } else {
          Statusbar.overlaysWebView(false);
        }
        if (params.androidTextColor === "white") {
          Statusbar.setTextColor("white");
        } else {
          Statusbar.setTextColor("black");
        }
      }
    }
    if (params.iosBackgroundColor && device.ios) {
      Statusbar.setBackgroundColor(params.iosBackgroundColor);
    }
    if (params.androidBackgroundColor && device.android) {
      Statusbar.setBackgroundColor(params.androidBackgroundColor);
    }
  }
};
const Statusbar$1 = {
  name: "statusbar",
  params: {
    statusbar: {
      enabled: true,
      scrollTopOnClick: true,
      iosOverlaysWebView: true,
      iosTextColor: "black",
      iosBackgroundColor: null,
      androidOverlaysWebView: false,
      androidTextColor: "black",
      androidBackgroundColor: null
    }
  },
  create() {
    const app = this;
    bindMethods(app, {
      statusbar: Statusbar
    });
  },
  on: {
    init() {
      const app = this;
      Statusbar.init.call(app);
    }
  }
};
function getCurrentView(app) {
  const $popoverView = $(".popover.modal-in .view");
  const $popupView = $(".popup.modal-in .view");
  const $panelView = $(".panel.panel-in .view");
  let $viewsEl = $(".views");
  if ($viewsEl.length === 0) $viewsEl = app.$el;
  let $viewEl = $viewsEl.children(".view");
  if ($viewEl.length === 0) {
    $viewEl = $viewsEl.children(".tabs").children(".view");
  }
  if ($viewEl.length > 1) {
    if ($viewEl.hasClass("tab")) {
      $viewEl = $viewsEl.children(".view.tab-active");
      if ($viewEl.length === 0) {
        $viewEl = $viewsEl.children(".tabs").children(".view.tab-active");
      }
    }
  }
  if ($popoverView.length > 0 && $popoverView[0].f7View) return $popoverView[0].f7View;
  if ($popupView.length > 0 && $popupView[0].f7View) return $popupView[0].f7View;
  if ($panelView.length > 0 && $panelView[0].f7View) return $panelView[0].f7View;
  if ($viewEl.length > 0) {
    if ($viewEl.length === 1 && $viewEl[0].f7View) return $viewEl[0].f7View;
    if ($viewEl.length > 1) {
      return app.views.main;
    }
  }
  return void 0;
}
const View$1 = {
  name: "view",
  params: {
    view: {
      init: true,
      initRouterOnTabShow: false,
      name: void 0,
      main: false,
      router: true,
      linksView: null,
      xhrCache: true,
      xhrCacheIgnore: [],
      xhrCacheIgnoreGetParameters: false,
      xhrCacheDuration: 1e3 * 60 * 10,
      // Ten minutes
      componentCache: true,
      preloadPreviousPage: true,
      allowDuplicateUrls: false,
      reloadPages: false,
      reloadDetail: false,
      masterDetailBreakpoint: 0,
      masterDetailResizable: false,
      removeElements: true,
      removeElementsWithTimeout: false,
      removeElementsTimeout: 0,
      restoreScrollTopOnBack: true,
      unloadTabContent: true,
      passRouteQueryToRequest: true,
      passRouteParamsToRequest: false,
      loadInitialPage: true,
      // Swipe Back
      iosSwipeBack: true,
      iosSwipeBackAnimateShadow: true,
      iosSwipeBackAnimateOpacity: true,
      iosSwipeBackActiveArea: 30,
      iosSwipeBackThreshold: 0,
      mdSwipeBack: false,
      mdSwipeBackAnimateShadow: true,
      mdSwipeBackAnimateOpacity: false,
      mdSwipeBackActiveArea: 30,
      mdSwipeBackThreshold: 0,
      // Push State
      browserHistory: false,
      browserHistoryRoot: void 0,
      browserHistoryAnimate: true,
      browserHistoryAnimateOnLoad: false,
      browserHistorySeparator: "#!",
      browserHistoryOnLoad: true,
      browserHistoryInitialMatch: false,
      browserHistoryStoreHistory: true,
      browserHistoryTabs: "replace",
      // Animate Pages
      animate: true,
      // iOS Dynamic Navbar
      iosDynamicNavbar: true,
      // Animate iOS Navbar Back Icon
      iosAnimateNavbarBackIcon: true,
      // Delays
      iosPageLoadDelay: 0,
      mdPageLoadDelay: 0,
      // Routes hooks
      routesBeforeEnter: null,
      routesBeforeLeave: null
    }
  },
  static: {
    View: View$2
  },
  create() {
    const app = this;
    extend$1(app, {
      views: extend$1([], {
        create(el, params) {
          return new View$2(app, el, params);
        },
        get(viewEl) {
          const $viewEl = $(viewEl);
          if ($viewEl.length && $viewEl[0].f7View) return $viewEl[0].f7View;
          return void 0;
        }
      })
    });
    Object.defineProperty(app.views, "current", {
      enumerable: true,
      configurable: true,
      get() {
        return getCurrentView(app);
      }
    });
    app.view = app.views;
  },
  on: {
    init() {
      const app = this;
      $(".view-init").each((viewEl) => {
        if (viewEl.f7View) return;
        const viewParams = $(viewEl).dataset();
        app.views.create(viewEl, viewParams);
      });
    },
    "modalOpen panelOpen": function onOpen(instance) {
      const app = this;
      instance.$el.find(".view-init").each((viewEl) => {
        if (viewEl.f7View) return;
        const viewParams = $(viewEl).dataset();
        app.views.create(viewEl, viewParams);
      });
    },
    "modalBeforeDestroy panelBeforeDestroy": function onClose(instance) {
      if (!instance || !instance.$el) return;
      instance.$el.find(".view-init").each((viewEl) => {
        const view = viewEl.f7View;
        if (!view) return;
        view.destroy();
      });
    }
  },
  vnode: {
    "view-init": {
      insert(vnode) {
        const app = this;
        const viewEl = vnode.elm;
        if (viewEl.f7View) return;
        const viewParams = $(viewEl).dataset();
        app.views.create(viewEl, viewParams);
      },
      destroy(vnode) {
        const viewEl = vnode.elm;
        const view = viewEl.f7View;
        if (!view) return;
        view.destroy();
      }
    }
  }
};
const Navbar$1 = {
  size(el) {
    const app = this;
    let $el = $(el);
    if ($el.hasClass("navbars")) {
      $el = $el.children(".navbar").each((navbarEl) => {
        app.navbar.size(navbarEl);
      });
      return;
    }
    const $innerEl = $el.children(".navbar-inner");
    if (!$innerEl.length) return;
    const needCenterTitle = $innerEl.hasClass("navbar-inner-centered-title") || app.params.navbar[`${app.theme}CenterTitle`];
    const needLeftTitle = app.theme === "ios" && !app.params.navbar[`${app.theme}CenterTitle`];
    if (!needCenterTitle && !needLeftTitle) return;
    if ($el.parents(".tab:not(.tab-active)").length > 0 || $el.parents(".popup:not(.modal-in)").length > 0) {
      return;
    }
    if (app.theme !== "ios" && app.params.navbar[`${app.theme}CenterTitle`]) {
      $innerEl.addClass("navbar-inner-centered-title");
    }
    if (app.theme === "ios" && !app.params.navbar.iosCenterTitle) {
      $innerEl.addClass("navbar-inner-left-title");
    }
    const $viewEl = $el.parents(".view").eq(0);
    const left = app.rtl ? $innerEl.children(".right") : $innerEl.children(".left");
    const right = app.rtl ? $innerEl.children(".left") : $innerEl.children(".right");
    const title2 = $innerEl.children(".title");
    const subnavbar = $innerEl.children(".subnavbar");
    const noLeft = left.length === 0;
    const noRight = right.length === 0;
    const leftWidth = noLeft ? 0 : left.outerWidth(true);
    const rightWidth = noRight ? 0 : right.outerWidth(true);
    const titleWidth = title2.outerWidth(true);
    const navbarStyles = $innerEl.styles();
    const navbarWidth = $innerEl[0].offsetWidth;
    const navbarInnerWidth = navbarWidth - parseInt(navbarStyles.paddingLeft, 10) - parseInt(navbarStyles.paddingRight, 10);
    const isPrevious = $el.hasClass("navbar-previous");
    const sliding = $innerEl.hasClass("sliding");
    let router;
    let dynamicNavbar;
    if ($viewEl.length > 0 && $viewEl[0].f7View) {
      router = $viewEl[0].f7View.router;
      dynamicNavbar = router && router.dynamicNavbar;
    }
    let currLeft;
    let diff;
    if (noRight) {
      currLeft = navbarInnerWidth - titleWidth;
    }
    if (noLeft) {
      currLeft = 0;
    }
    if (!noLeft && !noRight) {
      currLeft = (navbarInnerWidth - rightWidth - titleWidth + leftWidth) / 2;
    }
    let requiredLeft = (navbarInnerWidth - titleWidth) / 2;
    if (navbarInnerWidth - leftWidth - rightWidth > titleWidth) {
      if (requiredLeft < leftWidth) {
        requiredLeft = leftWidth;
      }
      if (requiredLeft + titleWidth > navbarInnerWidth - rightWidth) {
        requiredLeft = navbarInnerWidth - rightWidth - titleWidth;
      }
      diff = requiredLeft - currLeft;
    } else {
      diff = 0;
    }
    const inverter = app.rtl ? -1 : 1;
    if (dynamicNavbar && app.theme === "ios") {
      if (title2.hasClass("sliding") || title2.length > 0 && sliding) {
        let titleLeftOffset = -(currLeft + diff) * inverter;
        const titleRightOffset = (navbarInnerWidth - currLeft - diff - titleWidth) * inverter;
        if (isPrevious) {
          if (router && router.params.iosAnimateNavbarBackIcon) {
            const activeNavbarBackLink = $el.parent().find(".navbar-current").children(".left.sliding").find(".back .icon ~ span");
            if (activeNavbarBackLink.length > 0) {
              titleLeftOffset += activeNavbarBackLink[0].offsetLeft;
            }
          }
        }
        title2[0].f7NavbarLeftOffset = titleLeftOffset;
        title2[0].f7NavbarRightOffset = titleRightOffset;
      }
      if (!noLeft && (left.hasClass("sliding") || sliding)) {
        if (app.rtl) {
          left[0].f7NavbarLeftOffset = -(navbarInnerWidth - left[0].offsetWidth) / 2 * inverter;
          left[0].f7NavbarRightOffset = leftWidth * inverter;
        } else {
          left[0].f7NavbarLeftOffset = -leftWidth;
          left[0].f7NavbarRightOffset = (navbarInnerWidth - left[0].offsetWidth) / 2;
          if (router && router.params.iosAnimateNavbarBackIcon && left.find(".back .icon").length > 0) {
            if (left.find(".back .icon ~ span").length) {
              const leftOffset = left[0].f7NavbarLeftOffset;
              const rightOffset = left[0].f7NavbarRightOffset;
              left[0].f7NavbarLeftOffset = 0;
              left[0].f7NavbarRightOffset = 0;
              left.find(".back .icon ~ span")[0].f7NavbarLeftOffset = leftOffset;
              left.find(".back .icon ~ span")[0].f7NavbarRightOffset = rightOffset - left.find(".back .icon")[0].offsetWidth;
            }
          }
        }
      }
      if (!noRight && (right.hasClass("sliding") || sliding)) {
        if (app.rtl) {
          right[0].f7NavbarLeftOffset = -rightWidth * inverter;
          right[0].f7NavbarRightOffset = (navbarInnerWidth - right[0].offsetWidth) / 2 * inverter;
        } else {
          right[0].f7NavbarLeftOffset = -(navbarInnerWidth - right[0].offsetWidth) / 2;
          right[0].f7NavbarRightOffset = rightWidth;
        }
      }
      if (subnavbar.length && (subnavbar.hasClass("sliding") || sliding)) {
        subnavbar[0].f7NavbarLeftOffset = app.rtl ? subnavbar[0].offsetWidth : -subnavbar[0].offsetWidth;
        subnavbar[0].f7NavbarRightOffset = -subnavbar[0].f7NavbarLeftOffset;
      }
    }
    if (needCenterTitle) {
      let titleLeft = diff;
      if (app.rtl && noLeft && noRight && title2.length > 0) titleLeft = -titleLeft;
      title2.css({
        left: `${titleLeft}px`
      });
    }
  },
  hide(el, animate2, hideStatusbar, hideOnlyCurrent) {
    if (animate2 === void 0) {
      animate2 = true;
    }
    if (hideStatusbar === void 0) {
      hideStatusbar = false;
    }
    if (hideOnlyCurrent === void 0) {
      hideOnlyCurrent = false;
    }
    const app = this;
    let $el = $(el);
    const isDynamic = $el.hasClass("navbar") && $el.parent(".navbars").length && !hideOnlyCurrent;
    if (isDynamic) $el = $el.parents(".navbars");
    if (!$el.length) return;
    if ($el.hasClass("navbar-hidden")) return;
    let className = `navbar-hidden${animate2 ? " navbar-transitioning" : ""}`;
    const currentIsLarge = isDynamic ? $el.find(".navbar-current .title-large").length : $el.find(".title-large").length;
    if (currentIsLarge) {
      className += " navbar-large-hidden";
    }
    if (hideStatusbar) {
      className += " navbar-hidden-statusbar";
    }
    $el.transitionEnd(() => {
      $el.removeClass("navbar-transitioning");
    });
    $el.addClass(className);
    if (isDynamic) {
      $el.children(".navbar").each((subEl) => {
        $(subEl).trigger("navbar:hide");
        app.emit("navbarHide", subEl);
      });
    } else {
      $el.trigger("navbar:hide");
      app.emit("navbarHide", $el[0]);
    }
  },
  show(el, animate2, hideOnlyCurrent) {
    if (el === void 0) {
      el = ".navbar-hidden";
    }
    if (animate2 === void 0) {
      animate2 = true;
    }
    if (hideOnlyCurrent === void 0) {
      hideOnlyCurrent = false;
    }
    const app = this;
    let $el = $(el);
    const isDynamic = $el.hasClass("navbar") && $el.parent(".navbars").length && !hideOnlyCurrent;
    if (isDynamic) $el = $el.parents(".navbars");
    if (!$el.length) return;
    if (!$el.hasClass("navbar-hidden")) return;
    if (animate2) {
      $el.addClass("navbar-transitioning");
      $el.transitionEnd(() => {
        $el.removeClass("navbar-transitioning");
      });
    }
    $el.removeClass("navbar-hidden navbar-large-hidden navbar-hidden-statusbar");
    if (isDynamic) {
      $el.children(".navbar").each((subEl) => {
        $(subEl).trigger("navbar:show");
        app.emit("navbarShow", subEl);
      });
    } else {
      $el.trigger("navbar:show");
      app.emit("navbarShow", $el[0]);
    }
  },
  getElByPage(page) {
    let $pageEl;
    let $navbarEl;
    let pageData;
    if (page.$navbarEl || page.$el) {
      pageData = page;
      $pageEl = page.$el;
    } else {
      $pageEl = $(page);
      if ($pageEl.length > 0) pageData = $pageEl[0].f7Page;
    }
    if (pageData && pageData.$navbarEl && pageData.$navbarEl.length > 0) {
      $navbarEl = pageData.$navbarEl;
    } else if ($pageEl) {
      $navbarEl = $pageEl.children(".navbar");
    }
    if (!$navbarEl || $navbarEl && $navbarEl.length === 0) return void 0;
    return $navbarEl[0];
  },
  getPageByEl(navbarEl) {
    const $navbarEl = $(navbarEl);
    if ($navbarEl.parents(".page").length) {
      return $navbarEl.parents(".page")[0];
    }
    let pageEl;
    $navbarEl.parents(".view").find(".page").each((el) => {
      if (el && el.f7Page && el.f7Page.navbarEl && $navbarEl[0] === el.f7Page.navbarEl) {
        pageEl = el;
      }
    });
    return pageEl;
  },
  collapseLargeTitle(navbarEl) {
    const app = this;
    let $navbarEl = $(navbarEl);
    if ($navbarEl.hasClass("navbars")) {
      $navbarEl = $navbarEl.find(".navbar");
      if ($navbarEl.length > 1) {
        $navbarEl = $(navbarEl).find(".navbar-large.navbar-current");
      }
      if ($navbarEl.length > 1 || !$navbarEl.length) {
        return;
      }
    }
    const $pageEl = $(app.navbar.getPageByEl($navbarEl));
    $navbarEl.addClass("navbar-large-collapsed");
    $pageEl.eq(0).addClass("page-with-navbar-large-collapsed").trigger("page:navbarlargecollapsed");
    app.emit("pageNavbarLargeCollapsed", $pageEl[0]);
    $navbarEl.trigger("navbar:collapse");
    app.emit("navbarCollapse", $navbarEl[0]);
  },
  expandLargeTitle(navbarEl) {
    const app = this;
    let $navbarEl = $(navbarEl);
    if ($navbarEl.hasClass("navbars")) {
      $navbarEl = $navbarEl.find(".navbar-large");
      if ($navbarEl.length > 1) {
        $navbarEl = $(navbarEl).find(".navbar-large.navbar-current");
      }
      if ($navbarEl.length > 1 || !$navbarEl.length) {
        return;
      }
    }
    const $pageEl = $(app.navbar.getPageByEl($navbarEl));
    $navbarEl.removeClass("navbar-large-collapsed");
    $pageEl.eq(0).removeClass("page-with-navbar-large-collapsed").trigger("page:navbarlargeexpanded");
    app.emit("pageNavbarLargeExpanded", $pageEl[0]);
    $navbarEl.trigger("navbar:expand");
    app.emit("navbarExpand", $navbarEl[0]);
  },
  toggleLargeTitle(navbarEl) {
    const app = this;
    let $navbarEl = $(navbarEl);
    if ($navbarEl.hasClass("navbars")) {
      $navbarEl = $navbarEl.find(".navbar-large");
      if ($navbarEl.length > 1) {
        $navbarEl = $(navbarEl).find(".navbar-large.navbar-current");
      }
      if ($navbarEl.length > 1 || !$navbarEl.length) {
        return;
      }
    }
    if ($navbarEl.hasClass("navbar-large-collapsed")) {
      app.navbar.expandLargeTitle($navbarEl);
    } else {
      app.navbar.collapseLargeTitle($navbarEl);
    }
  },
  initNavbarOnScroll(pageEl, navbarEl, needHide, needCollapse, needTransparent) {
    const app = this;
    const support2 = getSupport();
    const $pageEl = $(pageEl);
    const $navbarEl = $(navbarEl);
    const $titleLargeEl = $navbarEl.find(".title-large");
    const isLarge = $titleLargeEl.length || $navbarEl.hasClass(".navbar-large");
    let navbarHideHeight = 44;
    const snapPageScrollToLargeTitle = app.params.navbar.snapPageScrollToLargeTitle;
    const snapPageScrollToTransparentNavbar = app.params.navbar.snapPageScrollToTransparentNavbar;
    let previousScrollTop;
    let currentScrollTop;
    let scrollHeight;
    let offsetHeight;
    let reachEnd;
    let action;
    let navbarHidden;
    let navbarCollapsed;
    let navbarTitleLargeHeight;
    let navbarOffsetHeight;
    if (needCollapse || needHide && isLarge) {
      navbarTitleLargeHeight = $navbarEl.css("--f7-navbar-large-title-height");
      if (navbarTitleLargeHeight && navbarTitleLargeHeight.indexOf("px") >= 0) {
        navbarTitleLargeHeight = parseInt(navbarTitleLargeHeight, 10);
        if (Number.isNaN(navbarTitleLargeHeight) && $titleLargeEl.length) {
          navbarTitleLargeHeight = $titleLargeEl[0].offsetHeight;
        } else if (Number.isNaN(navbarTitleLargeHeight)) {
          if (app.theme === "ios") navbarTitleLargeHeight = 52;
          else if (app.theme === "md") navbarTitleLargeHeight = 88;
        }
      } else if ($titleLargeEl.length) {
        navbarTitleLargeHeight = $titleLargeEl[0].offsetHeight;
      } else {
        if (app.theme === "ios") navbarTitleLargeHeight = 52;
        else if (app.theme === "md") navbarTitleLargeHeight = 88;
      }
    }
    if (needHide && isLarge) {
      navbarHideHeight += navbarTitleLargeHeight;
    }
    let scrollChanged;
    let scrollContent;
    let scrollTimeoutId;
    let touchEndTimeoutId;
    const touchSnapTimeout = 70;
    const desktopSnapTimeout = 300;
    function calcScrollableDistance() {
      $pageEl.find(".page-content").each((pageContentEl) => {
        pageContentEl.f7ScrollableDistance = pageContentEl.scrollHeight - pageContentEl.offsetHeight;
      });
    }
    function snapLargeNavbar() {
      const inSearchbarExpanded = $navbarEl.hasClass("with-searchbar-expandable-enabled");
      if (inSearchbarExpanded) return;
      if (!scrollContent || currentScrollTop < 0) return;
      if (currentScrollTop >= navbarTitleLargeHeight / 2 && currentScrollTop < navbarTitleLargeHeight) {
        $(scrollContent).scrollTop(navbarTitleLargeHeight, 100);
      } else if (currentScrollTop < navbarTitleLargeHeight) {
        $(scrollContent).scrollTop(0, 200);
      }
    }
    function snapTransparentNavbar() {
      const inSearchbarExpanded = $navbarEl.hasClass("with-searchbar-expandable-enabled");
      if (inSearchbarExpanded) return;
      if (!scrollContent || currentScrollTop < 0) return;
      if (currentScrollTop >= navbarOffsetHeight / 2 && currentScrollTop < navbarOffsetHeight) {
        $(scrollContent).scrollTop(navbarOffsetHeight, 100);
      } else if (currentScrollTop < navbarOffsetHeight) {
        $(scrollContent).scrollTop(0, 200);
      }
    }
    function handleNavbarTransparent() {
      const isHidden = $navbarEl.hasClass("navbar-hidden") || $navbarEl.parent(".navbars").hasClass("navbar-hidden");
      const inSearchbarExpanded = $navbarEl.hasClass("with-searchbar-expandable-enabled");
      if (inSearchbarExpanded || isHidden) return;
      if (!navbarOffsetHeight) {
        navbarOffsetHeight = navbarEl.offsetHeight;
      }
      let opacity = currentScrollTop / navbarOffsetHeight;
      const notTransparent = $navbarEl.hasClass("navbar-transparent-visible");
      opacity = Math.max(Math.min(opacity, 1), 0);
      if (notTransparent && opacity === 1 || !notTransparent && opacity === 0) {
        $navbarEl.find(".navbar-bg, .title").css("opacity", "");
        return;
      }
      if (notTransparent && opacity === 0) {
        $navbarEl.trigger("navbar:transparenthide");
        app.emit("navbarTransparentHide", $navbarEl[0]);
        $navbarEl.removeClass("navbar-transparent-visible");
        $navbarEl.find(".navbar-bg, .title").css("opacity", "");
        return;
      }
      if (!notTransparent && opacity === 1) {
        $navbarEl.trigger("navbar:transparentshow");
        app.emit("navbarTransparentShow", $navbarEl[0]);
        $navbarEl.addClass("navbar-transparent-visible");
        $navbarEl.find(".navbar-bg, .title").css("opacity", "");
        return;
      }
      $navbarEl.find(".navbar-bg, .title").css("opacity", opacity);
      if (snapPageScrollToTransparentNavbar) {
        if (!support2.touch) {
          clearTimeout(scrollTimeoutId);
          scrollTimeoutId = setTimeout(() => {
            snapTransparentNavbar();
          }, desktopSnapTimeout);
        } else if (touchEndTimeoutId) {
          clearTimeout(touchEndTimeoutId);
          touchEndTimeoutId = null;
          touchEndTimeoutId = setTimeout(() => {
            snapTransparentNavbar();
            clearTimeout(touchEndTimeoutId);
            touchEndTimeoutId = null;
          }, touchSnapTimeout);
        }
      }
    }
    let previousCollapseProgress = null;
    let collapseProgress = null;
    function handleLargeNavbarCollapse(pageContentEl) {
      const isHidden = $navbarEl.hasClass("navbar-hidden") || $navbarEl.parent(".navbars").hasClass("navbar-hidden");
      if (isHidden) return;
      const isLargeTransparent = $navbarEl.hasClass("navbar-large-transparent") || $navbarEl.hasClass("navbar-large") && $navbarEl.hasClass("navbar-transparent");
      previousCollapseProgress = collapseProgress;
      const scrollableDistance = Math.min(navbarTitleLargeHeight, pageContentEl.f7ScrollableDistance || navbarTitleLargeHeight);
      collapseProgress = Math.min(Math.max(currentScrollTop / scrollableDistance, 0), 1);
      const previousCollapseWasInMiddle = previousCollapseProgress > 0 && previousCollapseProgress < 1;
      const inSearchbarExpanded = $navbarEl.hasClass("with-searchbar-expandable-enabled");
      if (inSearchbarExpanded) return;
      navbarCollapsed = $navbarEl.hasClass("navbar-large-collapsed");
      const $bgEl = $navbarEl.find(".navbar-bg");
      if (collapseProgress === 0 && navbarCollapsed) {
        app.navbar.expandLargeTitle($navbarEl[0]);
      } else if (collapseProgress === 1 && !navbarCollapsed) {
        app.navbar.collapseLargeTitle($navbarEl[0]);
      }
      if (collapseProgress === 0 && navbarCollapsed || collapseProgress === 0 && previousCollapseWasInMiddle || collapseProgress === 1 && !navbarCollapsed || collapseProgress === 1 && previousCollapseWasInMiddle) {
        if (app.theme === "md") {
          $navbarEl.find(".navbar-inner").css("overflow", "");
        }
        $navbarEl.find(".title").css("opacity", "");
        $navbarEl.find(".title-large-text, .subnavbar").css("transform", "");
        $navbarEl.find(".title-large-text").css("opacity", "");
        if (isLargeTransparent) {
          $bgEl.css("opacity", "");
        }
        $bgEl.css("transform", "");
      } else if (collapseProgress > 0 && collapseProgress < 1) {
        if (app.theme === "md") {
          $navbarEl.find(".navbar-inner").css("overflow", "visible");
        }
        $navbarEl.find(".title").css("opacity", -0.5 + collapseProgress * 1.5);
        $navbarEl.find(".title-large-text, .subnavbar").css("transform", `translate3d(0px, ${-1 * collapseProgress * navbarTitleLargeHeight}px, 0)`);
        $navbarEl.find(".title-large-text").css("opacity", 1 - collapseProgress * 2);
        if (isLargeTransparent) {
          $bgEl.css("opacity", collapseProgress);
        }
        $bgEl.css("transform", `translate3d(0px, ${-1 * collapseProgress * navbarTitleLargeHeight}px, 0)`);
      }
      if (snapPageScrollToLargeTitle) {
        if (!support2.touch) {
          clearTimeout(scrollTimeoutId);
          scrollTimeoutId = setTimeout(() => {
            snapLargeNavbar();
          }, desktopSnapTimeout);
        } else if (touchEndTimeoutId) {
          clearTimeout(touchEndTimeoutId);
          touchEndTimeoutId = null;
          touchEndTimeoutId = setTimeout(() => {
            snapLargeNavbar();
            clearTimeout(touchEndTimeoutId);
            touchEndTimeoutId = null;
          }, touchSnapTimeout);
        }
      }
    }
    function handleTitleHideShow() {
      if ($pageEl.hasClass("page-with-card-opened")) return;
      scrollHeight = scrollContent.scrollHeight;
      offsetHeight = scrollContent.offsetHeight;
      reachEnd = currentScrollTop + offsetHeight >= scrollHeight;
      navbarHidden = $navbarEl.hasClass("navbar-hidden") || $navbarEl.parent(".navbars").hasClass("navbar-hidden");
      if (reachEnd) {
        if (app.params.navbar.showOnPageScrollEnd) {
          action = "show";
        }
      } else if (previousScrollTop > currentScrollTop) {
        if (app.params.navbar.showOnPageScrollTop || currentScrollTop <= navbarHideHeight) {
          action = "show";
        } else {
          action = "hide";
        }
      } else if (currentScrollTop > navbarHideHeight) {
        action = "hide";
      } else {
        action = "show";
      }
      if (action === "show" && navbarHidden) {
        app.navbar.show($navbarEl, true, true);
        navbarHidden = false;
      } else if (action === "hide" && !navbarHidden) {
        app.navbar.hide($navbarEl, true, false, true);
        navbarHidden = true;
      }
      previousScrollTop = currentScrollTop;
    }
    function handleScroll(e) {
      scrollContent = this;
      if (e && e.target && e.target !== scrollContent) {
        return;
      }
      currentScrollTop = scrollContent.scrollTop;
      scrollChanged = currentScrollTop;
      if (needCollapse) {
        handleLargeNavbarCollapse(scrollContent);
      } else if (needTransparent) {
        handleNavbarTransparent();
      }
      if ($pageEl.hasClass("page-previous")) return;
      if (needHide) {
        handleTitleHideShow();
      }
    }
    function handeTouchStart() {
      scrollChanged = false;
    }
    function handleTouchEnd() {
      clearTimeout(touchEndTimeoutId);
      touchEndTimeoutId = null;
      touchEndTimeoutId = setTimeout(() => {
        if (scrollChanged !== false) {
          if (needTransparent && !needCollapse) {
            snapTransparentNavbar();
          } else {
            snapLargeNavbar();
          }
          clearTimeout(touchEndTimeoutId);
          touchEndTimeoutId = null;
        }
      }, touchSnapTimeout);
    }
    $pageEl.on("scroll", ".page-content", handleScroll, true);
    if (support2.touch && (needCollapse && snapPageScrollToLargeTitle || needTransparent && snapPageScrollToTransparentNavbar)) {
      app.on("touchstart:passive", handeTouchStart);
      app.on("touchend:passive", handleTouchEnd);
    }
    calcScrollableDistance();
    if (needCollapse || needTransparent) {
      $pageEl.find(".page-content").each((pageContentEl) => {
        if (pageContentEl.scrollTop > 0) handleScroll.call(pageContentEl);
      });
    }
    app.on("resize", calcScrollableDistance);
    $pageEl[0].f7DetachNavbarScrollHandlers = function f7DetachNavbarScrollHandlers() {
      app.off("resize", calcScrollableDistance);
      delete $pageEl[0].f7DetachNavbarScrollHandlers;
      $pageEl.off("scroll", ".page-content", handleScroll, true);
      if (support2.touch && (needCollapse && snapPageScrollToLargeTitle || needTransparent && snapPageScrollToTransparentNavbar)) {
        app.off("touchstart:passive", handeTouchStart);
        app.off("touchend:passive", handleTouchEnd);
      }
    };
  }
};
const Navbar$2 = {
  name: "navbar",
  create() {
    const app = this;
    bindMethods(app, {
      navbar: Navbar$1
    });
  },
  params: {
    navbar: {
      scrollTopOnTitleClick: true,
      iosCenterTitle: true,
      mdCenterTitle: false,
      hideOnPageScroll: false,
      showOnPageScrollEnd: true,
      showOnPageScrollTop: true,
      collapseLargeTitleOnScroll: true,
      snapPageScrollToLargeTitle: true,
      snapPageScrollToTransparentNavbar: true
    }
  },
  on: {
    "panelBreakpoint panelCollapsedBreakpoint panelResize viewResize resize viewMasterDetailBreakpoint": function onPanelResize() {
      const app = this;
      $(".navbar").each((navbarEl) => {
        app.navbar.size(navbarEl);
      });
    },
    pageBeforeRemove(page) {
      if (page.$el[0].f7DetachNavbarScrollHandlers) {
        page.$el[0].f7DetachNavbarScrollHandlers();
      }
    },
    pageBeforeIn(page) {
      const app = this;
      if (app.theme !== "ios") return;
      let $navbarsEl;
      const view = page.$el.parents(".view")[0].f7View;
      const navbarEl = app.navbar.getElByPage(page);
      if (!navbarEl) {
        $navbarsEl = page.$el.parents(".view").children(".navbars");
      } else {
        $navbarsEl = $(navbarEl).parents(".navbars");
      }
      if (page.$el.hasClass("no-navbar") || view.router.dynamicNavbar && !navbarEl) {
        const animate2 = !!(page.pageFrom && page.router.history.length > 0);
        app.navbar.hide($navbarsEl, animate2);
      } else {
        app.navbar.show($navbarsEl);
      }
    },
    pageReinit(page) {
      const app = this;
      const $navbarEl = $(app.navbar.getElByPage(page));
      if (!$navbarEl || $navbarEl.length === 0) return;
      app.navbar.size($navbarEl);
    },
    pageInit(page) {
      const app = this;
      const $navbarEl = $(app.navbar.getElByPage(page));
      if (!$navbarEl || $navbarEl.length === 0) return;
      app.navbar.size($navbarEl);
      let needCollapseOnScrollHandler;
      if ($navbarEl.find(".title-large").length > 0) {
        $navbarEl.addClass("navbar-large");
      }
      if ($navbarEl.hasClass("navbar-large")) {
        if (app.params.navbar.collapseLargeTitleOnScroll) needCollapseOnScrollHandler = true;
        page.$el.addClass("page-with-navbar-large");
      }
      let needTransparentOnScroll;
      if (!needCollapseOnScrollHandler && $navbarEl.hasClass("navbar-transparent")) {
        needTransparentOnScroll = true;
      }
      let needHideOnScrollHandler;
      if (app.params.navbar.hideOnPageScroll || page.$el.find(".hide-navbar-on-scroll").length || page.$el.hasClass("hide-navbar-on-scroll") || page.$el.find(".hide-bars-on-scroll").length || page.$el.hasClass("hide-bars-on-scroll")) {
        if (page.$el.find(".keep-navbar-on-scroll").length || page.$el.hasClass("keep-navbar-on-scroll") || page.$el.find(".keep-bars-on-scroll").length || page.$el.hasClass("keep-bars-on-scroll")) {
          needHideOnScrollHandler = false;
        } else {
          needHideOnScrollHandler = true;
        }
      }
      if (needCollapseOnScrollHandler || needHideOnScrollHandler || needTransparentOnScroll) {
        app.navbar.initNavbarOnScroll(page.el, $navbarEl[0], needHideOnScrollHandler, needCollapseOnScrollHandler, needTransparentOnScroll);
      }
    },
    "panelOpen panelSwipeOpen modalOpen": function onPanelModalOpen(instance) {
      const app = this;
      instance.$el.find(".navbar:not(.navbar-previous)").each((navbarEl) => {
        app.navbar.size(navbarEl);
      });
    },
    tabShow(tabEl) {
      const app = this;
      $(tabEl).find(".navbar:not(.navbar-previous)").each((navbarEl) => {
        app.navbar.size(navbarEl);
      });
    }
  },
  clicks: {
    ".navbar .title": function onTitleClick($clickedEl, clickedData, e) {
      const app = this;
      if (!app.params.navbar.scrollTopOnTitleClick) return;
      if ($(e.target).closest("a, button").length > 0) {
        return;
      }
      let $pageContentEl;
      const $navbarEl = $clickedEl.parents(".navbar");
      const $navbarsEl = $navbarEl.parents(".navbars");
      $pageContentEl = $navbarEl.parents(".page-content");
      if ($pageContentEl.length === 0) {
        if ($navbarEl.parents(".page").length > 0) {
          $pageContentEl = $navbarEl.parents(".page").find(".page-content");
        }
        if ($pageContentEl.length === 0 && $navbarsEl.length) {
          if ($navbarsEl.nextAll(".page-current").length > 0) {
            $pageContentEl = $navbarsEl.nextAll(".page-current").find(".page-content");
          }
        }
        if ($pageContentEl.length === 0) {
          if ($navbarEl.nextAll(".page-current").length > 0) {
            $pageContentEl = $navbarEl.nextAll(".page-current").find(".page-content");
          }
        }
      }
      if ($pageContentEl && $pageContentEl.length > 0) {
        if ($pageContentEl.hasClass("tab")) {
          $pageContentEl = $pageContentEl.parent(".tabs").children(".page-content.tab-active");
        }
        if ($pageContentEl.length > 0) $pageContentEl.scrollTop(0, 300);
      }
    }
  },
  vnode: {
    navbar: {
      postpatch(vnode) {
        const app = this;
        app.navbar.size(vnode.elm);
      }
    }
  }
};
const Toolbar$1 = {
  setHighlight(tabbarEl) {
    const app = this;
    const $tabbarEl = $(tabbarEl);
    if (app.theme === "ios" && !$tabbarEl.hasClass("tabbar-highlight")) return;
    if ($tabbarEl.length === 0 || !($tabbarEl.hasClass("tabbar") || $tabbarEl.hasClass("tabbar-icons"))) return;
    let $highlightEl = $tabbarEl.find(".tab-link-highlight");
    const tabLinksCount = $tabbarEl.find(".tab-link").length;
    if (tabLinksCount === 0) {
      $highlightEl.remove();
      return;
    }
    if ($highlightEl.length === 0) {
      $tabbarEl.children(".toolbar-inner").append('<span class="tab-link-highlight"></span>');
      $highlightEl = $tabbarEl.find(".tab-link-highlight");
    } else if ($highlightEl.next().length) {
      $tabbarEl.children(".toolbar-inner").append($highlightEl);
    }
    const $activeLink = $tabbarEl.find(".tab-link-active");
    let highlightWidth;
    let highlightTranslate;
    if ($tabbarEl.hasClass("tabbar-scrollable") && $activeLink && $activeLink[0]) {
      highlightWidth = `${$activeLink[0].offsetWidth}px`;
      highlightTranslate = `${$activeLink[0].offsetLeft}px`;
    } else {
      const activeIndex = $activeLink.index();
      highlightWidth = `${100 / tabLinksCount}%`;
      highlightTranslate = `${(app.rtl ? -activeIndex : activeIndex) * 100}%`;
    }
    nextFrame(() => {
      $highlightEl.css("width", highlightWidth).transform(`translate3d(${highlightTranslate},0,0)`);
    });
  },
  init(tabbarEl) {
    const app = this;
    app.toolbar.setHighlight(tabbarEl);
  },
  hide(el, animate2) {
    if (animate2 === void 0) {
      animate2 = true;
    }
    const app = this;
    const $el = $(el);
    if ($el.hasClass("toolbar-hidden")) return;
    const className = `toolbar-hidden${animate2 ? " toolbar-transitioning" : ""}`;
    $el.transitionEnd(() => {
      $el.removeClass("toolbar-transitioning");
    });
    $el.addClass(className);
    $el.trigger("toolbar:hide");
    app.emit("toolbarHide", $el[0]);
  },
  show(el, animate2) {
    if (animate2 === void 0) {
      animate2 = true;
    }
    const app = this;
    const $el = $(el);
    if (!$el.hasClass("toolbar-hidden")) return;
    if (animate2) {
      $el.addClass("toolbar-transitioning");
      $el.transitionEnd(() => {
        $el.removeClass("toolbar-transitioning");
      });
    }
    $el.removeClass("toolbar-hidden");
    $el.trigger("toolbar:show");
    app.emit("toolbarShow", $el[0]);
  },
  initToolbarOnScroll(pageEl) {
    const app = this;
    const $pageEl = $(pageEl);
    let $toolbarEl = $pageEl.parents(".view").children(".toolbar");
    if ($toolbarEl.length === 0) {
      $toolbarEl = $pageEl.find(".toolbar");
    }
    if ($toolbarEl.length === 0) {
      $toolbarEl = $pageEl.parents(".views").children(".tabbar, .tabbar-icons");
    }
    if ($toolbarEl.length === 0) {
      return;
    }
    let previousScrollTop;
    let currentScrollTop;
    let scrollHeight;
    let offsetHeight;
    let reachEnd;
    let action;
    let toolbarHidden;
    function handleScroll(e) {
      if ($pageEl.hasClass("page-with-card-opened")) return;
      if ($pageEl.hasClass("page-previous")) return;
      const scrollContent = this;
      if (e && e.target && e.target !== scrollContent) {
        return;
      }
      currentScrollTop = scrollContent.scrollTop;
      scrollHeight = scrollContent.scrollHeight;
      offsetHeight = scrollContent.offsetHeight;
      reachEnd = currentScrollTop + offsetHeight >= scrollHeight;
      toolbarHidden = $toolbarEl.hasClass("toolbar-hidden");
      if (reachEnd) {
        if (app.params.toolbar.showOnPageScrollEnd) {
          action = "show";
        }
      } else if (previousScrollTop > currentScrollTop) {
        if (app.params.toolbar.showOnPageScrollTop || currentScrollTop <= 44) {
          action = "show";
        } else {
          action = "hide";
        }
      } else if (currentScrollTop > 44) {
        action = "hide";
      } else {
        action = "show";
      }
      if (action === "show" && toolbarHidden) {
        app.toolbar.show($toolbarEl);
        toolbarHidden = false;
      } else if (action === "hide" && !toolbarHidden) {
        app.toolbar.hide($toolbarEl);
        toolbarHidden = true;
      }
      previousScrollTop = currentScrollTop;
    }
    $pageEl.on("scroll", ".page-content", handleScroll, true);
    $pageEl[0].f7ScrollToolbarHandler = handleScroll;
  }
};
const Toolbar$2 = {
  name: "toolbar",
  create() {
    const app = this;
    bindMethods(app, {
      toolbar: Toolbar$1
    });
  },
  params: {
    toolbar: {
      hideOnPageScroll: false,
      showOnPageScrollEnd: true,
      showOnPageScrollTop: true
    }
  },
  on: {
    pageBeforeRemove(page) {
      if (page.$el[0].f7ScrollToolbarHandler) {
        page.$el.off("scroll", ".page-content", page.$el[0].f7ScrollToolbarHandler, true);
      }
    },
    pageBeforeIn(page) {
      const app = this;
      let $toolbarEl = page.$el.parents(".view").children(".toolbar");
      if ($toolbarEl.length === 0) {
        $toolbarEl = page.$el.parents(".views").children(".tabbar, .tabbar-icons");
      }
      if ($toolbarEl.length === 0) {
        $toolbarEl = page.$el.find(".toolbar");
      }
      if ($toolbarEl.length === 0) {
        return;
      }
      if (page.$el.hasClass("no-toolbar")) {
        app.toolbar.hide($toolbarEl);
      } else {
        app.toolbar.show($toolbarEl);
      }
    },
    pageInit(page) {
      const app = this;
      page.$el.find(".tabbar, .tabbar-icons").each((tabbarEl) => {
        app.toolbar.init(tabbarEl);
      });
      if (app.params.toolbar.hideOnPageScroll || page.$el.find(".hide-toolbar-on-scroll").length || page.$el.hasClass("hide-toolbar-on-scroll") || page.$el.find(".hide-bars-on-scroll").length || page.$el.hasClass("hide-bars-on-scroll")) {
        if (page.$el.find(".keep-toolbar-on-scroll").length || page.$el.hasClass("keep-toolbar-on-scroll") || page.$el.find(".keep-bars-on-scroll").length || page.$el.hasClass("keep-bars-on-scroll")) {
          return;
        }
        app.toolbar.initToolbarOnScroll(page.el);
      }
    },
    init() {
      const app = this;
      app.$el.find(".tabbar, .tabbar-icons").each((tabbarEl) => {
        app.toolbar.init(tabbarEl);
      });
    }
  },
  vnode: {
    tabbar: {
      insert(vnode) {
        const app = this;
        app.toolbar.init(vnode.elm);
      }
    }
  }
};
const Subnavbar$1 = {
  name: "subnavbar",
  on: {
    pageInit(page) {
      if (page.$navbarEl && page.$navbarEl.length && page.$navbarEl.find(".subnavbar").length) {
        page.$el.addClass("page-with-subnavbar");
      }
      const $innerSubnavbars = page.$el.find(".subnavbar").filter((subnavbarEl) => {
        return $(subnavbarEl).parents(".page")[0] === page.$el[0];
      });
      if ($innerSubnavbars.length) {
        page.$el.addClass("page-with-subnavbar");
      }
    }
  }
};
let TouchRipple$1 = class TouchRipple {
  constructor(app, $el, x, y) {
    const ripple = this;
    if (!$el) return void 0;
    const {
      left,
      top,
      width: width2,
      height: height2
    } = $el[0].getBoundingClientRect();
    const center = {
      x: x - left,
      y: y - top
    };
    let diameter = Math.max((height2 ** 2 + width2 ** 2) ** 0.5, 48);
    let isInset = false;
    const insetElements = app.params.touch.touchRippleInsetElements || "";
    if (insetElements && $el.is(insetElements)) {
      isInset = true;
    }
    if (isInset) {
      diameter = Math.max(Math.min(width2, height2), 48);
    }
    if (!isInset && $el.css("overflow") === "hidden") {
      const distanceFromCenter = ((center.x - width2 / 2) ** 2 + (center.y - height2 / 2) ** 2) ** 0.5;
      const scale = (diameter / 2 + distanceFromCenter) / (diameter / 2);
      ripple.rippleTransform = `translate3d(0px, 0px, 0) scale(${scale * 2})`;
    } else {
      ripple.rippleTransform = `translate3d(${-center.x + width2 / 2}px, ${-center.y + height2 / 2}px, 0) scale(1)`;
    }
    if (isInset) {
      $el.addClass("ripple-inset");
    }
    ripple.$rippleWaveEl = $(`<div class="ripple-wave${isInset ? " ripple-wave-inset" : ""}" style="width: ${diameter}px; height: ${diameter}px; margin-top:-${diameter / 2}px; margin-left:-${diameter / 2}px; left:${center.x}px; top:${center.y}px; --f7-ripple-transform: ${ripple.rippleTransform}"></div>`);
    $el.prepend(ripple.$rippleWaveEl);
    ripple.$rippleWaveEl.animationEnd(() => {
      if (!ripple.$rippleWaveEl) return;
      if (ripple.$rippleWaveEl.hasClass("ripple-wave-out")) return;
      ripple.$rippleWaveEl.addClass("ripple-wave-in");
      if (ripple.shouldBeRemoved) {
        ripple.out();
      }
    });
    return ripple;
  }
  destroy() {
    let ripple = this;
    if (ripple.$rippleWaveEl) {
      ripple.$rippleWaveEl.remove();
    }
    Object.keys(ripple).forEach((key) => {
      ripple[key] = null;
      delete ripple[key];
    });
    ripple = null;
  }
  out() {
    const ripple = this;
    const {
      $rippleWaveEl
    } = this;
    clearTimeout(ripple.removeTimeout);
    $rippleWaveEl.addClass("ripple-wave-out");
    ripple.removeTimeout = setTimeout(() => {
      ripple.destroy();
    }, 300);
    $rippleWaveEl.animationEnd(() => {
      clearTimeout(ripple.removeTimeout);
      ripple.destroy();
    });
  }
  remove() {
    const ripple = this;
    if (ripple.shouldBeRemoved) return;
    ripple.removeTimeout = setTimeout(() => {
      ripple.destroy();
    }, 400);
    ripple.shouldBeRemoved = true;
    if (ripple.$rippleWaveEl.hasClass("ripple-wave-in")) {
      ripple.out();
    }
  }
};
const TouchRipple2 = {
  name: "touch-ripple",
  static: {
    TouchRipple: TouchRipple$1
  },
  create() {
    const app = this;
    app.touchRipple = {
      create() {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
        return new TouchRipple$1(...args);
      }
    };
  }
};
const openedModals = [];
const dialogsQueue = [];
function clearDialogsQueue() {
  if (dialogsQueue.length === 0) return;
  const dialog = dialogsQueue.shift();
  dialog.open();
}
let Modal$1 = class Modal extends Framework7Class {
  constructor(app, params) {
    super(params, [app]);
    const modal = this;
    const defaults = {};
    modal.useModulesParams(defaults);
    modal.params = extend$1(defaults, params);
    modal.opened = false;
    let $containerEl = modal.params.containerEl ? $(modal.params.containerEl).eq(0) : app.$el;
    if (!$containerEl.length) $containerEl = app.$el;
    modal.$containerEl = $containerEl;
    modal.containerEl = $containerEl[0];
    modal.useModules();
    return this;
  }
  onOpen() {
    const modal = this;
    modal.opened = true;
    openedModals.push(modal);
    $("html").addClass(`with-modal-${modal.type.toLowerCase()}`);
    modal.$el.trigger(`modal:open ${modal.type.toLowerCase()}:open`);
    modal.emit(`local::open modalOpen ${modal.type}Open`, modal);
  }
  onOpened() {
    const modal = this;
    modal.$el.trigger(`modal:opened ${modal.type.toLowerCase()}:opened`);
    modal.emit(`local::opened modalOpened ${modal.type}Opened`, modal);
  }
  onClose() {
    const modal = this;
    modal.opened = false;
    if (!modal.type || !modal.$el) return;
    openedModals.splice(openedModals.indexOf(modal), 1);
    $("html").removeClass(`with-modal-${modal.type.toLowerCase()}`);
    modal.$el.trigger(`modal:close ${modal.type.toLowerCase()}:close`);
    modal.emit(`local::close modalClose ${modal.type}Close`, modal);
  }
  onClosed() {
    const modal = this;
    if (!modal.type || !modal.$el) return;
    modal.$el.removeClass("modal-out");
    modal.$el.hide();
    if (modal.params.backdrop && (modal.params.backdropUnique || modal.forceBackdropUnique) && modal.$backdropEl) {
      modal.$backdropEl.remove();
    }
    modal.$el.trigger(`modal:closed ${modal.type.toLowerCase()}:closed`);
    modal.emit(`local::closed modalClosed ${modal.type}Closed`, modal);
  }
  open(animateModal, force) {
    const modal = this;
    const document2 = getDocument();
    const app = modal.app;
    const $el = modal.$el;
    const $backdropEl = modal.$backdropEl;
    const type = modal.type;
    let animate2 = true;
    if (typeof animateModal !== "undefined") animate2 = animateModal;
    else if (typeof modal.params.animate !== "undefined") {
      animate2 = modal.params.animate;
    }
    if (!$el || $el.hasClass("modal-in")) {
      if (animateModal === false && $el[0] && type !== "dialog") {
        $el[0].style.display = "block";
      }
      if (!force) return modal;
    }
    if (type === "dialog" && app.params.modal.queueDialogs) {
      let pushToQueue;
      if ($(".dialog.modal-in").length > 0) {
        pushToQueue = true;
      } else if (openedModals.length > 0) {
        openedModals.forEach((openedModal) => {
          if (openedModal.type === "dialog") pushToQueue = true;
        });
      }
      if (pushToQueue) {
        dialogsQueue.push(modal);
        return modal;
      }
    }
    const $modalParentEl = $el.parent();
    const wasInDom = $el.parents(document2).length > 0;
    if (!$modalParentEl.is(modal.$containerEl)) {
      modal.$containerEl.append($el);
      modal.once(`${type}Closed`, () => {
        if (wasInDom) {
          $modalParentEl.append($el);
        } else {
          $el.remove();
        }
      });
    }
    $el.show();
    if (modal.params.backdrop && (modal.params.backdropUnique || modal.forceBackdropUnique) && modal.$backdropEl) {
      modal.$backdropEl.insertBefore($el);
    }
    modal._clientLeft = $el[0].clientLeft;
    function transitionEnd2() {
      if ($el.hasClass("modal-out")) {
        modal.onClosed();
      } else if ($el.hasClass("modal-in")) {
        modal.onOpened();
      }
    }
    if (animate2) {
      if ($backdropEl) {
        $backdropEl.removeClass("not-animated");
        $backdropEl.addClass("backdrop-in");
      }
      $el.animationEnd(() => {
        transitionEnd2();
      });
      $el.transitionEnd(() => {
        transitionEnd2();
      });
      $el.removeClass("modal-out not-animated").addClass("modal-in");
      modal.onOpen();
    } else {
      if ($backdropEl) {
        $backdropEl.addClass("backdrop-in not-animated");
      }
      $el.removeClass("modal-out").addClass("modal-in not-animated");
      modal.onOpen();
      modal.onOpened();
    }
    return modal;
  }
  close(animateModal) {
    const modal = this;
    const $el = modal.$el;
    const $backdropEl = modal.$backdropEl;
    let animate2 = true;
    if (typeof animateModal !== "undefined") animate2 = animateModal;
    else if (typeof modal.params.animate !== "undefined") {
      animate2 = modal.params.animate;
    }
    if (!$el || !$el.hasClass("modal-in")) {
      if (dialogsQueue.indexOf(modal) >= 0) {
        dialogsQueue.splice(dialogsQueue.indexOf(modal), 1);
      }
      return modal;
    }
    if ($backdropEl) {
      let needToHideBackdrop = true;
      if (modal.type === "popup") {
        modal.$el.prevAll(".popup.modal-in").add(modal.$el.nextAll(".popup.modal-in")).each((popupEl) => {
          const popupInstance = popupEl.f7Modal;
          if (!popupInstance) return;
          if (popupInstance.params.closeByBackdropClick && popupInstance.params.backdrop && popupInstance.backdropEl === modal.backdropEl) {
            needToHideBackdrop = false;
          }
        });
      }
      if (needToHideBackdrop) {
        $backdropEl[animate2 ? "removeClass" : "addClass"]("not-animated");
        $backdropEl.removeClass("backdrop-in");
      }
    }
    $el[animate2 ? "removeClass" : "addClass"]("not-animated");
    function transitionEnd2() {
      if ($el.hasClass("modal-out")) {
        modal.onClosed();
      } else if ($el.hasClass("modal-in")) {
        modal.onOpened();
      }
    }
    if (animate2) {
      $el.animationEnd(() => {
        transitionEnd2();
      });
      $el.transitionEnd(() => {
        transitionEnd2();
      });
      $el.removeClass("modal-in").addClass("modal-out");
      modal.onClose();
    } else {
      $el.addClass("not-animated").removeClass("modal-in").addClass("modal-out");
      modal.onClose();
      modal.onClosed();
    }
    if (modal.type === "dialog") {
      clearDialogsQueue();
    }
    return modal;
  }
  destroy() {
    const modal = this;
    if (modal.destroyed) return;
    modal.emit(`local::beforeDestroy modalBeforeDestroy ${modal.type}BeforeDestroy`, modal);
    if (modal.$el) {
      modal.$el.trigger(`modal:beforedestroy ${modal.type.toLowerCase()}:beforedestroy`);
      if (modal.$el.length && modal.$el[0].f7Modal) {
        delete modal.$el[0].f7Modal;
      }
    }
    deleteProps(modal);
    modal.destroyed = true;
  }
};
class CustomModal extends Modal$1 {
  constructor(app, params) {
    const extendedParams = extend$1({
      backdrop: true,
      closeByBackdropClick: true,
      on: {}
    }, params);
    super(app, extendedParams);
    const customModal = this;
    customModal.params = extendedParams;
    let $el;
    if (!customModal.params.el) {
      $el = $(customModal.params.content);
    } else {
      $el = $(customModal.params.el);
    }
    if ($el && $el.length > 0 && $el[0].f7Modal) {
      return $el[0].f7Modal;
    }
    if ($el.length === 0) {
      return customModal.destroy();
    }
    let $backdropEl;
    if (customModal.params.backdrop) {
      $backdropEl = app.$el.children(".custom-modal-backdrop");
      if ($backdropEl.length === 0) {
        $backdropEl = $('<div class="custom-modal-backdrop"></div>');
        app.$el.append($backdropEl);
      }
    }
    function handleClick(e) {
      if (!customModal || customModal.destroyed) return;
      if ($backdropEl && e.target === $backdropEl[0]) {
        customModal.close();
      }
    }
    customModal.on("customModalOpened", () => {
      if (customModal.params.closeByBackdropClick && customModal.params.backdrop) {
        app.on("click", handleClick);
      }
    });
    customModal.on("customModalClose", () => {
      if (customModal.params.closeByBackdropClick && customModal.params.backdrop) {
        app.off("click", handleClick);
      }
    });
    extend$1(customModal, {
      app,
      $el,
      el: $el[0],
      $backdropEl,
      backdropEl: $backdropEl && $backdropEl[0],
      type: "customModal"
    });
    $el[0].f7Modal = customModal;
    return customModal;
  }
}
const Modal2 = {
  name: "modal",
  static: {
    Modal: Modal$1,
    CustomModal
  },
  create() {
    const app = this;
    app.customModal = {
      create(params) {
        return new CustomModal(app, params);
      }
    };
  },
  params: {
    modal: {
      queueDialogs: true
    }
  }
};
Framework7.use([DeviceModule, SupportModule, UtilsModule, ResizeModule, TouchModule, ClicksModule, RouterModule, HistoryModule, ServiceWorkerModule, StoreModule, Statusbar$1, View$1, Navbar$2, Toolbar$2, Subnavbar$1, TouchRipple2, Modal2]);
const obj_pick = (obj, ...props) => {
  const result = {};
  for (const prop2 of props) {
    result[prop2] = obj[prop2];
  }
  return result;
};
const obj_omit = (obj, ...props) => {
  const result = {};
  const omitKeys = /* @__PURE__ */ new Set();
  for (const prop2 of props) {
    let key;
    switch (typeof prop2) {
      case "string":
      case "symbol":
        key = prop2;
        break;
      default:
        key = String(prop2);
    }
    omitKeys.add(key);
  }
  for (const key of Reflect.ownKeys(obj)) {
    if (omitKeys.has(key)) {
      continue;
    }
    result[key] = obj[key];
  }
  return result;
};
const obj_assign_props = (a, b) => {
  const b_props = Object.getOwnPropertyDescriptors(b);
  Object.defineProperties(a, b_props);
  return a;
};
const func_remember = (func, key) => {
  let result;
  const once_fn = function(...args) {
    const newKey = key?.apply(this, args);
    if (result === void 0 || newKey !== result.key) {
      result = {
        key: newKey,
        res: func.apply(this, args)
      };
    }
    return result.res;
  };
  const once_fn_mix = Object.assign(once_fn, {
    /// 注意，这的get
    get source() {
      return func;
    },
    get key() {
      return result?.key;
    },
    get runned() {
      return result != null;
    },
    get returnValue() {
      return result?.res;
    },
    reset() {
      result = void 0;
    },
    rerun(...args) {
      once_fn_mix.reset();
      return once_fn_mix(...args);
    }
  });
  Object.defineProperties(once_fn_mix, {
    source: {
      value: func,
      writable: false,
      configurable: true,
      enumerable: true
    },
    key: {
      get: () => result?.key,
      configurable: true,
      enumerable: true
    },
    runned: {
      get: () => result != null,
      configurable: true,
      enumerable: true
    },
    returnValue: {
      get: () => result?.res,
      configurable: true,
      enumerable: true
    }
  });
  return once_fn_mix;
};
const createStyle = (id2, parent2 = document.head) => {
  const style = document.createElement("style");
  style.id = id2;
  parent2.appendChild(style);
  return style;
};
const css = String.raw;
const setupDdpx = () => {
  const styleEle = createStyle("ddpx");
  const ddpx = 1 / Math.min(window.devicePixelRatio, 2);
  styleEle.innerHTML = css`
    :root {
      --ddpx: ${ddpx}px;
    }
  `;
  return ddpx;
};
function noUndefinedProps(obj) {
  const o = {};
  Object.keys(obj).forEach((key) => {
    if (typeof obj[key] !== "undefined") o[key] = obj[key];
  });
  return o;
}
function isStringProp(val2) {
  return typeof val2 === "string" && val2 !== "";
}
function isObject(o) {
  return typeof o === "object" && o !== null && o.constructor && o.constructor === Object;
}
function now() {
  return Date.now();
}
function extend() {
  let deep = true;
  let to;
  let from;
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }
  if (typeof args[0] === "boolean") {
    [deep, to] = args;
    args.splice(0, 2);
    from = args;
  } else {
    [to] = args;
    args.splice(0, 1);
    from = args;
  }
  for (let i = 0; i < from.length; i += 1) {
    const nextSource = args[i];
    if (nextSource !== void 0 && nextSource !== null) {
      const keysArray = Object.keys(Object(nextSource));
      for (let nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex += 1) {
        const nextKey = keysArray[nextIndex];
        const desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
        if (desc !== void 0 && desc.enumerable) {
          if (!deep) {
            to[nextKey] = nextSource[nextKey];
          } else if (isObject(to[nextKey]) && isObject(nextSource[nextKey])) {
            extend(to[nextKey], nextSource[nextKey]);
          } else if (!isObject(to[nextKey]) && isObject(nextSource[nextKey])) {
            to[nextKey] = {};
            extend(to[nextKey], nextSource[nextKey]);
          } else {
            to[nextKey] = nextSource[nextKey];
          }
        }
      }
    }
  }
  return to;
}
function flattenArray() {
  const arr = [];
  for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    args[_key2] = arguments[_key2];
  }
  args.forEach((arg) => {
    if (Array.isArray(arg)) arr.push(...flattenArray(...arg));
    else arr.push(arg);
  });
  return arr;
}
function classNames() {
  const classes = [];
  for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    args[_key3] = arguments[_key3];
  }
  args.forEach((arg) => {
    if (typeof arg === "object" && arg.constructor === Object) {
      Object.keys(arg).forEach((key) => {
        if (arg[key]) classes.push(key);
      });
    } else if (arg) classes.push(arg);
  });
  const uniqueClasses = [];
  classes.forEach((c) => {
    if (uniqueClasses.indexOf(c) < 0) uniqueClasses.push(c);
  });
  return uniqueClasses.join(" ");
}
function getSlots(props) {
  if (props === void 0) {
    props = {};
  }
  const slots = {};
  if (!props) return slots;
  const children2 = props.children;
  if (!children2 || children2.length === 0) {
    return slots;
  }
  function addChildToSlot(name2, child) {
    if (!slots[name2]) slots[name2] = [];
    slots[name2].push(child);
  }
  if (Array.isArray(children2)) {
    children2.forEach((child) => {
      if (!child) return;
      const slotName = child.props && child.props.slot || "default";
      addChildToSlot(slotName, child);
    });
  } else {
    let slotName = "default";
    if (children2.props && children2.props.slot) slotName = children2.props.slot;
    addChildToSlot(slotName, children2);
  }
  return slots;
}
function emit(props, events) {
  for (var _len4 = arguments.length, args = new Array(_len4 > 2 ? _len4 - 2 : 0), _key4 = 2; _key4 < _len4; _key4++) {
    args[_key4 - 2] = arguments[_key4];
  }
  if (!events || !events.trim().length || typeof events !== "string") return;
  events.trim().split(" ").forEach((event) => {
    let eventName = (event || "").trim();
    if (!eventName) return;
    eventName = eventName.charAt(0).toUpperCase() + eventName.slice(1);
    const propName = `on${eventName}`;
    if (props[propName]) props[propName](...args);
  });
}
function getExtraAttrs(props) {
  if (props === void 0) {
    props = {};
  }
  const extraAttrs = {};
  Object.keys(props).forEach((key) => {
    if (key.indexOf("data-") === 0 || key.indexOf("aria-") === 0 || key === "role") {
      extraAttrs[key] = props[key];
    }
  });
  return extraAttrs;
}
let routerIdCounter = 0;
let routerComponentIdCounter = 0;
function unsetRouterIds() {
  routerIdCounter = 0;
  routerComponentIdCounter = 0;
}
function getRouterId() {
  routerIdCounter += 1;
  return `${now()}_${routerIdCounter}`;
}
function getComponentId() {
  routerComponentIdCounter += 1;
  return `${now()}_${routerComponentIdCounter}`;
}
let f7;
let f7events;
const theme = {};
const f7routers = {
  views: [],
  tabs: [],
  modals: null
};
const setTheme = () => {
  if (!f7) return;
  theme.ios = f7.theme === "ios";
  theme.md = f7.theme === "md";
};
const cleanup = () => {
  unsetRouterIds();
  delete theme.ios;
  delete theme.md;
  f7routers.views = [];
  f7routers.tabs = [];
  f7routers.modals = null;
};
const f7initEvents = () => {
  f7events = new Framework7.Events();
};
const f7init = function(rootEl, params, init) {
  if (params === void 0) {
    params = {};
  }
  if (init === void 0) {
    init = true;
  }
  const f7Params = extend({}, params, {
    el: rootEl,
    init
  });
  if (typeof params.store !== "undefined") f7Params.store = params.store;
  if (!f7Params.routes) f7Params.routes = [];
  if (f7Params.userAgent && (f7Params.theme === "auto" || !f7Params.theme)) {
    const device = Framework7.getDevice({
      userAgent: f7Params.userAgent
    }, true);
    theme.ios = !!device.ios;
    theme.md = !theme.ios;
  }
  if (f7 && typeof window !== "undefined") return;
  if (typeof window === "undefined") cleanup();
  const instance = new Framework7(f7Params);
  f7 = instance;
  setTheme();
  if (instance.initialized) {
    f7 = instance;
    f7events.emit("ready", f7);
  } else {
    instance.on("init", () => {
      f7 = instance;
      f7events.emit("ready", f7);
    });
  }
};
const f7ready = (callback) => {
  if (!callback) return;
  if (f7 && f7.initialized) callback(f7);
  else {
    f7events.once("ready", callback);
  }
};
function getDefaultExportFromCjs(x) {
  return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
}
var react = { exports: {} };
var react_production_min = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var hasRequiredReact_production_min;
function requireReact_production_min() {
  if (hasRequiredReact_production_min) return react_production_min;
  hasRequiredReact_production_min = 1;
  var l = Symbol.for("react.element"), n = Symbol.for("react.portal"), p = Symbol.for("react.fragment"), q = Symbol.for("react.strict_mode"), r = Symbol.for("react.profiler"), t = Symbol.for("react.provider"), u = Symbol.for("react.context"), v = Symbol.for("react.forward_ref"), w = Symbol.for("react.suspense"), x = Symbol.for("react.memo"), y = Symbol.for("react.lazy"), z = Symbol.iterator;
  function A(a) {
    if (null === a || "object" !== typeof a) return null;
    a = z && a[z] || a["@@iterator"];
    return "function" === typeof a ? a : null;
  }
  var B = { isMounted: function() {
    return false;
  }, enqueueForceUpdate: function() {
  }, enqueueReplaceState: function() {
  }, enqueueSetState: function() {
  } }, C = Object.assign, D = {};
  function E(a, b, e) {
    this.props = a;
    this.context = b;
    this.refs = D;
    this.updater = e || B;
  }
  E.prototype.isReactComponent = {};
  E.prototype.setState = function(a, b) {
    if ("object" !== typeof a && "function" !== typeof a && null != a) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, a, b, "setState");
  };
  E.prototype.forceUpdate = function(a) {
    this.updater.enqueueForceUpdate(this, a, "forceUpdate");
  };
  function F() {
  }
  F.prototype = E.prototype;
  function G(a, b, e) {
    this.props = a;
    this.context = b;
    this.refs = D;
    this.updater = e || B;
  }
  var H = G.prototype = new F();
  H.constructor = G;
  C(H, E.prototype);
  H.isPureReactComponent = true;
  var I = Array.isArray, J = Object.prototype.hasOwnProperty, K = { current: null }, L = { key: true, ref: true, __self: true, __source: true };
  function M(a, b, e) {
    var d, c = {}, k = null, h = null;
    if (null != b) for (d in void 0 !== b.ref && (h = b.ref), void 0 !== b.key && (k = "" + b.key), b) J.call(b, d) && !L.hasOwnProperty(d) && (c[d] = b[d]);
    var g = arguments.length - 2;
    if (1 === g) c.children = e;
    else if (1 < g) {
      for (var f = Array(g), m = 0; m < g; m++) f[m] = arguments[m + 2];
      c.children = f;
    }
    if (a && a.defaultProps) for (d in g = a.defaultProps, g) void 0 === c[d] && (c[d] = g[d]);
    return { $$typeof: l, type: a, key: k, ref: h, props: c, _owner: K.current };
  }
  function N(a, b) {
    return { $$typeof: l, type: a.type, key: b, ref: a.ref, props: a.props, _owner: a._owner };
  }
  function O(a) {
    return "object" === typeof a && null !== a && a.$$typeof === l;
  }
  function escape(a) {
    var b = { "=": "=0", ":": "=2" };
    return "$" + a.replace(/[=:]/g, function(a2) {
      return b[a2];
    });
  }
  var P = /\/+/g;
  function Q(a, b) {
    return "object" === typeof a && null !== a && null != a.key ? escape("" + a.key) : b.toString(36);
  }
  function R(a, b, e, d, c) {
    var k = typeof a;
    if ("undefined" === k || "boolean" === k) a = null;
    var h = false;
    if (null === a) h = true;
    else switch (k) {
      case "string":
      case "number":
        h = true;
        break;
      case "object":
        switch (a.$$typeof) {
          case l:
          case n:
            h = true;
        }
    }
    if (h) return h = a, c = c(h), a = "" === d ? "." + Q(h, 0) : d, I(c) ? (e = "", null != a && (e = a.replace(P, "$&/") + "/"), R(c, b, e, "", function(a2) {
      return a2;
    })) : null != c && (O(c) && (c = N(c, e + (!c.key || h && h.key === c.key ? "" : ("" + c.key).replace(P, "$&/") + "/") + a)), b.push(c)), 1;
    h = 0;
    d = "" === d ? "." : d + ":";
    if (I(a)) for (var g = 0; g < a.length; g++) {
      k = a[g];
      var f = d + Q(k, g);
      h += R(k, b, e, f, c);
    }
    else if (f = A(a), "function" === typeof f) for (a = f.call(a), g = 0; !(k = a.next()).done; ) k = k.value, f = d + Q(k, g++), h += R(k, b, e, f, c);
    else if ("object" === k) throw b = String(a), Error("Objects are not valid as a React child (found: " + ("[object Object]" === b ? "object with keys {" + Object.keys(a).join(", ") + "}" : b) + "). If you meant to render a collection of children, use an array instead.");
    return h;
  }
  function S(a, b, e) {
    if (null == a) return a;
    var d = [], c = 0;
    R(a, d, "", "", function(a2) {
      return b.call(e, a2, c++);
    });
    return d;
  }
  function T(a) {
    if (-1 === a._status) {
      var b = a._result;
      b = b();
      b.then(function(b2) {
        if (0 === a._status || -1 === a._status) a._status = 1, a._result = b2;
      }, function(b2) {
        if (0 === a._status || -1 === a._status) a._status = 2, a._result = b2;
      });
      -1 === a._status && (a._status = 0, a._result = b);
    }
    if (1 === a._status) return a._result.default;
    throw a._result;
  }
  var U = { current: null }, V = { transition: null }, W = { ReactCurrentDispatcher: U, ReactCurrentBatchConfig: V, ReactCurrentOwner: K };
  function X() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  react_production_min.Children = { map: S, forEach: function(a, b, e) {
    S(a, function() {
      b.apply(this, arguments);
    }, e);
  }, count: function(a) {
    var b = 0;
    S(a, function() {
      b++;
    });
    return b;
  }, toArray: function(a) {
    return S(a, function(a2) {
      return a2;
    }) || [];
  }, only: function(a) {
    if (!O(a)) throw Error("React.Children.only expected to receive a single React element child.");
    return a;
  } };
  react_production_min.Component = E;
  react_production_min.Fragment = p;
  react_production_min.Profiler = r;
  react_production_min.PureComponent = G;
  react_production_min.StrictMode = q;
  react_production_min.Suspense = w;
  react_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = W;
  react_production_min.act = X;
  react_production_min.cloneElement = function(a, b, e) {
    if (null === a || void 0 === a) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + a + ".");
    var d = C({}, a.props), c = a.key, k = a.ref, h = a._owner;
    if (null != b) {
      void 0 !== b.ref && (k = b.ref, h = K.current);
      void 0 !== b.key && (c = "" + b.key);
      if (a.type && a.type.defaultProps) var g = a.type.defaultProps;
      for (f in b) J.call(b, f) && !L.hasOwnProperty(f) && (d[f] = void 0 === b[f] && void 0 !== g ? g[f] : b[f]);
    }
    var f = arguments.length - 2;
    if (1 === f) d.children = e;
    else if (1 < f) {
      g = Array(f);
      for (var m = 0; m < f; m++) g[m] = arguments[m + 2];
      d.children = g;
    }
    return { $$typeof: l, type: a.type, key: c, ref: k, props: d, _owner: h };
  };
  react_production_min.createContext = function(a) {
    a = { $$typeof: u, _currentValue: a, _currentValue2: a, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null };
    a.Provider = { $$typeof: t, _context: a };
    return a.Consumer = a;
  };
  react_production_min.createElement = M;
  react_production_min.createFactory = function(a) {
    var b = M.bind(null, a);
    b.type = a;
    return b;
  };
  react_production_min.createRef = function() {
    return { current: null };
  };
  react_production_min.forwardRef = function(a) {
    return { $$typeof: v, render: a };
  };
  react_production_min.isValidElement = O;
  react_production_min.lazy = function(a) {
    return { $$typeof: y, _payload: { _status: -1, _result: a }, _init: T };
  };
  react_production_min.memo = function(a, b) {
    return { $$typeof: x, type: a, compare: void 0 === b ? null : b };
  };
  react_production_min.startTransition = function(a) {
    var b = V.transition;
    V.transition = {};
    try {
      a();
    } finally {
      V.transition = b;
    }
  };
  react_production_min.unstable_act = X;
  react_production_min.useCallback = function(a, b) {
    return U.current.useCallback(a, b);
  };
  react_production_min.useContext = function(a) {
    return U.current.useContext(a);
  };
  react_production_min.useDebugValue = function() {
  };
  react_production_min.useDeferredValue = function(a) {
    return U.current.useDeferredValue(a);
  };
  react_production_min.useEffect = function(a, b) {
    return U.current.useEffect(a, b);
  };
  react_production_min.useId = function() {
    return U.current.useId();
  };
  react_production_min.useImperativeHandle = function(a, b, e) {
    return U.current.useImperativeHandle(a, b, e);
  };
  react_production_min.useInsertionEffect = function(a, b) {
    return U.current.useInsertionEffect(a, b);
  };
  react_production_min.useLayoutEffect = function(a, b) {
    return U.current.useLayoutEffect(a, b);
  };
  react_production_min.useMemo = function(a, b) {
    return U.current.useMemo(a, b);
  };
  react_production_min.useReducer = function(a, b, e) {
    return U.current.useReducer(a, b, e);
  };
  react_production_min.useRef = function(a) {
    return U.current.useRef(a);
  };
  react_production_min.useState = function(a) {
    return U.current.useState(a);
  };
  react_production_min.useSyncExternalStore = function(a, b, e) {
    return U.current.useSyncExternalStore(a, b, e);
  };
  react_production_min.useTransition = function() {
    return U.current.useTransition();
  };
  react_production_min.version = "18.3.1";
  return react_production_min;
}
var hasRequiredReact;
function requireReact() {
  if (hasRequiredReact) return react.exports;
  hasRequiredReact = 1;
  {
    react.exports = /* @__PURE__ */ requireReact_production_min();
  }
  return react.exports;
}
var reactExports = /* @__PURE__ */ requireReact();
const React = /* @__PURE__ */ getDefaultExportFromCjs(reactExports);
function colorClasses(props) {
  const {
    color,
    textColor,
    bgColor,
    borderColor,
    rippleColor,
    dark
  } = props;
  return {
    dark,
    [`color-${color}`]: color,
    [`text-color-${textColor}`]: textColor,
    [`bg-color-${bgColor}`]: bgColor,
    [`border-color-${borderColor}`]: borderColor,
    [`ripple-color-${rippleColor}`]: rippleColor
  };
}
function routerAttrs(props) {
  const {
    force,
    reloadCurrent,
    reloadPrevious,
    reloadAll,
    reloadDetail,
    animate: animate2,
    ignoreCache,
    routeTabId,
    view,
    transition: transition2,
    openIn
  } = props;
  let dataAnimate;
  if ("animate" in props && typeof animate2 !== "undefined") {
    dataAnimate = animate2.toString();
  }
  let dataReloadDetail;
  if ("reloadDetail" in props && typeof reloadDetail !== "undefined") {
    dataReloadDetail = reloadDetail.toString();
  }
  return {
    "data-force": force || void 0,
    "data-reload-current": reloadCurrent || void 0,
    "data-reload-all": reloadAll || void 0,
    "data-reload-previous": reloadPrevious || void 0,
    "data-reload-detail": dataReloadDetail,
    "data-animate": dataAnimate,
    "data-ignore-cache": ignoreCache || void 0,
    "data-route-tab-id": routeTabId || void 0,
    "data-view": isStringProp(view) ? view : void 0,
    "data-transition": isStringProp(transition2) ? transition2 : void 0,
    "data-open-in": isStringProp(openIn) ? openIn : void 0
  };
}
function routerClasses(props) {
  const {
    back: back2,
    linkBack,
    external,
    preventRouter
  } = props;
  return {
    back: back2 || linkBack,
    external,
    "prevent-router": preventRouter
  };
}
function actionsAttrs(props) {
  const {
    searchbarEnable,
    searchbarDisable,
    searchbarClear,
    searchbarToggle,
    panelOpen,
    panelClose,
    panelToggle,
    popupOpen,
    popupClose,
    actionsOpen,
    actionsClose,
    popoverOpen,
    popoverClose,
    loginScreenOpen,
    loginScreenClose,
    sheetOpen,
    sheetClose,
    sortableEnable,
    sortableDisable,
    sortableToggle,
    cardOpen,
    cardClose
  } = props;
  return {
    "data-searchbar": isStringProp(searchbarEnable) && searchbarEnable || isStringProp(searchbarDisable) && searchbarDisable || isStringProp(searchbarClear) && searchbarClear || isStringProp(searchbarToggle) && searchbarToggle || void 0,
    "data-panel": isStringProp(panelOpen) && panelOpen || isStringProp(panelClose) && panelClose || isStringProp(panelToggle) && panelToggle || void 0,
    "data-popup": isStringProp(popupOpen) && popupOpen || isStringProp(popupClose) && popupClose || void 0,
    "data-actions": isStringProp(actionsOpen) && actionsOpen || isStringProp(actionsClose) && actionsClose || void 0,
    "data-popover": isStringProp(popoverOpen) && popoverOpen || isStringProp(popoverClose) && popoverClose || void 0,
    "data-sheet": isStringProp(sheetOpen) && sheetOpen || isStringProp(sheetClose) && sheetClose || void 0,
    "data-login-screen": isStringProp(loginScreenOpen) && loginScreenOpen || isStringProp(loginScreenClose) && loginScreenClose || void 0,
    "data-sortable": isStringProp(sortableEnable) && sortableEnable || isStringProp(sortableDisable) && sortableDisable || isStringProp(sortableToggle) && sortableToggle || void 0,
    "data-card": isStringProp(cardOpen) && cardOpen || isStringProp(cardClose) && cardClose || void 0
  };
}
function actionsClasses(props) {
  const {
    searchbarEnable,
    searchbarDisable,
    searchbarClear,
    searchbarToggle,
    panelOpen,
    panelClose,
    panelToggle,
    popupOpen,
    popupClose,
    actionsClose,
    actionsOpen,
    popoverOpen,
    popoverClose,
    loginScreenOpen,
    loginScreenClose,
    sheetOpen,
    sheetClose,
    sortableEnable,
    sortableDisable,
    sortableToggle,
    cardOpen,
    cardPreventOpen,
    cardClose
  } = props;
  return {
    "searchbar-enable": searchbarEnable || searchbarEnable === "",
    "searchbar-disable": searchbarDisable || searchbarDisable === "",
    "searchbar-clear": searchbarClear || searchbarClear === "",
    "searchbar-toggle": searchbarToggle || searchbarToggle === "",
    "panel-close": panelClose || panelClose === "",
    "panel-open": panelOpen || panelOpen === "",
    "panel-toggle": panelToggle || panelToggle === "",
    "popup-close": popupClose || popupClose === "",
    "popup-open": popupOpen || popupOpen === "",
    "actions-close": actionsClose || actionsClose === "",
    "actions-open": actionsOpen || actionsOpen === "",
    "popover-close": popoverClose || popoverClose === "",
    "popover-open": popoverOpen || popoverOpen === "",
    "sheet-close": sheetClose || sheetClose === "",
    "sheet-open": sheetOpen || sheetOpen === "",
    "login-screen-close": loginScreenClose || loginScreenClose === "",
    "login-screen-open": loginScreenOpen || loginScreenOpen === "",
    "sortable-enable": sortableEnable || sortableEnable === "",
    "sortable-disable": sortableDisable || sortableDisable === "",
    "sortable-toggle": sortableToggle || sortableToggle === "",
    "card-close": cardClose || cardClose === "",
    "card-open": cardOpen || cardOpen === "",
    "card-prevent-open": cardPreventOpen || cardPreventOpen === ""
  };
}
const modalStateClasses = function(_temp) {
  let {
    isOpened,
    isClosing
  } = _temp === void 0 ? {} : _temp;
  return {
    "modal-in": isOpened.current && !isClosing.current,
    "modal-out": isClosing.current
  };
};
function useIsomorphicLayoutEffect(callback, deps) {
  if (typeof window === "undefined") return reactExports.useEffect(callback, deps);
  return reactExports.useLayoutEffect(callback, deps);
}
const watchProp = (value2, callback) => {
  const valueRef = reactExports.useRef(value2);
  useIsomorphicLayoutEffect(() => {
    if (value2 !== valueRef.current && callback) {
      callback(value2, valueRef.current);
    }
    valueRef.current = value2;
  }, [value2]);
};
function _extends$1m() {
  _extends$1m = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1m.apply(this, arguments);
}
const Popup = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7Popup = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    children: children2,
    tabletFullscreen,
    push,
    opened,
    closeByBackdropClick,
    backdrop,
    backdropEl,
    animate: animate2,
    closeOnEscape,
    swipeToClose = false,
    swipeHandler,
    containerEl
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const isOpened = reactExports.useRef(opened);
  const isClosing = reactExports.useRef(false);
  const onSwipeStart = (instance) => {
    emit(props, "popupSwipeStart", instance);
  };
  const onSwipeMove = (instance) => {
    emit(props, "popupSwipeMove", instance);
  };
  const onSwipeEnd = (instance) => {
    emit(props, "popupSwipeEnd", instance);
  };
  const onSwipeClose = (instance) => {
    emit(props, "popupSwipeClose", instance);
  };
  const onOpen2 = (instance) => {
    isOpened.current = true;
    isClosing.current = false;
    emit(props, "popupOpen", instance);
  };
  const onOpened = (instance) => {
    emit(props, "popupOpened", instance);
  };
  const onClose2 = (instance) => {
    isOpened.current = false;
    isClosing.current = true;
    emit(props, "popupClose", instance);
  };
  const onClosed = (instance) => {
    isClosing.current = false;
    emit(props, "popupClosed", instance);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7Popup: () => f7Popup.current
  }));
  watchProp(opened, (value2) => {
    if (!f7Popup.current) return;
    if (value2) {
      f7Popup.current.open();
    } else {
      f7Popup.current.close();
    }
  });
  const modalEvents = (method) => {
    if (!f7Popup.current) return;
    f7Popup.current[method]("swipeStart", onSwipeStart);
    f7Popup.current[method]("swipeMove", onSwipeMove);
    f7Popup.current[method]("swipeEnd", onSwipeEnd);
    f7Popup.current[method]("swipeClose", onSwipeClose);
    f7Popup.current[method]("open", onOpen2);
    f7Popup.current[method]("opened", onOpened);
    f7Popup.current[method]("close", onClose2);
    f7Popup.current[method]("closed", onClosed);
  };
  const onMount = () => {
    if (!elRef.current) return;
    const popupParams = {
      el: elRef.current
    };
    if ("closeByBackdropClick" in props) popupParams.closeByBackdropClick = closeByBackdropClick;
    if ("closeOnEscape" in props) popupParams.closeOnEscape = closeOnEscape;
    if ("animate" in props) popupParams.animate = animate2;
    if ("backdrop" in props) popupParams.backdrop = backdrop;
    if ("backdropEl" in props) popupParams.backdropEl = backdropEl;
    if ("swipeToClose" in props) popupParams.swipeToClose = swipeToClose;
    if ("swipeHandler" in props) popupParams.swipeHandler = swipeHandler;
    if ("containerEl" in props) popupParams.containerEl = containerEl;
    f7ready(() => {
      f7Popup.current = f7.popup.create(popupParams);
      modalEvents("on");
      if (opened) {
        f7Popup.current.open(false, true);
      }
    });
  };
  const onDestroy = () => {
    if (f7Popup.current) {
      f7Popup.current.destroy();
    }
    f7Popup.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    modalEvents("on");
    return () => {
      modalEvents("off");
    };
  });
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  const classes = classNames(className, "popup", {
    "popup-tablet-fullscreen": tabletFullscreen,
    "popup-push": push
  }, modalStateClasses({
    isOpened,
    isClosing
  }), colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1m({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
Popup.displayName = "f7-popup";
const useTab = (elRef, props) => {
  const onTabShow = (el) => {
    if (elRef.current !== el) return;
    emit(props, "tabShow", el);
  };
  const onTabHide = (el) => {
    if (elRef.current !== el) return;
    emit(props, "tabHide", el);
  };
  const attachEvents = () => {
    if (!elRef.current) return;
    f7ready(() => {
      f7.on("tabShow", onTabShow);
      f7.on("tabHide", onTabHide);
    });
  };
  const detachEvents = () => {
    if (!f7) return;
    f7.off("tabShow", onTabShow);
    f7.off("tabHide", onTabHide);
  };
  useIsomorphicLayoutEffect(() => {
    attachEvents();
    return detachEvents;
  });
};
const useAsyncComponent = (component, props, key) => {
  const Component = /* @__PURE__ */ reactExports.lazy(component);
  return /* @__PURE__ */ React.createElement(reactExports.Suspense, {
    fallback: null,
    key
  }, /* @__PURE__ */ React.createElement(Component, props));
};
const getRouterInitialComponent = (router, initialComponent) => {
  let initialComponentData;
  const {
    initialUrl
  } = router.getInitialUrl();
  const initialRoute = router.findMatchingRoute(initialUrl);
  let routeProps = {};
  if (initialRoute && initialRoute.route && initialRoute.route.options) {
    routeProps = initialRoute.route.options.props;
  }
  const isMasterRoute = (route) => {
    if (route.master === true) return true;
    if (typeof route.master === "function") return route.master(router.app);
    return false;
  };
  if (initialRoute && initialRoute.route && (initialRoute.route.component || initialRoute.route.asyncComponent) && !isMasterRoute(initialRoute.route)) {
    initialComponentData = {
      component: initialRoute.route.component || initialRoute.route.asyncComponent,
      initialComponent,
      id: getComponentId(),
      isAsync: !!initialRoute.route.asyncComponent,
      props: {
        f7route: initialRoute,
        f7router: router,
        ...routeProps,
        ...initialRoute.params
      }
    };
  }
  return {
    initialPage: initialComponentData,
    initialRoute
  };
};
const RouterContext = /* @__PURE__ */ React.createContext({
  route: null,
  router: null
});
function _extends$1l() {
  _extends$1l = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1l.apply(this, arguments);
}
const View2 = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    init = true,
    main,
    tab,
    tabActive,
    url,
    initRouterOnTabShow,
    browserHistoryInitialMatch = true
  } = props;
  const childrenArray = React.Children.toArray(children2);
  const initialPageComponent = childrenArray.filter((c) => c.props && c.props.initialPage)[0];
  const restChildren = childrenArray.filter((c) => !c.props || !c.props.initialPage);
  const shouldInitRouter = !(initRouterOnTabShow && tab && !tabActive);
  const extraAttrs = getExtraAttrs(props);
  const f7View = reactExports.useRef(null);
  const elRef = reactExports.useRef(null);
  const routerData = reactExports.useRef(null);
  let initialPage;
  let initialRoute;
  const onViewInit = (view) => {
    emit(props, "viewInit", view);
    if (!init) {
      routerData.current.instance = view;
      f7View.current = routerData.current.instance;
    }
  };
  if (f7 && !f7View.current && init) {
    const routerId = getRouterId();
    f7View.current = f7.views.create(elRef.current, {
      routerId,
      init: false,
      ...noUndefinedProps(props),
      browserHistoryInitialMatch,
      on: {
        init: onViewInit
      }
    });
    routerData.current = {
      routerId,
      instance: f7View.current
    };
    f7routers.views.push(routerData.current);
    if (shouldInitRouter && f7View.current && f7View.current.router && (url || main)) {
      const initialData = getRouterInitialComponent(f7View.current.router, initialPageComponent);
      initialPage = initialData.initialPage;
      initialRoute = initialData.initialRoute;
      if (initialRoute && initialRoute.route && initialRoute.route.masterRoute) {
        initialPage = void 0;
        initialRoute = void 0;
      }
    }
  }
  const [pages, setPages] = reactExports.useState(initialPage ? [initialPage] : []);
  const onResize = (view, width2) => {
    emit(props, "viewResize", width2);
  };
  const onSwipeBackMove = (data2) => {
    const swipeBackData = data2;
    emit(props, "swipeBackMove", swipeBackData);
  };
  const onSwipeBackBeforeChange = (data2) => {
    const swipeBackData = data2;
    emit(props, "swipeBackBeforeChange", swipeBackData);
  };
  const onSwipeBackAfterChange = (data2) => {
    const swipeBackData = data2;
    emit(props, "swipeBackAfterChange", swipeBackData);
  };
  const onSwipeBackBeforeReset = (data2) => {
    const swipeBackData = data2;
    emit(props, "swipeBackBeforeReset", swipeBackData);
  };
  const onSwipeBackAfterReset = (data2) => {
    const swipeBackData = data2;
    emit(props, "swipeBackAfterReset", swipeBackData);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7View: () => f7View.current
  }));
  const onMount = () => {
    f7ready(() => {
      if (f7View.current) {
        routerData.current.el = elRef.current;
        routerData.current.pages = pages;
        routerData.current.setPages = (newPages) => {
          setPages([...newPages]);
        };
        if (initialPage && initialPage.isAsync && !initialPage.initialComponent) {
          initialPage.component().then(() => {
            setTimeout(() => {
              f7View.current.init(elRef.current);
              if (initialPage) {
                initialPage.el = f7View.current.router.currentPageEl;
                if (initialRoute && initialRoute.route && initialRoute.route.keepAlive) {
                  initialRoute.route.keepAliveData = {
                    pageEl: initialPage.el
                  };
                }
              }
            }, 100);
          });
        } else {
          f7View.current.init(elRef.current);
          if (initialPage) {
            initialPage.el = f7View.current.router.currentPageEl;
            if (initialRoute && initialRoute.route && initialRoute.route.keepAlive) {
              initialRoute.route.keepAliveData = {
                pageEl: initialPage.el
              };
            }
          }
        }
      } else {
        const routerId = getRouterId();
        routerData.current = {
          el: elRef.current,
          routerId,
          pages,
          instance: f7View.current,
          setPages(newPages) {
            setPages([...newPages]);
          }
        };
        f7routers.views.push(routerData.current);
        routerData.current.instance = f7.views.create(elRef.current, {
          routerId,
          ...noUndefinedProps(props),
          browserHistoryInitialMatch,
          on: {
            init: onViewInit
          }
        });
        f7View.current = routerData.current.instance;
      }
      if (!init) return;
      f7View.current.on("resize", onResize);
      f7View.current.on("swipebackMove", onSwipeBackMove);
      f7View.current.on("swipebackBeforeChange", onSwipeBackBeforeChange);
      f7View.current.on("swipebackAfterChange", onSwipeBackAfterChange);
      f7View.current.on("swipebackBeforeReset", onSwipeBackBeforeReset);
      f7View.current.on("swipebackAfterReset", onSwipeBackAfterReset);
    });
  };
  const onDestroy = () => {
    if (f7View.current) {
      f7View.current.off("resize", onResize);
      f7View.current.off("swipebackMove", onSwipeBackMove);
      f7View.current.off("swipebackBeforeChange", onSwipeBackBeforeChange);
      f7View.current.off("swipebackAfterChange", onSwipeBackAfterChange);
      f7View.current.off("swipebackBeforeReset", onSwipeBackBeforeReset);
      f7View.current.off("swipebackAfterReset", onSwipeBackAfterReset);
      if (f7View.current.destroy) f7View.current.destroy();
      f7View.current = null;
    }
    f7routers.views.splice(f7routers.views.indexOf(routerData.current), 1);
    routerData.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  useIsomorphicLayoutEffect(() => {
    if (routerData.current && f7) {
      f7events.emit("viewRouterDidUpdate", routerData.current);
    }
  });
  useTab(elRef, props);
  const classes = classNames(className, "view", {
    "view-main": main,
    "tab-active": tabActive,
    tab
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1l({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), restChildren, pages.map((_ref) => {
    let {
      component: PageComponent,
      id: pageId,
      props: pageProps,
      isAsync,
      initialComponent
    } = _ref;
    return /* @__PURE__ */ React.createElement(RouterContext.Provider, {
      key: pageId,
      value: {
        router: pageProps.f7router,
        route: pageProps.f7route
      }
    }, initialComponent ? /* @__PURE__ */ React.cloneElement(initialComponent, {
      ...pageProps
    }) : isAsync ? useAsyncComponent(PageComponent, pageProps) : /* @__PURE__ */ React.createElement(PageComponent, pageProps));
  }));
});
View2.displayName = "f7-view";
function _extends$1k() {
  _extends$1k = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1k.apply(this, arguments);
}
const LoginScreen = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7LoginScreen = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    children: children2,
    opened,
    animate: animate2,
    containerEl
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const isOpened = reactExports.useRef(opened);
  const isClosing = reactExports.useRef(false);
  const elRef = reactExports.useRef(null);
  const onOpen2 = (instance) => {
    isOpened.current = true;
    isClosing.current = false;
    emit(props, "loginScreenOpen", instance);
  };
  const onOpened = (instance) => {
    emit(props, "loginScreenOpened", instance);
  };
  const onClose2 = (instance) => {
    isOpened.current = false;
    isClosing.current = true;
    emit(props, "loginScreenClose", instance);
  };
  const onClosed = (instance) => {
    isClosing.current = false;
    emit(props, "loginScreenClosed", instance);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7LoginScreen: () => f7LoginScreen.current
  }));
  watchProp(opened, (value2) => {
    if (!f7LoginScreen.current) return;
    if (value2) {
      f7LoginScreen.current.open();
    } else {
      f7LoginScreen.current.close();
    }
  });
  const modalEvents = (method) => {
    if (!f7LoginScreen.current) return;
    f7LoginScreen.current[method]("open", onOpen2);
    f7LoginScreen.current[method]("opened", onOpened);
    f7LoginScreen.current[method]("close", onClose2);
    f7LoginScreen.current[method]("closed", onClosed);
  };
  const onMount = () => {
    if (!elRef.current) return;
    f7ready(() => {
      const loginScreenParams = {
        el: elRef.current
      };
      if ("animate" in props) loginScreenParams.animate = animate2;
      if ("containerEl" in props) loginScreenParams.containerEl = containerEl;
      f7LoginScreen.current = f7.loginScreen.create(loginScreenParams);
      modalEvents("on");
      if (opened) {
        f7LoginScreen.current.open(false);
      }
    });
  };
  const onDestroy = () => {
    if (f7LoginScreen.current) {
      f7LoginScreen.current.destroy();
    }
    f7LoginScreen.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    modalEvents("on");
    return () => {
      modalEvents("off");
    };
  });
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  const classes = classNames(className, "login-screen", modalStateClasses({
    isOpened,
    isClosing
  }), colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1k({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
LoginScreen.displayName = "f7-login-screen";
function _extends$1j() {
  _extends$1j = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1j.apply(this, arguments);
}
const Sheet = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7Sheet = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    top,
    bottom,
    position,
    push,
    opened,
    animate: animate2,
    backdrop,
    backdropEl,
    closeByBackdropClick,
    closeByOutsideClick,
    closeOnEscape,
    swipeToClose,
    swipeToStep,
    swipeHandler,
    containerEl,
    breakpoints,
    backdropBreakpoint,
    pushBreakpoint
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const isOpened = reactExports.useRef(opened);
  const isClosing = reactExports.useRef(false);
  const onBreakpoint = (instance, breakpoint) => {
    emit(props, "sheetBreakpoint", instance, breakpoint);
  };
  const onStepProgress = (instance, progress) => {
    emit(props, "sheetStepProgress", instance, progress);
  };
  const onStepOpen = (instance) => {
    emit(props, "sheetStepOpen", instance);
  };
  const onStepClose = (instance) => {
    emit(props, "sheetStepClose", instance);
  };
  const onOpen2 = (instance) => {
    isOpened.current = true;
    isClosing.current = false;
    emit(props, "sheetOpen", instance);
  };
  const onOpened = (instance) => {
    emit(props, "sheetOpened", instance);
  };
  const onClose2 = (instance) => {
    isOpened.current = false;
    isClosing.current = true;
    emit(props, "sheetClose", instance);
  };
  const onClosed = (instance) => {
    isClosing.current = false;
    emit(props, "sheetClosed", instance);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7Sheet: () => f7Sheet.current
  }));
  const modalEvents = (method) => {
    if (!f7Sheet.current) return;
    f7Sheet.current[method]("open", onOpen2);
    f7Sheet.current[method]("opened", onOpened);
    f7Sheet.current[method]("close", onClose2);
    f7Sheet.current[method]("closed", onClosed);
    f7Sheet.current[method]("stepOpen", onStepOpen);
    f7Sheet.current[method]("stepClose", onStepClose);
    f7Sheet.current[method]("stepProgress", onStepProgress);
    f7Sheet.current[method]("breakpoint", onBreakpoint);
  };
  const onMount = () => {
    if (!elRef.current) return;
    const sheetParams = {
      el: elRef.current,
      breakpoints,
      backdropBreakpoint,
      pushBreakpoint
    };
    if ("animate" in props && typeof animate2 !== "undefined") sheetParams.animate = animate2;
    if ("backdrop" in props && typeof backdrop !== "undefined") sheetParams.backdrop = backdrop;
    if ("backdropEl" in props) sheetParams.backdropEl = backdropEl;
    if ("closeByBackdropClick" in props) sheetParams.closeByBackdropClick = closeByBackdropClick;
    if ("closeByOutsideClick" in props) sheetParams.closeByOutsideClick = closeByOutsideClick;
    if ("closeOnEscape" in props) sheetParams.closeOnEscape = closeOnEscape;
    if ("swipeToClose" in props) sheetParams.swipeToClose = swipeToClose;
    if ("swipeToStep" in props) sheetParams.swipeToStep = swipeToStep;
    if ("swipeHandler" in props) sheetParams.swipeHandler = swipeHandler;
    if ("containerEl" in props) sheetParams.containerEl = containerEl;
    if ("breakpoints" in props) sheetParams.breakpoints = breakpoints;
    if ("backdropBreakpoint" in props) sheetParams.backdropBreakpoint = backdropBreakpoint;
    if ("pushBreakpoint" in props) sheetParams.pushBreakpoint = pushBreakpoint;
    f7ready(() => {
      f7Sheet.current = f7.sheet.create(sheetParams);
      modalEvents("on");
      if (opened) {
        f7Sheet.current.open(false);
      }
    });
  };
  const onDestroy = () => {
    if (f7Sheet.current) {
      f7Sheet.current.destroy();
    }
    f7Sheet.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    modalEvents("on");
    return () => {
      modalEvents("off");
    };
  });
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  watchProp(opened, (value2) => {
    if (!f7Sheet.current) return;
    if (value2) {
      f7Sheet.current.open();
    } else {
      f7Sheet.current.close();
    }
  });
  const slots = getSlots(props);
  const fixedList = [];
  const staticList = [];
  const fixedTags = "navbar toolbar tabbar subnavbar searchbar messagebar fab list-index panel".split(" ").map((tagName) => `f7-${tagName}`);
  const slotsDefault = slots.default;
  if (slotsDefault && slotsDefault.length) {
    slotsDefault.forEach((child) => {
      if (typeof child === "undefined") return;
      let isFixedTag = false;
      const tag = child.type && (child.type.displayName || child.type.name);
      if (!tag) {
        staticList.push(child);
        return;
      }
      if (fixedTags.indexOf(tag) >= 0) {
        isFixedTag = true;
      }
      if (isFixedTag) fixedList.push(child);
      else staticList.push(child);
    });
  }
  const innerEl = /* @__PURE__ */ React.createElement("div", {
    className: "sheet-modal-inner"
  }, staticList, slots.static);
  let positionComputed = "bottom";
  if (position) positionComputed = position;
  else if (top) positionComputed = "top";
  else if (bottom) positionComputed = "bottom";
  const classes = classNames(className, "sheet-modal", `sheet-modal-${positionComputed}`, {
    "sheet-modal-push": push
  }, modalStateClasses({
    isOpened,
    isClosing
  }), colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1j({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), fixedList, slots.fixed, innerEl);
});
Sheet.displayName = "f7-sheet";
function _extends$1i() {
  _extends$1i = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1i.apply(this, arguments);
}
const Popover = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7Popover = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    children: children2,
    opened,
    animate: animate2,
    targetEl,
    arrow,
    backdrop,
    backdropEl,
    closeByBackdropClick,
    closeByOutsideClick,
    closeOnEscape,
    containerEl,
    verticalPosition
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const isOpened = reactExports.useRef(opened);
  const isClosing = reactExports.useRef(false);
  const onOpen2 = (instance) => {
    isOpened.current = true;
    isClosing.current = false;
    emit(props, "popoverOpen", instance);
  };
  const onOpened = (instance) => {
    emit(props, "popoverOpened", instance);
  };
  const onClose2 = (instance) => {
    isOpened.current = false;
    isClosing.current = true;
    emit(props, "popoverClose", instance);
  };
  const onClosed = (instance) => {
    isClosing.current = false;
    emit(props, "popoverClosed", instance);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7Popover: () => f7Popover.current
  }));
  watchProp(opened, (value2) => {
    if (!f7Popover.current) return;
    if (value2) {
      f7Popover.current.open();
    } else {
      f7Popover.current.close();
    }
  });
  const modalEvents = (method) => {
    if (!f7Popover.current) return;
    f7Popover.current[method]("open", onOpen2);
    f7Popover.current[method]("opened", onOpened);
    f7Popover.current[method]("close", onClose2);
    f7Popover.current[method]("closed", onClosed);
  };
  const onMount = () => {
    if (!elRef.current) return;
    const popoverParams = {
      el: elRef.current
    };
    if (targetEl) popoverParams.targetEl = targetEl;
    if ("closeByBackdropClick" in props) popoverParams.closeByBackdropClick = closeByBackdropClick;
    if ("closeByOutsideClick" in props) popoverParams.closeByOutsideClick = closeByOutsideClick;
    if ("closeOnEscape" in props) popoverParams.closeOnEscape = closeOnEscape;
    if ("arrow" in props) popoverParams.arrow = arrow;
    if ("backdrop" in props) popoverParams.backdrop = backdrop;
    if ("backdropEl" in props) popoverParams.backdropEl = backdropEl;
    if ("animate" in props) popoverParams.animate = animate2;
    if ("containerEl" in props) popoverParams.containerEl = containerEl;
    if ("verticalPosition" in props) popoverParams.verticalPosition = verticalPosition;
    f7ready(() => {
      f7Popover.current = f7.popover.create(popoverParams);
      modalEvents("on");
      if (opened && targetEl) {
        f7Popover.current.open(targetEl, false);
      }
    });
  };
  const onDestroy = () => {
    if (f7Popover.current) {
      f7Popover.current.destroy();
    }
    f7Popover.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    modalEvents("on");
    return () => {
      modalEvents("off");
    };
  });
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  const classes = classNames(className, "popover", modalStateClasses({
    isOpened,
    isClosing
  }), colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1i({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), arrow !== false && /* @__PURE__ */ React.createElement("div", {
    className: "popover-arrow"
  }), /* @__PURE__ */ React.createElement("div", {
    className: "popover-inner"
  }, children2));
});
Popover.displayName = "f7-popover";
function _extends$1h() {
  _extends$1h = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1h.apply(this, arguments);
}
const Panel = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7Panel = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    children: children2,
    side,
    effect,
    // eslint-disable-next-line
    cover,
    reveal,
    push,
    floating,
    left,
    // right,
    opened,
    resizable,
    backdrop = true,
    backdropEl,
    containerEl,
    closeByBackdropClick,
    visibleBreakpoint,
    collapsedBreakpoint,
    swipe,
    swipeNoFollow,
    swipeOnlyClose,
    swipeActiveArea = 0,
    swipeThreshold = 0
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const isOpened = reactExports.useRef(false);
  const isClosing = reactExports.useRef(false);
  const isCollapsed = reactExports.useRef(false);
  const isBreakpoint = reactExports.useRef(false);
  const onOpen2 = (event) => {
    isOpened.current = true;
    isClosing.current = false;
    emit(props, "panelOpen", event);
  };
  const onOpened = (event) => {
    emit(props, "panelOpened", event);
  };
  const onClose2 = (event) => {
    isOpened.current = false;
    isClosing.current = true;
    emit(props, "panelClose", event);
  };
  const onClosed = (event) => {
    isClosing.current = false;
    emit(props, "panelClosed", event);
  };
  const onBackdropClick = (event) => {
    emit(props, "click panelBackdropClick", event);
  };
  const onSwipe = (event) => {
    emit(props, "panelSwipe", event);
  };
  const onSwipeOpen = (event) => {
    emit(props, "panelSwipeOpen", event);
  };
  const onBreakpoint = (event) => {
    isBreakpoint.current = true;
    isCollapsed.current = false;
    emit(props, "panelBreakpoint", event);
  };
  const onCollapsedBreakpoint = (event) => {
    isBreakpoint.current = false;
    isCollapsed.current = true;
    emit(props, "panelCollapsedBreakpoint", event);
  };
  const onResize = function() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    emit(props, "panelResize", ...args);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7Panel: () => f7Panel.current
  }));
  watchProp(resizable, (newValue) => {
    if (!f7Panel.current) return;
    if (newValue) f7Panel.current.enableResizable();
    else f7Panel.current.disableResizable();
  });
  watchProp(opened, (newValue) => {
    if (!f7Panel.current) return;
    if (newValue) {
      f7Panel.current.open();
    } else {
      f7Panel.current.close();
    }
  });
  const modalEvents = (method) => {
    if (!f7Panel.current) return;
    f7Panel.current[method]("open", onOpen2);
    f7Panel.current[method]("opened", onOpened);
    f7Panel.current[method]("close", onClose2);
    f7Panel.current[method]("closed", onClosed);
    f7Panel.current[method]("backdropClick", onBackdropClick);
    f7Panel.current[method]("swipe", onSwipe);
    f7Panel.current[method]("swipeOpen", onSwipeOpen);
    f7Panel.current[method]("collapsedBreakpoint", onCollapsedBreakpoint);
    f7Panel.current[method]("breakpoint", onBreakpoint);
    f7Panel.current[method]("resize", onResize);
  };
  const onMount = () => {
    f7ready(() => {
      const $2 = f7.$;
      if (!$2) return;
      if ($2(".panel-backdrop").length === 0) {
        $2('<div class="panel-backdrop"></div>').insertBefore(elRef.current);
      }
      const params = noUndefinedProps({
        el: elRef.current,
        resizable,
        backdrop,
        backdropEl,
        containerEl,
        visibleBreakpoint,
        collapsedBreakpoint,
        swipe,
        swipeNoFollow,
        swipeOnlyClose,
        swipeActiveArea,
        swipeThreshold,
        closeByBackdropClick
      });
      f7Panel.current = f7.panel.create(params);
      modalEvents("on");
      if (opened) {
        f7Panel.current.open(false);
      }
    });
  };
  const onDestroy = () => {
    if (f7Panel.current && f7Panel.current.destroy) {
      f7Panel.current.destroy();
    }
    f7Panel.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    modalEvents("on");
    return () => {
      modalEvents("off");
    };
  });
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  const sideComputed = side || (left ? "left" : "right");
  const effectComputed = effect || (reveal ? "reveal" : push ? "push" : floating ? "floating" : "cover");
  const classes = classNames(className, "panel", {
    "panel-in": isOpened.current && !isClosing.current && !isBreakpoint.current,
    "panel-in-breakpoint": isBreakpoint.current,
    "panel-in-collapsed": isCollapsed.current,
    "panel-resizable": resizable,
    [`panel-${sideComputed}`]: sideComputed,
    [`panel-${effectComputed}`]: effectComputed
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1h({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2, resizable && /* @__PURE__ */ React.createElement("div", {
    className: "panel-resize-handler"
  }));
});
Panel.displayName = "f7-panel";
const routerOpenIn = (router, url, options) => {
  const navigateOptions = {
    url,
    route: {
      path: url,
      options: {
        ...options,
        openIn: void 0
      }
    }
  };
  const params = {
    ...options
  };
  if (options.openIn === "popup") {
    params.component = function DynamicPopup() {
      return /* @__PURE__ */ React.createElement(Popup, {
        className: "popup-router-open-in",
        "data-url": url
      }, /* @__PURE__ */ React.createElement(View2, {
        linksView: router.view.selector,
        url,
        ignoreOpenIn: true
      }));
    };
    navigateOptions.route.popup = params;
  }
  if (options.openIn === "loginScreen") {
    params.component = function DynamicPopover() {
      return /* @__PURE__ */ React.createElement(LoginScreen, {
        className: "login-screen-router-open-in",
        "data-url": url
      }, /* @__PURE__ */ React.createElement(View2, {
        linksView: router.view.selector,
        url,
        ignoreOpenIn: true
      }));
    };
    navigateOptions.route.loginScreen = params;
  }
  if (options.openIn === "sheet") {
    params.component = function DynamicSheet() {
      return /* @__PURE__ */ React.createElement(Sheet, {
        className: "sheet-modal-router-open-in",
        "data-url": url
      }, /* @__PURE__ */ React.createElement(View2, {
        linksView: router.view.selector,
        url,
        ignoreOpenIn: true
      }));
    };
    navigateOptions.route.sheet = params;
  }
  if (options.openIn === "popover") {
    params.targetEl = options.clickedEl || options.targetEl;
    params.component = function DynamicPopover() {
      return /* @__PURE__ */ React.createElement(Popover, {
        className: "popover-router-open-in",
        targetEl: options.clickedEl || options.targetEl,
        "data-url": url
      }, /* @__PURE__ */ React.createElement(View2, {
        linksView: router.view.selector,
        url,
        ignoreOpenIn: true
      }));
    };
    navigateOptions.route.popover = params;
  }
  if (options.openIn.indexOf("panel") >= 0) {
    const parts = options.openIn.split(":");
    const side = parts[1] || "left";
    const effect = parts[2] || "cover";
    params.component = function DynamicPanel() {
      return /* @__PURE__ */ React.createElement(Panel, {
        side,
        effect,
        className: "panel-router-open-in",
        "data-url": url
      }, /* @__PURE__ */ React.createElement(View2, {
        linksView: router.view.selector,
        url,
        ignoreOpenIn: true
      }));
    };
    navigateOptions.route.panel = params;
  }
  return router.navigate(navigateOptions);
};
const getChildrenArray = (el) => {
  const arr = [];
  for (let i = 0; i < el.children.length; i += 1) {
    arr.push(el.children[i]);
  }
  return arr;
};
const hasSameChildren = (childrenBefore, childrenAfter) => {
  if (childrenBefore.length !== childrenAfter.length) return false;
  const set = /* @__PURE__ */ new Set([...childrenBefore, ...childrenAfter]);
  if (set.size === childrenBefore.length) return true;
  return false;
};
const componentsRouter = {
  proto: {
    openIn(router, navigateUrl, options) {
      return routerOpenIn(router, navigateUrl, options);
    },
    pageComponentLoader(_ref) {
      let {
        routerEl,
        component,
        options,
        resolve,
        reject
      } = _ref;
      const router = this;
      const routerId = router.id;
      const el = routerEl;
      let viewRouter;
      f7routers.views.forEach((data2) => {
        if (data2.el && data2.el === routerEl || data2.routerId && data2.routerId === routerId) {
          viewRouter = data2;
        }
      });
      if (!viewRouter) {
        reject();
        return;
      }
      const pageData = {
        component,
        id: getComponentId(),
        props: extend({
          f7route: options.route,
          f7router: router
        }, options.route.params, options.props || {})
      };
      let resolved;
      const childrenBefore = getChildrenArray(el);
      function onDidUpdate(componentRouterData) {
        if (componentRouterData !== viewRouter || resolved) return;
        const childrenAfter = getChildrenArray(el);
        if (hasSameChildren(childrenBefore, childrenAfter)) return;
        f7events.off("viewRouterDidUpdate", onDidUpdate);
        const pageEl = el.children[el.children.length - 1];
        pageData.el = pageEl;
        resolve(pageEl);
        resolved = true;
      }
      f7events.on("viewRouterDidUpdate", onDidUpdate);
      viewRouter.pages.push(pageData);
      viewRouter.setPages(viewRouter.pages);
    },
    removePage($pageEl) {
      if (!$pageEl) return;
      const router = this;
      let f7Page;
      if ("length" in $pageEl && $pageEl[0]) f7Page = $pageEl[0].f7Page;
      else f7Page = $pageEl.f7Page;
      if (f7Page && f7Page.route && f7Page.route.route && f7Page.route.route.keepAlive) {
        router.app.$($pageEl).remove();
        return;
      }
      let viewRouter;
      f7routers.views.forEach((data2) => {
        if (data2.el && data2.el === router.el) {
          viewRouter = data2;
        }
      });
      let pageEl;
      if ("length" in $pageEl) {
        if ($pageEl.length === 0) return;
        pageEl = $pageEl[0];
      } else {
        pageEl = $pageEl;
      }
      if (!pageEl) return;
      let pageComponentFound;
      viewRouter.pages.forEach((page, index2) => {
        if (page.el === pageEl) {
          pageComponentFound = true;
          viewRouter.pages.splice(index2, 1);
          viewRouter.setPages(viewRouter.pages);
        }
      });
      if (!pageComponentFound) {
        pageEl.parentNode.removeChild(pageEl);
      }
    },
    tabComponentLoader(_temp) {
      let {
        tabEl,
        component,
        options,
        resolve,
        reject
      } = _temp === void 0 ? {} : _temp;
      const router = this;
      if (!tabEl) reject();
      let tabRouter;
      f7routers.tabs.forEach((tabData) => {
        if (tabData.el && tabData.el === tabEl) {
          tabRouter = tabData;
        }
      });
      if (!tabRouter) {
        reject();
        return;
      }
      const id2 = getComponentId();
      const tabContent = {
        id: id2,
        component,
        props: extend({
          f7route: options.route,
          f7router: router
        }, options.route.route && options.route.route.tab && options.route.route.tab.options && options.route.route.tab.options.props || {}, options.route.params, options.props || {})
      };
      let resolved;
      function onDidUpdate(componentRouterData) {
        if (componentRouterData !== tabRouter || resolved) return;
        f7events.off("tabRouterDidUpdate", onDidUpdate);
        const tabContentEl = tabEl.children[0];
        resolve(tabContentEl);
        resolved = true;
      }
      f7events.on("tabRouterDidUpdate", onDidUpdate);
      tabRouter.setTabContent(tabContent);
    },
    removeTabContent(tabEl) {
      if (!tabEl) return;
      let tabRouter;
      f7routers.tabs.forEach((tabData) => {
        if (tabData.el && tabData.el === tabEl) {
          tabRouter = tabData;
        }
      });
      if (!tabRouter) {
        tabEl.innerHTML = "";
        return;
      }
      tabRouter.setTabContent(null);
    },
    modalComponentLoader(_temp2) {
      let {
        component,
        options,
        resolve,
        reject
      } = _temp2 === void 0 ? {} : _temp2;
      const router = this;
      const modalsRouter = f7routers.modals;
      if (!modalsRouter) {
        reject();
        return;
      }
      const modalData = {
        component,
        id: getComponentId(),
        props: extend({
          f7route: options.route,
          f7router: router
        }, options.route.params, options.props || {})
      };
      let resolved;
      function onDidUpdate() {
        if (resolved) return;
        f7events.off("modalsRouterDidUpdate", onDidUpdate);
        const modalEl = modalsRouter.el.children[modalsRouter.el.children.length - 1];
        modalData.el = modalEl;
        resolve(modalEl);
        resolved = true;
      }
      f7events.on("modalsRouterDidUpdate", onDidUpdate);
      modalsRouter.modals.push(modalData);
      modalsRouter.setModals(modalsRouter.modals);
    },
    removeModal(modalEl) {
      const modalsRouter = f7routers.modals;
      if (!modalsRouter) return;
      let modalDataToRemove;
      modalsRouter.modals.forEach((modalData) => {
        if (modalData.el === modalEl) modalDataToRemove = modalData;
      });
      modalsRouter.modals.splice(modalsRouter.modals.indexOf(modalDataToRemove), 1);
      modalsRouter.setModals(modalsRouter.modals);
    }
  }
};
const Framework7React = {
  name: "reactPlugin",
  installed: false,
  install(params) {
    if (params === void 0) {
      params = {};
    }
    if (Framework7React.installed) return;
    Framework7React.installed = true;
    f7initEvents();
    const {
      theme: paramsTheme,
      userAgent
    } = params;
    if (paramsTheme === "md") theme.md = true;
    if (paramsTheme === "ios") theme.ios = true;
    const needThemeCalc = typeof window === "undefined" ? !!userAgent : true;
    if (needThemeCalc && (!paramsTheme || paramsTheme === "auto")) {
      const device = Framework7.getDevice({
        userAgent
      }, true);
      theme.ios = !!device.ios;
      theme.md = !theme.ios;
    }
    f7ready(() => {
      setTheme();
    });
    Framework7.Router.use(componentsRouter);
  }
};
const useStore = function() {
  const assignedGetters = reactExports.useRef({});
  let store = arguments.length <= 0 ? void 0 : arguments[0];
  let getter = arguments.length <= 1 ? void 0 : arguments[1];
  if (arguments.length === 1) {
    store = f7.store;
    getter = arguments.length <= 0 ? void 0 : arguments[0];
  }
  const obj = store._gettersPlain[getter];
  const [value2, setValue] = reactExports.useState(obj.value);
  function onUpdated(newValue) {
    setValue(newValue);
  }
  if (!assignedGetters.current[getter]) {
    obj.onUpdated(onUpdated);
    assignedGetters.current[getter] = true;
  }
  reactExports.useEffect(() => {
    return () => {
      store.__removeCallback(onUpdated);
    };
  }, []);
  return value2;
};
function _extends$1g() {
  _extends$1g = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1g.apply(this, arguments);
}
const AccordionContent = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const extraAttrs = getExtraAttrs(props);
  const classes = classNames(className, "accordion-item-content", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1g({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
AccordionContent.displayName = "f7-accordion-content";
function _extends$1f() {
  _extends$1f = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1f.apply(this, arguments);
}
const AccordionItem = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    opened
  } = props;
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const onBeforeOpen = (el, prevent) => {
    if (elRef.current !== el) return;
    emit(props, "accordionBeforeOpen", prevent);
  };
  const onOpen2 = (el) => {
    if (elRef.current !== el) return;
    emit(props, "accordionOpen");
  };
  const onOpened = (el) => {
    if (elRef.current !== el) return;
    emit(props, "accordionOpened");
  };
  const onBeforeClose = (el, prevent) => {
    if (elRef.current !== el) return;
    emit(props, "accordionBeforeClose", prevent);
  };
  const onClose2 = (el) => {
    if (elRef.current !== el) return;
    emit(props, "accordionClose");
  };
  const onClosed = (el) => {
    if (elRef.current !== el) return;
    emit(props, "accordionClosed");
  };
  const attachEvents = () => {
    f7ready(() => {
      f7.on("accordionBeforeOpen", onBeforeOpen);
      f7.on("accordionOpen", onOpen2);
      f7.on("accordionOpened", onOpened);
      f7.on("accordionBeforeClose", onBeforeClose);
      f7.on("accordionClose", onClose2);
      f7.on("accordionClosed", onClosed);
    });
  };
  const detachEvents = () => {
    f7.off("accordionBeforeOpen", onBeforeOpen);
    f7.off("accordionOpen", onOpen2);
    f7.off("accordionOpened", onOpened);
    f7.off("accordionBeforeClose", onBeforeClose);
    f7.off("accordionClose", onClose2);
    f7.off("accordionClosed", onClosed);
  };
  useIsomorphicLayoutEffect(() => {
    attachEvents();
    return detachEvents;
  });
  const extraAttrs = getExtraAttrs(props);
  const classes = classNames(className, "accordion-item", {
    "accordion-item-opened": opened
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1f({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
AccordionItem.displayName = "f7-accordion-item";
function _extends$1e() {
  _extends$1e = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1e.apply(this, arguments);
}
const AccordionToggle = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const extraAttrs = getExtraAttrs(props);
  const classes = classNames(className, "accordion-item-toggle", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1e({
    id: id2,
    style,
    className: classes
  }, extraAttrs, {
    ref: elRef
  }), children2);
});
AccordionToggle.displayName = "f7-accordion-toggle";
function _extends$1d() {
  _extends$1d = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1d.apply(this, arguments);
}
const Accordion = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    accordionOpposite,
    children: children2
  } = props;
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const extraAttrs = getExtraAttrs(props);
  const classes = classNames(className, "accordion-list", accordionOpposite && "accordion-opposite", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1d({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
Accordion.displayName = "f7-accordion";
function _extends$1c() {
  _extends$1c = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1c.apply(this, arguments);
}
const ComponentName = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    strong,
    close = true
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, {
    "actions-button": true,
    "actions-button-strong": strong
  }, colorClasses(props));
  let mediaEl;
  const slots = getSlots(props);
  if (slots.media && slots.media.length) {
    mediaEl = /* @__PURE__ */ React.createElement("div", {
      className: "actions-button-media"
    }, slots.media);
  }
  const onClick = (e) => {
    if (elRef.current && close && f7) {
      f7.actions.close(f7.$(elRef.current).parents(".actions-modal"));
    }
    emit(props, "click", e);
  };
  return /* @__PURE__ */ React.createElement("div", _extends$1c({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs, {
    onClick
  }), mediaEl, /* @__PURE__ */ React.createElement("div", {
    className: "actions-button-text"
  }, slots.default));
});
ComponentName.displayName = "f7-actions-button";
function _extends$1b() {
  _extends$1b = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1b.apply(this, arguments);
}
const ActionsGroup = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "actions-group", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1b({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
ActionsGroup.displayName = "f7-actions-group";
function _extends$1a() {
  _extends$1a = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1a.apply(this, arguments);
}
const ActionsLabel = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    strong
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "actions-label", {
    "actions-button-strong": strong
  }, colorClasses(props));
  const onClick = (e) => {
    emit(props, "click", e);
  };
  return /* @__PURE__ */ React.createElement("div", _extends$1a({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs, {
    onClick
  }), children2);
});
ActionsLabel.displayName = "f7-actions-label";
function _extends$19() {
  _extends$19 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$19.apply(this, arguments);
}
const Actions = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    grid,
    opened = false,
    animate: animate2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const isOpened = reactExports.useRef(opened);
  const isClosing = reactExports.useRef(false);
  const f7Actions = reactExports.useRef(null);
  const onOpen2 = (instance) => {
    isOpened.current = true;
    isClosing.current = false;
    emit(props, "actionsOpen", instance);
  };
  const onOpened = (instance) => {
    emit(props, "actionsOpened", instance);
  };
  const onClose2 = (instance) => {
    isOpened.current = false;
    isClosing.current = true;
    emit(props, "actionsClose", instance);
  };
  const onClosed = (instance) => {
    isClosing.current = false;
    emit(props, "actionsClosed", instance);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7Actions: () => f7Actions.current
  }));
  watchProp(opened, (value2) => {
    if (!f7Actions.current) return;
    if (value2) {
      f7Actions.current.open();
    } else {
      f7Actions.current.close();
    }
  });
  const modalEvents = (method) => {
    if (!f7Actions.current) return;
    f7Actions.current[method]("open", onOpen2);
    f7Actions.current[method]("opened", onOpened);
    f7Actions.current[method]("close", onClose2);
    f7Actions.current[method]("closed", onClosed);
  };
  const onMount = () => {
    if (!elRef.current) return;
    const {
      target,
      convertToPopover,
      forceToPopover,
      closeByBackdropClick,
      closeByOutsideClick,
      closeOnEscape,
      backdrop,
      backdropEl,
      containerEl
    } = props;
    const params = {
      el: elRef.current,
      grid
    };
    if (target) params.targetEl = target;
    if ("convertToPopover" in props) params.convertToPopover = convertToPopover;
    if ("forceToPopover" in props) params.forceToPopover = forceToPopover;
    if ("backdrop" in props) params.backdrop = backdrop;
    if ("backdropEl" in props) params.backdropEl = backdropEl;
    if ("closeByBackdropClick" in props) params.closeByBackdropClick = closeByBackdropClick;
    if ("closeByOutsideClick" in props) params.closeByOutsideClick = closeByOutsideClick;
    if ("closeOnEscape" in props) params.closeOnEscape = closeOnEscape;
    if ("animate" in props) params.animate = animate2;
    if ("containerEl" in props) params.containerEl = containerEl;
    f7ready(() => {
      f7Actions.current = f7.actions.create(params);
      modalEvents("on");
      if (opened) {
        f7Actions.current.open(false);
      }
    });
  };
  const onDestroy = () => {
    if (f7Actions.current) f7Actions.current.destroy();
    f7Actions.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    modalEvents("on");
    return () => {
      modalEvents("off");
    };
  });
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  const classes = classNames(className, "actions-modal", {
    "actions-grid": grid
  }, modalStateClasses({
    isOpened,
    isClosing
  }), colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$19({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
Actions.displayName = "f7-actions";
function _extends$18() {
  _extends$18 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$18.apply(this, arguments);
}
const RoutableModals = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const [modals, setModals] = reactExports.useState([]);
  const elRef = reactExports.useRef(null);
  const routerData = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const onMount = () => {
    routerData.current = {
      modals,
      el: elRef.current,
      setModals(newModals) {
        setModals([...newModals]);
      }
    };
    f7routers.modals = routerData.current;
  };
  const onDestroy = () => {
    if (!routerData.current) return;
    f7routers.modals = null;
    routerData.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  useIsomorphicLayoutEffect(() => {
    if (!routerData.current || !f7) return;
    f7events.emit("modalsRouterDidUpdate", routerData.current);
  });
  return /* @__PURE__ */ React.createElement("div", {
    ref: elRef,
    className: "framework7-modals"
  }, modals.map((_ref) => {
    let {
      component: ModalComponent,
      id: modalId,
      props: modalProps
    } = _ref;
    return /* @__PURE__ */ React.createElement(ModalComponent, _extends$18({
      key: modalId
    }, modalProps));
  }));
});
RoutableModals.displayName = "f7-routable-modals";
function _extends$17() {
  _extends$17 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$17.apply(this, arguments);
}
const App$1 = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    style,
    children: children2,
    ...rest
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const params = rest;
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "framework7-root", colorClasses(props));
  if (!f7 || typeof window === "undefined") {
    f7init(elRef.current, params, false);
  }
  useIsomorphicLayoutEffect(() => {
    const parentEl = elRef.current && elRef.current.parentNode;
    if (typeof document !== "undefined" && parentEl && parentEl !== document.body && parentEl.parentNode === document.body) {
      parentEl.style.height = "100%";
    }
    if (f7) {
      f7.init(elRef.current);
      return;
    }
    f7init(elRef.current, params, true);
  }, []);
  return /* @__PURE__ */ React.createElement("div", _extends$17({
    id: "framework7-root",
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2, /* @__PURE__ */ React.createElement(RoutableModals, null));
});
App$1.displayName = "f7-app";
function _extends$16() {
  _extends$16 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$16.apply(this, arguments);
}
const AreaChart = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    lineChart = false,
    datasets = [],
    axis = false,
    axisLabels = [],
    tooltip = false,
    legend = false,
    toggleDatasets = false,
    width: width2 = 640,
    height: height2 = 320,
    maxAxisLabels = 8,
    formatAxisLabel: formatAxisLabelProp,
    formatLegendLabel: formatLegendLabelProp,
    formatTooltip: formatTooltipProp,
    formatTooltipAxisLabel,
    formatTooltipTotal,
    formatTooltipDataset,
    children: children2
  } = props;
  const [currentIndex, setCurrentIndex] = reactExports.useState(null);
  const previousIndex = reactExports.useRef(null);
  const [hiddenDatasets, setHiddenDatasets] = reactExports.useState([]);
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const svgElRef = reactExports.useRef(null);
  const f7Tooltip = reactExports.useRef(null);
  const linesOffsets = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const getVisibleLegends = () => {
    if (!maxAxisLabels || axisLabels.length <= maxAxisLabels) return axisLabels;
    const skipStep = Math.ceil(axisLabels.length / maxAxisLabels);
    const filtered = axisLabels.filter((label, index2) => index2 % skipStep === 0);
    return filtered;
  };
  const getSummValues = () => {
    const summValues = [];
    datasets.filter((dataset2, index2) => !hiddenDatasets.includes(index2)).forEach((_ref) => {
      let {
        values
      } = _ref;
      values.forEach((value2, valueIndex) => {
        if (!summValues[valueIndex]) summValues[valueIndex] = 0;
        summValues[valueIndex] += value2;
      });
    });
    return summValues;
  };
  const getChartData = () => {
    const data2 = [];
    if (!datasets.length) {
      return data2;
    }
    const lastValues = datasets[0].values.map(() => 0);
    let maxValue = 0;
    if (lineChart) {
      datasets.forEach((_ref2) => {
        let {
          values
        } = _ref2;
        const datasetMaxValue = Math.max(...values);
        if (datasetMaxValue > maxValue) maxValue = datasetMaxValue;
      });
    } else {
      maxValue = Math.max(...getSummValues());
    }
    datasets.filter((dataset2, index2) => !hiddenDatasets.includes(index2)).forEach((_ref3) => {
      let {
        label,
        values,
        color
      } = _ref3;
      const points = values.map((originalValue, valueIndex) => {
        lastValues[valueIndex] += originalValue;
        const value2 = lineChart ? originalValue : lastValues[valueIndex];
        const x = valueIndex / (values.length - 1) * width2;
        const y = height2 - value2 / maxValue * height2;
        if (lineChart) {
          return `${valueIndex === 0 ? "M" : "L"}${x},${y}`;
        }
        return `${x} ${y}`;
      });
      if (!lineChart) {
        points.push(`${width2} ${height2} 0 ${height2}`);
      }
      data2.push({
        label,
        points: points.join(" "),
        color
      });
    });
    return data2.reverse();
  };
  const getVerticalLines = () => {
    const lines = [];
    if (!datasets.length) {
      return lines;
    }
    const values = datasets[0].values;
    values.forEach((value2, valueIndex) => {
      const x = valueIndex / (values.length - 1) * width2;
      lines.push(x);
    });
    return lines;
  };
  const toggleDataset = (index2) => {
    if (!toggleDatasets) return;
    if (hiddenDatasets.includes(index2)) {
      hiddenDatasets.splice(hiddenDatasets.indexOf(index2), 1);
    } else {
      hiddenDatasets.push(index2);
    }
    setHiddenDatasets([...hiddenDatasets]);
  };
  const formatAxisLabel = (label) => {
    if (formatAxisLabelProp) return formatAxisLabelProp(label);
    return label;
  };
  const formatLegendLabel = (label) => {
    if (formatLegendLabelProp) return formatLegendLabelProp(label);
    return label;
  };
  const calcLinesOffsets = () => {
    const lines = svgElRef.current.querySelectorAll("line");
    linesOffsets.current = [];
    for (let i = 0; i < lines.length; i += 1) {
      linesOffsets.current.push(lines[i].getBoundingClientRect().left);
    }
  };
  const formatTooltip = () => {
    if (currentIndex === null) return "";
    let total = 0;
    const currentValues = datasets.filter((dataset2, index2) => !hiddenDatasets.includes(index2)).map((dataset2) => ({
      color: dataset2.color,
      label: dataset2.label,
      value: dataset2.values[currentIndex]
    }));
    currentValues.forEach((dataset2) => {
      total += dataset2.value;
    });
    if (formatTooltipProp) {
      return formatTooltipProp({
        index: currentIndex,
        total,
        datasets: currentValues
      });
    }
    let labelText = formatTooltipAxisLabel ? formatTooltipAxisLabel(axisLabels[currentIndex]) : formatAxisLabel(axisLabels[currentIndex]);
    if (!labelText) labelText = "";
    const totalText = formatTooltipTotal ? formatTooltipTotal(total) : total;
    const datasetsText = currentValues.length > 0 ? `
      <ul class="area-chart-tooltip-list">
        ${currentValues.map((_ref4) => {
      let {
        label,
        color,
        value: value2
      } = _ref4;
      const valueText = formatTooltipDataset ? formatTooltipDataset(label, value2, color) : `${label}: ${value2}`;
      return `
              <li><span style="background-color: ${color};"></span>${valueText}</li>
            `;
    }).join("")}
      </ul>` : "";
    return `
      <div class="area-chart-tooltip-label">${labelText}</div>
      <div class="area-chart-tooltip-total">${totalText}</div>
      ${datasetsText}
    `;
  };
  const setTooltip = () => {
    if (!tooltip) return;
    const hasVisibleDataSets = datasets.filter((dataset2, index2) => !hiddenDatasets.includes(index2)).length > 0;
    if (!hasVisibleDataSets) {
      if (f7Tooltip.current && f7Tooltip.current.hide) f7Tooltip.current.hide();
      return;
    }
    if (currentIndex !== null && !f7Tooltip.current) {
      f7Tooltip.current = f7.tooltip.create({
        trigger: "manual",
        containerEl: elRef.current,
        targetEl: svgElRef.current.querySelector(`line[data-index="${currentIndex}"]`),
        text: formatTooltip(),
        cssClass: "area-chart-tooltip"
      });
      if (f7Tooltip.current && f7Tooltip.current.show) {
        f7Tooltip.current.show();
      }
      return;
    }
    if (!f7Tooltip.current || !f7Tooltip.current.hide || !f7Tooltip.current.show) {
      return;
    }
    if (currentIndex !== null) {
      f7Tooltip.current.setText(formatTooltip());
      f7Tooltip.current.setTargetEl(svgElRef.current.querySelector(`line[data-index="${currentIndex}"]`));
      f7Tooltip.current.show();
    } else {
      f7Tooltip.current.hide();
    }
  };
  const onMouseEnter = () => {
    calcLinesOffsets();
  };
  const onMouseMove = (e) => {
    if (!linesOffsets.current) {
      calcLinesOffsets();
    }
    let currentLeft = e.pageX;
    if (typeof currentLeft === "undefined") currentLeft = 0;
    const distances = linesOffsets.current.map((left) => Math.abs(currentLeft - left));
    const minDistance = Math.min(...distances);
    const closestIndex = distances.indexOf(minDistance);
    setCurrentIndex(closestIndex);
  };
  const onMouseLeave = () => {
    setCurrentIndex(null);
  };
  const attachEvents = () => {
    if (!svgElRef.current) return;
    svgElRef.current.addEventListener("mouseenter", onMouseEnter);
    svgElRef.current.addEventListener("mousemove", onMouseMove);
    svgElRef.current.addEventListener("mouseleave", onMouseLeave);
  };
  const detachEvents = () => {
    if (!svgElRef.current) return;
    svgElRef.current.removeEventListener("mouseenter", onMouseEnter);
    svgElRef.current.removeEventListener("mousemove", onMouseMove);
    svgElRef.current.removeEventListener("mouseleave", onMouseLeave);
  };
  reactExports.useEffect(() => {
    if (previousIndex.current === currentIndex) return;
    previousIndex.current = currentIndex;
    emit(props, "select", currentIndex);
    setTooltip();
  }, [currentIndex]);
  reactExports.useEffect(() => {
    attachEvents();
    return detachEvents;
  });
  reactExports.useEffect(() => {
    return () => {
      if (f7Tooltip.current && f7Tooltip.current.destroy) {
        f7Tooltip.current.destroy();
      }
      f7Tooltip.current = null;
    };
  }, []);
  const classes = classNames("area-chart", className);
  const chartData = getChartData();
  const verticalLines = getVerticalLines();
  const visibleLegends = getVisibleLegends();
  const LegendItemTag = toggleDatasets ? "button" : "span";
  const ChartTag = lineChart ? "path" : "polygon";
  return /* @__PURE__ */ React.createElement("div", _extends$16({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), /* @__PURE__ */ React.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width2,
    height: height2,
    viewBox: `0 0 ${width2} ${height2}`,
    preserveAspectRatio: "none",
    ref: svgElRef
  }, chartData.map((data2, index2) => /* @__PURE__ */ React.createElement(ChartTag, {
    key: `${ChartTag}-${index2}`,
    fill: lineChart ? void 0 : data2.color,
    stroke: lineChart ? data2.color : void 0,
    fillRule: "evenodd",
    points: lineChart ? void 0 : data2.points,
    d: lineChart ? data2.points : void 0
  })), verticalLines.map((line, index2) => /* @__PURE__ */ React.createElement("line", {
    key: `line-${index2}`,
    "data-index": index2,
    fill: "#000",
    x1: line,
    y1: 0,
    x2: line,
    y2: height2,
    className: classNames({
      "area-chart-current-line": currentIndex === index2
    })
  }))), axis && /* @__PURE__ */ React.createElement("div", {
    className: "area-chart-axis"
  }, axisLabels.map((label, index2) => /* @__PURE__ */ React.createElement("span", {
    key: index2
  }, visibleLegends.includes(label) && /* @__PURE__ */ React.createElement("span", null, formatAxisLabel(label))))), legend && /* @__PURE__ */ React.createElement("div", {
    className: "area-chart-legend"
  }, datasets.map((dataset2, index2) => /* @__PURE__ */ React.createElement(LegendItemTag, {
    key: index2,
    className: classNames("area-chart-legend-item", {
      "area-chart-legend-item-hidden": hiddenDatasets.includes(index2),
      "area-chart-legend-button": toggleDatasets
    }),
    type: toggleDatasets ? "button" : void 0,
    onClick: () => toggleDataset(index2)
  }, /* @__PURE__ */ React.createElement("span", {
    style: {
      backgroundColor: dataset2.color
    }
  }), formatLegendLabel(dataset2.label)))), children2);
});
AreaChart.displayName = "f7-area-chart";
const useTooltip = (elRef, props) => {
  const f7Tooltip = reactExports.useRef(null);
  const {
    tooltip,
    tooltipTrigger
  } = props;
  const onMount = () => {
    if (!elRef.current) return;
    if (!tooltip) return;
    f7ready(() => {
      f7Tooltip.current = f7.tooltip.create({
        targetEl: elRef.current,
        text: tooltip,
        trigger: tooltipTrigger
      });
    });
  };
  const onDestroy = () => {
    if (f7Tooltip.current && f7Tooltip.current.destroy) {
      f7Tooltip.current.destroy();
      f7Tooltip.current = null;
    }
  };
  reactExports.useEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  watchProp(tooltip, (value2) => {
    if (!value2 && f7Tooltip.current) {
      f7Tooltip.current.destroy();
      f7Tooltip.current = null;
      return;
    }
    if (value2 && !f7Tooltip.current && f7) {
      f7Tooltip.current = f7.tooltip.create({
        targetEl: elRef.current,
        text: value2,
        trigger: tooltipTrigger
      });
      return;
    }
    if (!value2 || !f7Tooltip.current) return;
    f7Tooltip.current.setText(value2);
  });
};
function _extends$15() {
  _extends$15 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$15.apply(this, arguments);
}
const Badge = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  useTooltip(elRef, props);
  const classes = classNames(className, "badge", colorClasses(props));
  return /* @__PURE__ */ React.createElement("span", _extends$15({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
Badge.displayName = "f7-badge";
function _extends$14() {
  _extends$14 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$14.apply(this, arguments);
}
const BlockFooter = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "block-footer", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$14({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
BlockFooter.displayName = "f7-block-footer";
function _extends$13() {
  _extends$13 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$13.apply(this, arguments);
}
const BlockHeader = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "block-header", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$13({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
BlockHeader.displayName = "f7-block-header";
function _extends$12() {
  _extends$12 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$12.apply(this, arguments);
}
const BlockTitle = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    large,
    medium
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "block-title", {
    "block-title-large": large,
    "block-title-medium": medium
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$12({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
BlockTitle.displayName = "f7-block-title";
function _extends$11() {
  _extends$11 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$11.apply(this, arguments);
}
const Block = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    inset,
    insetIos,
    insetMd,
    xsmallInset,
    xsmallInsetIos,
    xsmallInsetMd,
    smallInset,
    smallInsetIos,
    smallInsetMd,
    mediumInset,
    mediumInsetIos,
    mediumInsetMd,
    largeInset,
    largeInsetIos,
    largeInsetMd,
    xlargeInset,
    xlargeInsetIos,
    xlargeInsetMd,
    strong,
    strongIos,
    strongMd,
    outline,
    outlineIos,
    outlineMd,
    accordionList,
    accordionOpposite,
    tabs,
    tab,
    tabActive,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  useTab(elRef, props);
  const classes = classNames(className, "block", {
    inset,
    "inset-ios": insetIos,
    "inset-md": insetMd,
    "xsmall-inset": xsmallInset,
    "xsmall-inset-ios": xsmallInsetIos,
    "xsmall-inset-md": xsmallInsetMd,
    "small-inset": smallInset,
    "small-inset-ios": smallInsetIos,
    "small-inset-md": smallInsetMd,
    "medium-inset": mediumInset,
    "medium-inset-ios": mediumInsetIos,
    "medium-inset-md": mediumInsetMd,
    "large-inset": largeInset,
    "large-inset-ios": largeInsetIos,
    "large-inset-md": largeInsetMd,
    "xlarge-inset": xlargeInset,
    "xlarge-inset-ios": xlargeInsetIos,
    "xlarge-inset-md": xlargeInsetMd,
    "block-strong": strong,
    "block-strong-ios": strongIos,
    "block-strong-md": strongMd,
    "block-outline": outline,
    "block-outline-ios": outlineIos,
    "block-outline-md": outlineMd,
    "accordion-list": accordionList,
    "accordion-opposite": accordionOpposite,
    tabs,
    tab,
    "tab-active": tabActive
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$11({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
Block.displayName = "f7-block";
function _extends$10() {
  _extends$10 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$10.apply(this, arguments);
}
const BreadcrumbsCollapsed = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const onClick = (e) => {
    emit(props, "click", e);
  };
  return /* @__PURE__ */ React.createElement("div", _extends$10({
    className: classNames("breadcrumbs-collapsed", className),
    ref: elRef,
    id: id2,
    style,
    onClick
  }, extraAttrs), /* @__PURE__ */ React.createElement("span", null), children2);
});
BreadcrumbsCollapsed.displayName = "f7-breadcrumbs-collapsed";
function _extends$$() {
  _extends$$ = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$$.apply(this, arguments);
}
const BreadcrumbsItem = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    active,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const onClick = (e) => {
    emit(props, "click", e);
  };
  return /* @__PURE__ */ React.createElement("div", _extends$$({
    className: classNames("breadcrumbs-item", className, active && "breadcrumbs-item-active"),
    ref: elRef,
    id: id2,
    style,
    onClick
  }, extraAttrs), children2);
});
BreadcrumbsItem.displayName = "f7-breadcrumbs-item";
function _extends$_() {
  _extends$_ = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$_.apply(this, arguments);
}
const BreadcrumbsSeparator = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  return /* @__PURE__ */ React.createElement("div", _extends$_({
    className: classNames("breadcrumbs-separator", className),
    ref: elRef,
    id: id2,
    style
  }, extraAttrs));
});
BreadcrumbsSeparator.displayName = "f7-breadcrumbs-separator";
function _extends$Z() {
  _extends$Z = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$Z.apply(this, arguments);
}
const Breadcrumbs = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  return /* @__PURE__ */ React.createElement("div", _extends$Z({
    className: classNames("breadcrumbs", className),
    ref: elRef,
    id: id2,
    style
  }, extraAttrs), children2);
});
Breadcrumbs.displayName = "f7-breadcrumbs";
const useTheme = () => {
  const [t, setTheme2] = reactExports.useState(f7 ? theme : null);
  if (!f7) {
    f7ready(() => {
      setTheme2(theme);
    });
  }
  return t;
};
function _extends$Y() {
  _extends$Y = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$Y.apply(this, arguments);
}
const Icon = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const theme2 = useTheme();
  const {
    className,
    id: id2,
    style,
    children: children2,
    material,
    f7: f72,
    icon,
    md,
    ios,
    size
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  useTooltip(elRef, props);
  const getClasses = () => {
    let classes = {
      icon: true
    };
    let themeIcon;
    if (theme2 && theme2.ios) themeIcon = ios;
    else if (theme2 && theme2.md) themeIcon = md;
    if (themeIcon) {
      const parts = themeIcon.split(":");
      const prop2 = parts[0];
      const value2 = parts[1];
      if (prop2 === "material" || prop2 === "f7") {
        classes["material-icons"] = prop2 === "material";
        classes["f7-icons"] = prop2 === "f7";
      }
      if (prop2 === "icon") {
        classes[value2] = true;
      }
      if (icon) classes[icon] = true;
    } else {
      classes = {
        icon: true,
        "material-icons": material,
        "f7-icons": f72
      };
      if (icon) classes[icon] = true;
    }
    return classNames(className, classes, colorClasses(props));
  };
  const getIconText = () => {
    let text2 = material || f72;
    if (md && theme2 && theme2.md && (md.indexOf("material:") >= 0 || md.indexOf("f7:") >= 0)) {
      text2 = md.split(":")[1];
    } else if (ios && theme2 && theme2.ios && (ios.indexOf("material:") >= 0 || ios.indexOf("f7:") >= 0)) {
      text2 = ios.split(":")[1];
    }
    return text2;
  };
  let sizeComputed = size;
  if (typeof size === "number" || parseFloat(size) === size * 1) {
    sizeComputed = `${size}px`;
  }
  return /* @__PURE__ */ React.createElement("i", _extends$Y({
    id: id2,
    style: extend({
      fontSize: sizeComputed,
      width: sizeComputed,
      height: sizeComputed
    }, style),
    className: getClasses(),
    ref: elRef
  }, extraAttrs), getIconText(), children2);
});
Icon.displayName = "f7-icon";
const useIcon = function(props) {
  if (props === void 0) {
    props = {};
  }
  const {
    icon,
    iconMaterial,
    iconF7,
    iconMd,
    iconIos,
    iconColor,
    iconSize,
    iconBadge,
    badgeColor,
    iconBadgeColor
  } = props;
  if (icon || iconMaterial || iconF7 || iconMd || iconIos) {
    return /* @__PURE__ */ React.createElement(Icon, {
      material: iconMaterial,
      f7: iconF7,
      icon,
      md: iconMd,
      ios: iconIos,
      color: iconColor,
      size: iconSize
    }, (iconBadge || iconBadge === 0) && /* @__PURE__ */ React.createElement(Badge, {
      color: badgeColor || iconBadgeColor
    }, iconBadge));
  }
  return null;
};
const useRouteProps = function(elRef, _temp) {
  let {
    routeProps
  } = _temp === void 0 ? {} : _temp;
  reactExports.useEffect(() => {
    if (elRef.current) {
      elRef.current.f7RouteProps = routeProps;
    }
    return () => {
      if (elRef.current && elRef.current.f7RouteProps) {
        delete elRef.current.f7RouteProps;
      }
    };
  }, [routeProps]);
};
function _extends$X() {
  _extends$X = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$X.apply(this, arguments);
}
const Preloader = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const theme2 = useTheme();
  const {
    className,
    id: id2,
    style,
    size
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const preloaderStyle = {};
  let sizeComputed = size;
  if (sizeComputed && typeof sizeComputed === "string" && sizeComputed.indexOf("px") >= 0) {
    sizeComputed = sizeComputed.replace("px", "");
  }
  if (sizeComputed) {
    preloaderStyle.width = `${sizeComputed}px`;
    preloaderStyle.height = `${sizeComputed}px`;
    preloaderStyle["--f7-preloader-size"] = `${sizeComputed}px`;
  }
  if (style) extend(preloaderStyle, style || {});
  let innerEl;
  if (theme2 && theme2.md) {
    innerEl = /* @__PURE__ */ React.createElement("span", {
      className: "preloader-inner"
    }, /* @__PURE__ */ React.createElement("svg", {
      viewBox: "0 0 36 36"
    }, /* @__PURE__ */ React.createElement("circle", {
      cx: "18",
      cy: "18",
      r: "16"
    })));
  } else if (theme2 && theme2.ios) {
    innerEl = /* @__PURE__ */ React.createElement("span", {
      className: "preloader-inner"
    }, /* @__PURE__ */ React.createElement("span", {
      className: "preloader-inner-line"
    }), /* @__PURE__ */ React.createElement("span", {
      className: "preloader-inner-line"
    }), /* @__PURE__ */ React.createElement("span", {
      className: "preloader-inner-line"
    }), /* @__PURE__ */ React.createElement("span", {
      className: "preloader-inner-line"
    }), /* @__PURE__ */ React.createElement("span", {
      className: "preloader-inner-line"
    }), /* @__PURE__ */ React.createElement("span", {
      className: "preloader-inner-line"
    }), /* @__PURE__ */ React.createElement("span", {
      className: "preloader-inner-line"
    }), /* @__PURE__ */ React.createElement("span", {
      className: "preloader-inner-line"
    }));
  } else if (!theme2) {
    innerEl = /* @__PURE__ */ React.createElement("span", {
      className: "preloader-inner"
    });
  }
  const classes = classNames(className, {
    preloader: true
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("span", _extends$X({
    id: id2,
    style: preloaderStyle,
    className: classes,
    ref: elRef
  }, extraAttrs), innerEl);
});
Preloader.displayName = "f7-preloader";
function _extends$W() {
  _extends$W = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$W.apply(this, arguments);
}
const Button = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    text: text2,
    type,
    href = "#",
    target,
    tabLink,
    tabLinkActive,
    round,
    roundIos,
    roundMd,
    fill,
    fillIos,
    fillMd,
    tonal,
    tonalIos,
    tonalMd,
    large,
    largeIos,
    largeMd,
    small,
    smallIos,
    smallMd,
    raised,
    raisedIos,
    raisedMd,
    active,
    outline,
    outlineIos,
    outlineMd,
    disabled,
    preloader,
    preloaderSize,
    preloaderColor,
    loading
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onClick = (e) => {
    emit(props, "click", e);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  useTooltip(elRef, props);
  useRouteProps(elRef, props);
  const getClasses = () => {
    return classNames(className, "button", {
      "tab-link": tabLink || tabLink === "",
      "tab-link-active": tabLinkActive,
      "button-round": round,
      "button-round-ios": roundIos,
      "button-round-md": roundMd,
      "button-fill": fill,
      "button-fill-ios": fillIos,
      "button-fill-md": fillMd,
      "button-tonal": tonal,
      "button-tonal-ios": tonalIos,
      "button-tonal-md": tonalMd,
      "button-large": large,
      "button-large-ios": largeIos,
      "button-large-md": largeMd,
      "button-small": small,
      "button-small-ios": smallIos,
      "button-small-md": smallMd,
      "button-raised": raised,
      "button-raised-ios": raisedIos,
      "button-raised-md": raisedMd,
      "button-active": active,
      "button-outline": outline,
      "button-outline-ios": outlineIos,
      "button-outline-md": outlineMd,
      "button-preloader": preloader,
      "button-loading": loading,
      disabled
    }, colorClasses(props), routerClasses(props), actionsClasses(props));
  };
  const ButtonTag = type === "submit" || type === "reset" || type === "button" ? "button" : "a";
  const getAttrs = () => {
    let hrefComputed = href;
    if (href === true) hrefComputed = "#";
    if (href === false || ButtonTag === "button") hrefComputed = void 0;
    return extend({
      href: hrefComputed,
      target,
      type,
      "data-tab": isStringProp(tabLink) && tabLink || void 0
    }, routerAttrs(props), actionsAttrs(props));
  };
  const iconEl = useIcon(props);
  let textEl;
  if (text2) {
    textEl = /* @__PURE__ */ React.createElement("span", null, text2);
  }
  if (preloader) {
    return /* @__PURE__ */ React.createElement(ButtonTag, _extends$W({
      ref: elRef,
      id: id2,
      style,
      className: getClasses()
    }, getAttrs(), extraAttrs, {
      onClick
    }), /* @__PURE__ */ React.createElement(Preloader, {
      size: preloaderSize,
      color: preloaderColor
    }), /* @__PURE__ */ React.createElement("span", null, iconEl, textEl, children2));
  }
  return /* @__PURE__ */ React.createElement(ButtonTag, _extends$W({
    ref: elRef,
    id: id2,
    style,
    className: getClasses()
  }, getAttrs(), extraAttrs, {
    onClick
  }), iconEl, textEl, children2);
});
Button.displayName = "f7-button";
function _extends$V() {
  _extends$V = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$V.apply(this, arguments);
}
const CardContent = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    padding = true
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "card-content", {
    "card-content-padding": padding
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$V({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
CardContent.displayName = "f7-card-content";
function _extends$U() {
  _extends$U = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$U.apply(this, arguments);
}
const CardFooter = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "card-footer", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$U({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
CardFooter.displayName = "f7-card-footer";
function _extends$T() {
  _extends$T = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$T.apply(this, arguments);
}
const CardHeader = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "card-header", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$T({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
CardHeader.displayName = "f7-card-header";
function _extends$S() {
  _extends$S = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$S.apply(this, arguments);
}
const Card = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    title: title2,
    content,
    footer,
    padding,
    raised,
    outline,
    outlineIos,
    outlineMd,
    headerDivider,
    footerDivider,
    expandable,
    expandableAnimateWidth,
    expandableOpened,
    animate: animate2,
    hideNavbarOnOpen,
    hideToolbarOnOpen,
    hideStatusbarOnOpen,
    scrollableEl,
    swipeToClose,
    closeByBackdropClick,
    backdrop,
    backdropEl
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const open = () => {
    if (!elRef.current) return;
    f7.card.open(elRef.current);
  };
  const close = () => {
    if (!elRef.current) return;
    f7.card.close(elRef.current);
  };
  const onBeforeOpen = (el, prevent) => {
    if (elRef.current !== el) return;
    emit(props, "cardBeforeOpen", el, prevent);
  };
  const onOpen2 = (el) => {
    if (elRef.current !== el) return;
    emit(props, "cardOpen", el);
  };
  const onOpened = (el, pageEl) => {
    if (elRef.current !== el) return;
    emit(props, "cardOpened", el, pageEl);
  };
  const onClose2 = (el) => {
    if (elRef.current !== el) return;
    emit(props, "cardClose", el);
  };
  const onClosed = (el, pageEl) => {
    if (elRef.current !== el) return;
    emit(props, "cardClosed", el, pageEl);
  };
  const attachEvents = () => {
    if (!expandable || !elRef.current) return;
    f7ready(() => {
      f7.on("cardBeforeOpen", onBeforeOpen);
      f7.on("cardOpen", onOpen2);
      f7.on("cardOpened", onOpened);
      f7.on("cardClose", onClose2);
      f7.on("cardClosed", onClosed);
    });
  };
  const detachEvents = () => {
    f7.off("cardBeforeOpen", onBeforeOpen);
    f7.off("cardOpen", onOpen2);
    f7.off("cardOpened", onOpened);
    f7.off("cardClose", onClose2);
    f7.off("cardClosed", onClosed);
  };
  const onMount = () => {
    if (!expandable || !elRef.current) return;
    f7ready(() => {
      if (expandable && expandableOpened) {
        f7.card.open(elRef.current, false);
      }
    });
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
  }, []);
  useIsomorphicLayoutEffect(() => {
    attachEvents();
    return detachEvents;
  });
  watchProp(expandableOpened, (value2) => {
    if (value2) {
      open();
    } else {
      close();
    }
  });
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    open,
    close
  }));
  let headerEl;
  let contentEl;
  let footerEl;
  const classes = classNames(className, "card", {
    "card-raised": raised,
    "card-header-divider": headerDivider,
    "card-footer-divider": footerDivider,
    "card-outline": outline,
    "card-outline-ios": outlineIos,
    "card-outline-md": outlineMd,
    "card-expandable": expandable,
    "card-expandable-animate-width": expandableAnimateWidth
  }, colorClasses(props));
  const slots = getSlots(props);
  if (title2 || slots.header) {
    headerEl = /* @__PURE__ */ React.createElement(CardHeader, null, title2, slots.header);
  }
  if (content || slots.content) {
    contentEl = /* @__PURE__ */ React.createElement(CardContent, {
      padding
    }, content, slots.content);
  }
  if (footer || slots.footer) {
    footerEl = /* @__PURE__ */ React.createElement(CardFooter, null, footer, slots.footer);
  }
  return /* @__PURE__ */ React.createElement("div", _extends$S({
    id: id2,
    style,
    className: classes,
    "data-animate": typeof animate2 === "undefined" ? animate2 : animate2.toString(),
    "data-hide-navbar-on-open": typeof hideNavbarOnOpen === "undefined" ? hideNavbarOnOpen : hideNavbarOnOpen.toString(),
    "data-hide-toolbar-on-open": typeof hideToolbarOnOpen === "undefined" ? hideToolbarOnOpen : hideToolbarOnOpen.toString(),
    "data-hide-statusbar-on-open": typeof hideStatusbarOnOpen === "undefined" ? hideStatusbarOnOpen : hideStatusbarOnOpen.toString(),
    "data-scrollable-el": scrollableEl,
    "data-swipe-to-close": typeof swipeToClose === "undefined" ? swipeToClose : swipeToClose.toString(),
    "data-close-by-backdrop-click": typeof closeByBackdropClick === "undefined" ? closeByBackdropClick : closeByBackdropClick.toString(),
    "data-backdrop": typeof backdrop === "undefined" ? backdrop : backdrop.toString(),
    "data-backdrop-el": backdropEl,
    ref: elRef
  }, extraAttrs), headerEl, contentEl, footerEl, slots.default);
});
Card.displayName = "f7-card";
function _extends$R() {
  _extends$R = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$R.apply(this, arguments);
}
const Checkbox = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    name: name2,
    value: value2,
    disabled,
    readonly,
    checked,
    defaultChecked,
    indeterminate
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const inputElRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    inputEl: inputElRef.current
  }));
  const onChange = (event) => {
    emit(props, "change", event);
  };
  reactExports.useEffect(() => {
    if (inputElRef.current) {
      inputElRef.current.indeterminate = !!indeterminate;
    }
  }, [indeterminate]);
  const inputEl = /* @__PURE__ */ React.createElement("input", {
    ref: inputElRef,
    type: "checkbox",
    name: name2,
    value: value2,
    disabled,
    readOnly: readonly,
    checked,
    defaultChecked,
    onChange
  });
  const iconEl = /* @__PURE__ */ React.createElement("i", {
    className: "icon-checkbox"
  });
  const classes = classNames(className, {
    checkbox: true,
    disabled
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("label", _extends$R({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), inputEl, iconEl, children2);
});
Checkbox.displayName = "f7-checkbox";
function _extends$Q() {
  _extends$Q = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$Q.apply(this, arguments);
}
const Chip = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    media,
    text: text2,
    deleteable,
    mediaTextColor,
    mediaBgColor,
    outline
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const onClick = (event) => {
    emit(props, "click", event);
  };
  const onDeleteClick = (event) => {
    emit(props, "delete", event);
  };
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  useTooltip(elRef, props);
  const slots = getSlots(props);
  const iconEl = useIcon(props);
  let mediaEl;
  let labelEl;
  let deleteEl;
  if (media || iconEl || slots && slots.media) {
    const mediaClasses = classNames("chip-media", mediaTextColor && `text-color-${mediaTextColor}`, mediaBgColor && `bg-color-${mediaBgColor}`);
    mediaEl = /* @__PURE__ */ React.createElement("div", {
      className: mediaClasses
    }, iconEl, media, slots.media);
  }
  if (text2 || slots && (slots.text || slots.default && slots.default.length)) {
    labelEl = /* @__PURE__ */ React.createElement("div", {
      className: "chip-label"
    }, text2, slots.text, slots.default);
  }
  if (deleteable) {
    deleteEl = /* @__PURE__ */ React.createElement("a", {
      className: "chip-delete",
      onClick: onDeleteClick
    });
  }
  const classes = classNames(className, "chip", {
    "chip-outline": outline
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$Q({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs, {
    onClick
  }), mediaEl, labelEl, deleteEl);
});
Chip.displayName = "f7-chip";
function _extends$P() {
  _extends$P = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$P.apply(this, arguments);
}
const FabBackdrop = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "fab-backdrop");
  return /* @__PURE__ */ React.createElement("div", _extends$P({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
FabBackdrop.displayName = "f7-fab-backdrop";
function _extends$O() {
  _extends$O = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$O.apply(this, arguments);
}
const FabButton = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    fabClose,
    label,
    target
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onClick = (e) => {
    emit(props, "click", e);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  useTooltip(elRef, props);
  const classes = classNames(className, {
    "fab-close": fabClose,
    "fab-label-button": label
  }, colorClasses(props));
  let labelEl;
  if (label) {
    labelEl = /* @__PURE__ */ React.createElement("span", {
      className: "fab-label"
    }, label);
  }
  return /* @__PURE__ */ React.createElement("a", _extends$O({
    id: id2,
    style,
    target,
    className: classes,
    ref: elRef
  }, extraAttrs, {
    onClick
  }), children2, labelEl);
});
FabButton.displayName = "f7-fab-button";
function _extends$N() {
  _extends$N = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$N.apply(this, arguments);
}
const FabButtons = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    position
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "fab-buttons", `fab-buttons-${position}`, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$N({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
FabButtons.displayName = "f7-fab-buttons";
function _extends$M() {
  _extends$M = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$M.apply(this, arguments);
}
const Fab = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    morphTo,
    href,
    target,
    text: text2,
    position = "right-bottom"
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onClick = (e) => {
    emit(props, "click", e);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  useTooltip(elRef, props);
  let hrefComputed = href;
  if (hrefComputed === true) hrefComputed = "#";
  if (hrefComputed === false) hrefComputed = void 0;
  const linkChildren = [];
  const rootChildren = [];
  const {
    link: linkSlots,
    default: defaultSlots,
    root: rootSlots,
    text: textSlots
  } = getSlots(props);
  if (defaultSlots) {
    for (let i = 0; i < defaultSlots.length; i += 1) {
      const child = defaultSlots[i];
      let isRoot;
      const tag = child.type && (child.type.displayName || child.type.name);
      if (tag === "FabButtons" || tag === "f7-fab-buttons") isRoot = true;
      if (isRoot) rootChildren.push(child);
      else linkChildren.push(child);
    }
  }
  let textEl;
  if (text2 || textSlots && textSlots.length) {
    textEl = /* @__PURE__ */ React.createElement("div", {
      className: "fab-text"
    }, text2, textSlots);
  }
  let linkEl;
  if (linkChildren.length || linkSlots && linkSlots.length || textEl) {
    linkEl = /* @__PURE__ */ React.createElement("a", {
      target,
      href: hrefComputed,
      onClick
    }, linkChildren, textEl, linkSlots);
  }
  const classes = classNames(className, "fab", `fab-${position}`, {
    "fab-morph": morphTo,
    "fab-extended": typeof textEl !== "undefined"
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$M({
    id: id2,
    style,
    className: classes,
    "data-morph-to": morphTo,
    ref: elRef
  }, extraAttrs), linkEl, rootChildren, rootSlots);
});
Fab.displayName = "f7-fab";
function _extends$L() {
  _extends$L = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$L.apply(this, arguments);
}
const Gauge = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    type = "circle",
    value: value2 = 0,
    size = 200,
    bgColor = "transparent",
    borderBgColor = "#eeeeee",
    borderColor = "#000000",
    borderWidth = 10,
    valueText,
    valueTextColor = "#000000",
    valueFontSize = 31,
    valueFontWeight = 500,
    labelText,
    labelTextColor = "#888888",
    labelFontSize = 14,
    labelFontWeight = 400
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "gauge");
  const semiCircle = type === "semicircle";
  const radius = size / 2 - borderWidth / 2;
  const length = 2 * Math.PI * radius;
  const progress = Math.max(Math.min(value2, 1), 0);
  return /* @__PURE__ */ React.createElement("div", _extends$L({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), /* @__PURE__ */ React.createElement("svg", {
    className: "gauge-svg",
    width: `${size}px`,
    height: `${semiCircle ? size / 2 : size}px`,
    viewBox: `0 0 ${size} ${semiCircle ? size / 2 : size}`
  }, semiCircle && /* @__PURE__ */ React.createElement("path", {
    className: "gauge-back-semi",
    d: `M${size - borderWidth / 2},${size / 2} a1,1 0 0,0 -${size - borderWidth},0`,
    stroke: borderBgColor,
    strokeWidth: borderWidth,
    fill: bgColor || "none"
  }), semiCircle && /* @__PURE__ */ React.createElement("path", {
    className: "gauge-front-semi",
    d: `M${size - borderWidth / 2},${size / 2} a1,1 0 0,0 -${size - borderWidth},0`,
    stroke: borderColor,
    strokeWidth: borderWidth,
    strokeDasharray: length / 2,
    strokeDashoffset: length / 2 * (1 + progress),
    fill: borderBgColor ? "none" : bgColor || "none"
  }), !semiCircle && borderBgColor && /* @__PURE__ */ React.createElement("circle", {
    className: "gauge-back-circle",
    stroke: borderBgColor,
    strokeWidth: borderWidth,
    fill: bgColor || "none",
    cx: size / 2,
    cy: size / 2,
    r: radius
  }), !semiCircle && /* @__PURE__ */ React.createElement("circle", {
    className: "gauge-front-circle",
    transform: `rotate(-90 ${size / 2} ${size / 2})`,
    stroke: borderColor,
    strokeWidth: borderWidth,
    strokeDasharray: length,
    strokeDashoffset: length * (1 - progress),
    fill: borderBgColor ? "none" : bgColor || "none",
    cx: size / 2,
    cy: size / 2,
    r: radius
  }), valueText && /* @__PURE__ */ React.createElement("text", {
    className: "gauge-value-text",
    x: "50%",
    y: semiCircle ? "100%" : "50%",
    fontWeight: valueFontWeight,
    fontSize: valueFontSize,
    fill: valueTextColor,
    dy: semiCircle ? labelText ? -labelFontSize - 15 : -5 : 0,
    textAnchor: "middle",
    dominantBaseline: !semiCircle ? "middle" : null
  }, valueText), labelText && /* @__PURE__ */ React.createElement("text", {
    className: "gauge-label-text",
    x: "50%",
    y: semiCircle ? "100%" : "50%",
    fontWeight: labelFontWeight,
    fontSize: labelFontSize,
    fill: labelTextColor,
    dy: semiCircle ? -5 : valueText ? valueFontSize / 2 + 10 : 0,
    textAnchor: "middle",
    dominantBaseline: !semiCircle ? "middle" : null
  }, labelText)));
});
Gauge.displayName = "f7-gauge";
function _extends$K() {
  _extends$K = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$K.apply(this, arguments);
}
const Toggle = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7Toggle = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    init = true,
    checked,
    defaultChecked,
    disabled,
    readonly,
    name: name2,
    value: value2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const inputElRef = reactExports.useRef(null);
  const onChange = (event) => {
    emit(props, "change", event);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7Toggle: () => f7Toggle.current
  }));
  useTooltip(elRef, props);
  watchProp(checked, (newValue) => {
    if (!f7Toggle.current) return;
    f7Toggle.current.checked = newValue;
  });
  const onToggleChange = (toggleInstance) => {
    emit(props, "toggleChange", toggleInstance.checked);
  };
  const toggleEvents = (method) => {
    if (!f7Toggle.current) return;
    f7Toggle.current[method]("toggleChange", onToggleChange);
  };
  const onMount = () => {
    f7ready(() => {
      if (!init || !elRef.current) return;
      f7Toggle.current = f7.toggle.create({
        el: elRef.current
      });
      toggleEvents("on");
    });
  };
  const onDestroy = () => {
    if (f7Toggle.current && f7Toggle.current.destroy && f7Toggle.current.$el) {
      f7Toggle.current.destroy();
    }
    f7Toggle.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    toggleEvents("on");
    if (inputElRef.current) {
      inputElRef.current.addEventListener("change", onChange);
    }
    return () => {
      toggleEvents("off");
      if (inputElRef.current) {
        inputElRef.current.removeEventListener("change", onChange);
      }
    };
  });
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  const labelClasses = classNames("toggle", className, {
    disabled
  }, colorClasses(props));
  const inputEl = /* @__PURE__ */ React.createElement("input", {
    ref: inputElRef,
    type: "checkbox",
    name: name2,
    disabled,
    readOnly: readonly,
    checked,
    defaultChecked,
    value: value2,
    onChange: () => {
    }
  });
  return /* @__PURE__ */ React.createElement("label", _extends$K({
    id: id2,
    style,
    className: labelClasses,
    ref: elRef
  }, extraAttrs), inputEl, /* @__PURE__ */ React.createElement("span", {
    className: "toggle-icon"
  }));
});
Toggle.displayName = "f7-toggle";
function _extends$J() {
  _extends$J = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$J.apply(this, arguments);
}
const Range = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7Range = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    children: children2,
    init = true,
    value: value2 = 0,
    min = 0,
    max = 100,
    step = 1,
    label = false,
    dual = false,
    vertical = false,
    verticalReversed = false,
    draggableBar = true,
    formatLabel,
    scale = false,
    scaleSteps = 5,
    scaleSubSteps = 0,
    formatScaleLabel,
    limitKnobPosition = void 0,
    name: name2,
    input,
    inputId,
    disabled
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7Range: () => f7Range.current
  }));
  watchProp(value2, (newValue) => {
    if (!f7Range.current) return;
    const rangeValue = f7Range.current.value;
    if (Array.isArray(newValue) && Array.isArray(rangeValue)) {
      if (rangeValue[0] !== newValue[0] || rangeValue[1] !== newValue[1]) {
        f7Range.current.setValue(newValue);
      }
    } else {
      f7Range.current.setValue(newValue);
    }
  });
  const onChange = (range, val2) => {
    emit(props, "rangeChange", val2);
  };
  const onChanged = (range, val2) => {
    emit(props, "rangeChanged", val2);
  };
  const rangeEvents = (method) => {
    if (!f7Range.current) return;
    f7Range.current[method]("change", onChange);
    f7Range.current[method]("changed", onChanged);
  };
  const onMount = () => {
    f7ready(() => {
      if (!init || !elRef.current) return;
      f7Range.current = f7.range.create(noUndefinedProps({
        el: elRef.current,
        value: value2,
        min,
        max,
        step,
        label,
        dual,
        draggableBar,
        vertical,
        verticalReversed,
        formatLabel,
        scale,
        scaleSteps,
        scaleSubSteps,
        formatScaleLabel,
        limitKnobPosition
      }));
      rangeEvents("on");
    });
  };
  const onDestroy = () => {
    if (f7Range.current && f7Range.current.destroy) f7Range.current.destroy();
    f7Range.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    rangeEvents("on");
    return () => {
      rangeEvents("off");
    };
  });
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  const classes = classNames(className, "range-slider", {
    "range-slider-horizontal": !vertical,
    "range-slider-vertical": vertical,
    "range-slider-vertical-reversed": vertical && verticalReversed,
    disabled
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$J({
    ref: elRef,
    id: id2,
    style,
    className: classes
  }, extraAttrs), input && /* @__PURE__ */ React.createElement("input", {
    type: "range",
    name: name2,
    id: inputId
  }), children2);
});
Range.displayName = "f7-range";
function _extends$I() {
  _extends$I = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$I.apply(this, arguments);
}
const TextEditor = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7TextEditor = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    mode,
    value: value2,
    buttons,
    customButtons,
    dividers,
    imageUrlText,
    linkUrlText,
    placeholder,
    clearFormattingOnPaste,
    resizable = false
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onChange = (editor, editorValue) => {
    emit(props, "textEditorChange", editorValue);
  };
  const onInput = (editor, editorValue) => {
    emit(props, "textEditorInput", editorValue);
  };
  const onFocus = () => {
    emit(props, "textEditorFocus");
  };
  const onBlur = () => {
    emit(props, "textEditorBlur");
  };
  const onButtonClick = (editor, button) => {
    emit(props, "textEditorButtonClick", button);
  };
  const onKeyboardOpen = () => {
    emit(props, "textEditorKeyboardOpen");
  };
  const onKeyboardClose = () => {
    emit(props, "textEditorKeyboardClose");
  };
  const onPopoverOpen = () => {
    emit(props, "textEditorPopoverOpen");
  };
  const onPopoverClose = () => {
    emit(props, "textEditorPopoverClose");
  };
  const onInsertLink = (editor, url) => {
    emit(props, "textEditorInsertLink", url);
  };
  const onInsertImage = (editor, url) => {
    emit(props, "textEditorInsertImage", url);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7TextEditor: () => f7TextEditor.current
  }));
  watchProp(value2, (newValue) => {
    if (f7TextEditor.current) {
      f7TextEditor.current.setValue(newValue);
    }
  });
  const onMount = () => {
    const params = noUndefinedProps({
      el: elRef.current,
      mode,
      value: value2,
      buttons,
      customButtons,
      dividers,
      imageUrlText,
      linkUrlText,
      placeholder,
      clearFormattingOnPaste,
      on: {
        change: onChange,
        input: onInput,
        focus: onFocus,
        blur: onBlur,
        buttonClick: onButtonClick,
        keyboardOpen: onKeyboardOpen,
        keyboardClose: onKeyboardClose,
        popoverOpen: onPopoverOpen,
        popoverClose: onPopoverClose,
        insertLink: onInsertLink,
        insertImage: onInsertImage
      }
    });
    f7ready(() => {
      f7TextEditor.current = f7.textEditor.create(params);
    });
  };
  const onDestroy = () => {
    if (f7TextEditor.current && f7TextEditor.current.destroy) {
      f7TextEditor.current.destroy();
    }
    f7TextEditor.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  const slots = getSlots(props);
  const classes = classNames(className, "text-editor", resizable && "text-editor-resizable", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$I({
    ref: elRef,
    id: id2,
    style,
    className: classes
  }, extraAttrs), slots["root-start"], /* @__PURE__ */ React.createElement("div", {
    className: "text-editor-content",
    contentEditable: true
  }, slots.default), slots["root-end"], slots.root);
});
TextEditor.displayName = "f7-text-editor";
function _extends$H() {
  _extends$H = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$H.apply(this, arguments);
}
const Input = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    type,
    name: name2,
    value: value2,
    defaultValue,
    inputmode,
    placeholder,
    inputId,
    size,
    accept,
    autocomplete,
    autocorrect,
    autocapitalize,
    spellcheck,
    autofocus,
    autosave,
    checked,
    disabled,
    max,
    min,
    step,
    maxlength,
    minlength,
    multiple,
    readonly,
    required,
    inputStyle,
    pattern,
    validate,
    validateOnBlur,
    onValidate,
    tabindex,
    resizable,
    clearButton,
    // Form
    noFormStoreData,
    noStoreData,
    ignoreStoreData,
    // Error, Info
    errorMessage,
    errorMessageForce,
    info,
    // Outline
    outline,
    // Components
    wrap = true,
    dropdown = "auto",
    // Datepicker
    calendarParams,
    // Colorpicker
    colorPickerParams,
    // Text editor
    textEditorParams
  } = props;
  const [inputInvalid, setInputInvalid] = reactExports.useState(false);
  const [inputFocused, setInputFocused] = reactExports.useState(false);
  const extraAttrs = getExtraAttrs(props);
  const f7Calendar = reactExports.useRef(null);
  const f7ColorPicker = reactExports.useRef(null);
  const elRef = reactExports.useRef(null);
  const inputElRef = reactExports.useRef(null);
  const updateInputOnDidUpdate = reactExports.useRef(false);
  const getDomValue = () => {
    if (!inputElRef.current) return void 0;
    return inputElRef.current.value;
  };
  const isInputHasValue = () => {
    if (type === "datepicker" && Array.isArray(value2) && value2.length === 0) {
      return false;
    }
    const domValue2 = getDomValue();
    return typeof value2 === "undefined" ? domValue2 || domValue2 === 0 : value2 || value2 === 0;
  };
  const validateInput = () => {
    if (!f7 || !inputElRef.current) return;
    const validity = inputElRef.current.validity;
    if (!validity) return;
    if (!validity.valid) {
      if (onValidate) onValidate(false);
      if (inputInvalid !== true) {
        setInputInvalid(true);
      }
    } else {
      if (onValidate) onValidate(true);
      if (inputInvalid !== false) {
        setInputInvalid(false);
      }
    }
  };
  const onTextareaResize = (event) => {
    emit(props, "textareaResize", event);
  };
  const onInputNotEmpty = (event) => {
    emit(props, "inputNotEmpty", event);
  };
  const onInputEmpty = (event) => {
    emit(props, "inputEmpty", event);
  };
  const onInputClear = (event) => {
    emit(props, "inputClear", event);
  };
  const onInput = function() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    emit(props, "input", ...args);
    if (!(validateOnBlur || validateOnBlur === "") && (validate || validate === "") && inputElRef.current) {
      validateInput();
    }
  };
  const onFocus = function() {
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    emit(props, "focus", ...args);
    setInputFocused(true);
  };
  const onBlur = function() {
    for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }
    emit(props, "blur", ...args);
    if ((validate || validate === "" || validateOnBlur || validateOnBlur === "") && inputElRef.current) {
      validateInput();
    }
    setInputFocused(false);
  };
  const onChange = function() {
    for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
      args[_key4] = arguments[_key4];
    }
    emit(props, "change", ...args);
    if (type === "texteditor") {
      emit(props, "textEditorChange", args[1]);
    }
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const onMount = () => {
    f7ready(() => {
      if (type === "range" || type === "toggle") return;
      if (!inputElRef.current) return;
      inputElRef.current.addEventListener("input:notempty", onInputNotEmpty, false);
      if (type === "textarea" && resizable) {
        inputElRef.current.addEventListener("textarea:resize", onTextareaResize, false);
      }
      if (clearButton) {
        inputElRef.current.addEventListener("input:empty", onInputEmpty, false);
        inputElRef.current.addEventListener("input:clear", onInputClear, false);
      }
      if (type === "datepicker") {
        f7Calendar.current = f7.calendar.create({
          inputEl: inputElRef.current,
          value: value2,
          on: {
            change(calendar, calendarValue) {
              emit(props, "calendarChange", calendarValue);
            }
          },
          ...calendarParams || {}
        });
      }
      if (type === "colorpicker") {
        f7ColorPicker.current = f7.colorPicker.create({
          inputEl: inputElRef.current,
          value: value2,
          on: {
            change(colorPicker, colorPickerValue) {
              emit(props, "colorPickerChange", colorPickerValue);
            }
          },
          ...colorPickerParams || {}
        });
      }
      f7.input.checkEmptyState(inputElRef.current);
      if (!(validateOnBlur || validateOnBlur === "") && (validate || validate === "") && (typeof value2 !== "undefined" && value2 !== null && value2 !== "" || typeof defaultValue !== "undefined" && defaultValue !== null && defaultValue !== "")) {
        setTimeout(() => {
          validateInput();
        }, 0);
      }
      if (resizable) {
        f7.input.resizeTextarea(inputElRef.current);
      }
    });
  };
  const onDestroy = () => {
    if (type === "range" || type === "toggle") return;
    if (!inputElRef.current) return;
    inputElRef.current.removeEventListener("input:notempty", onInputNotEmpty, false);
    if (type === "textarea" && resizable) {
      inputElRef.current.removeEventListener("textarea:resize", onTextareaResize, false);
    }
    if (clearButton) {
      inputElRef.current.removeEventListener("input:empty", onInputEmpty, false);
      inputElRef.current.removeEventListener("input:clear", onInputClear, false);
    }
    if (f7Calendar.current && f7Calendar.current.destroy) {
      f7Calendar.current.destroy();
      f7Calendar.current = null;
    }
    if (f7ColorPicker.current && f7ColorPicker.current.destroy) {
      f7ColorPicker.current.destroy();
      f7ColorPicker.current = null;
    }
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  useIsomorphicLayoutEffect(() => {
    if (!f7) return;
    if (updateInputOnDidUpdate.current) {
      if (!inputElRef.current) return;
      updateInputOnDidUpdate.current = false;
      f7.input.checkEmptyState(inputElRef.current);
      if (validate && !validateOnBlur) {
        validateInput();
      }
      if (resizable) {
        f7.input.resizeTextarea(inputElRef.current);
      }
    }
  });
  watchProp(colorPickerParams, (newValue) => {
    if (!f7 || !f7ColorPicker.current) return;
    extend(f7ColorPicker.current.params, newValue || {});
  });
  watchProp(calendarParams, (newValue) => {
    if (!f7 || !f7Calendar.current) return;
    extend(f7Calendar.current.params, newValue || {});
  });
  watchProp(value2, (newValue) => {
    if (type === "range" || type === "toggle") return;
    if (!f7) return;
    updateInputOnDidUpdate.current = true;
    if (f7Calendar.current) {
      f7Calendar.current.setValue(newValue);
    }
    if (f7ColorPicker.current) {
      f7ColorPicker.current.setValue(newValue);
    }
  });
  const domValue = getDomValue();
  const inputHasValue = isInputHasValue();
  const slots = getSlots(props);
  let inputEl;
  const createInput = (InputTag, children2) => {
    const needsValue = type !== "file" && type !== "datepicker" && type !== "colorpicker";
    const needsType = InputTag === "input";
    let inputType = type;
    if (inputType === "datepicker" || inputType === "colorpicker") {
      inputType = "text";
    }
    const inputClassName = classNames(!wrap && className, {
      resizable: inputType === "textarea" && resizable,
      "no-store-data": noFormStoreData || noStoreData || ignoreStoreData,
      "input-invalid": errorMessage && errorMessageForce || inputInvalid,
      "input-with-value": inputHasValue,
      "input-focused": inputFocused
    });
    let inputValue;
    if (needsValue) {
      if (typeof value2 !== "undefined") inputValue = value2;
      else inputValue = domValue;
    }
    const valueProps = {};
    if (type !== "datepicker" && type !== "colorpicker") {
      if ("value" in props) valueProps.value = inputValue;
      if ("defaultValue" in props) valueProps.defaultValue = defaultValue;
    }
    return /* @__PURE__ */ React.createElement(InputTag, _extends$H({
      ref: inputElRef,
      style: inputStyle,
      name: name2,
      type: needsType ? inputType : void 0,
      placeholder,
      inputMode: inputmode,
      id: inputId,
      size,
      accept,
      autoComplete: autocomplete,
      autoCorrect: autocorrect,
      autoCapitalize: autocapitalize,
      spellCheck: spellcheck,
      autoFocus: autofocus,
      autoSave: autosave,
      checked,
      disabled,
      max,
      maxLength: maxlength,
      min,
      minLength: minlength,
      step,
      multiple,
      readOnly: readonly,
      required,
      pattern,
      validate: typeof validate === "string" && validate.length ? validate : void 0,
      "data-validate": validate === true || validate === "" || validateOnBlur === true || validateOnBlur === "" ? true : void 0,
      "data-validate-on-blur": validateOnBlur === true || validateOnBlur === "" ? true : void 0,
      tabIndex: tabindex,
      "data-error-message": errorMessageForce ? void 0 : errorMessage,
      className: inputClassName,
      onFocus,
      onBlur,
      onInput,
      onChange
    }, valueProps), children2);
  };
  if (type === "select" || type === "textarea" || type === "file") {
    if (type === "select") {
      inputEl = createInput("select", slots.default);
    } else if (type === "file") {
      inputEl = createInput("input");
    } else {
      inputEl = createInput("textarea");
    }
  } else if (slots.default && slots.default.length > 0 || !type) {
    inputEl = slots.default;
  } else if (type === "toggle") {
    inputEl = /* @__PURE__ */ React.createElement(Toggle, {
      checked,
      readonly,
      name: name2,
      value: value2,
      disabled,
      id: inputId,
      onChange
    });
  } else if (type === "range") {
    inputEl = /* @__PURE__ */ React.createElement(Range, {
      value: value2,
      disabled,
      min,
      max,
      step,
      name: name2,
      id: inputId,
      input: true,
      onRangeChange: onChange
    });
  } else if (type === "texteditor") {
    inputEl = /* @__PURE__ */ React.createElement(TextEditor, _extends$H({
      value: value2,
      resizable,
      placeholder,
      onTextEditorFocus: onFocus,
      onTextEditorBlur: onBlur,
      onTextEditorInput: onInput,
      onTextEditorChange: onChange
    }, textEditorParams));
  } else {
    inputEl = createInput("input");
  }
  if (wrap) {
    const wrapClasses = classNames(className, "input", {
      "input-outline": outline,
      "input-dropdown": dropdown === "auto" ? type === "select" : dropdown,
      "input-invalid": errorMessage && errorMessageForce || inputInvalid
    }, colorClasses(props));
    return /* @__PURE__ */ React.createElement("div", _extends$H({
      id: id2,
      className: wrapClasses,
      style,
      ref: elRef
    }, extraAttrs), inputEl, (errorMessage || slots["error-message"] && slots["error-message"].length) && errorMessageForce && /* @__PURE__ */ React.createElement("div", {
      className: "input-error-message"
    }, errorMessage, slots["error-message"]), clearButton && /* @__PURE__ */ React.createElement("span", {
      className: "input-clear-button"
    }), (info || slots.info && slots.info.length) && /* @__PURE__ */ React.createElement("div", {
      className: "input-info"
    }, info, slots.info));
  }
  return inputEl;
});
Input.displayName = "f7-input";
const TabbarContext = /* @__PURE__ */ React.createContext({
  tabbarHasIcons: false
});
const useSmartSelect = (smartSelect, smartSelectParams, f7SmartSelect, getEl) => {
  const onMount = () => {
    f7ready(() => {
      if (smartSelect) {
        const ssParams = extend({
          el: getEl()
        }, smartSelectParams || {});
        f7SmartSelect.current = f7.smartSelect.create(ssParams);
      }
    });
  };
  const onDestroy = () => {
    if (f7SmartSelect.current && f7SmartSelect.current.destroy) {
      f7SmartSelect.current.destroy();
    }
    f7SmartSelect.current = null;
  };
  reactExports.useEffect(() => {
    onMount();
    return onDestroy;
  }, []);
};
function _extends$G() {
  _extends$G = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$G.apply(this, arguments);
}
const Link = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7SmartSelect = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    children: children2,
    noLinkClass,
    text: text2,
    tabLink,
    tabLinkActive,
    tabbarLabel,
    iconOnly,
    badge,
    badgeColor,
    href = "#",
    target,
    // Smart Select
    smartSelect,
    smartSelectParams
  } = props;
  const tabbarContext = reactExports.useContext(TabbarContext);
  const isTabbarIcons = tabbarLabel || tabbarContext.tabbarHasIcons;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onClick = (e) => {
    emit(props, "click", e);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7SmartSelect: () => f7SmartSelect.current
  }));
  useTooltip(elRef, props);
  useRouteProps(elRef, props);
  useSmartSelect(smartSelect, smartSelectParams, f7SmartSelect, () => {
    return elRef.current;
  });
  let textEl;
  let badgeEl;
  if (text2) {
    if (badge) badgeEl = /* @__PURE__ */ React.createElement(Badge, {
      color: badgeColor
    }, badge);
    textEl = /* @__PURE__ */ React.createElement("span", {
      className: isTabbarIcons ? "tabbar-label" : ""
    }, text2, badgeEl);
  }
  const iconEl = useIcon(props);
  let iconOnlyComputed;
  if (iconOnly || !text2 && children2 && children2.length === 0 || !text2 && !children2) {
    iconOnlyComputed = true;
  } else {
    iconOnlyComputed = false;
  }
  const classes = classNames(className, {
    link: !(noLinkClass || isTabbarIcons),
    "icon-only": iconOnlyComputed,
    "tab-link": tabLink || tabLink === "",
    "tab-link-active": tabLinkActive,
    "smart-select": smartSelect
  }, colorClasses(props), routerClasses(props), actionsClasses(props));
  let hrefComputed = href;
  if (href === true) hrefComputed = "#";
  if (href === false) hrefComputed = void 0;
  const attrs = {
    href: hrefComputed,
    target,
    "data-tab": isStringProp(tabLink) && tabLink || void 0,
    ...routerAttrs(props),
    ...actionsAttrs(props)
  };
  return /* @__PURE__ */ React.createElement("a", _extends$G({
    ref: elRef,
    id: id2,
    style,
    className: classes
  }, attrs, extraAttrs, {
    onClick
  }), iconEl, textEl, children2);
});
Link.displayName = "f7-link";
function _extends$F() {
  _extends$F = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$F.apply(this, arguments);
}
const ListButton = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    title: title2,
    text: text2,
    tabLink,
    tabLinkActive,
    link,
    href,
    target
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const linkElRef = reactExports.useRef(null);
  const onClick = (e) => {
    emit(props, "click", e);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  useTooltip(linkElRef, props);
  useRouteProps(linkElRef, props);
  const linkAttrs = {
    href: typeof link === "boolean" && typeof href === "boolean" ? "#" : link || href,
    target,
    "data-tab": isStringProp(tabLink) && tabLink,
    ...routerAttrs(props),
    ...actionsAttrs(props)
  };
  const linkClasses = classNames({
    "list-button": true,
    "tab-link": tabLink || tabLink === "",
    "tab-link-active": tabLinkActive,
    ...colorClasses(props),
    ...routerClasses(props),
    ...actionsClasses(props)
  });
  return /* @__PURE__ */ React.createElement("li", _extends$F({
    id: id2,
    style,
    className,
    ref: elRef
  }, extraAttrs), /* @__PURE__ */ React.createElement("a", _extends$F({
    className: linkClasses
  }, linkAttrs, {
    onClick,
    ref: linkElRef
  }), title2, text2, children2));
});
ListButton.displayName = "f7-list-button";
const ListContext = /* @__PURE__ */ React.createContext({
  listIsMedia: false,
  listIsSimple: false,
  listIsSortable: false,
  listIsSortableOpposite: false
});
function _extends$E() {
  _extends$E = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$E.apply(this, arguments);
}
const ListGroup = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    simpleList,
    mediaList,
    sortable,
    sortableOpposite,
    sortableTapHold,
    sortableMoveElements
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const listContext = reactExports.useContext(ListContext);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "list-group", {
    "media-list": mediaList,
    sortable,
    "sortable-tap-hold": sortableTapHold,
    "sortable-opposite": sortableOpposite
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$E({
    id: id2,
    style,
    className: classes,
    "data-sortable-move-elements": typeof sortableMoveElements !== "undefined" ? sortableMoveElements.toString() : void 0,
    ref: elRef
  }, extraAttrs), /* @__PURE__ */ React.createElement("ul", null, /* @__PURE__ */ React.createElement(ListContext.Provider, {
    value: {
      listIsMedia: mediaList || listContext.listIsMedia,
      listIsSimple: simpleList || listContext.listIsSimple,
      listIsSortable: sortable || listContext.listIsSortable,
      listIsSortableOpposite: sortableOpposite || listContext.listIsSortableOpposite
    }
  }, children2)));
});
ListGroup.displayName = "f7-list-group";
function _extends$D() {
  _extends$D = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$D.apply(this, arguments);
}
const ListIndex = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7ListIndex = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    children: children2,
    init = true,
    listEl,
    indexes = "auto",
    scrollList = true,
    label = false,
    iosItemHeight = 14,
    mdItemHeight = 14
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const update = () => {
    if (!f7ListIndex.current) return;
    f7ListIndex.current.update();
  };
  const scrollListToIndex = (indexContent) => {
    if (!f7ListIndex.current) return;
    f7ListIndex.current.scrollListToIndex(indexContent);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7ListIndex: () => f7ListIndex.current,
    update,
    scrollListToIndex
  }));
  watchProp(indexes, (newValue) => {
    if (!f7ListIndex.current) return;
    f7ListIndex.current.params.indexes = newValue;
    update();
  });
  const onMount = () => {
    if (!init) return;
    f7ready(() => {
      f7ListIndex.current = f7.listIndex.create({
        el: elRef.current,
        listEl,
        indexes,
        iosItemHeight,
        mdItemHeight,
        scrollList,
        label,
        on: {
          select(index2, itemContent, itemIndex) {
            emit(props, "listIndexSelect", itemContent, itemIndex);
          }
        }
      });
    });
  };
  const onDestroy = () => {
    if (f7ListIndex.current && f7ListIndex.current.destroy) {
      f7ListIndex.current.destroy();
    }
    f7ListIndex.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  const classes = classNames(className, "list-index", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$D({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
ListIndex.displayName = "f7-list-index";
function _extends$C() {
  _extends$C = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$C.apply(this, arguments);
}
const ListInput = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    sortable,
    media,
    dropdown = "auto",
    wrap = true,
    // Inputs
    input: renderInput = true,
    type = "text",
    name: name2,
    value: value2,
    defaultValue,
    inputmode,
    readonly,
    required,
    disabled,
    placeholder,
    inputId,
    size,
    accept,
    autocomplete,
    autocorrect,
    autocapitalize,
    spellcheck,
    autofocus,
    autosave,
    max,
    min,
    step,
    maxlength,
    minlength,
    multiple,
    inputStyle,
    pattern,
    validate,
    validateOnBlur,
    onValidate,
    tabindex,
    resizable,
    clearButton,
    // Form
    noFormStoreData,
    noStoreData,
    ignoreStoreData,
    // Error, Info
    errorMessage,
    errorMessageForce,
    info,
    // Outline
    outline,
    // Label
    label,
    floatingLabel,
    // Datepicker
    calendarParams,
    // Colorpicker
    colorPickerParams,
    // Text editor
    textEditorParams
  } = props;
  const [inputInvalid, setInputInvalid] = reactExports.useState(false);
  const [inputFocused, setInputFocused] = reactExports.useState(false);
  const listContext = reactExports.useContext(ListContext);
  const {
    listIsSortable = false
  } = listContext || {};
  const extraAttrs = getExtraAttrs(props);
  const f7Calendar = reactExports.useRef(null);
  const f7ColorPicker = reactExports.useRef(null);
  const elRef = reactExports.useRef(null);
  const inputElRef = reactExports.useRef(null);
  const itemContentElRef = reactExports.useRef(null);
  const updateInputOnDidUpdate = reactExports.useRef(false);
  const getDomValue = () => {
    if (!inputElRef.current) return void 0;
    return inputElRef.current.value;
  };
  const isInputHasValue = () => {
    if (type === "datepicker" && Array.isArray(value2) && value2.length === 0) {
      return false;
    }
    const domValue2 = getDomValue();
    return typeof value2 === "undefined" ? domValue2 || domValue2 === 0 : value2 || value2 === 0;
  };
  const validateInput = () => {
    if (!f7 || !inputElRef.current) return;
    const validity = inputElRef.current.validity;
    if (!validity) return;
    if (!validity.valid) {
      if (onValidate) onValidate(false);
      if (inputInvalid !== true) {
        setInputInvalid(true);
      }
    } else {
      if (onValidate) onValidate(true);
      if (inputInvalid !== false) {
        setInputInvalid(false);
      }
    }
  };
  const onTextareaResize = (event) => {
    emit(props, "textareaResize", event);
  };
  const onInputNotEmpty = (event) => {
    emit(props, "inputNotEmpty", event);
  };
  const onInputEmpty = (event) => {
    emit(props, "inputEmpty", event);
  };
  const onInputClear = (event) => {
    emit(props, "inputClear", event);
  };
  const onInput = function() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    emit(props, "input", ...args);
    if (!(validateOnBlur || validateOnBlur === "") && (validate || validate === "") && inputElRef.current) {
      validateInput();
    }
  };
  const onFocus = function() {
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    emit(props, "focus", ...args);
    setInputFocused(true);
  };
  const onBlur = function() {
    for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }
    emit(props, "blur", ...args);
    if ((validate || validate === "" || validateOnBlur || validateOnBlur === "") && inputElRef.current) {
      validateInput();
    }
    setInputFocused(false);
  };
  const onChange = function() {
    for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
      args[_key4] = arguments[_key4];
    }
    emit(props, "change", ...args);
    if (type === "texteditor") {
      emit(props, "textEditorChange", args[0]);
    }
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const onMount = () => {
    if (!elRef.current && !itemContentElRef.current) return;
    f7ready(() => {
      if (!inputElRef.current) return;
      inputElRef.current.addEventListener("input:notempty", onInputNotEmpty, false);
      inputElRef.current.addEventListener("textarea:resize", onTextareaResize, false);
      inputElRef.current.addEventListener("input:empty", onInputEmpty, false);
      inputElRef.current.addEventListener("input:clear", onInputClear, false);
      if (type === "datepicker") {
        f7Calendar.current = f7.calendar.create({
          inputEl: inputElRef.current,
          value: value2,
          on: {
            change(calendar, calendarValue) {
              emit(props, "calendarChange", calendarValue);
            }
          },
          ...calendarParams || {}
        });
      }
      if (type === "colorpicker") {
        f7ColorPicker.current = f7.colorPicker.create({
          inputEl: inputElRef.current,
          value: value2,
          on: {
            change(colorPicker, colorPickerValue) {
              emit(props, "colorpicker:change colorPickerChange", colorPickerValue);
            }
          },
          ...colorPickerParams || {}
        });
      }
      if (!(validateOnBlur || validateOnBlur === "") && (validate || validate === "") && (typeof value2 !== "undefined" && value2 !== null && value2 !== "" || typeof defaultValue !== "undefined" && defaultValue !== null && defaultValue !== "")) {
        setTimeout(() => {
          validateInput();
        }, 0);
      }
      if (type === "textarea" && resizable) {
        f7.input.resizeTextarea(inputElRef.current);
      }
    });
  };
  const onDestroy = () => {
    if (inputElRef.current) {
      inputElRef.current.removeEventListener("input:notempty", onInputNotEmpty, false);
      inputElRef.current.removeEventListener("textarea:resize", onTextareaResize, false);
      inputElRef.current.removeEventListener("input:empty", onInputEmpty, false);
      inputElRef.current.removeEventListener("input:clear", onInputClear, false);
    }
    if (f7Calendar.current && f7Calendar.current.destroy) {
      f7Calendar.current.destroy();
      f7Calendar.current = null;
    }
    if (f7ColorPicker.current && f7ColorPicker.current.destroy) {
      f7ColorPicker.current.destroy();
      f7ColorPicker.current = null;
    }
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  useIsomorphicLayoutEffect(() => {
    if (!f7) return;
    if (updateInputOnDidUpdate.current) {
      if (!inputElRef.current) return;
      updateInputOnDidUpdate.current = false;
      if (validate && !validateOnBlur) {
        validateInput();
      }
      if (type === "textarea" && resizable) {
        f7.input.resizeTextarea(inputElRef.current);
      }
    }
  });
  watchProp(colorPickerParams, (newValue) => {
    if (!f7 || !f7ColorPicker.current) return;
    extend(f7ColorPicker.current.params, newValue || {});
  });
  watchProp(calendarParams, (newValue) => {
    if (!f7 || !f7Calendar.current) return;
    extend(f7Calendar.current.params, newValue || {});
  });
  watchProp(value2, (newValue) => {
    if (!f7) return;
    updateInputOnDidUpdate.current = true;
    if (f7Calendar.current) {
      f7Calendar.current.setValue(newValue);
    }
    if (f7ColorPicker.current) {
      f7ColorPicker.current.setValue(newValue);
    }
  });
  const slots = getSlots(props);
  const domValue = getDomValue();
  const inputHasValue = isInputHasValue();
  const isSortableComputed = sortable === true || sortable === false ? sortable : listIsSortable;
  let inputEl;
  const createInput = (InputTag, children2) => {
    const needsValue = type !== "file" && type !== "datepicker" && type !== "colorpicker";
    const needsType = InputTag === "input";
    let inputType = type;
    if (inputType === "datepicker" || inputType === "colorpicker") {
      inputType = "text";
    }
    const inputClassName = classNames({
      resizable: inputType === "textarea" && resizable,
      "no-store-data": noFormStoreData || noStoreData || ignoreStoreData,
      "input-invalid": errorMessage && errorMessageForce || inputInvalid,
      "input-with-value": inputHasValue,
      "input-focused": inputFocused
    });
    let inputValue;
    if (needsValue) {
      if (typeof value2 !== "undefined") inputValue = value2;
      else inputValue = domValue;
    }
    const valueProps = {};
    if (type !== "datepicker" && type !== "colorpicker") {
      if ("value" in props) valueProps.value = inputValue;
      if ("defaultValue" in props) valueProps.defaultValue = defaultValue;
    }
    return /* @__PURE__ */ React.createElement(InputTag, _extends$C({
      ref: inputElRef,
      style: inputStyle,
      name: name2,
      type: needsType ? inputType : void 0,
      placeholder,
      inputMode: inputmode,
      id: inputId,
      size,
      accept,
      autoComplete: autocomplete,
      autoCorrect: autocorrect,
      autoCapitalize: autocapitalize,
      spellCheck: spellcheck,
      autoFocus: autofocus,
      autoSave: autosave,
      disabled,
      max,
      maxLength: maxlength,
      min,
      minLength: minlength,
      step,
      multiple,
      readOnly: readonly,
      required,
      pattern,
      validate: typeof validate === "string" && validate.length ? validate : void 0,
      "data-validate": validate === true || validate === "" || validateOnBlur === true || validateOnBlur === "" ? true : void 0,
      "data-validate-on-blur": validateOnBlur === true || validateOnBlur === "" ? true : void 0,
      tabIndex: tabindex,
      "data-error-message": errorMessageForce ? void 0 : errorMessage,
      className: inputClassName,
      onFocus,
      onBlur,
      onInput,
      onChange
    }, valueProps), children2);
  };
  if (renderInput) {
    if (type === "select" || type === "textarea" || type === "file") {
      if (type === "select") {
        inputEl = createInput("select", slots.default);
      } else if (type === "file") {
        inputEl = createInput("input");
      } else {
        inputEl = createInput("textarea");
      }
    } else if (type === "texteditor") {
      inputEl = /* @__PURE__ */ React.createElement(TextEditor, _extends$C({
        value: value2,
        resizable,
        placeholder,
        onTextEditorFocus: onFocus,
        onTextEditorBlur: onBlur,
        onTextEditorInput: onInput,
        onTextEditorChange: onChange
      }, textEditorParams || {}));
    } else {
      inputEl = createInput("input");
    }
  }
  const hasErrorMessage = !!errorMessage || slots["error-message"] && slots["error-message"].length;
  const ItemContent = /* @__PURE__ */ React.createElement("div", {
    ref: itemContentElRef,
    className: classNames("item-content item-input", !wrap && className, !wrap && {
      disabled
    }, !wrap && colorClasses(props), {
      "item-input-outline": outline,
      "item-input-focused": inputFocused,
      "item-input-with-info": !!info || slots.info && slots.info.length,
      "item-input-with-value": inputHasValue,
      "item-input-with-error-message": hasErrorMessage && errorMessageForce || inputInvalid,
      "item-input-invalid": hasErrorMessage && errorMessageForce || inputInvalid
    })
  }, slots["content-start"], (media || slots.media) && /* @__PURE__ */ React.createElement("div", {
    className: "item-media"
  }, media && /* @__PURE__ */ React.createElement("img", {
    src: media
  }), slots.media), /* @__PURE__ */ React.createElement("div", {
    className: "item-inner"
  }, slots["inner-start"], (label || slots.label) && /* @__PURE__ */ React.createElement("div", {
    className: classNames("item-title item-label", {
      "item-floating-label": floatingLabel
    })
  }, label, slots.label), /* @__PURE__ */ React.createElement("div", {
    className: classNames("item-input-wrap", {
      "input-dropdown": dropdown === "auto" ? type === "select" : dropdown
    })
  }, inputEl, slots.input, hasErrorMessage && errorMessageForce && /* @__PURE__ */ React.createElement("div", {
    className: "item-input-error-message"
  }, errorMessage, slots["error-message"]), clearButton && /* @__PURE__ */ React.createElement("span", {
    className: "input-clear-button"
  }), (info || slots.info) && /* @__PURE__ */ React.createElement("div", {
    className: "item-input-info"
  }, info, slots.info)), slots.inner, slots["inner-end"]), slots.content, slots["content-end"]);
  if (!wrap) {
    return ItemContent;
  }
  return /* @__PURE__ */ React.createElement("li", _extends$C({
    ref: elRef,
    id: id2,
    style,
    className: classNames(className, {
      disabled
    }, colorClasses(props))
  }, extraAttrs), slots["root-start"], ItemContent, isSortableComputed && /* @__PURE__ */ React.createElement("div", {
    className: "sortable-handler"
  }), slots.root, slots["root-end"]);
});
ListInput.displayName = "f7-list-input";
const ListItemContent = (props) => {
  const {
    indeterminate,
    radio,
    checkbox,
    value: value2,
    name: name2,
    readonly,
    disabled,
    checked,
    defaultChecked,
    required,
    media,
    header,
    footer,
    title: title2,
    subtitle: subtitle2,
    text: text2,
    after,
    badge,
    badgeColor,
    checkboxIcon,
    radioIcon,
    swipeout,
    sortable,
    accordionItem,
    onChange,
    onClick,
    isMediaComputed,
    isSortableComputed,
    isSortableOppositeComputed,
    slots
  } = props;
  const inputElRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    if (inputElRef.current) {
      inputElRef.current.indeterminate = !!indeterminate;
    }
  }, [indeterminate]);
  let titleEl;
  let afterWrapEl;
  let afterEl;
  let badgeEl;
  let innerEl;
  let titleRowEl;
  let subtitleEl;
  let textEl;
  let mediaEl;
  let inputEl;
  let inputIconEl;
  let headerEl;
  let footerEl;
  if (radio || checkbox) {
    inputEl = /* @__PURE__ */ React.createElement("input", {
      ref: inputElRef,
      value: value2,
      name: name2,
      checked,
      defaultChecked,
      readOnly: readonly,
      disabled,
      required,
      type: radio ? "radio" : "checkbox",
      onChange
    });
    inputIconEl = /* @__PURE__ */ React.createElement("i", {
      className: `icon icon-${radio ? "radio" : "checkbox"}`
    });
  }
  if (media || slots.media) {
    let mediaImgEl;
    if (media) {
      mediaImgEl = /* @__PURE__ */ React.createElement("img", {
        src: media
      });
    }
    mediaEl = /* @__PURE__ */ React.createElement("div", {
      className: "item-media"
    }, mediaImgEl, slots.media);
  }
  if (header || slots.header) {
    headerEl = /* @__PURE__ */ React.createElement("div", {
      className: "item-header"
    }, header, slots.header);
  }
  if (footer || slots.footer) {
    footerEl = /* @__PURE__ */ React.createElement("div", {
      className: "item-footer"
    }, footer, slots.footer);
  }
  if (title2 || slots.title || !isMediaComputed && headerEl || !isMediaComputed && footerEl) {
    titleEl = /* @__PURE__ */ React.createElement("div", {
      className: "item-title"
    }, !isMediaComputed && headerEl, title2, slots.title, !isMediaComputed && footerEl);
  }
  if (subtitle2 || slots.subtitle) {
    subtitleEl = /* @__PURE__ */ React.createElement("div", {
      className: "item-subtitle"
    }, subtitle2, slots.subtitle);
  }
  if (text2 || slots.text) {
    textEl = /* @__PURE__ */ React.createElement("div", {
      className: "item-text"
    }, text2, slots.text);
  }
  if (after || badge || slots.after) {
    if (after) {
      afterEl = /* @__PURE__ */ React.createElement("span", null, after);
    }
    if (badge) {
      badgeEl = /* @__PURE__ */ React.createElement(Badge, {
        color: badgeColor
      }, badge);
    }
    afterWrapEl = /* @__PURE__ */ React.createElement("div", {
      className: "item-after"
    }, slots["after-start"], afterEl, badgeEl, slots.after, slots["after-end"]);
  }
  if (isMediaComputed) {
    titleRowEl = /* @__PURE__ */ React.createElement("div", {
      className: "item-title-row"
    }, slots["before-title"], titleEl, slots["after-title"], afterWrapEl);
    innerEl = /* @__PURE__ */ React.createElement("div", {
      className: "item-inner"
    }, slots["inner-start"], headerEl, titleRowEl, subtitleEl, textEl, swipeout || accordionItem ? null : slots.default, slots.inner, footerEl, slots["inner-end"]);
  } else {
    innerEl = /* @__PURE__ */ React.createElement("div", {
      className: "item-inner"
    }, slots["inner-start"], slots["before-title"], titleEl, slots["after-title"], afterWrapEl, swipeout || accordionItem ? null : slots.default, slots.inner, slots["inner-end"]);
  }
  const ItemContentTag = checkbox || radio ? "label" : "div";
  const classes = classNames("item-content", {
    "item-checkbox": checkbox,
    "item-radio": radio,
    "item-checkbox-icon-start": checkbox && checkboxIcon === "start",
    "item-checkbox-icon-end": checkbox && checkboxIcon === "end",
    "item-radio-icon-start": radio && radioIcon === "start",
    "item-radio-icon-end": radio && radioIcon === "end"
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement(ItemContentTag, {
    className: classes,
    onClick
  }, isSortableComputed && sortable !== false && isSortableOppositeComputed && /* @__PURE__ */ React.createElement("div", {
    className: "sortable-handler"
  }), slots["content-start"], inputEl, inputIconEl, mediaEl, innerEl, slots.content, slots["content-end"]);
};
ListItemContent.displayName = "f7-list-item-content";
function _extends$B() {
  _extends$B = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$B.apply(this, arguments);
}
const ListItem = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    title: title2,
    link,
    target,
    tabLink,
    tabLinkActive,
    selected,
    mediaItem,
    mediaList,
    groupTitle,
    swipeout,
    swipeoutOpened,
    sortable,
    sortableOpposite,
    accordionItem,
    accordionItemOpened,
    smartSelect,
    smartSelectParams,
    noChevron,
    chevronCenter,
    checkbox,
    radio,
    disabled,
    virtualListIndex,
    href
  } = props;
  const listContext = reactExports.useContext(ListContext);
  const {
    listIsMedia = false,
    listIsSortable = false,
    listIsSortableOpposite = false,
    listIsSimple = false
  } = listContext || {};
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const linkElRef = reactExports.useRef(null);
  const f7SmartSelect = reactExports.useRef(null);
  const onClick = (event) => {
    if (event.target.tagName.toLowerCase() !== "input") {
      emit(props, "click", event);
    }
  };
  const onSwipeoutOverswipeEnter = (el) => {
    if (elRef.current !== el) return;
    emit(props, "swipeoutOverswipeEnter");
  };
  const onSwipeoutOverswipeExit = (el) => {
    if (elRef.current !== el) return;
    emit(props, "swipeoutOverswipeExit");
  };
  const onSwipeoutDeleted = (el) => {
    if (elRef.current !== el) return;
    emit(props, "swipeoutDeleted");
  };
  const onSwipeoutDelete = (el) => {
    if (elRef.current !== el) return;
    emit(props, "swipeoutDelete");
  };
  const onSwipeoutClose = (el) => {
    if (elRef.current !== el) return;
    emit(props, "swipeoutClose");
  };
  const onSwipeoutClosed = (el) => {
    if (elRef.current !== el) return;
    emit(props, "swipeoutClosed");
  };
  const onSwipeoutOpen = (el) => {
    if (elRef.current !== el) return;
    emit(props, "swipeoutOpen");
  };
  const onSwipeoutOpened = (el) => {
    if (elRef.current !== el) return;
    emit(props, "swipeoutOpened");
  };
  const onSwipeout = (el, progress) => {
    if (elRef.current !== el) return;
    emit(props, "swipeout", progress);
  };
  const onAccBeforeClose = (el, prevent) => {
    if (elRef.current !== el) return;
    emit(props, "accordionBeforeClose", prevent);
  };
  const onAccClose = (el) => {
    if (elRef.current !== el) return;
    emit(props, "accordionClose");
  };
  const onAccClosed = (el) => {
    if (elRef.current !== el) return;
    emit(props, "accordionClosed");
  };
  const onAccBeforeOpen = (el, prevent) => {
    if (elRef.current !== el) return;
    emit(props, "accordionBeforeOpen", prevent);
  };
  const onAccOpen = (el) => {
    if (elRef.current !== el) return;
    emit(props, "accordionOpen");
  };
  const onAccOpened = (el) => {
    if (elRef.current !== el) return;
    emit(props, "accordionOpened");
  };
  const onChange = (event) => {
    emit(props, "change", event);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7SmartSelect: () => f7SmartSelect.current
  }));
  useTooltip(elRef, props);
  useRouteProps(linkElRef, props);
  watchProp(swipeoutOpened, (newValue) => {
    if (!swipeout || !elRef.current || !f7) return;
    if (newValue) {
      f7.swipeout.open(elRef.current);
    } else {
      f7.swipeout.close(elRef.current);
    }
  });
  const attachEvents = () => {
    f7ready(() => {
      if (swipeout) {
        f7.on("swipeoutOpen", onSwipeoutOpen);
        f7.on("swipeoutOpened", onSwipeoutOpened);
        f7.on("swipeoutClose", onSwipeoutClose);
        f7.on("swipeoutClosed", onSwipeoutClosed);
        f7.on("swipeoutDelete", onSwipeoutDelete);
        f7.on("swipeoutDeleted", onSwipeoutDeleted);
        f7.on("swipeoutOverswipeEnter", onSwipeoutOverswipeEnter);
        f7.on("swipeoutOverswipeExit", onSwipeoutOverswipeExit);
        f7.on("swipeout", onSwipeout);
      }
      if (accordionItem) {
        f7.on("accordionBeforeOpen", onAccBeforeOpen);
        f7.on("accordionOpen", onAccOpen);
        f7.on("accordionOpened", onAccOpened);
        f7.on("accordionBeforeClose", onAccBeforeClose);
        f7.on("accordionClose", onAccClose);
        f7.on("accordionClosed", onAccClosed);
      }
    });
  };
  const detachEvents = () => {
    if (!f7) return;
    f7.off("swipeoutOpen", onSwipeoutOpen);
    f7.off("swipeoutOpened", onSwipeoutOpened);
    f7.off("swipeoutClose", onSwipeoutClose);
    f7.off("swipeoutClosed", onSwipeoutClosed);
    f7.off("swipeoutDelete", onSwipeoutDelete);
    f7.off("swipeoutDeleted", onSwipeoutDeleted);
    f7.off("swipeoutOverswipeEnter", onSwipeoutOverswipeEnter);
    f7.off("swipeoutOverswipeExit", onSwipeoutOverswipeExit);
    f7.off("swipeout", onSwipeout);
    f7.off("accordionBeforeOpen", onAccBeforeOpen);
    f7.off("accordionOpen", onAccOpen);
    f7.off("accordionOpened", onAccOpened);
    f7.off("accordionBeforeClose", onAccBeforeClose);
    f7.off("accordionClose", onAccClose);
    f7.off("accordionClosed", onAccClosed);
  };
  useSmartSelect(smartSelect, smartSelectParams, f7SmartSelect, () => elRef.current.querySelector("a.smart-select"));
  useIsomorphicLayoutEffect(() => {
    f7ready(() => {
      if (swipeout && swipeoutOpened) {
        f7.swipeout.open(elRef.current);
      }
    });
  }, []);
  useIsomorphicLayoutEffect(() => {
    attachEvents();
    return detachEvents;
  });
  const slots = getSlots(props);
  let linkEl;
  let itemContentEl;
  const isMediaComputed = mediaItem || mediaList || listIsMedia;
  const isSortableComputed = sortable === true || sortable === false ? sortable : listIsSortable;
  const isSortableOppositeComputed = isSortableComputed && (sortableOpposite || listIsSortableOpposite);
  if (!listIsSimple) {
    itemContentEl = /* @__PURE__ */ React.createElement(ListItemContent, _extends$B({}, props, {
      slots,
      onChange,
      onClick: link || href || accordionItem || smartSelect ? void 0 : onClick,
      isMediaComputed,
      isSortableComputed,
      isSortableOppositeComputed
    }));
    if (link || href || accordionItem || smartSelect) {
      const linkAttrs = {
        href: href === false ? void 0 : link === true ? href || "" : link || href,
        target,
        "data-tab": isStringProp(tabLink) && tabLink || void 0,
        ...routerAttrs(props),
        ...actionsAttrs(props)
      };
      const linkClasses = classNames({
        "item-link": true,
        "smart-select": smartSelect,
        "tab-link": tabLink || tabLink === "",
        "tab-link-active": tabLinkActive,
        "item-selected": selected
      }, routerClasses(props), actionsClasses(props));
      linkEl = /* @__PURE__ */ React.createElement("a", _extends$B({
        ref: linkElRef,
        className: linkClasses
      }, linkAttrs, {
        onClick
      }), itemContentEl);
    }
  }
  const liClasses = classNames(className, {
    "list-group-title": groupTitle,
    "media-item": isMediaComputed,
    swipeout,
    "accordion-item": accordionItem,
    "accordion-item-opened": accordionItemOpened,
    disabled: disabled && !(radio || checkbox),
    "no-chevron": noChevron,
    "chevron-center": chevronCenter,
    "disallow-sorting": sortable === false
  }, colorClasses(props));
  if (groupTitle) {
    return /* @__PURE__ */ React.createElement("li", {
      ref: elRef,
      id: id2,
      style,
      className: liClasses,
      "data-virtual-list-index": virtualListIndex,
      onClick
    }, /* @__PURE__ */ React.createElement("span", null, title2, children2));
  }
  if (listIsSimple) {
    return /* @__PURE__ */ React.createElement("li", {
      ref: elRef,
      id: id2,
      style,
      className: liClasses,
      "data-virtual-list-index": virtualListIndex,
      onClick
    }, title2, children2);
  }
  const linkItemEl = link || href || smartSelect || accordionItem ? linkEl : itemContentEl;
  return /* @__PURE__ */ React.createElement("li", _extends$B({
    ref: elRef,
    id: id2,
    style,
    className: liClasses,
    "data-virtual-list-index": virtualListIndex
  }, extraAttrs), slots["root-start"], swipeout ? /* @__PURE__ */ React.createElement("div", {
    className: "swipeout-content"
  }, linkItemEl) : linkItemEl, isSortableComputed && sortable !== false && !isSortableOppositeComputed && /* @__PURE__ */ React.createElement("div", {
    className: "sortable-handler"
  }), (swipeout || accordionItem) && slots.default, slots.root, slots["root-end"]);
});
ListItem.displayName = "f7-list-item";
function _extends$A() {
  _extends$A = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$A.apply(this, arguments);
}
const List = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7VirtualList = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    inset,
    insetIos,
    insetMd,
    xsmallInset,
    xsmallInsetIos,
    xsmallInsetMd,
    smallInset,
    smallInsetIos,
    smallInsetMd,
    mediumInset,
    mediumInsetIos,
    mediumInsetMd,
    largeInset,
    largeInsetIos,
    largeInsetMd,
    xlargeInset,
    xlargeInsetIos,
    xlargeInsetMd,
    strong,
    strongIos,
    strongMd,
    outline,
    outlineIos,
    outlineMd,
    dividers,
    dividersIos,
    dividersMd,
    mediaList,
    sortable,
    sortableTapHold,
    sortableEnabled,
    sortableMoveElements,
    sortableOpposite,
    accordionList,
    accordionOpposite,
    contactsList,
    simpleList,
    linksList,
    menuList,
    noChevron,
    chevronCenter,
    tab,
    tabActive,
    form,
    formStoreData,
    virtualList,
    virtualListParams
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onSubmit = (event) => {
    emit(props, "submit", event);
  };
  const onSortableEnable = (el) => {
    if (elRef.current !== el) return;
    emit(props, "sortableEnable");
  };
  const onSortableDisable = (el) => {
    if (elRef.current !== el) return;
    emit(props, "sortableDisable");
  };
  const onSortableSort = (el, sortData, listEl) => {
    if (elRef.current !== listEl) return;
    emit(props, "sortableSort", sortData);
  };
  const onSortableMove = (el, listEl) => {
    if (elRef.current !== listEl) return;
    emit(props, "sortableMove", el, listEl);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7VirtualList: () => f7VirtualList.current
  }));
  useTab(elRef, props);
  const attachEvents = () => {
    f7ready(() => {
      f7.on("sortableEnable", onSortableEnable);
      f7.on("sortableDisable", onSortableDisable);
      f7.on("sortableSort", onSortableSort);
      f7.on("sortableMove", onSortableMove);
    });
  };
  const detachEvents = () => {
    if (!f7) return;
    f7.off("sortableEnable", onSortableEnable);
    f7.off("sortableDisable", onSortableDisable);
    f7.off("sortableSort", onSortableSort);
    f7.off("sortableMove", onSortableMove);
  };
  const onMount = () => {
    f7ready(() => {
      if (!virtualList) return;
      const vlParams = virtualListParams || {};
      if (!vlParams.renderItem && !vlParams.renderExternal) return;
      f7VirtualList.current = f7.virtualList.create(extend({
        el: elRef.current,
        on: {
          itemBeforeInsert(itemEl, item) {
            const vl = this;
            emit(props, "virtualItemBeforeInsert", vl, itemEl, item);
          },
          beforeClear(fragment) {
            const vl = this;
            emit(props, "virtualBeforeClear", vl, fragment);
          },
          itemsBeforeInsert(fragment) {
            const vl = this;
            emit(props, "virtualItemsBeforeInsert", vl, fragment);
          },
          itemsAfterInsert(fragment) {
            const vl = this;
            emit(props, "virtualItemsAfterInsert", vl, fragment);
          }
        }
      }, vlParams));
    });
  };
  const onDestroy = () => {
    if (!f7) return;
    if (!(virtualList && f7VirtualList.current)) return;
    if (f7VirtualList.current.destroy) f7VirtualList.current.destroy();
    f7VirtualList.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  useIsomorphicLayoutEffect(() => {
    attachEvents();
    return detachEvents;
  });
  const slots = getSlots(props);
  const {
    list: slotsList,
    default: slotsDefault
  } = slots;
  const rootChildrenBeforeList = [];
  const rootChildrenAfterList = [];
  const ulChildren = slotsList || [];
  const flattenSlots = flattenArray(slotsDefault);
  let wasUlChild = false;
  flattenSlots.forEach((child) => {
    if (typeof child === "undefined") return;
    let tag = child.type && (child.type.displayName || child.type.name);
    if (!tag && typeof child.type === "string") {
      tag = child.type;
    }
    if (!tag || tag && !(tag === "li" || tag.indexOf("f7-list-item") >= 0 || tag.indexOf("f7-list-button") >= 0 || tag.indexOf("f7-list-input") >= 0)) {
      if (wasUlChild) rootChildrenAfterList.push(child);
      else rootChildrenBeforeList.push(child);
    } else if (tag) {
      wasUlChild = true;
      ulChildren.push(child);
    }
  });
  const ListTag = form ? "form" : "div";
  const classes = classNames(className, "list", {
    inset,
    "inset-ios": insetIos,
    "inset-md": insetMd,
    "xsmall-inset": xsmallInset,
    "xsmall-inset-ios": xsmallInsetIos,
    "xsmall-inset-md": xsmallInsetMd,
    "small-inset": smallInset,
    "small-inset-ios": smallInsetIos,
    "small-inset-md": smallInsetMd,
    "medium-inset": mediumInset,
    "medium-inset-ios": mediumInsetIos,
    "medium-inset-md": mediumInsetMd,
    "large-inset": largeInset,
    "large-inset-ios": largeInsetIos,
    "large-inset-md": largeInsetMd,
    "xlarge-inset": xlargeInset,
    "xlarge-inset-ios": xlargeInsetIos,
    "xlarge-inset-md": xlargeInsetMd,
    "list-strong": strong,
    "list-strong-ios": strongIos,
    "list-strong-md": strongMd,
    "list-outline": outline,
    "list-outline-ios": outlineIos,
    "list-outline-md": outlineMd,
    "list-dividers": dividers,
    "list-dividers-ios": dividersIos,
    "list-dividers-md": dividersMd,
    "media-list": mediaList,
    "simple-list": simpleList,
    "links-list": linksList,
    "menu-list": menuList,
    sortable,
    "sortable-tap-hold": sortableTapHold,
    "sortable-enabled": sortableEnabled,
    "sortable-opposite": sortableOpposite,
    "accordion-list": accordionList,
    "accordion-opposite": accordionOpposite,
    "contacts-list": contactsList,
    "virtual-list": virtualList,
    tab,
    "tab-active": tabActive,
    "form-store-data": formStoreData,
    "no-chevron": noChevron,
    "chevron-center": chevronCenter
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement(ListTag, _extends$A({
    id: id2,
    ref: elRef,
    style,
    className: classes
  }, extraAttrs, {
    "data-sortable-move-elements": typeof sortableMoveElements !== "undefined" ? sortableMoveElements.toString() : void 0,
    onSubmit
  }), /* @__PURE__ */ React.createElement(ListContext.Provider, {
    value: {
      listIsMedia: mediaList,
      listIsSimple: simpleList,
      listIsSortable: sortable,
      listIsSortableOpposite: sortableOpposite
    }
  }, slots["before-list"], rootChildrenBeforeList, ulChildren.length > 0 && /* @__PURE__ */ React.createElement("ul", null, ulChildren), slots["after-list"], rootChildrenAfterList));
});
List.displayName = "f7-list";
function _extends$z() {
  _extends$z = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$z.apply(this, arguments);
}
const LoginScreenTitle = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "login-screen-title", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$z({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
LoginScreenTitle.displayName = "f7-login-screen-title";
function _extends$y() {
  _extends$y = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$y.apply(this, arguments);
}
const Message = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    text: text2,
    name: name2,
    avatar,
    type = "sent",
    image,
    header,
    footer,
    textHeader,
    textFooter,
    first,
    last,
    tail,
    sameName,
    sameHeader,
    sameFooter,
    sameAvatar,
    typing
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onClick = (event) => {
    emit(props, "click", event);
  };
  const onNameClick = (event) => {
    emit(props, "clickName", event);
  };
  const onTextClick = (event) => {
    emit(props, "clickText", event);
  };
  const onAvatarClick = (event) => {
    emit(props, "clickAvatar", event);
  };
  const onHeaderClick = (event) => {
    emit(props, "clickHeader", event);
  };
  const onFooterClick = (event) => {
    emit(props, "clickFooter", event);
  };
  const onBubbleClick = (event) => {
    emit(props, "clickBubble", event);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const slots = getSlots(props);
  const classes = classNames(className, "message", {
    "message-sent": type === "sent",
    "message-received": type === "received",
    "message-typing": typing,
    "message-first": first,
    "message-last": last,
    "message-tail": tail,
    "message-same-name": sameName,
    "message-same-header": sameHeader,
    "message-same-footer": sameFooter,
    "message-same-avatar": sameAvatar
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$y({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs, {
    onClick
  }), slots.start, (avatar || slots.avatar) && /* @__PURE__ */ React.createElement("div", {
    className: "message-avatar",
    style: {
      backgroundImage: avatar && `url(${avatar})`
    },
    onClick: onAvatarClick
  }, slots.avatar), /* @__PURE__ */ React.createElement("div", {
    className: "message-content"
  }, slots["content-start"], (slots.name || name2) && /* @__PURE__ */ React.createElement("div", {
    className: "message-name",
    onClick: onNameClick
  }, name2, slots.name), (slots.header || header) && /* @__PURE__ */ React.createElement("div", {
    className: "message-header",
    onClick: onHeaderClick
  }, header, slots.header), /* @__PURE__ */ React.createElement("div", {
    className: "message-bubble",
    onClick: onBubbleClick
  }, slots["bubble-start"], (slots.image || image) && /* @__PURE__ */ React.createElement("div", {
    className: "message-image"
  }, slots.image || /* @__PURE__ */ React.createElement("img", {
    src: image
  })), (slots["text-header"] || textHeader) && /* @__PURE__ */ React.createElement("div", {
    className: "message-text-header"
  }, textHeader, slots["text-header"]), (slots.text || text2 || typing) && /* @__PURE__ */ React.createElement("div", {
    className: "message-text",
    onClick: onTextClick
  }, text2, slots.text, typing && /* @__PURE__ */ React.createElement("div", {
    className: "message-typing-indicator"
  }, /* @__PURE__ */ React.createElement("div", null), /* @__PURE__ */ React.createElement("div", null), /* @__PURE__ */ React.createElement("div", null))), (slots["text-footer"] || textFooter) && /* @__PURE__ */ React.createElement("div", {
    className: "message-text-footer"
  }, textFooter, slots["text-footer"]), slots["bubble-end"], slots.default), (slots.footer || footer) && /* @__PURE__ */ React.createElement("div", {
    className: "message-footer",
    onClick: onFooterClick
  }, footer, slots.footer), slots["content-end"]), slots.end);
});
Message.displayName = "f7-message";
function _extends$x() {
  _extends$x = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$x.apply(this, arguments);
}
const MessagebarAttachment = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    image,
    deletable = true
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onClick = (event) => {
    emit(props, "attachmentClick", event);
  };
  const onDeleteClick = (event) => {
    emit(props, "attachmentDelete", event);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "messagebar-attachment", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$x({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs, {
    onClick
  }), image && /* @__PURE__ */ React.createElement("img", {
    src: image
  }), deletable && /* @__PURE__ */ React.createElement("span", {
    className: "messagebar-attachment-delete",
    onClick: onDeleteClick
  }), children2);
});
MessagebarAttachment.displayName = "f7-messagebar-attachment";
function _extends$w() {
  _extends$w = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$w.apply(this, arguments);
}
const MessagebarAttachments = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "messagebar-attachments", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$w({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
MessagebarAttachments.displayName = "f7-messagebar-attachments";
function _extends$v() {
  _extends$v = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$v.apply(this, arguments);
}
const MessagebarSheetImage = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    image,
    checked
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onChange = (event) => {
    if (event.target.checked) emit(props, "checked", event);
    else emit(props, "unchecked", event);
    emit(props, "change", event);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "messagebar-sheet-image", "checkbox", colorClasses(props));
  const styles2 = {
    ...style || {}
  };
  return /* @__PURE__ */ React.createElement("label", _extends$v({
    id: id2,
    className: classes,
    style: styles2,
    ref: elRef
  }, extraAttrs), /* @__PURE__ */ React.createElement("input", {
    type: "checkbox",
    checked,
    onChange
  }), /* @__PURE__ */ React.createElement("i", {
    className: "icon icon-checkbox"
  }), image && /* @__PURE__ */ React.createElement("img", {
    src: image
  }), children2);
});
MessagebarSheetImage.displayName = "f7-messagebar-sheet-image";
function _extends$u() {
  _extends$u = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$u.apply(this, arguments);
}
const MessagebarSheetItem = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "messagebar-sheet-item", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$u({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
MessagebarSheetItem.displayName = "f7-messagebar-sheet-item";
function _extends$t() {
  _extends$t = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$t.apply(this, arguments);
}
const MessagebarSheet = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "messagebar-sheet", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$t({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
MessagebarSheet.displayName = "f7-messagebar-sheet";
function _extends$s() {
  _extends$s = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$s.apply(this, arguments);
}
const Messagebar = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7Messagebar = reactExports.useRef(null);
  const updateSheetVisible = reactExports.useRef(false);
  const updateAttachmentsVisible = reactExports.useRef(false);
  const {
    className,
    id: id2,
    style,
    sheetVisible,
    attachmentsVisible,
    top,
    resizable = true,
    bottomOffset = 0,
    topOffset = 0,
    maxHeight,
    resizePage = true,
    sendLink,
    value: value2,
    disabled,
    readonly,
    textareaId,
    name: name2,
    placeholder = "Message",
    init = true
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const areaElRef = reactExports.useRef(null);
  const onChange = (event) => {
    emit(props, "change", event);
  };
  const onInput = (event) => {
    emit(props, "input", event);
  };
  const onFocus = (event) => {
    emit(props, "focus", event);
  };
  const onBlur = (event) => {
    emit(props, "blur", event);
  };
  const onClick = (event) => {
    const inputValue = areaElRef.current.el.value;
    const clear = f7Messagebar.current ? () => {
      f7Messagebar.current.clear();
    } : () => {
    };
    emit(props, "submit", inputValue, clear);
    emit(props, "send", inputValue, clear);
    emit(props, "click", event);
  };
  const onAttachmentDelete = (instance, attachmentEl, attachmentElIndex) => {
    emit(props, "messagebarAttachmentDelete", instance, attachmentEl, attachmentElIndex);
  };
  const onAttachmentClick = (instance, attachmentEl, attachmentElIndex) => {
    emit(props, "messagebarAttachmentClick", instance, attachmentEl, attachmentElIndex);
  };
  const onResizePage = (instance) => {
    emit(props, "messagebarResizePage", instance);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7Messagebar: () => f7Messagebar.current
  }));
  watchProp(sheetVisible, () => {
    if (!resizable || !f7Messagebar.current) return;
    updateSheetVisible.current = true;
  });
  watchProp(attachmentsVisible, () => {
    if (!resizable || !f7Messagebar.current) return;
    updateAttachmentsVisible.current = true;
  });
  useIsomorphicLayoutEffect(() => {
    if (!f7Messagebar.current) return;
    if (updateSheetVisible.current) {
      updateSheetVisible.current = false;
      f7Messagebar.current.sheetVisible = sheetVisible;
      f7Messagebar.current.resizePage();
    }
    if (updateAttachmentsVisible.current) {
      updateAttachmentsVisible.current = false;
      f7Messagebar.current.attachmentsVisible = attachmentsVisible;
      f7Messagebar.current.resizePage();
    }
  });
  const onMount = () => {
    if (!init) return;
    if (!elRef.current) return;
    const params = noUndefinedProps({
      el: elRef.current,
      top,
      resizePage,
      bottomOffset,
      topOffset,
      maxHeight,
      on: {
        attachmentDelete: onAttachmentDelete,
        attachmentClick: onAttachmentClick,
        resizePage: onResizePage
      }
    });
    f7ready(() => {
      f7Messagebar.current = f7.messagebar.create(params);
    });
  };
  const onDestroy = () => {
    if (f7Messagebar.current && f7Messagebar.current.destroy) f7Messagebar.current.destroy();
    f7Messagebar.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  const slots = getSlots(props);
  const {
    default: slotsDefault,
    "before-inner": slotsBeforeInner,
    "after-inner": slotsAfterInner,
    "send-link": slotsSendLink,
    "inner-start": slotsInnerStart,
    "inner-end": slotsInnerEnd,
    "before-area": slotsBeforeArea,
    "after-area": slotsAfterArea
  } = slots;
  const innerEndEls = [];
  let messagebarAttachmentsEl;
  let messagebarSheetEl;
  if (slotsDefault) {
    slotsDefault.forEach((child) => {
      if (typeof child === "undefined") return;
      const tag = child.type && (child.type.displayName || child.type.name);
      if (tag && (tag.indexOf("messagebar-attachments") >= 0 || tag === "F7MessagebarAttachments" || tag === "f7-messagebar-attachments")) {
        messagebarAttachmentsEl = child;
      } else if (tag && (tag.indexOf("messagebar-sheet") >= 0 || tag === "F7MessagebarSheet" || tag === "f7-messagebar-sheet")) {
        messagebarSheetEl = child;
      } else {
        innerEndEls.push(child);
      }
    });
  }
  const valueProps = {};
  if ("value" in props) valueProps.value = value2;
  const classes = classNames(className, "toolbar", "messagebar", {
    "messagebar-attachments-visible": attachmentsVisible,
    "messagebar-sheet-visible": sheetVisible
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$s({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), slotsBeforeInner, /* @__PURE__ */ React.createElement("div", {
    className: "toolbar-inner"
  }, slotsInnerStart, /* @__PURE__ */ React.createElement("div", {
    className: "messagebar-area"
  }, slotsBeforeArea, messagebarAttachmentsEl, /* @__PURE__ */ React.createElement(Input, _extends$s({
    inputId: textareaId,
    ref: areaElRef,
    type: "textarea",
    wrap: false,
    placeholder,
    disabled,
    name: name2,
    readonly,
    resizable,
    onInput,
    onChange,
    onFocus,
    onBlur
  }, valueProps)), slotsAfterArea), (sendLink && sendLink.length > 0 || slotsSendLink) && /* @__PURE__ */ React.createElement(Link, {
    onClick
  }, slotsSendLink || sendLink), slotsInnerEnd, innerEndEls), slotsAfterInner, messagebarSheetEl);
});
Messagebar.displayName = "f7-messagebar";
function _extends$r() {
  _extends$r = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$r.apply(this, arguments);
}
const MessagesTitle = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "messages-title", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$r({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
MessagesTitle.displayName = "f7-messages-title";
function _extends$q() {
  _extends$q = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$q.apply(this, arguments);
}
const Messages = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7Messages = reactExports.useRef(null);
  const mounted = reactExports.useRef(false);
  const {
    className,
    id: id2,
    style,
    children: children2,
    autoLayout = false,
    messages = [],
    newMessagesFirst = false,
    scrollMessages = true,
    scrollMessagesOnEdge = true,
    firstMessageRule,
    lastMessageRule,
    tailMessageRule,
    sameNameMessageRule,
    sameHeaderMessageRule,
    sameFooterMessageRule,
    sameAvatarMessageRule,
    customClassMessageRule,
    renderMessage,
    typing = false,
    init = true
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const childrenBeforeUpdated = reactExports.useRef(null);
  const reactChildrenBefore = reactExports.useRef(children2 ? React.Children.count(children2) : 0);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7Messages: () => f7Messages.current
  }));
  const onMount = () => {
    if (!init) return;
    f7ready(() => {
      f7Messages.current = f7.messages.create(noUndefinedProps({
        el: elRef.current,
        autoLayout,
        messages,
        newMessagesFirst,
        scrollMessages,
        scrollMessagesOnEdge,
        firstMessageRule,
        lastMessageRule,
        tailMessageRule,
        sameNameMessageRule,
        sameHeaderMessageRule,
        sameFooterMessageRule,
        sameAvatarMessageRule,
        customClassMessageRule,
        renderMessage
      }));
      if (typing) {
        f7Messages.current.showTyping();
      }
    });
  };
  const onDestroy = () => {
    if (f7Messages.current && f7Messages.current.destroy) f7Messages.current.destroy();
    f7Messages.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  const currentChildrenLength = children2 ? React.Children.count(children2) : 0;
  if (f7Messages.current && scrollMessages) {
    const beforeChildrenLength = reactChildrenBefore.current || 0;
    if (currentChildrenLength !== beforeChildrenLength) {
      f7Messages.current.setScrollData();
    }
  }
  reactChildrenBefore.current = currentChildrenLength;
  useIsomorphicLayoutEffect(() => {
    const wasMounted = mounted.current;
    mounted.current = true;
    if (!init || !elRef.current) return;
    const childElements = elRef.current.children;
    if (!childElements) return;
    const childrenAfterUpdated = childElements.length;
    if (!wasMounted) {
      for (let i = 0; i < childElements.length; i += 1) {
        childElements[i].classList.add("message-appeared");
      }
      return;
    }
    for (let i = 0; i < childElements.length; i += 1) {
      if (!childElements[i].classList.contains("message-appeared")) {
        childElements[i].classList.add("message-appear-from-bottom");
      }
    }
    if (f7Messages.current) {
      if (f7Messages.current.layout && autoLayout) {
        f7Messages.current.layout();
      }
      if (childrenBeforeUpdated.current !== childrenAfterUpdated && f7Messages.current.scroll && f7Messages.current.scrollData && scrollMessages) {
        f7Messages.current.scrollWithEdgeCheck(true);
      }
    }
    childrenBeforeUpdated.current = childrenAfterUpdated;
  });
  watchProp(typing, (newValue) => {
    if (!f7Messages.current) return;
    if (newValue) f7Messages.current.showTyping();
    else f7Messages.current.hideTyping();
  });
  const classes = classNames(className, "messages", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$q({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
Messages.displayName = "f7-messages";
function _extends$p() {
  _extends$p = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$p.apply(this, arguments);
}
const NavLeft = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    backLink,
    backLinkUrl,
    backLinkForce,
    backLinkShowText,
    sliding
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onBackClick = (event) => {
    emit(props, "backClick clickBack", event);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const theme2 = useTheme();
  let linkEl;
  let needBackLinkText = backLinkShowText;
  if (typeof needBackLinkText === "undefined") needBackLinkText = !theme2.md;
  if (backLink) {
    const text2 = backLink !== true && needBackLinkText ? backLink : void 0;
    linkEl = /* @__PURE__ */ React.createElement(Link, {
      href: backLinkUrl || "#",
      back: true,
      icon: "icon-back",
      force: backLinkForce || void 0,
      className: !text2 ? "icon-only" : void 0,
      text: text2,
      onClick: onBackClick
    });
  }
  const classes = classNames(className, "left", {
    sliding
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$p({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), linkEl, children2);
});
NavLeft.displayName = "f7-nav-left";
function _extends$o() {
  _extends$o = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$o.apply(this, arguments);
}
const NavRight = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    sliding
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "right", {
    sliding
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$o({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
NavRight.displayName = "f7-nav-right";
function _extends$n() {
  _extends$n = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$n.apply(this, arguments);
}
const NavTitleLarge = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "title-large", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$n({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), /* @__PURE__ */ React.createElement("div", {
    className: "title-large-text"
  }, children2));
});
NavTitleLarge.displayName = "f7-nav-title-large";
function _extends$m() {
  _extends$m = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$m.apply(this, arguments);
}
const NavTitle = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    title: title2,
    subtitle: subtitle2,
    sliding
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  let subtitleEl;
  if (subtitle2) {
    subtitleEl = /* @__PURE__ */ React.createElement("span", {
      className: "subtitle"
    }, subtitle2);
  }
  const classes = classNames(className, "title", {
    sliding
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$m({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2, title2, subtitleEl);
});
NavTitle.displayName = "f7-nav-title";
function _extends$l() {
  _extends$l = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$l.apply(this, arguments);
}
const Navbar = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    sliding = true,
    large,
    largeTransparent,
    transparent,
    hidden,
    outline = true,
    backLink,
    backLinkForce,
    backLinkUrl,
    backLinkShowText,
    title: title2,
    subtitle: subtitle2,
    titleLarge,
    innerClass,
    innerClassName
  } = props;
  const routerPositionClass = reactExports.useRef("");
  const largeCollapsed = reactExports.useRef(false);
  const routerNavbarRole = reactExports.useRef(null);
  const routerNavbarRoleDetailRoot = reactExports.useRef(false);
  const routerNavbarMasterStack = reactExports.useRef(false);
  const transparentVisible = reactExports.useRef(false);
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const theme2 = useTheme();
  const onHide = (navbarEl) => {
    if (elRef.current !== navbarEl) return;
    emit(props, "navbarHide");
  };
  const onShow = (navbarEl) => {
    if (elRef.current !== navbarEl) return;
    emit(props, "navbarShow");
  };
  const onExpand = (navbarEl) => {
    if (elRef.current !== navbarEl) return;
    largeCollapsed.current = false;
    emit(props, "navbarExpand");
  };
  const onCollapse = (navbarEl) => {
    if (elRef.current !== navbarEl) return;
    largeCollapsed.current = true;
    emit(props, "navbarCollapse");
  };
  const onNavbarTransparentShow = (navbarEl) => {
    if (elRef.current !== navbarEl) return;
    transparentVisible.current = true;
    emit(props, "navbarTransparentShow");
  };
  const onNavbarTransparentHide = (navbarEl) => {
    if (elRef.current !== navbarEl) return;
    transparentVisible.current = false;
    emit(props, "navbarTransparentHide");
  };
  const onNavbarPosition = (navbarEl, position) => {
    if (elRef.current !== navbarEl) return;
    routerPositionClass.current = position ? `navbar-${position}` : "";
  };
  const onNavbarRole = (navbarEl, rolesData) => {
    if (elRef.current !== navbarEl) return;
    routerNavbarRole.current = rolesData.role;
    routerNavbarRoleDetailRoot.current = rolesData.detailRoot;
  };
  const onNavbarMasterStack = (navbarEl) => {
    if (elRef.current !== navbarEl) return;
    routerNavbarMasterStack.current = true;
  };
  const onNavbarMasterUnstack = (navbarEl) => {
    if (elRef.current !== navbarEl) return;
    routerNavbarMasterStack.current = false;
  };
  const hide2 = (animate2) => {
    if (!f7) return;
    f7.navbar.hide(elRef.current, animate2);
  };
  const show2 = (animate2) => {
    if (!f7) return;
    f7.navbar.show(elRef.current, animate2);
  };
  const size = () => {
    if (!f7) return;
    f7.navbar.size(elRef.current);
  };
  const onBackClick = (event) => {
    emit(props, "backClick clickBack", event);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    hide: hide2,
    show: show2,
    size
  }));
  const attachEvents = () => {
    if (!elRef.current) return;
    f7ready(() => {
      f7.navbar.size(elRef.current);
      f7.on("navbarShow", onShow);
      f7.on("navbarHide", onHide);
      f7.on("navbarCollapse", onCollapse);
      f7.on("navbarExpand", onExpand);
      f7.on("navbarPosition", onNavbarPosition);
      f7.on("navbarRole", onNavbarRole);
      f7.on("navbarMasterStack", onNavbarMasterStack);
      f7.on("navbarMasterUnstack", onNavbarMasterUnstack);
      f7.on("navbarTransparentShow", onNavbarTransparentShow);
      f7.on("navbarTransparentHide", onNavbarTransparentHide);
    });
  };
  const detachEvents = () => {
    if (!f7) return;
    f7.off("navbarShow", onShow);
    f7.off("navbarHide", onHide);
    f7.off("navbarCollapse", onCollapse);
    f7.off("navbarExpand", onExpand);
    f7.off("navbarPosition", onNavbarPosition);
    f7.off("navbarRole", onNavbarRole);
    f7.off("navbarMasterStack", onNavbarMasterStack);
    f7.off("navbarMasterUnstack", onNavbarMasterUnstack);
    f7.off("navbarTransparentShow", onNavbarTransparentShow);
    f7.off("navbarTransparentHide", onNavbarTransparentHide);
  };
  useIsomorphicLayoutEffect(() => {
    attachEvents();
    return detachEvents;
  });
  const slots = getSlots(props);
  let leftEl;
  let titleEl;
  let rightEl;
  let titleLargeEl;
  const addLeftTitleClass = theme2 && theme2.ios && f7 && !f7.params.navbar.iosCenterTitle;
  const addCenterTitleClass = theme2 && theme2.md && f7 && f7.params.navbar.mdCenterTitle;
  const isLarge = large || largeTransparent;
  const isTransparent = transparent || isLarge && largeTransparent;
  const isTransparentVisible = isTransparent && transparentVisible.current;
  const classes = classNames(className, "navbar", routerPositionClass.current, {
    "navbar-hidden": hidden,
    "navbar-large": isLarge,
    "navbar-large-collapsed": isLarge && largeCollapsed.current,
    "navbar-transparent": isTransparent,
    "navbar-transparent-visible": isTransparentVisible,
    "navbar-master": routerNavbarRole.current === "master",
    "navbar-master-detail": routerNavbarRole.current === "detail",
    "navbar-master-detail-root": routerNavbarRoleDetailRoot.current === true,
    "navbar-master-stacked": routerNavbarMasterStack.current === true,
    "no-outline": !outline
  }, colorClasses(props));
  if (backLink || slots["nav-left"] || slots.left) {
    leftEl = /* @__PURE__ */ React.createElement(NavLeft, {
      backLink,
      backLinkUrl,
      backLinkForce,
      backLinkShowText,
      onBackClick
    }, slots["nav-left"], slots.left);
  }
  if (title2 || subtitle2 || slots.title) {
    titleEl = /* @__PURE__ */ React.createElement(NavTitle, {
      title: title2,
      subtitle: subtitle2
    }, slots.title);
  }
  if (slots["nav-right"] || slots.right) {
    rightEl = /* @__PURE__ */ React.createElement(NavRight, null, slots["nav-right"], slots.right);
  }
  let largeTitle = titleLarge;
  if (!largeTitle && large && title2) largeTitle = title2;
  if (largeTitle || slots["title-large"]) {
    titleLargeEl = /* @__PURE__ */ React.createElement("div", {
      className: "title-large"
    }, /* @__PURE__ */ React.createElement("div", {
      className: "title-large-text"
    }, largeTitle || "", slots["title-large"]));
  }
  const innerEl = /* @__PURE__ */ React.createElement("div", {
    className: classNames("navbar-inner", innerClass, innerClassName, {
      sliding,
      "navbar-inner-left-title": addLeftTitleClass,
      "navbar-inner-centered-title": addCenterTitleClass
    })
  }, leftEl, titleEl, rightEl, titleLargeEl, slots.default);
  return /* @__PURE__ */ React.createElement("div", _extends$l({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), /* @__PURE__ */ React.createElement("div", {
    className: "navbar-bg"
  }), slots["before-inner"], innerEl, slots["after-inner"]);
});
Navbar.displayName = "f7-navbar";
function _extends$k() {
  _extends$k = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$k.apply(this, arguments);
}
const PageContent = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    tab,
    tabActive,
    ptr,
    ptrDistance,
    ptrPreloader = true,
    ptrBottom,
    ptrMousewheel,
    infinite,
    infiniteTop,
    infiniteDistance,
    infinitePreloader = true,
    hideBarsOnScroll,
    hideNavbarOnScroll,
    hideToolbarOnScroll,
    messagesContent,
    loginScreen
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onPtrPullStart = (el) => {
    if (elRef.current !== el) return;
    emit(props, "ptrPullStart");
  };
  const onPtrPullMove = (el) => {
    if (elRef.current !== el) return;
    emit(props, "ptrPullMove");
  };
  const onPtrPullEnd = (el) => {
    if (elRef.current !== el) return;
    emit(props, "ptrPullEnd");
  };
  const onPtrRefresh = (el, done) => {
    if (elRef.current !== el) return;
    emit(props, "ptrRefresh", done);
  };
  const onPtrDone = (el) => {
    if (elRef.current !== el) return;
    emit(props, "ptrDone");
  };
  const onInfinite = (el) => {
    if (elRef.current !== el) return;
    emit(props, "infinite");
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  useTab(elRef, props);
  const attachEvents = () => {
    f7ready(() => {
      if (ptr) {
        f7.on("ptrPullStart", onPtrPullStart);
        f7.on("ptrPullMove", onPtrPullMove);
        f7.on("ptrPullEnd", onPtrPullEnd);
        f7.on("ptrRefresh", onPtrRefresh);
        f7.on("ptrDone", onPtrDone);
      }
      if (infinite) {
        f7.on("infinite", onInfinite);
      }
    });
  };
  const detachEvents = () => {
    if (!f7) return;
    f7.off("ptrPullStart", onPtrPullStart);
    f7.off("ptrPullMove", onPtrPullMove);
    f7.off("ptrPullEnd", onPtrPullEnd);
    f7.off("ptrRefresh", onPtrRefresh);
    f7.off("ptrDone", onPtrDone);
    f7.off("infinite", onInfinite);
  };
  useIsomorphicLayoutEffect(() => {
    attachEvents();
    return detachEvents;
  });
  let ptrEl;
  let infiniteEl;
  if (ptr && ptrPreloader) {
    ptrEl = /* @__PURE__ */ React.createElement("div", {
      className: "ptr-preloader"
    }, /* @__PURE__ */ React.createElement(Preloader, null), /* @__PURE__ */ React.createElement("div", {
      className: "ptr-arrow"
    }));
  }
  if (infinite && infinitePreloader) {
    infiniteEl = /* @__PURE__ */ React.createElement(Preloader, {
      className: "infinite-scroll-preloader"
    });
  }
  const classes = classNames(className, "page-content", {
    tab,
    "tab-active": tabActive,
    "ptr-content": ptr,
    "ptr-bottom": ptrBottom,
    "infinite-scroll-content": infinite,
    "infinite-scroll-top": infiniteTop,
    "hide-bars-on-scroll": hideBarsOnScroll,
    "hide-navbar-on-scroll": hideNavbarOnScroll,
    "hide-toolbar-on-scroll": hideToolbarOnScroll,
    "messages-content": messagesContent,
    "login-screen-content": loginScreen
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$k({
    id: id2,
    style,
    className: classes,
    "data-ptr-distance": ptrDistance || void 0,
    "data-ptr-mousewheel": ptrMousewheel || void 0,
    "data-infinite-distance": infiniteDistance || void 0,
    ref: elRef
  }, extraAttrs), ptrBottom ? null : ptrEl, infiniteTop ? infiniteEl : null, children2, infiniteTop ? null : infiniteEl, ptrBottom ? ptrEl : null);
});
PageContent.displayName = "f7-page-content";
function _extends$j() {
  _extends$j = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$j.apply(this, arguments);
}
const Page = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    name: name2,
    withSubnavbar,
    subnavbar,
    withNavbarLarge,
    navbarLarge,
    noNavbar,
    noToolbar,
    tabs,
    pageContent = true,
    noSwipeback,
    ptr,
    ptrDistance,
    ptrPreloader = true,
    ptrBottom,
    ptrMousewheel,
    infinite,
    infiniteTop,
    infiniteDistance,
    infinitePreloader = true,
    hideBarsOnScroll,
    hideNavbarOnScroll,
    hideToolbarOnScroll,
    messagesContent,
    loginScreen,
    onPtrPullStart,
    onPtrPullMove,
    onPtrPullEnd,
    onPtrRefresh,
    onPtrDone,
    onInfinite
  } = props;
  const hasSubnavbar = reactExports.useRef(false);
  const hasNavbarLarge = reactExports.useRef(false);
  const hasNavbarLargeCollapsed = reactExports.useRef(false);
  const hasCardExpandableOpened = reactExports.useRef(false);
  const routerPositionClass = reactExports.useRef("");
  const routerPageRole = reactExports.useRef(null);
  const routerPageRoleDetailRoot = reactExports.useRef(false);
  const routerPageMasterStack = reactExports.useRef(false);
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onPageMounted = (page) => {
    if (elRef.current !== page.el) return;
    emit(props, "pageMounted", page);
  };
  const onPageInit = (page) => {
    if (elRef.current !== page.el) return;
    if (typeof withSubnavbar === "undefined" && typeof subnavbar === "undefined") {
      if (page.$navbarEl && page.$navbarEl.length && page.$navbarEl.find(".subnavbar").length || page.$el.children(".navbar").find(".subnavbar").length) {
        hasSubnavbar.current = true;
      }
    }
    if (typeof withNavbarLarge === "undefined" && typeof navbarLarge === "undefined") {
      if (page.$navbarEl && page.$navbarEl.hasClass("navbar-large")) {
        hasNavbarLarge.current = true;
      }
    }
    emit(props, "pageInit", page);
  };
  const onPageReinit = (page) => {
    if (elRef.current !== page.el) return;
    emit(props, "pageReinit", page);
  };
  const onPageBeforeIn = (page) => {
    if (elRef.current !== page.el) return;
    if (!page.swipeBack) {
      if (page.from === "next") {
        routerPositionClass.current = "page-next";
      }
      if (page.from === "previous") {
        routerPositionClass.current = "page-previous";
      }
    }
    emit(props, "pageBeforeIn", page);
  };
  const onPageBeforeOut = (page) => {
    if (elRef.current !== page.el) return;
    emit(props, "pageBeforeOut", page);
  };
  const onPageAfterOut = (page) => {
    if (elRef.current !== page.el) return;
    if (page.to === "next") {
      routerPositionClass.current = "page-next";
    }
    if (page.to === "previous") {
      routerPositionClass.current = "page-previous";
    }
    emit(props, "pageAfterOut", page);
  };
  const onPageAfterIn = (page) => {
    if (elRef.current !== page.el) return;
    routerPositionClass.current = "page-current";
    emit(props, "pageAfterIn", page);
  };
  const onPageBeforeRemove = (page) => {
    if (elRef.current !== page.el) return;
    emit(props, "pageBeforeRemove", page);
  };
  const onPageBeforeUnmount = (page) => {
    if (elRef.current !== page.el) return;
    emit(props, "pageBeforeUnmount", page);
  };
  const onPagePosition = (pageEl, position) => {
    if (elRef.current !== pageEl) return;
    routerPositionClass.current = `page-${position}`;
  };
  const onPageRole = (pageEl, rolesData) => {
    if (elRef.current !== pageEl) return;
    routerPageRole.current = rolesData.role;
    routerPageRoleDetailRoot.current = rolesData.detailRoot;
  };
  const onPageMasterStack = (pageEl) => {
    if (elRef.current !== pageEl) return;
    routerPageMasterStack.current = true;
  };
  const onPageMasterUnstack = (pageEl) => {
    if (elRef.current !== pageEl) return;
    routerPageMasterStack.current = false;
  };
  const onPageNavbarLargeCollapsed = (pageEl) => {
    if (elRef.current !== pageEl) return;
    hasNavbarLargeCollapsed.current = true;
  };
  const onPageNavbarLargeExpanded = (pageEl) => {
    if (elRef.current !== pageEl) return;
    hasNavbarLargeCollapsed.current = false;
  };
  const onCardOpened = (cardEl, pageEl) => {
    if (elRef.current !== pageEl) return;
    hasCardExpandableOpened.current = true;
  };
  const onCardClose = (cardEl, pageEl) => {
    if (elRef.current !== pageEl) return;
    hasCardExpandableOpened.current = false;
  };
  const onPageTabShow = (pageEl) => {
    if (elRef.current !== pageEl) return;
    emit(props, "pageTabShow");
  };
  const onPageTabHide = (pageEl) => {
    if (elRef.current !== pageEl) return;
    emit(props, "pageTabHide");
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const attachEvents = () => {
    f7ready(() => {
      f7.on("pageMounted", onPageMounted);
      f7.on("pageInit", onPageInit);
      f7.on("pageReinit", onPageReinit);
      f7.on("pageBeforeIn", onPageBeforeIn);
      f7.on("pageBeforeOut", onPageBeforeOut);
      f7.on("pageAfterOut", onPageAfterOut);
      f7.on("pageAfterIn", onPageAfterIn);
      f7.on("pageBeforeRemove", onPageBeforeRemove);
      f7.on("pageBeforeUnmount", onPageBeforeUnmount);
      f7.on("pagePosition", onPagePosition);
      f7.on("pageRole", onPageRole);
      f7.on("pageMasterStack", onPageMasterStack);
      f7.on("pageMasterUnstack", onPageMasterUnstack);
      f7.on("pageNavbarLargeCollapsed", onPageNavbarLargeCollapsed);
      f7.on("pageNavbarLargeExpanded", onPageNavbarLargeExpanded);
      f7.on("cardOpened", onCardOpened);
      f7.on("cardClose", onCardClose);
      f7.on("pageTabShow", onPageTabShow);
      f7.on("pageTabHide", onPageTabHide);
    });
  };
  const detachEvents = () => {
    if (!f7) return;
    f7.off("pageMounted", onPageMounted);
    f7.off("pageInit", onPageInit);
    f7.off("pageReinit", onPageReinit);
    f7.off("pageBeforeIn", onPageBeforeIn);
    f7.off("pageBeforeOut", onPageBeforeOut);
    f7.off("pageAfterOut", onPageAfterOut);
    f7.off("pageAfterIn", onPageAfterIn);
    f7.off("pageBeforeRemove", onPageBeforeRemove);
    f7.off("pageBeforeUnmount", onPageBeforeUnmount);
    f7.off("pagePosition", onPagePosition);
    f7.off("pageRole", onPageRole);
    f7.off("pageMasterStack", onPageMasterStack);
    f7.off("pageMasterUnstack", onPageMasterUnstack);
    f7.off("pageNavbarLargeCollapsed", onPageNavbarLargeCollapsed);
    f7.off("pageNavbarLargeExpanded", onPageNavbarLargeExpanded);
    f7.off("cardOpened", onCardOpened);
    f7.off("cardClose", onCardClose);
    f7.off("pageTabShow", onPageTabShow);
    f7.off("pageTabHide", onPageTabHide);
  };
  useIsomorphicLayoutEffect(() => {
    attachEvents();
    return detachEvents;
  });
  const slots = getSlots(props);
  const fixedList = [];
  const staticList = [];
  const {
    static: slotsStatic,
    fixed: slotsFixed,
    default: slotsDefault
  } = slots;
  const fixedTags = "navbar toolbar tabbar subnavbar searchbar messagebar fab list-index panel".split(" ").map((tagName) => `f7-${tagName}`);
  let hasSubnavbarComputed;
  let hasNavbarLargeComputed;
  let hasMessages = messagesContent;
  if (slotsDefault) {
    slotsDefault.forEach((child) => {
      if (typeof child === "undefined") return;
      let isFixedTag = false;
      const tag = child.type && (child.type.displayName || child.type.name);
      if (!tag) {
        if (pageContent) staticList.push(child);
        return;
      }
      if (tag === "f7-subnavbar") hasSubnavbarComputed = true;
      if (tag === "f7-navbar") {
        if (child.props && child.props.large) hasNavbarLargeComputed = true;
      }
      if (typeof hasMessages === "undefined" && tag === "f7-messages") hasMessages = true;
      if (fixedTags.indexOf(tag) >= 0) {
        isFixedTag = true;
      }
      if (pageContent) {
        if (isFixedTag) fixedList.push(child);
        else staticList.push(child);
      }
    });
  }
  const forceSubnavbar = typeof subnavbar === "undefined" && typeof withSubnavbar === "undefined" ? hasSubnavbarComputed || hasSubnavbar.current : false;
  const forceNavbarLarge = typeof navbarLarge === "undefined" && typeof withNavbarLarge === "undefined" ? hasNavbarLargeComputed || hasNavbarLarge.current : false;
  const classes = classNames(className, "page", routerPositionClass.current, {
    tabs,
    "page-with-subnavbar": subnavbar || withSubnavbar || forceSubnavbar,
    "page-with-navbar-large": navbarLarge || withNavbarLarge || forceNavbarLarge,
    "no-navbar": noNavbar,
    "no-toolbar": noToolbar,
    "no-swipeback": noSwipeback,
    "page-master": routerPageRole.current === "master",
    "page-master-detail": routerPageRole.current === "detail",
    "page-master-detail-root": routerPageRoleDetailRoot.current === true,
    "page-master-stacked": routerPageMasterStack.current === true,
    "page-with-navbar-large-collapsed": hasNavbarLargeCollapsed.current === true,
    "page-with-card-opened": hasCardExpandableOpened.current === true,
    "login-screen-page": loginScreen
  }, colorClasses(props));
  if (!pageContent) {
    return /* @__PURE__ */ React.createElement("div", _extends$j({
      id: id2,
      style,
      className: classes,
      "data-name": name2,
      ref: elRef
    }, extraAttrs), slotsFixed, slotsStatic, slotsDefault);
  }
  const pageContentEl = /* @__PURE__ */ React.createElement(PageContent, {
    ptr,
    ptrDistance,
    ptrPreloader,
    ptrBottom,
    ptrMousewheel,
    infinite,
    infiniteTop,
    infiniteDistance,
    infinitePreloader,
    hideBarsOnScroll,
    hideNavbarOnScroll,
    hideToolbarOnScroll,
    messagesContent: messagesContent || hasMessages,
    loginScreen,
    onPtrPullStart,
    onPtrPullMove,
    onPtrPullEnd,
    onPtrRefresh,
    onPtrDone,
    onInfinite
  }, slotsStatic, staticList);
  return /* @__PURE__ */ React.createElement("div", _extends$j({
    id: id2,
    style,
    className: classes,
    "data-name": name2,
    ref: elRef
  }, extraAttrs), fixedList, slotsFixed, pageContentEl);
});
Page.displayName = "f7-page";
const PhotoBrowser = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7PhotoBrowser = reactExports.useRef(null);
  const {
    init = true,
    params,
    photos,
    thumbs,
    exposition = true,
    expositionHideCaptions = false,
    type,
    navbar = true,
    toolbar = true,
    theme: theme2,
    captionsTheme,
    iconsColor,
    swipeToClose = true,
    pageBackLinkText,
    popupCloseLinkIcon,
    popupCloseLinkText,
    navbarOfText,
    navbarShowCount,
    swiper,
    url,
    routableModals = false,
    virtualSlides = true,
    view,
    renderNavbar,
    renderToolbar,
    renderCaption,
    renderObject,
    renderLazyPhoto,
    renderPhoto,
    renderPage,
    renderPopup,
    renderStandalone,
    renderThumb
  } = props;
  const open = (index2) => {
    return f7PhotoBrowser.current.open(index2);
  };
  const close = () => {
    return f7PhotoBrowser.current.close();
  };
  const expositionToggle = () => {
    return f7PhotoBrowser.current.expositionToggle();
  };
  const expositionEnable = () => {
    return f7PhotoBrowser.current.expositionEnable();
  };
  const expositionDisable = () => {
    return f7PhotoBrowser.current.expositionDisable();
  };
  reactExports.useImperativeHandle(ref, () => ({
    f7PhotoBrowser: () => f7PhotoBrowser.current,
    open,
    close,
    expositionToggle,
    expositionEnable,
    expositionDisable
  }));
  watchProp(photos, (newValue) => {
    const pb = f7PhotoBrowser.current;
    if (!pb) return;
    pb.params.photos = newValue;
    if (pb.opened && pb.swiper) {
      pb.swiper.update();
    }
  });
  watchProp(thumbs, (newValue) => {
    const pb = f7PhotoBrowser.current;
    if (!pb) return;
    pb.params.thumbs = newValue;
    if (pb.opened && pb.thumbsSwiper) {
      pb.thumbsSwiper.update();
    }
  });
  const onMount = () => {
    if (!init) return;
    f7ready(() => {
      let paramsComputed;
      if (typeof params !== "undefined") {
        paramsComputed = params;
      } else {
        paramsComputed = {
          photos,
          thumbs,
          exposition,
          expositionHideCaptions,
          type,
          navbar,
          toolbar,
          theme: theme2,
          captionsTheme,
          iconsColor,
          swipeToClose,
          pageBackLinkText,
          popupCloseLinkText,
          popupCloseLinkIcon,
          navbarOfText,
          navbarShowCount,
          swiper,
          url,
          routableModals,
          virtualSlides,
          view,
          renderNavbar,
          renderToolbar,
          renderCaption,
          renderObject,
          renderLazyPhoto,
          renderPhoto,
          renderPage,
          renderPopup,
          renderStandalone,
          renderThumb
        };
      }
      Object.keys(paramsComputed).forEach((param) => {
        if (typeof paramsComputed[param] === "undefined" || paramsComputed[param] === "") delete paramsComputed[param];
      });
      paramsComputed = extend({}, paramsComputed, {
        on: {
          open() {
            emit(props, "photoBrowserOpen");
          },
          close() {
            emit(props, "photoBrowserClose");
          },
          opened() {
            emit(props, "photoBrowserOpened");
          },
          closed() {
            emit(props, "photoBrowserClosed");
          },
          swipeToClose() {
            emit(props, "photoBrowserSwipeToClose");
          }
        }
      });
      f7PhotoBrowser.current = f7.photoBrowser.create(paramsComputed);
    });
  };
  const onDestroy = () => {
    if (f7PhotoBrowser.current && f7PhotoBrowser.current.destroy) f7PhotoBrowser.current.destroy();
    f7PhotoBrowser.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  return null;
});
PhotoBrowser.displayName = "f7-photo-browser";
function _extends$i() {
  _extends$i = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$i.apply(this, arguments);
}
const PieChart = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    size = 320,
    tooltip = false,
    datasets = [],
    formatTooltip,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const [currentIndex, setCurrentIndex] = reactExports.useState(null);
  const previousIndex = reactExports.useRef(null);
  const elRef = reactExports.useRef(null);
  const f7Tooltip = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const getSummValue = () => {
    let summ = 0;
    datasets.map((d) => d.value || 0).forEach((value2) => {
      summ += value2;
    });
    return summ;
  };
  const getPaths = () => {
    const paths2 = [];
    let cumulativePercentage = 0;
    function getCoordinatesForPercentage(percentage) {
      const x = Math.cos(2 * Math.PI * percentage) * (size / 3);
      const y = Math.sin(2 * Math.PI * percentage) * (size / 3);
      return [x, y];
    }
    datasets.forEach((_ref) => {
      let {
        value: value2,
        label,
        color
      } = _ref;
      const percentage = value2 / getSummValue();
      const [startX, startY] = getCoordinatesForPercentage(cumulativePercentage);
      cumulativePercentage += percentage;
      const [endX, endY] = getCoordinatesForPercentage(cumulativePercentage);
      const largeArcFlag = percentage > 0.5 ? 1 : 0;
      const points = [
        `M ${startX} ${startY}`,
        // Move
        `A ${size / 3} ${size / 3} 0 ${largeArcFlag} 1 ${endX} ${endY}`,
        // Arc
        "L 0 0"
        // Line
      ].join(" ");
      paths2.push({
        points,
        label,
        color
      });
    });
    return paths2;
  };
  const formatTooltipText = () => {
    if (currentIndex === null) return "";
    const {
      value: value2,
      label,
      color
    } = datasets[currentIndex];
    const percentage = value2 / getSummValue() * 100;
    const round = (v) => {
      if (parseInt(v, 10) === v) return v;
      return Math.round(v * 100) / 100;
    };
    if (formatTooltip) {
      return formatTooltip({
        index: currentIndex,
        value: value2,
        label,
        color,
        percentage
      });
    }
    const tooltipText = `${label ? `${label}: ` : ""}${round(value2)} (${round(percentage)}%)`;
    return `
      <div class="pie-chart-tooltip-label">
        <span class="pie-chart-tooltip-color" style="background-color: ${color};"></span> ${tooltipText}
      </div>
    `;
  };
  const setTooltip = () => {
    if (currentIndex === null && !f7Tooltip.current) return;
    if (!tooltip || !elRef.current || !f7) return;
    if (currentIndex !== null && !f7Tooltip.current) {
      f7Tooltip.current = f7.tooltip.create({
        trigger: "manual",
        containerEl: elRef.current,
        targetEl: elRef.current.querySelector(`path[data-index="${currentIndex}"]`),
        text: formatTooltipText(),
        cssClass: "pie-chart-tooltip"
      });
      f7Tooltip.current.show();
      return;
    }
    if (!f7Tooltip.current) return;
    if (currentIndex !== null) {
      f7Tooltip.current.setText(formatTooltipText());
      f7Tooltip.current.setTargetEl(elRef.current.querySelector(`path[data-index="${currentIndex}"]`));
      f7Tooltip.current.show();
    } else {
      f7Tooltip.current.hide();
    }
  };
  reactExports.useEffect(() => {
    if (previousIndex.current === currentIndex) return;
    previousIndex.current = currentIndex;
    emit(props, "select", currentIndex, datasets[currentIndex]);
    setTooltip();
  }, [currentIndex]);
  reactExports.useEffect(() => {
    return () => {
      if (f7Tooltip.current && f7Tooltip.current.destroy) {
        f7Tooltip.current.destroy();
      }
      f7Tooltip.current = null;
    };
  }, []);
  const classes = classNames("pie-chart", className);
  const paths = getPaths();
  return /* @__PURE__ */ React.createElement("div", _extends$i({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), /* @__PURE__ */ React.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: size,
    height: size,
    viewBox: `-${size / 3} -${size / 3} ${size * 2 / 3} ${size * 2 / 3}`,
    style: {
      transform: "rotate(-90deg)"
    }
  }, paths.map((path, index2) => /* @__PURE__ */ React.createElement("path", {
    key: path.label || index2,
    d: path.points,
    fill: path.color,
    "data-index": index2,
    className: classNames({
      "pie-chart-hidden": currentIndex !== null && currentIndex !== index2
    }),
    onClick: () => setCurrentIndex(index2),
    onMouseEnter: () => setCurrentIndex(index2),
    onMouseLeave: () => setCurrentIndex(null)
  }))), children2);
});
PieChart.displayName = "f7-pie-chart";
function _extends$h() {
  _extends$h = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$h.apply(this, arguments);
}
const Progressbar = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    progress,
    infinite
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const set = (newProgress, speed) => {
    if (!f7) return;
    f7.progressbar.set(elRef.current, newProgress, speed);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    set
  }));
  const transformStyle = {
    transform: progress ? `translate3d(${-100 + progress}%, 0, 0)` : "",
    WebkitTransform: progress ? `translate3d(${-100 + progress}%, 0, 0)` : ""
  };
  const classes = classNames(className, "progressbar", {
    "progressbar-infinite": infinite
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("span", _extends$h({
    ref: elRef,
    id: id2,
    style,
    className: classes,
    "data-progress": progress
  }, extraAttrs), /* @__PURE__ */ React.createElement("span", {
    style: transformStyle
  }));
});
Progressbar.displayName = "f7-progressbar";
function _extends$g() {
  _extends$g = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$g.apply(this, arguments);
}
const Radio = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    value: value2,
    disabled,
    readonly,
    checked,
    defaultChecked
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onChange = (event) => {
    emit(props, "change", event);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const inputEl = /* @__PURE__ */ React.createElement("input", {
    type: "radio",
    name,
    value: value2,
    disabled,
    readOnly: readonly,
    checked,
    defaultChecked,
    onChange
  });
  const iconEl = /* @__PURE__ */ React.createElement("i", {
    className: "icon-radio"
  });
  const classes = classNames(className, "radio", {
    disabled
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("label", _extends$g({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), inputEl, iconEl, children2);
});
Radio.displayName = "f7-radio";
function _extends$f() {
  _extends$f = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$f.apply(this, arguments);
}
const Searchbar = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7Searchbar = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    outline = true,
    form = true,
    placeholder = "Search",
    spellcheck,
    disableButton = true,
    disableButtonText = "Cancel",
    clearButton = true,
    // Input Value
    value: value2,
    // SB Params
    inputEvents = "change input compositionend",
    expandable,
    inline,
    searchContainer,
    searchIn = ".item-title",
    searchItem = "li",
    searchGroup = ".list-group",
    searchGroupTitle = ".list-group-title",
    foundEl = ".searchbar-found",
    notFoundEl = ".searchbar-not-found",
    backdrop,
    backdropEl,
    hideOnEnableEl = ".searchbar-hide-on-enable",
    hideOnSearchEl = ".searchbar-hide-on-search",
    ignore = ".searchbar-ignore",
    customSearch = false,
    removeDiacritics = false,
    hideGroupTitles = true,
    hideGroups = true,
    init = true
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const search = (query) => {
    if (!f7Searchbar.current) return void 0;
    return f7Searchbar.current.search(query);
  };
  const enable = () => {
    if (!f7Searchbar.current) return void 0;
    return f7Searchbar.current.enable();
  };
  const disable = () => {
    if (!f7Searchbar.current) return void 0;
    return f7Searchbar.current.disable();
  };
  const toggle = () => {
    if (!f7Searchbar.current) return void 0;
    return f7Searchbar.current.toggle();
  };
  const clear = () => {
    if (!f7Searchbar.current) return void 0;
    return f7Searchbar.current.clear();
  };
  const onChange = (event) => {
    emit(props, "change", event);
  };
  const onInput = (event) => {
    emit(props, "input", event);
  };
  const onFocus = (event) => {
    emit(props, "focus", event);
  };
  const onBlur = (event) => {
    emit(props, "blur", event);
  };
  const onSubmit = (event) => {
    emit(props, "submit", event);
  };
  const onClearButtonClick = (event) => {
    emit(props, "click:clear clickClear", event);
  };
  const onDisableButtonClick = (event) => {
    emit(props, "click:disable clickDisable", event);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7Searchbar: () => f7Searchbar.current,
    search,
    enable,
    disable,
    toggle,
    clear
  }));
  const onMount = () => {
    if (!init) return;
    f7ready(() => {
      const params = noUndefinedProps({
        el: elRef.current,
        inputEvents,
        searchContainer,
        searchIn,
        searchItem,
        searchGroup,
        searchGroupTitle,
        hideOnEnableEl,
        hideOnSearchEl,
        foundEl,
        notFoundEl,
        backdrop,
        backdropEl,
        disableButton,
        ignore,
        customSearch,
        removeDiacritics,
        hideGroupTitles,
        hideGroups,
        expandable,
        inline,
        on: {
          search(searchbar, query, previousQuery) {
            emit(props, "searchbarSearch", searchbar, query, previousQuery);
          },
          clear(searchbar, previousQuery) {
            emit(props, "searchbarClear", searchbar, previousQuery);
          },
          enable(searchbar) {
            emit(props, "searchbarEnable", searchbar);
          },
          disable(searchbar) {
            emit(props, "searchbarDisable", searchbar);
          }
        }
      });
      Object.keys(params).forEach((key) => {
        if (params[key] === "") {
          delete params[key];
        }
      });
      f7Searchbar.current = f7.searchbar.create(params);
    });
  };
  const onDestroy = () => {
    if (f7Searchbar.current && f7Searchbar.current.destroy) f7Searchbar.current.destroy();
    f7Searchbar.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  let clearEl;
  let disableEl;
  if (clearButton) {
    clearEl = /* @__PURE__ */ React.createElement("span", {
      className: "input-clear-button",
      onClick: onClearButtonClick
    });
  }
  if (disableButton) {
    disableEl = /* @__PURE__ */ React.createElement("span", {
      className: "searchbar-disable-button",
      onClick: onDisableButtonClick
    }, disableButtonText);
  }
  const SearchbarTag = form ? "form" : "div";
  const classes = classNames(className, "searchbar", {
    "searchbar-inline": inline,
    "no-outline": !outline,
    "searchbar-expandable": expandable
  }, colorClasses(props));
  const slots = getSlots(props);
  return /* @__PURE__ */ React.createElement(SearchbarTag, _extends$f({
    ref: elRef,
    id: id2,
    style,
    className: classes
  }, extraAttrs, {
    onSubmit
  }), slots["before-inner"], /* @__PURE__ */ React.createElement("div", {
    className: "searchbar-inner"
  }, slots["inner-start"], /* @__PURE__ */ React.createElement("div", {
    className: "searchbar-input-wrap"
  }, slots["input-wrap-start"], /* @__PURE__ */ React.createElement("input", {
    value: value2,
    placeholder,
    spellCheck: spellcheck,
    type: "search",
    onInput,
    onChange,
    onFocus,
    onBlur
  }), /* @__PURE__ */ React.createElement("i", {
    className: "searchbar-icon"
  }), clearEl, slots["input-wrap-end"]), disableEl, slots["inner-end"], slots.default), slots["after-inner"]);
});
Searchbar.displayName = "f7-searchbar";
function _extends$e() {
  _extends$e = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$e.apply(this, arguments);
}
const Segmented = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    raised,
    raisedIos,
    raisedMd,
    round,
    roundIos,
    roundMd,
    strong,
    strongIos,
    strongMd,
    tag = "div"
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, {
    segmented: true,
    "segmented-raised": raised,
    "segmented-raised-ios": raisedIos,
    "segmented-raised-md": raisedMd,
    "segmented-round": round,
    "segmented-round-ios": roundIos,
    "segmented-round-md": roundMd,
    "segmented-strong": strong,
    "segmented-strong-ios": strongIos,
    "segmented-strong-md": strongMd
  }, colorClasses(props));
  const SegmentedTag = tag;
  return /* @__PURE__ */ React.createElement(SegmentedTag, _extends$e({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2, (strong || strongIos || strongMd) && /* @__PURE__ */ React.createElement("span", {
    className: "segmented-highlight"
  }));
});
Segmented.displayName = "f7-segmented";
function _extends$d() {
  _extends$d = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$d.apply(this, arguments);
}
const SkeletonBlock = ({
  tag: Tag = "div",
  width: width2,
  height: height2,
  borderRadius,
  effect,
  className,
  style,
  children: children2,
  ...other
} = {}) => {
  const skeletonStyle = style || {};
  if (width2) skeletonStyle.width = width2;
  if (height2) skeletonStyle.height = height2;
  if (borderRadius) skeletonStyle.borderRadius = borderRadius;
  const skeletonClassName = ["skeleton-block", effect && `skeleton-effect-${effect}`, className].filter((c) => !!c).join(" ");
  return /* @__PURE__ */ React.createElement(Tag, _extends$d({
    style: skeletonStyle,
    className: skeletonClassName
  }, other), children2);
};
function _extends$c() {
  _extends$c = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$c.apply(this, arguments);
}
const SkeletonText = ({
  tag: Tag = "span",
  effect,
  className,
  children: children2,
  ...other
} = {}) => {
  const skeletonClassName = ["skeleton-text", effect && `skeleton-effect-${effect}`, className].filter((c) => !!c).join(" ");
  return /* @__PURE__ */ React.createElement(Tag, _extends$c({
    className: skeletonClassName
  }, other), children2);
};
function multiplySvgPoints(pointsString, iconSize, width2, height2) {
  const iconMaxSize = Math.min(width2, height2) * 0.5;
  const scale = iconMaxSize / iconSize;
  return pointsString.replace(/([0-9,\.]{1,})/g, (coords) => {
    coords = coords.split(",").map((p) => parseFloat(p));
    const x = coords[0] * scale + width2 / 2 - iconSize * scale / 2;
    const y = coords[1] * scale + height2 / 2 - iconSize * scale / 2;
    if (iconMaxSize >= 100) {
      return `${Math.round(x)},${Math.round(y)}`;
    }
    return `${x},${y}`;
  });
}
function _extends$b() {
  _extends$b = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$b.apply(this, arguments);
}
const SkeletonImage = ({
  tag: Tag = "span",
  width: width2 = 1200,
  height: height2 = 600,
  borderRadius,
  color,
  iconColor,
  showIcon = true,
  effect,
  className,
  children: children2,
  ...other
} = {}) => {
  const skeletonClassName = ["skeleton-image", effect && `skeleton-effect-${effect}`, className].filter((c) => !!c).join(" ");
  function multiplyPoints(pointsString) {
    return multiplySvgPoints(pointsString, 56, width2, height2);
  }
  return /* @__PURE__ */ React.createElement(Tag, _extends$b({
    className: skeletonClassName
  }, other), /* @__PURE__ */ React.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width2,
    height: height2,
    viewBox: `0 0 ${width2} ${height2}`,
    style: {
      borderRadius
    },
    preserveAspectRatio: "none"
  }, /* @__PURE__ */ React.createElement("polygon", {
    style: {
      fill: color
    },
    fillRule: "evenodd",
    points: `0 0 ${width2} 0 ${width2} ${height2} 0 ${height2}`
  }), showIcon && /* @__PURE__ */ React.createElement("path", {
    style: {
      fill: iconColor
    },
    d: multiplyPoints("M7.7148,49.5742 L48.2852,49.5742 C53.1836,49.5742 55.6446,47.1367 55.6446,42.3086 L55.6446,13.6914 C55.6446,8.8633 53.1836,6.4258 48.2852,6.4258 L7.7148,6.4258 C2.8398,6.4258 0.3554,8.8398 0.3554,13.6914 L0.3554,42.3086 C0.3554,47.1602 2.8398,49.5742 7.7148,49.5742 Z M39.2851,27.9414 C38.2304,27.0039 37.0351,26.5118 35.7695,26.5118 C34.457,26.5118 33.3085,26.9571 32.2304,27.918 L21.6366,37.3867 L17.3007,33.4492 C16.3163,32.582 15.2617,32.1133 14.1366,32.1133 C13.1054,32.1133 12.0976,32.5586 11.1366,33.4258 L4.1288,39.7305 L4.1288,13.8789 C4.1288,11.4414 5.4413,10.1992 7.7851,10.1992 L48.2147,10.1992 C50.535,10.1992 51.8708,11.4414 51.8708,13.8789 L51.8708,39.7539 L39.2851,27.9414 Z M17.8163,28.1992 C20.8398,28.1992 23.3241,25.7149 23.3241,22.668 C23.3241,19.6445 20.8398,17.1367 17.8163,17.1367 C14.7695,17.1367 12.2851,19.6445 12.2851,22.668 C12.2851,25.7149 14.7695,28.1992 17.8163,28.1992 Z")
  })), children2);
};
function _extends$a() {
  _extends$a = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$a.apply(this, arguments);
}
const SkeletonAvatar = ({
  tag: Tag = "span",
  size = 48,
  color,
  showIcon = true,
  iconColor,
  borderRadius = "50%",
  effect,
  className,
  children: children2,
  ...other
} = {}) => {
  const skeletonClassName = ["skeleton-avatar", effect && `skeleton-effect-${effect}`, className].filter((c) => !!c).join(" ");
  function multiplyPoints(pointsString) {
    return multiplySvgPoints(pointsString, 56, size, size);
  }
  return /* @__PURE__ */ React.createElement(Tag, _extends$a({
    className: skeletonClassName
  }, other), /* @__PURE__ */ React.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: size,
    height: size,
    viewBox: `0 0 ${size} ${size}`,
    preserveAspectRatio: "none"
  }, /* @__PURE__ */ React.createElement("rect", {
    width: size,
    height: size,
    fillRule: "evenodd",
    style: {
      fill: color
    },
    rx: borderRadius
  }), showIcon && /* @__PURE__ */ React.createElement("path", {
    style: {
      fill: iconColor
    },
    d: multiplyPoints("M28.22461,27.1590817 C34.9209931,27.1590817 40.6829044,21.1791004 40.6829044,13.3926332 C40.6829044,5.69958662 34.8898972,0 28.22461,0 C21.5594557,0 15.7663156,5.82423601 15.7663156,13.4549579 C15.7663156,21.1791004 21.5594557,27.1590817 28.22461,27.1590817 Z M8.66515427,56 L47.7841986,56 C52.6739629,56 54.4181241,54.5984253 54.4181241,51.8576005 C54.4181241,43.8219674 44.358068,32.7341519 28.22461,32.7341519 C12.0600561,32.7341519 2,43.8219674 2,51.8576005 C2,54.5984253 3.74402832,56 8.66515427,56 Z")
  })), children2);
};
function _extends$9() {
  _extends$9 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$9.apply(this, arguments);
}
const Stepper = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const f7Stepper = reactExports.useRef(null);
  const {
    className,
    id: id2,
    style,
    init = true,
    value: value2 = 0,
    min = 0,
    max = 100,
    step = 1,
    formatValue,
    name: name2,
    inputId,
    input = true,
    inputType = "text",
    inputReadonly = false,
    autorepeat = false,
    autorepeatDynamic = false,
    wraps = false,
    manualInputMode = false,
    decimalPoint = 4,
    buttonsEndInputMode = true,
    disabled,
    buttonsOnly,
    round,
    roundMd,
    roundIos,
    fill,
    fillMd,
    fillIos,
    large,
    largeMd,
    largeIos,
    small,
    smallMd,
    smallIos,
    raised,
    raisedMd,
    raisedIos
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const increment = () => {
    if (!f7Stepper.current) return;
    f7Stepper.current.increment();
  };
  const decrement = () => {
    if (!f7Stepper.current) return;
    f7Stepper.current.decrement();
  };
  const setValue = (newValue) => {
    if (f7Stepper.current && f7Stepper.current.setValue) f7Stepper.current.setValue(newValue);
  };
  const getValue = () => {
    if (f7Stepper.current && f7Stepper.current.getValue) {
      return f7Stepper.current.getValue();
    }
    return void 0;
  };
  const onInput = (event) => {
    emit(props, "input", event, f7Stepper.current);
  };
  const onChange = (event) => {
    emit(props, "change", event, f7Stepper.current);
  };
  const onMinusClick = (event) => {
    emit(props, "stepperMinusClick", event, f7Stepper.current);
  };
  const onPlusClick = (event) => {
    emit(props, "stepperPlusClick", event, f7Stepper.current);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    f7Stepper: () => f7Stepper.current,
    increment,
    decrement,
    setValue,
    getValue
  }));
  watchProp(value2, (newValue) => {
    if (!f7Stepper.current) return;
    f7Stepper.current.setValue(newValue);
  });
  const onStepperChange = (stepper, newValue) => {
    emit(props, "stepperChange", newValue);
  };
  const stepperEvents = (method) => {
    if (!f7Stepper.current) return;
    f7Stepper.current[method]("change", onStepperChange);
  };
  const onMount = () => {
    f7ready(() => {
      if (!init || !elRef.current) return;
      f7Stepper.current = f7.stepper.create(noUndefinedProps({
        el: elRef.current,
        min,
        max,
        value: value2,
        step,
        formatValue,
        autorepeat,
        autorepeatDynamic,
        wraps,
        manualInputMode,
        decimalPoint,
        buttonsEndInputMode
      }));
      stepperEvents("on");
    });
  };
  const onDestroy = () => {
    if (f7Stepper.current && f7Stepper.current.destroy) {
      f7Stepper.current.destroy();
    }
    f7Stepper.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    stepperEvents("on");
    return () => {
      stepperEvents("off");
    };
  });
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  let inputWrapEl;
  let valueEl;
  if (input && !buttonsOnly) {
    const inputEl = /* @__PURE__ */ React.createElement("input", {
      name: name2,
      id: inputId,
      type: inputType,
      min: inputType === "number" ? min : void 0,
      max: inputType === "number" ? max : void 0,
      step: inputType === "number" ? step : void 0,
      onInput,
      onChange,
      value: value2,
      readOnly: inputReadonly
    });
    inputWrapEl = /* @__PURE__ */ React.createElement("div", {
      className: "stepper-input-wrap"
    }, inputEl);
  }
  if (!input && !buttonsOnly) {
    valueEl = /* @__PURE__ */ React.createElement("div", {
      className: "stepper-value"
    }, value2);
  }
  const classes = classNames(className, "stepper", {
    disabled,
    "stepper-round": round,
    "stepper-round-ios": roundIos,
    "stepper-round-md": roundMd,
    "stepper-fill": fill,
    "stepper-fill-ios": fillIos,
    "stepper-fill-md": fillMd,
    "stepper-large": large,
    "stepper-large-ios": largeIos,
    "stepper-large-md": largeMd,
    "stepper-small": small,
    "stepper-small-ios": smallIos,
    "stepper-small-md": smallMd,
    "stepper-raised": raised,
    "stepper-raised-ios": raisedIos,
    "stepper-raised-md": raisedMd
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$9({
    ref: elRef,
    id: id2,
    style,
    className: classes
  }, extraAttrs), /* @__PURE__ */ React.createElement("div", {
    className: "stepper-button-minus",
    onClick: onMinusClick
  }), inputWrapEl, valueEl, /* @__PURE__ */ React.createElement("div", {
    className: "stepper-button-plus",
    onClick: onPlusClick
  }));
});
Stepper.displayName = "f7-stepper";
function _extends$8() {
  _extends$8 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$8.apply(this, arguments);
}
const Subnavbar = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    inner = true,
    title: title2,
    sliding
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "subnavbar", {
    sliding
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$8({
    className: classes,
    id: id2,
    style,
    ref: elRef
  }, extraAttrs), inner ? /* @__PURE__ */ React.createElement("div", {
    className: "subnavbar-inner"
  }, title2 && /* @__PURE__ */ React.createElement("div", {
    className: "subnavbar-title"
  }, title2), children2) : children2);
});
Subnavbar.displayName = "f7-subnavbar";
function _extends$7() {
  _extends$7 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$7.apply(this, arguments);
}
const SwipeoutActions = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    left,
    right,
    side
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  let sideComputed = side;
  if (!sideComputed) {
    if (left) sideComputed = "left";
    if (right) sideComputed = "right";
  }
  const classes = classNames(className, `swipeout-actions-${sideComputed}`, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$7({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
SwipeoutActions.displayName = "f7-swipeout-actions";
function _extends$6() {
  _extends$6 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$6.apply(this, arguments);
}
const SwipeoutButton = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    text: text2,
    confirmTitle,
    confirmText,
    overswipe,
    close,
    delete: deleteProp,
    href
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onClick = (e) => {
    emit(props, "click", e);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, {
    "swipeout-overswipe": overswipe,
    "swipeout-delete": deleteProp,
    "swipeout-close": close
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("a", _extends$6({
    ref: elRef,
    href: href || "#",
    id: id2,
    style,
    "data-confirm": confirmText || void 0,
    "data-confirm-title": confirmTitle || void 0,
    className: classes
  }, extraAttrs, {
    onClick
  }), children2, text2);
});
SwipeoutButton.displayName = "f7-swipeout-button";
const TabsSwipeableContext = /* @__PURE__ */ React.createContext(false);
function _extends$5() {
  _extends$5 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$5.apply(this, arguments);
}
const Tab = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    tabActive
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const routerData = reactExports.useRef(null);
  const routerContext = reactExports.useContext(RouterContext);
  const tabsSwipeableContext = reactExports.useContext(TabsSwipeableContext);
  let initialTabContent = null;
  if (!routerData.current && routerContext && routerContext.route && routerContext.route.route && routerContext.route.route.tab && routerContext.route.route.tab.id === id2) {
    const {
      component,
      asyncComponent: asyncComponent2,
      options: tabRouteOptions
    } = routerContext.route.route.tab;
    if (component || asyncComponent2) {
      const parentProps = routerContext.route.route.options && routerContext.route.route.options.props;
      initialTabContent = {
        id: getComponentId(),
        component: component || asyncComponent2,
        isAsync: !!asyncComponent2,
        props: {
          ...parentProps || {},
          ...tabRouteOptions && tabRouteOptions.props || {},
          f7router: routerContext.router,
          f7route: routerContext.route,
          ...routerContext.route.params
        }
      };
    }
  }
  const [tabContent, setTabContent] = reactExports.useState(initialTabContent || null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  if (f7 && !routerData.current) {
    routerData.current = {
      setTabContent
    };
    f7routers.tabs.push(routerData.current);
  }
  const onMount = () => {
    if (elRef.current && initialTabContent) {
      elRef.current.f7RouterTabLoaded = true;
    }
    f7ready(() => {
      if (!routerData.current) {
        routerData.current = {
          el: elRef.current,
          setTabContent
        };
        f7routers.tabs.push(routerData.current);
      } else {
        routerData.current.el = elRef.current;
      }
    });
  };
  const onDestroy = () => {
    if (!routerData.current) return;
    f7routers.tabs.splice(f7routers.tabs.indexOf(routerData.current), 1);
    routerData.current = null;
  };
  useIsomorphicLayoutEffect(() => {
    onMount();
    return onDestroy;
  }, []);
  useIsomorphicLayoutEffect(() => {
    if (!routerData.current || !f7) return;
    f7events.emit("tabRouterDidUpdate", routerData.current);
  });
  useTab(elRef, props);
  const classes = classNames(className, "tab", {
    "tab-active": tabActive
  }, colorClasses(props));
  const renderChildren = () => {
    if (!tabContent) return children2;
    if (tabContent.isAsync) {
      return useAsyncComponent(tabContent.component, tabContent.props, tabContent.id);
    }
    const TabContent = tabContent.component;
    return /* @__PURE__ */ React.createElement(TabContent, _extends$5({
      key: tabContent.id
    }, tabContent.props));
  };
  const Component = tabsSwipeableContext ? "swiper-slide" : "div";
  const classAttrs = tabsSwipeableContext ? {
    class: classes
  } : {
    className: classes
  };
  return /* @__PURE__ */ React.createElement(Component, _extends$5({
    id: id2,
    style,
    ref: elRef
  }, extraAttrs, classAttrs), renderChildren());
});
Tab.displayName = "f7-tab";
function _extends$4() {
  _extends$4 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$4.apply(this, arguments);
}
const Tabs = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    animated,
    swipeable,
    routable,
    swiperParams
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  useIsomorphicLayoutEffect(() => {
    if (!swipeable || !swiperParams) return;
    if (!elRef.current) return;
    Object.assign(elRef.current, swiperParams);
    elRef.current.initialize();
  }, []);
  const classes = classNames(className, colorClasses(props));
  const tabsClasses = classNames({
    tabs: true,
    "tabs-routable": routable
  });
  if (animated) {
    return /* @__PURE__ */ React.createElement("div", _extends$4({
      id: id2,
      style,
      className: classNames("tabs-animated-wrap", classes),
      ref: elRef
    }, extraAttrs), /* @__PURE__ */ React.createElement("div", {
      className: tabsClasses
    }, children2));
  }
  if (swipeable) {
    return /* @__PURE__ */ React.createElement("swiper-container", _extends$4({
      id: id2,
      style,
      class: classNames(tabsClasses, classes),
      ref: elRef,
      init: swiperParams ? "false" : "true"
    }, extraAttrs), /* @__PURE__ */ React.createElement(TabsSwipeableContext.Provider, {
      value: true
    }, children2));
  }
  return /* @__PURE__ */ React.createElement("div", _extends$4({
    id: id2,
    style,
    className: classNames(tabsClasses, classes),
    ref: elRef
  }, extraAttrs), children2);
});
Tabs.displayName = "f7-tabs";
function _extends$3() {
  _extends$3 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$3.apply(this, arguments);
}
const Toolbar = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    tabbar,
    icons,
    scrollable,
    hidden,
    outline = true,
    position,
    topMd,
    topIos,
    top,
    bottomMd,
    bottomIos,
    bottom,
    inner = true
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onHide = (toolbarEl) => {
    if (elRef.current !== toolbarEl) return;
    emit(props, "toolbarHide");
  };
  const onShow = (toolbarEl) => {
    if (elRef.current !== toolbarEl) return;
    emit(props, "toolbarShow");
  };
  const hide2 = (animate2) => {
    if (!f7) return;
    f7.toolbar.hide(elRef.current, animate2);
  };
  const show2 = (animate2) => {
    if (!f7) return;
    f7.toolbar.show(elRef.current, animate2);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current,
    hide: hide2,
    show: show2
  }));
  useIsomorphicLayoutEffect(() => {
    f7ready(() => {
      if (tabbar && f7 && elRef.current) {
        f7.toolbar.setHighlight(elRef.current);
      }
      f7.on("toolbarShow", onShow);
      f7.on("toolbarHide", onHide);
    });
    return () => {
      if (!f7) return;
      f7.off("toolbarShow", onShow);
      f7.off("toolbarHide", onHide);
    };
  });
  const theme2 = useTheme();
  const classes = classNames(className, "toolbar", {
    tabbar,
    "toolbar-bottom": theme2 && theme2.md && bottomMd || theme2 && theme2.ios && bottomIos || bottom || position === "bottom",
    "toolbar-top": theme2 && theme2.md && topMd || theme2 && theme2.ios && topIos || top || position === "top",
    "tabbar-icons": icons,
    "tabbar-scrollable": scrollable,
    "toolbar-hidden": hidden,
    "no-outline": !outline
  }, colorClasses(props));
  const slots = getSlots(props);
  return /* @__PURE__ */ React.createElement("div", _extends$3({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), /* @__PURE__ */ React.createElement(TabbarContext.Provider, {
    value: {
      tabbarHasIcons: icons
    }
  }, slots["before-inner"], inner ? /* @__PURE__ */ React.createElement("div", {
    className: "toolbar-inner"
  }, slots.default) : slots.default, slots["after-inner"]));
});
Toolbar.displayName = "f7-toolbar";
function _extends$2() {
  _extends$2 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$2.apply(this, arguments);
}
const TreeviewItem = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    toggle,
    itemToggle,
    selectable,
    selected,
    opened,
    label,
    loadChildren,
    link
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  const onClick = (event) => {
    emit(props, "click", event);
  };
  const onOpen2 = (el) => {
    if (elRef.current !== el) return;
    emit(props, "treeviewOpen", el);
  };
  const onClose2 = (el) => {
    if (elRef.current !== el) return;
    emit(props, "treeviewClose", el);
  };
  const onLoadChildren = (el, done) => {
    if (elRef.current !== el) return;
    emit(props, "treeviewLoadChildren", el, done);
  };
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const attachEvents = () => {
    if (!elRef.current) return;
    f7ready(() => {
      f7.on("treeviewOpen", onOpen2);
      f7.on("treeviewClose", onClose2);
      f7.on("treeviewLoadChildren", onLoadChildren);
    });
  };
  const detachEvents = () => {
    if (!f7) return;
    f7.off("treeviewOpen", onOpen2);
    f7.off("treeviewClose", onClose2);
    f7.off("treeviewLoadChildren", onLoadChildren);
  };
  useIsomorphicLayoutEffect(() => {
    attachEvents();
    return detachEvents;
  });
  const slots = getSlots(props);
  const hasChildren = slots.default && slots.default.length || slots.children && slots.children.length || slots["children-start"] && slots["children-start"].length;
  const needToggle = typeof toggle === "undefined" ? hasChildren : toggle;
  const iconEl = useIcon(props);
  const TreeviewRootTag = link || link === "" ? "a" : "div";
  const classes = classNames(className, "treeview-item", {
    "treeview-item-opened": opened,
    "treeview-load-children": loadChildren
  }, colorClasses(props));
  const itemRootClasses = classNames("treeview-item-root", {
    "treeview-item-selectable": selectable,
    "treeview-item-selected": selected,
    "treeview-item-toggle": itemToggle
  }, routerClasses(props), actionsClasses(props));
  let href = link;
  if (link === true) href = "#";
  if (link === false) href = void 0;
  const itemRootAttrs = {
    href,
    ...routerAttrs(props),
    ...actionsAttrs(props)
  };
  return /* @__PURE__ */ React.createElement("div", _extends$2({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), /* @__PURE__ */ React.createElement(TreeviewRootTag, _extends$2({
    onClick,
    className: itemRootClasses
  }, itemRootAttrs), slots["root-start"], needToggle && /* @__PURE__ */ React.createElement("div", {
    className: "treeview-toggle"
  }), /* @__PURE__ */ React.createElement("div", {
    className: "treeview-item-content"
  }, slots["content-start"], iconEl, slots.media, /* @__PURE__ */ React.createElement("div", {
    className: "treeview-item-label"
  }, slots["label-start"], label, slots.label), slots.content, slots["content-end"]), slots.root, slots["root-end"]), hasChildren && /* @__PURE__ */ React.createElement("div", {
    className: "treeview-item-children"
  }, slots["children-start"], slots.default, slots.children));
});
TreeviewItem.displayName = "f7-treeview-item";
function _extends$1() {
  _extends$1 = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends$1.apply(this, arguments);
}
const Treeview = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "treeview", colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends$1({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
Treeview.displayName = "f7-treeview";
function _extends() {
  _extends = Object.assign ? Object.assign.bind() : function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}
const Views = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    className,
    id: id2,
    style,
    children: children2,
    tabs
  } = props;
  const extraAttrs = getExtraAttrs(props);
  const elRef = reactExports.useRef(null);
  reactExports.useImperativeHandle(ref, () => ({
    el: elRef.current
  }));
  const classes = classNames(className, "views", {
    tabs
  }, colorClasses(props));
  return /* @__PURE__ */ React.createElement("div", _extends({
    id: id2,
    style,
    className: classes,
    ref: elRef
  }, extraAttrs), children2);
});
Views.displayName = "f7-views";
const f7react = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionToggle,
  Actions,
  ActionsButton: ComponentName,
  ActionsGroup,
  ActionsLabel,
  App: App$1,
  AreaChart,
  Badge,
  Block,
  BlockFooter,
  BlockHeader,
  BlockTitle,
  Breadcrumbs,
  BreadcrumbsCollapsed,
  BreadcrumbsItem,
  BreadcrumbsSeparator,
  Button,
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  Checkbox,
  Chip,
  Fab,
  FabBackdrop,
  FabButton,
  FabButtons,
  Gauge,
  Icon,
  Input,
  Link,
  List,
  ListButton,
  ListGroup,
  ListIndex,
  ListInput,
  ListItem,
  ListItemContent,
  LoginScreen,
  LoginScreenTitle,
  Message,
  Messagebar,
  MessagebarAttachment,
  MessagebarAttachments,
  MessagebarSheet,
  MessagebarSheetImage,
  MessagebarSheetItem,
  Messages,
  MessagesTitle,
  NavLeft,
  NavRight,
  NavTitle,
  NavTitleLarge,
  Navbar,
  Page,
  PageContent,
  Panel,
  PhotoBrowser,
  PieChart,
  Popover,
  Popup,
  Preloader,
  Progressbar,
  Radio,
  Range,
  RoutableModals,
  Searchbar,
  Segmented,
  Sheet,
  SkeletonAvatar,
  SkeletonBlock,
  SkeletonImage,
  SkeletonText,
  Stepper,
  Subnavbar,
  SwipeoutActions,
  SwipeoutButton,
  Tab,
  Tabs,
  TextEditor,
  Toggle,
  Toolbar,
  Treeview,
  TreeviewItem,
  View: View2,
  Views,
  default: Framework7React,
  get f7() {
    return f7;
  },
  f7ready,
  theme,
  useStore
}, Symbol.toStringTag, { value: "Module" }));
const setupEsm = func_remember(async () => {
  setupDdpx();
  Framework7.use(Framework7React);
  const job = Promise.withResolvers();
  f7ready(() => {
    Object.assign(globalThis, { f7 });
    job.resolve(f7react);
  });
  return job.promise;
});
const setupDialog = func_remember(async () => {
  const f7_dialog = await __vitePreload(() => import("./dialog-_ZdTIzfL.js"), true ? [] : void 0).then((m) => m.default);
  await f7.loadModule(f7_dialog);
  return f7.dialog;
});
const setupToast = func_remember(async () => {
  const f7_toast = await __vitePreload(() => import("./toast-Cl-gfNPt.js"), true ? [] : void 0).then((m) => m.default);
  await f7.loadModule(f7_toast);
  return f7.toast;
});
const white = "#ffffff";
const grey = "#f4f4fc";
const black = "#000000";
const primary = "#1f53ba";
const newest = "#00FF0A";
const red = "#F2313E";
const green = "#20D401";
const background = "#F4F4F4";
const title = "#222222";
const text = "#7C7C7C";
const subtext = "#C1C1C1";
const border = "#313335";
const subtitle = "#626a73";
const colors = {
  white,
  grey,
  black,
  primary,
  newest,
  red,
  "secondary-red": "#F2313E",
  green,
  "secondary-green": "#20D401",
  background,
  "pop-background": "#F4F4F4",
  "btn-gradient-start": "#FFD940",
  "btn-gradient-end": "#F7C807",
  title,
  text,
  subtext,
  "number-bg": "#28292C",
  "footer-bg": "#1A1C1F",
  border,
  subtitle,
  "stepper-bg": "#36393D",
  "": ""
};
var client = {};
var reactDom = { exports: {} };
var reactDom_production_min = {};
var scheduler = { exports: {} };
var scheduler_production_min = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var hasRequiredScheduler_production_min;
function requireScheduler_production_min() {
  if (hasRequiredScheduler_production_min) return scheduler_production_min;
  hasRequiredScheduler_production_min = 1;
  (function(exports) {
    function f(a, b) {
      var c = a.length;
      a.push(b);
      a: for (; 0 < c; ) {
        var d = c - 1 >>> 1, e = a[d];
        if (0 < g(e, b)) a[d] = b, a[c] = e, c = d;
        else break a;
      }
    }
    function h(a) {
      return 0 === a.length ? null : a[0];
    }
    function k(a) {
      if (0 === a.length) return null;
      var b = a[0], c = a.pop();
      if (c !== b) {
        a[0] = c;
        a: for (var d = 0, e = a.length, w = e >>> 1; d < w; ) {
          var m = 2 * (d + 1) - 1, C = a[m], n = m + 1, x = a[n];
          if (0 > g(C, c)) n < e && 0 > g(x, C) ? (a[d] = x, a[n] = c, d = n) : (a[d] = C, a[m] = c, d = m);
          else if (n < e && 0 > g(x, c)) a[d] = x, a[n] = c, d = n;
          else break a;
        }
      }
      return b;
    }
    function g(a, b) {
      var c = a.sortIndex - b.sortIndex;
      return 0 !== c ? c : a.id - b.id;
    }
    if ("object" === typeof performance && "function" === typeof performance.now) {
      var l = performance;
      exports.unstable_now = function() {
        return l.now();
      };
    } else {
      var p = Date, q = p.now();
      exports.unstable_now = function() {
        return p.now() - q;
      };
    }
    var r = [], t = [], u = 1, v = null, y = 3, z = false, A = false, B = false, D = "function" === typeof setTimeout ? setTimeout : null, E = "function" === typeof clearTimeout ? clearTimeout : null, F = "undefined" !== typeof setImmediate ? setImmediate : null;
    "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
    function G(a) {
      for (var b = h(t); null !== b; ) {
        if (null === b.callback) k(t);
        else if (b.startTime <= a) k(t), b.sortIndex = b.expirationTime, f(r, b);
        else break;
        b = h(t);
      }
    }
    function H(a) {
      B = false;
      G(a);
      if (!A) if (null !== h(r)) A = true, I(J);
      else {
        var b = h(t);
        null !== b && K(H, b.startTime - a);
      }
    }
    function J(a, b) {
      A = false;
      B && (B = false, E(L), L = -1);
      z = true;
      var c = y;
      try {
        G(b);
        for (v = h(r); null !== v && (!(v.expirationTime > b) || a && !M()); ) {
          var d = v.callback;
          if ("function" === typeof d) {
            v.callback = null;
            y = v.priorityLevel;
            var e = d(v.expirationTime <= b);
            b = exports.unstable_now();
            "function" === typeof e ? v.callback = e : v === h(r) && k(r);
            G(b);
          } else k(r);
          v = h(r);
        }
        if (null !== v) var w = true;
        else {
          var m = h(t);
          null !== m && K(H, m.startTime - b);
          w = false;
        }
        return w;
      } finally {
        v = null, y = c, z = false;
      }
    }
    var N = false, O = null, L = -1, P = 5, Q = -1;
    function M() {
      return exports.unstable_now() - Q < P ? false : true;
    }
    function R() {
      if (null !== O) {
        var a = exports.unstable_now();
        Q = a;
        var b = true;
        try {
          b = O(true, a);
        } finally {
          b ? S() : (N = false, O = null);
        }
      } else N = false;
    }
    var S;
    if ("function" === typeof F) S = function() {
      F(R);
    };
    else if ("undefined" !== typeof MessageChannel) {
      var T = new MessageChannel(), U = T.port2;
      T.port1.onmessage = R;
      S = function() {
        U.postMessage(null);
      };
    } else S = function() {
      D(R, 0);
    };
    function I(a) {
      O = a;
      N || (N = true, S());
    }
    function K(a, b) {
      L = D(function() {
        a(exports.unstable_now());
      }, b);
    }
    exports.unstable_IdlePriority = 5;
    exports.unstable_ImmediatePriority = 1;
    exports.unstable_LowPriority = 4;
    exports.unstable_NormalPriority = 3;
    exports.unstable_Profiling = null;
    exports.unstable_UserBlockingPriority = 2;
    exports.unstable_cancelCallback = function(a) {
      a.callback = null;
    };
    exports.unstable_continueExecution = function() {
      A || z || (A = true, I(J));
    };
    exports.unstable_forceFrameRate = function(a) {
      0 > a || 125 < a ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : P = 0 < a ? Math.floor(1e3 / a) : 5;
    };
    exports.unstable_getCurrentPriorityLevel = function() {
      return y;
    };
    exports.unstable_getFirstCallbackNode = function() {
      return h(r);
    };
    exports.unstable_next = function(a) {
      switch (y) {
        case 1:
        case 2:
        case 3:
          var b = 3;
          break;
        default:
          b = y;
      }
      var c = y;
      y = b;
      try {
        return a();
      } finally {
        y = c;
      }
    };
    exports.unstable_pauseExecution = function() {
    };
    exports.unstable_requestPaint = function() {
    };
    exports.unstable_runWithPriority = function(a, b) {
      switch (a) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          a = 3;
      }
      var c = y;
      y = a;
      try {
        return b();
      } finally {
        y = c;
      }
    };
    exports.unstable_scheduleCallback = function(a, b, c) {
      var d = exports.unstable_now();
      "object" === typeof c && null !== c ? (c = c.delay, c = "number" === typeof c && 0 < c ? d + c : d) : c = d;
      switch (a) {
        case 1:
          var e = -1;
          break;
        case 2:
          e = 250;
          break;
        case 5:
          e = 1073741823;
          break;
        case 4:
          e = 1e4;
          break;
        default:
          e = 5e3;
      }
      e = c + e;
      a = { id: u++, callback: b, priorityLevel: a, startTime: c, expirationTime: e, sortIndex: -1 };
      c > d ? (a.sortIndex = c, f(t, a), null === h(r) && a === h(t) && (B ? (E(L), L = -1) : B = true, K(H, c - d))) : (a.sortIndex = e, f(r, a), A || z || (A = true, I(J)));
      return a;
    };
    exports.unstable_shouldYield = M;
    exports.unstable_wrapCallback = function(a) {
      var b = y;
      return function() {
        var c = y;
        y = b;
        try {
          return a.apply(this, arguments);
        } finally {
          y = c;
        }
      };
    };
  })(scheduler_production_min);
  return scheduler_production_min;
}
var hasRequiredScheduler;
function requireScheduler() {
  if (hasRequiredScheduler) return scheduler.exports;
  hasRequiredScheduler = 1;
  {
    scheduler.exports = /* @__PURE__ */ requireScheduler_production_min();
  }
  return scheduler.exports;
}
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var hasRequiredReactDom_production_min;
function requireReactDom_production_min() {
  if (hasRequiredReactDom_production_min) return reactDom_production_min;
  hasRequiredReactDom_production_min = 1;
  var aa = /* @__PURE__ */ requireReact(), ca = /* @__PURE__ */ requireScheduler();
  function p(a) {
    for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++) b += "&args[]=" + encodeURIComponent(arguments[c]);
    return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  var da = /* @__PURE__ */ new Set(), ea = {};
  function fa(a, b) {
    ha(a, b);
    ha(a + "Capture", b);
  }
  function ha(a, b) {
    ea[a] = b;
    for (a = 0; a < b.length; a++) da.add(b[a]);
  }
  var ia = !("undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement), ja = Object.prototype.hasOwnProperty, ka = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, la = {}, ma = {};
  function oa(a) {
    if (ja.call(ma, a)) return true;
    if (ja.call(la, a)) return false;
    if (ka.test(a)) return ma[a] = true;
    la[a] = true;
    return false;
  }
  function pa(a, b, c, d) {
    if (null !== c && 0 === c.type) return false;
    switch (typeof b) {
      case "function":
      case "symbol":
        return true;
      case "boolean":
        if (d) return false;
        if (null !== c) return !c.acceptsBooleans;
        a = a.toLowerCase().slice(0, 5);
        return "data-" !== a && "aria-" !== a;
      default:
        return false;
    }
  }
  function qa(a, b, c, d) {
    if (null === b || "undefined" === typeof b || pa(a, b, c, d)) return true;
    if (d) return false;
    if (null !== c) switch (c.type) {
      case 3:
        return !b;
      case 4:
        return false === b;
      case 5:
        return isNaN(b);
      case 6:
        return isNaN(b) || 1 > b;
    }
    return false;
  }
  function v(a, b, c, d, e, f, g) {
    this.acceptsBooleans = 2 === b || 3 === b || 4 === b;
    this.attributeName = d;
    this.attributeNamespace = e;
    this.mustUseProperty = c;
    this.propertyName = a;
    this.type = b;
    this.sanitizeURL = f;
    this.removeEmptyString = g;
  }
  var z = {};
  "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a) {
    z[a] = new v(a, 0, false, a, null, false, false);
  });
  [["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(a) {
    var b = a[0];
    z[b] = new v(b, 1, false, a[1], null, false, false);
  });
  ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(a) {
    z[a] = new v(a, 2, false, a.toLowerCase(), null, false, false);
  });
  ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(a) {
    z[a] = new v(a, 2, false, a, null, false, false);
  });
  "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a) {
    z[a] = new v(a, 3, false, a.toLowerCase(), null, false, false);
  });
  ["checked", "multiple", "muted", "selected"].forEach(function(a) {
    z[a] = new v(a, 3, true, a, null, false, false);
  });
  ["capture", "download"].forEach(function(a) {
    z[a] = new v(a, 4, false, a, null, false, false);
  });
  ["cols", "rows", "size", "span"].forEach(function(a) {
    z[a] = new v(a, 6, false, a, null, false, false);
  });
  ["rowSpan", "start"].forEach(function(a) {
    z[a] = new v(a, 5, false, a.toLowerCase(), null, false, false);
  });
  var ra = /[\-:]([a-z])/g;
  function sa(a) {
    return a[1].toUpperCase();
  }
  "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a) {
    var b = a.replace(
      ra,
      sa
    );
    z[b] = new v(b, 1, false, a, null, false, false);
  });
  "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a) {
    var b = a.replace(ra, sa);
    z[b] = new v(b, 1, false, a, "http://www.w3.org/1999/xlink", false, false);
  });
  ["xml:base", "xml:lang", "xml:space"].forEach(function(a) {
    var b = a.replace(ra, sa);
    z[b] = new v(b, 1, false, a, "http://www.w3.org/XML/1998/namespace", false, false);
  });
  ["tabIndex", "crossOrigin"].forEach(function(a) {
    z[a] = new v(a, 1, false, a.toLowerCase(), null, false, false);
  });
  z.xlinkHref = new v("xlinkHref", 1, false, "xlink:href", "http://www.w3.org/1999/xlink", true, false);
  ["src", "href", "action", "formAction"].forEach(function(a) {
    z[a] = new v(a, 1, false, a.toLowerCase(), null, true, true);
  });
  function ta(a, b, c, d) {
    var e = z.hasOwnProperty(b) ? z[b] : null;
    if (null !== e ? 0 !== e.type : d || !(2 < b.length) || "o" !== b[0] && "O" !== b[0] || "n" !== b[1] && "N" !== b[1]) qa(b, c, e, d) && (c = null), d || null === e ? oa(b) && (null === c ? a.removeAttribute(b) : a.setAttribute(b, "" + c)) : e.mustUseProperty ? a[e.propertyName] = null === c ? 3 === e.type ? false : "" : c : (b = e.attributeName, d = e.attributeNamespace, null === c ? a.removeAttribute(b) : (e = e.type, c = 3 === e || 4 === e && true === c ? "" : "" + c, d ? a.setAttributeNS(d, b, c) : a.setAttribute(b, c)));
  }
  var ua = aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, va = Symbol.for("react.element"), wa = Symbol.for("react.portal"), ya = Symbol.for("react.fragment"), za = Symbol.for("react.strict_mode"), Aa = Symbol.for("react.profiler"), Ba = Symbol.for("react.provider"), Ca = Symbol.for("react.context"), Da = Symbol.for("react.forward_ref"), Ea = Symbol.for("react.suspense"), Fa = Symbol.for("react.suspense_list"), Ga = Symbol.for("react.memo"), Ha = Symbol.for("react.lazy");
  var Ia = Symbol.for("react.offscreen");
  var Ja = Symbol.iterator;
  function Ka(a) {
    if (null === a || "object" !== typeof a) return null;
    a = Ja && a[Ja] || a["@@iterator"];
    return "function" === typeof a ? a : null;
  }
  var A = Object.assign, La;
  function Ma(a) {
    if (void 0 === La) try {
      throw Error();
    } catch (c) {
      var b = c.stack.trim().match(/\n( *(at )?)/);
      La = b && b[1] || "";
    }
    return "\n" + La + a;
  }
  var Na = false;
  function Oa(a, b) {
    if (!a || Na) return "";
    Na = true;
    var c = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (b) if (b = function() {
        throw Error();
      }, Object.defineProperty(b.prototype, "props", { set: function() {
        throw Error();
      } }), "object" === typeof Reflect && Reflect.construct) {
        try {
          Reflect.construct(b, []);
        } catch (l) {
          var d = l;
        }
        Reflect.construct(a, [], b);
      } else {
        try {
          b.call();
        } catch (l) {
          d = l;
        }
        a.call(b.prototype);
      }
      else {
        try {
          throw Error();
        } catch (l) {
          d = l;
        }
        a();
      }
    } catch (l) {
      if (l && d && "string" === typeof l.stack) {
        for (var e = l.stack.split("\n"), f = d.stack.split("\n"), g = e.length - 1, h = f.length - 1; 1 <= g && 0 <= h && e[g] !== f[h]; ) h--;
        for (; 1 <= g && 0 <= h; g--, h--) if (e[g] !== f[h]) {
          if (1 !== g || 1 !== h) {
            do
              if (g--, h--, 0 > h || e[g] !== f[h]) {
                var k = "\n" + e[g].replace(" at new ", " at ");
                a.displayName && k.includes("<anonymous>") && (k = k.replace("<anonymous>", a.displayName));
                return k;
              }
            while (1 <= g && 0 <= h);
          }
          break;
        }
      }
    } finally {
      Na = false, Error.prepareStackTrace = c;
    }
    return (a = a ? a.displayName || a.name : "") ? Ma(a) : "";
  }
  function Pa(a) {
    switch (a.tag) {
      case 5:
        return Ma(a.type);
      case 16:
        return Ma("Lazy");
      case 13:
        return Ma("Suspense");
      case 19:
        return Ma("SuspenseList");
      case 0:
      case 2:
      case 15:
        return a = Oa(a.type, false), a;
      case 11:
        return a = Oa(a.type.render, false), a;
      case 1:
        return a = Oa(a.type, true), a;
      default:
        return "";
    }
  }
  function Qa(a) {
    if (null == a) return null;
    if ("function" === typeof a) return a.displayName || a.name || null;
    if ("string" === typeof a) return a;
    switch (a) {
      case ya:
        return "Fragment";
      case wa:
        return "Portal";
      case Aa:
        return "Profiler";
      case za:
        return "StrictMode";
      case Ea:
        return "Suspense";
      case Fa:
        return "SuspenseList";
    }
    if ("object" === typeof a) switch (a.$$typeof) {
      case Ca:
        return (a.displayName || "Context") + ".Consumer";
      case Ba:
        return (a._context.displayName || "Context") + ".Provider";
      case Da:
        var b = a.render;
        a = a.displayName;
        a || (a = b.displayName || b.name || "", a = "" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
        return a;
      case Ga:
        return b = a.displayName || null, null !== b ? b : Qa(a.type) || "Memo";
      case Ha:
        b = a._payload;
        a = a._init;
        try {
          return Qa(a(b));
        } catch (c) {
        }
    }
    return null;
  }
  function Ra(a) {
    var b = a.type;
    switch (a.tag) {
      case 24:
        return "Cache";
      case 9:
        return (b.displayName || "Context") + ".Consumer";
      case 10:
        return (b._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return a = b.render, a = a.displayName || a.name || "", b.displayName || ("" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
      case 7:
        return "Fragment";
      case 5:
        return b;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return Qa(b);
      case 8:
        return b === za ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if ("function" === typeof b) return b.displayName || b.name || null;
        if ("string" === typeof b) return b;
    }
    return null;
  }
  function Sa(a) {
    switch (typeof a) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return a;
      case "object":
        return a;
      default:
        return "";
    }
  }
  function Ta(a) {
    var b = a.type;
    return (a = a.nodeName) && "input" === a.toLowerCase() && ("checkbox" === b || "radio" === b);
  }
  function Ua(a) {
    var b = Ta(a) ? "checked" : "value", c = Object.getOwnPropertyDescriptor(a.constructor.prototype, b), d = "" + a[b];
    if (!a.hasOwnProperty(b) && "undefined" !== typeof c && "function" === typeof c.get && "function" === typeof c.set) {
      var e = c.get, f = c.set;
      Object.defineProperty(a, b, { configurable: true, get: function() {
        return e.call(this);
      }, set: function(a2) {
        d = "" + a2;
        f.call(this, a2);
      } });
      Object.defineProperty(a, b, { enumerable: c.enumerable });
      return { getValue: function() {
        return d;
      }, setValue: function(a2) {
        d = "" + a2;
      }, stopTracking: function() {
        a._valueTracker = null;
        delete a[b];
      } };
    }
  }
  function Va(a) {
    a._valueTracker || (a._valueTracker = Ua(a));
  }
  function Wa(a) {
    if (!a) return false;
    var b = a._valueTracker;
    if (!b) return true;
    var c = b.getValue();
    var d = "";
    a && (d = Ta(a) ? a.checked ? "true" : "false" : a.value);
    a = d;
    return a !== c ? (b.setValue(a), true) : false;
  }
  function Xa(a) {
    a = a || ("undefined" !== typeof document ? document : void 0);
    if ("undefined" === typeof a) return null;
    try {
      return a.activeElement || a.body;
    } catch (b) {
      return a.body;
    }
  }
  function Ya(a, b) {
    var c = b.checked;
    return A({}, b, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: null != c ? c : a._wrapperState.initialChecked });
  }
  function Za(a, b) {
    var c = null == b.defaultValue ? "" : b.defaultValue, d = null != b.checked ? b.checked : b.defaultChecked;
    c = Sa(null != b.value ? b.value : c);
    a._wrapperState = { initialChecked: d, initialValue: c, controlled: "checkbox" === b.type || "radio" === b.type ? null != b.checked : null != b.value };
  }
  function ab(a, b) {
    b = b.checked;
    null != b && ta(a, "checked", b, false);
  }
  function bb(a, b) {
    ab(a, b);
    var c = Sa(b.value), d = b.type;
    if (null != c) if ("number" === d) {
      if (0 === c && "" === a.value || a.value != c) a.value = "" + c;
    } else a.value !== "" + c && (a.value = "" + c);
    else if ("submit" === d || "reset" === d) {
      a.removeAttribute("value");
      return;
    }
    b.hasOwnProperty("value") ? cb(a, b.type, c) : b.hasOwnProperty("defaultValue") && cb(a, b.type, Sa(b.defaultValue));
    null == b.checked && null != b.defaultChecked && (a.defaultChecked = !!b.defaultChecked);
  }
  function db(a, b, c) {
    if (b.hasOwnProperty("value") || b.hasOwnProperty("defaultValue")) {
      var d = b.type;
      if (!("submit" !== d && "reset" !== d || void 0 !== b.value && null !== b.value)) return;
      b = "" + a._wrapperState.initialValue;
      c || b === a.value || (a.value = b);
      a.defaultValue = b;
    }
    c = a.name;
    "" !== c && (a.name = "");
    a.defaultChecked = !!a._wrapperState.initialChecked;
    "" !== c && (a.name = c);
  }
  function cb(a, b, c) {
    if ("number" !== b || Xa(a.ownerDocument) !== a) null == c ? a.defaultValue = "" + a._wrapperState.initialValue : a.defaultValue !== "" + c && (a.defaultValue = "" + c);
  }
  var eb = Array.isArray;
  function fb(a, b, c, d) {
    a = a.options;
    if (b) {
      b = {};
      for (var e = 0; e < c.length; e++) b["$" + c[e]] = true;
      for (c = 0; c < a.length; c++) e = b.hasOwnProperty("$" + a[c].value), a[c].selected !== e && (a[c].selected = e), e && d && (a[c].defaultSelected = true);
    } else {
      c = "" + Sa(c);
      b = null;
      for (e = 0; e < a.length; e++) {
        if (a[e].value === c) {
          a[e].selected = true;
          d && (a[e].defaultSelected = true);
          return;
        }
        null !== b || a[e].disabled || (b = a[e]);
      }
      null !== b && (b.selected = true);
    }
  }
  function gb(a, b) {
    if (null != b.dangerouslySetInnerHTML) throw Error(p(91));
    return A({}, b, { value: void 0, defaultValue: void 0, children: "" + a._wrapperState.initialValue });
  }
  function hb(a, b) {
    var c = b.value;
    if (null == c) {
      c = b.children;
      b = b.defaultValue;
      if (null != c) {
        if (null != b) throw Error(p(92));
        if (eb(c)) {
          if (1 < c.length) throw Error(p(93));
          c = c[0];
        }
        b = c;
      }
      null == b && (b = "");
      c = b;
    }
    a._wrapperState = { initialValue: Sa(c) };
  }
  function ib(a, b) {
    var c = Sa(b.value), d = Sa(b.defaultValue);
    null != c && (c = "" + c, c !== a.value && (a.value = c), null == b.defaultValue && a.defaultValue !== c && (a.defaultValue = c));
    null != d && (a.defaultValue = "" + d);
  }
  function jb(a) {
    var b = a.textContent;
    b === a._wrapperState.initialValue && "" !== b && null !== b && (a.value = b);
  }
  function kb(a) {
    switch (a) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function lb(a, b) {
    return null == a || "http://www.w3.org/1999/xhtml" === a ? kb(b) : "http://www.w3.org/2000/svg" === a && "foreignObject" === b ? "http://www.w3.org/1999/xhtml" : a;
  }
  var mb, nb = function(a) {
    return "undefined" !== typeof MSApp && MSApp.execUnsafeLocalFunction ? function(b, c, d, e) {
      MSApp.execUnsafeLocalFunction(function() {
        return a(b, c, d, e);
      });
    } : a;
  }(function(a, b) {
    if ("http://www.w3.org/2000/svg" !== a.namespaceURI || "innerHTML" in a) a.innerHTML = b;
    else {
      mb = mb || document.createElement("div");
      mb.innerHTML = "<svg>" + b.valueOf().toString() + "</svg>";
      for (b = mb.firstChild; a.firstChild; ) a.removeChild(a.firstChild);
      for (; b.firstChild; ) a.appendChild(b.firstChild);
    }
  });
  function ob(a, b) {
    if (b) {
      var c = a.firstChild;
      if (c && c === a.lastChild && 3 === c.nodeType) {
        c.nodeValue = b;
        return;
      }
    }
    a.textContent = b;
  }
  var pb = {
    animationIterationCount: true,
    aspectRatio: true,
    borderImageOutset: true,
    borderImageSlice: true,
    borderImageWidth: true,
    boxFlex: true,
    boxFlexGroup: true,
    boxOrdinalGroup: true,
    columnCount: true,
    columns: true,
    flex: true,
    flexGrow: true,
    flexPositive: true,
    flexShrink: true,
    flexNegative: true,
    flexOrder: true,
    gridArea: true,
    gridRow: true,
    gridRowEnd: true,
    gridRowSpan: true,
    gridRowStart: true,
    gridColumn: true,
    gridColumnEnd: true,
    gridColumnSpan: true,
    gridColumnStart: true,
    fontWeight: true,
    lineClamp: true,
    lineHeight: true,
    opacity: true,
    order: true,
    orphans: true,
    tabSize: true,
    widows: true,
    zIndex: true,
    zoom: true,
    fillOpacity: true,
    floodOpacity: true,
    stopOpacity: true,
    strokeDasharray: true,
    strokeDashoffset: true,
    strokeMiterlimit: true,
    strokeOpacity: true,
    strokeWidth: true
  }, qb = ["Webkit", "ms", "Moz", "O"];
  Object.keys(pb).forEach(function(a) {
    qb.forEach(function(b) {
      b = b + a.charAt(0).toUpperCase() + a.substring(1);
      pb[b] = pb[a];
    });
  });
  function rb(a, b, c) {
    return null == b || "boolean" === typeof b || "" === b ? "" : c || "number" !== typeof b || 0 === b || pb.hasOwnProperty(a) && pb[a] ? ("" + b).trim() : b + "px";
  }
  function sb(a, b) {
    a = a.style;
    for (var c in b) if (b.hasOwnProperty(c)) {
      var d = 0 === c.indexOf("--"), e = rb(c, b[c], d);
      "float" === c && (c = "cssFloat");
      d ? a.setProperty(c, e) : a[c] = e;
    }
  }
  var tb = A({ menuitem: true }, { area: true, base: true, br: true, col: true, embed: true, hr: true, img: true, input: true, keygen: true, link: true, meta: true, param: true, source: true, track: true, wbr: true });
  function ub(a, b) {
    if (b) {
      if (tb[a] && (null != b.children || null != b.dangerouslySetInnerHTML)) throw Error(p(137, a));
      if (null != b.dangerouslySetInnerHTML) {
        if (null != b.children) throw Error(p(60));
        if ("object" !== typeof b.dangerouslySetInnerHTML || !("__html" in b.dangerouslySetInnerHTML)) throw Error(p(61));
      }
      if (null != b.style && "object" !== typeof b.style) throw Error(p(62));
    }
  }
  function vb(a, b) {
    if (-1 === a.indexOf("-")) return "string" === typeof b.is;
    switch (a) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return false;
      default:
        return true;
    }
  }
  var wb = null;
  function xb(a) {
    a = a.target || a.srcElement || window;
    a.correspondingUseElement && (a = a.correspondingUseElement);
    return 3 === a.nodeType ? a.parentNode : a;
  }
  var yb = null, zb = null, Ab = null;
  function Bb(a) {
    if (a = Cb(a)) {
      if ("function" !== typeof yb) throw Error(p(280));
      var b = a.stateNode;
      b && (b = Db(b), yb(a.stateNode, a.type, b));
    }
  }
  function Eb(a) {
    zb ? Ab ? Ab.push(a) : Ab = [a] : zb = a;
  }
  function Fb() {
    if (zb) {
      var a = zb, b = Ab;
      Ab = zb = null;
      Bb(a);
      if (b) for (a = 0; a < b.length; a++) Bb(b[a]);
    }
  }
  function Gb(a, b) {
    return a(b);
  }
  function Hb() {
  }
  var Ib = false;
  function Jb(a, b, c) {
    if (Ib) return a(b, c);
    Ib = true;
    try {
      return Gb(a, b, c);
    } finally {
      if (Ib = false, null !== zb || null !== Ab) Hb(), Fb();
    }
  }
  function Kb(a, b) {
    var c = a.stateNode;
    if (null === c) return null;
    var d = Db(c);
    if (null === d) return null;
    c = d[b];
    a: switch (b) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (d = !d.disabled) || (a = a.type, d = !("button" === a || "input" === a || "select" === a || "textarea" === a));
        a = !d;
        break a;
      default:
        a = false;
    }
    if (a) return null;
    if (c && "function" !== typeof c) throw Error(p(231, b, typeof c));
    return c;
  }
  var Lb = false;
  if (ia) try {
    var Mb = {};
    Object.defineProperty(Mb, "passive", { get: function() {
      Lb = true;
    } });
    window.addEventListener("test", Mb, Mb);
    window.removeEventListener("test", Mb, Mb);
  } catch (a) {
    Lb = false;
  }
  function Nb(a, b, c, d, e, f, g, h, k) {
    var l = Array.prototype.slice.call(arguments, 3);
    try {
      b.apply(c, l);
    } catch (m) {
      this.onError(m);
    }
  }
  var Ob = false, Pb = null, Qb = false, Rb = null, Sb = { onError: function(a) {
    Ob = true;
    Pb = a;
  } };
  function Tb(a, b, c, d, e, f, g, h, k) {
    Ob = false;
    Pb = null;
    Nb.apply(Sb, arguments);
  }
  function Ub(a, b, c, d, e, f, g, h, k) {
    Tb.apply(this, arguments);
    if (Ob) {
      if (Ob) {
        var l = Pb;
        Ob = false;
        Pb = null;
      } else throw Error(p(198));
      Qb || (Qb = true, Rb = l);
    }
  }
  function Vb(a) {
    var b = a, c = a;
    if (a.alternate) for (; b.return; ) b = b.return;
    else {
      a = b;
      do
        b = a, 0 !== (b.flags & 4098) && (c = b.return), a = b.return;
      while (a);
    }
    return 3 === b.tag ? c : null;
  }
  function Wb(a) {
    if (13 === a.tag) {
      var b = a.memoizedState;
      null === b && (a = a.alternate, null !== a && (b = a.memoizedState));
      if (null !== b) return b.dehydrated;
    }
    return null;
  }
  function Xb(a) {
    if (Vb(a) !== a) throw Error(p(188));
  }
  function Yb(a) {
    var b = a.alternate;
    if (!b) {
      b = Vb(a);
      if (null === b) throw Error(p(188));
      return b !== a ? null : a;
    }
    for (var c = a, d = b; ; ) {
      var e = c.return;
      if (null === e) break;
      var f = e.alternate;
      if (null === f) {
        d = e.return;
        if (null !== d) {
          c = d;
          continue;
        }
        break;
      }
      if (e.child === f.child) {
        for (f = e.child; f; ) {
          if (f === c) return Xb(e), a;
          if (f === d) return Xb(e), b;
          f = f.sibling;
        }
        throw Error(p(188));
      }
      if (c.return !== d.return) c = e, d = f;
      else {
        for (var g = false, h = e.child; h; ) {
          if (h === c) {
            g = true;
            c = e;
            d = f;
            break;
          }
          if (h === d) {
            g = true;
            d = e;
            c = f;
            break;
          }
          h = h.sibling;
        }
        if (!g) {
          for (h = f.child; h; ) {
            if (h === c) {
              g = true;
              c = f;
              d = e;
              break;
            }
            if (h === d) {
              g = true;
              d = f;
              c = e;
              break;
            }
            h = h.sibling;
          }
          if (!g) throw Error(p(189));
        }
      }
      if (c.alternate !== d) throw Error(p(190));
    }
    if (3 !== c.tag) throw Error(p(188));
    return c.stateNode.current === c ? a : b;
  }
  function Zb(a) {
    a = Yb(a);
    return null !== a ? $b(a) : null;
  }
  function $b(a) {
    if (5 === a.tag || 6 === a.tag) return a;
    for (a = a.child; null !== a; ) {
      var b = $b(a);
      if (null !== b) return b;
      a = a.sibling;
    }
    return null;
  }
  var ac = ca.unstable_scheduleCallback, bc = ca.unstable_cancelCallback, cc = ca.unstable_shouldYield, dc = ca.unstable_requestPaint, B = ca.unstable_now, ec = ca.unstable_getCurrentPriorityLevel, fc = ca.unstable_ImmediatePriority, gc = ca.unstable_UserBlockingPriority, hc = ca.unstable_NormalPriority, ic = ca.unstable_LowPriority, jc = ca.unstable_IdlePriority, kc = null, lc = null;
  function mc(a) {
    if (lc && "function" === typeof lc.onCommitFiberRoot) try {
      lc.onCommitFiberRoot(kc, a, void 0, 128 === (a.current.flags & 128));
    } catch (b) {
    }
  }
  var oc = Math.clz32 ? Math.clz32 : nc, pc = Math.log, qc = Math.LN2;
  function nc(a) {
    a >>>= 0;
    return 0 === a ? 32 : 31 - (pc(a) / qc | 0) | 0;
  }
  var rc = 64, sc = 4194304;
  function tc(a) {
    switch (a & -a) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return a & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return a & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return a;
    }
  }
  function uc(a, b) {
    var c = a.pendingLanes;
    if (0 === c) return 0;
    var d = 0, e = a.suspendedLanes, f = a.pingedLanes, g = c & 268435455;
    if (0 !== g) {
      var h = g & ~e;
      0 !== h ? d = tc(h) : (f &= g, 0 !== f && (d = tc(f)));
    } else g = c & ~e, 0 !== g ? d = tc(g) : 0 !== f && (d = tc(f));
    if (0 === d) return 0;
    if (0 !== b && b !== d && 0 === (b & e) && (e = d & -d, f = b & -b, e >= f || 16 === e && 0 !== (f & 4194240))) return b;
    0 !== (d & 4) && (d |= c & 16);
    b = a.entangledLanes;
    if (0 !== b) for (a = a.entanglements, b &= d; 0 < b; ) c = 31 - oc(b), e = 1 << c, d |= a[c], b &= ~e;
    return d;
  }
  function vc(a, b) {
    switch (a) {
      case 1:
      case 2:
      case 4:
        return b + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return b + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function wc(a, b) {
    for (var c = a.suspendedLanes, d = a.pingedLanes, e = a.expirationTimes, f = a.pendingLanes; 0 < f; ) {
      var g = 31 - oc(f), h = 1 << g, k = e[g];
      if (-1 === k) {
        if (0 === (h & c) || 0 !== (h & d)) e[g] = vc(h, b);
      } else k <= b && (a.expiredLanes |= h);
      f &= ~h;
    }
  }
  function xc(a) {
    a = a.pendingLanes & -1073741825;
    return 0 !== a ? a : a & 1073741824 ? 1073741824 : 0;
  }
  function yc() {
    var a = rc;
    rc <<= 1;
    0 === (rc & 4194240) && (rc = 64);
    return a;
  }
  function zc(a) {
    for (var b = [], c = 0; 31 > c; c++) b.push(a);
    return b;
  }
  function Ac(a, b, c) {
    a.pendingLanes |= b;
    536870912 !== b && (a.suspendedLanes = 0, a.pingedLanes = 0);
    a = a.eventTimes;
    b = 31 - oc(b);
    a[b] = c;
  }
  function Bc(a, b) {
    var c = a.pendingLanes & ~b;
    a.pendingLanes = b;
    a.suspendedLanes = 0;
    a.pingedLanes = 0;
    a.expiredLanes &= b;
    a.mutableReadLanes &= b;
    a.entangledLanes &= b;
    b = a.entanglements;
    var d = a.eventTimes;
    for (a = a.expirationTimes; 0 < c; ) {
      var e = 31 - oc(c), f = 1 << e;
      b[e] = 0;
      d[e] = -1;
      a[e] = -1;
      c &= ~f;
    }
  }
  function Cc(a, b) {
    var c = a.entangledLanes |= b;
    for (a = a.entanglements; c; ) {
      var d = 31 - oc(c), e = 1 << d;
      e & b | a[d] & b && (a[d] |= b);
      c &= ~e;
    }
  }
  var C = 0;
  function Dc(a) {
    a &= -a;
    return 1 < a ? 4 < a ? 0 !== (a & 268435455) ? 16 : 536870912 : 4 : 1;
  }
  var Ec, Fc, Gc, Hc, Ic, Jc = false, Kc = [], Lc = null, Mc = null, Nc = null, Oc = /* @__PURE__ */ new Map(), Pc = /* @__PURE__ */ new Map(), Qc = [], Rc = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
  function Sc(a, b) {
    switch (a) {
      case "focusin":
      case "focusout":
        Lc = null;
        break;
      case "dragenter":
      case "dragleave":
        Mc = null;
        break;
      case "mouseover":
      case "mouseout":
        Nc = null;
        break;
      case "pointerover":
      case "pointerout":
        Oc.delete(b.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Pc.delete(b.pointerId);
    }
  }
  function Tc(a, b, c, d, e, f) {
    if (null === a || a.nativeEvent !== f) return a = { blockedOn: b, domEventName: c, eventSystemFlags: d, nativeEvent: f, targetContainers: [e] }, null !== b && (b = Cb(b), null !== b && Fc(b)), a;
    a.eventSystemFlags |= d;
    b = a.targetContainers;
    null !== e && -1 === b.indexOf(e) && b.push(e);
    return a;
  }
  function Uc(a, b, c, d, e) {
    switch (b) {
      case "focusin":
        return Lc = Tc(Lc, a, b, c, d, e), true;
      case "dragenter":
        return Mc = Tc(Mc, a, b, c, d, e), true;
      case "mouseover":
        return Nc = Tc(Nc, a, b, c, d, e), true;
      case "pointerover":
        var f = e.pointerId;
        Oc.set(f, Tc(Oc.get(f) || null, a, b, c, d, e));
        return true;
      case "gotpointercapture":
        return f = e.pointerId, Pc.set(f, Tc(Pc.get(f) || null, a, b, c, d, e)), true;
    }
    return false;
  }
  function Vc(a) {
    var b = Wc(a.target);
    if (null !== b) {
      var c = Vb(b);
      if (null !== c) {
        if (b = c.tag, 13 === b) {
          if (b = Wb(c), null !== b) {
            a.blockedOn = b;
            Ic(a.priority, function() {
              Gc(c);
            });
            return;
          }
        } else if (3 === b && c.stateNode.current.memoizedState.isDehydrated) {
          a.blockedOn = 3 === c.tag ? c.stateNode.containerInfo : null;
          return;
        }
      }
    }
    a.blockedOn = null;
  }
  function Xc(a) {
    if (null !== a.blockedOn) return false;
    for (var b = a.targetContainers; 0 < b.length; ) {
      var c = Yc(a.domEventName, a.eventSystemFlags, b[0], a.nativeEvent);
      if (null === c) {
        c = a.nativeEvent;
        var d = new c.constructor(c.type, c);
        wb = d;
        c.target.dispatchEvent(d);
        wb = null;
      } else return b = Cb(c), null !== b && Fc(b), a.blockedOn = c, false;
      b.shift();
    }
    return true;
  }
  function Zc(a, b, c) {
    Xc(a) && c.delete(b);
  }
  function $c() {
    Jc = false;
    null !== Lc && Xc(Lc) && (Lc = null);
    null !== Mc && Xc(Mc) && (Mc = null);
    null !== Nc && Xc(Nc) && (Nc = null);
    Oc.forEach(Zc);
    Pc.forEach(Zc);
  }
  function ad(a, b) {
    a.blockedOn === b && (a.blockedOn = null, Jc || (Jc = true, ca.unstable_scheduleCallback(ca.unstable_NormalPriority, $c)));
  }
  function bd(a) {
    function b(b2) {
      return ad(b2, a);
    }
    if (0 < Kc.length) {
      ad(Kc[0], a);
      for (var c = 1; c < Kc.length; c++) {
        var d = Kc[c];
        d.blockedOn === a && (d.blockedOn = null);
      }
    }
    null !== Lc && ad(Lc, a);
    null !== Mc && ad(Mc, a);
    null !== Nc && ad(Nc, a);
    Oc.forEach(b);
    Pc.forEach(b);
    for (c = 0; c < Qc.length; c++) d = Qc[c], d.blockedOn === a && (d.blockedOn = null);
    for (; 0 < Qc.length && (c = Qc[0], null === c.blockedOn); ) Vc(c), null === c.blockedOn && Qc.shift();
  }
  var cd = ua.ReactCurrentBatchConfig, dd = true;
  function ed(a, b, c, d) {
    var e = C, f = cd.transition;
    cd.transition = null;
    try {
      C = 1, fd(a, b, c, d);
    } finally {
      C = e, cd.transition = f;
    }
  }
  function gd(a, b, c, d) {
    var e = C, f = cd.transition;
    cd.transition = null;
    try {
      C = 4, fd(a, b, c, d);
    } finally {
      C = e, cd.transition = f;
    }
  }
  function fd(a, b, c, d) {
    if (dd) {
      var e = Yc(a, b, c, d);
      if (null === e) hd(a, b, d, id2, c), Sc(a, d);
      else if (Uc(e, a, b, c, d)) d.stopPropagation();
      else if (Sc(a, d), b & 4 && -1 < Rc.indexOf(a)) {
        for (; null !== e; ) {
          var f = Cb(e);
          null !== f && Ec(f);
          f = Yc(a, b, c, d);
          null === f && hd(a, b, d, id2, c);
          if (f === e) break;
          e = f;
        }
        null !== e && d.stopPropagation();
      } else hd(a, b, d, null, c);
    }
  }
  var id2 = null;
  function Yc(a, b, c, d) {
    id2 = null;
    a = xb(d);
    a = Wc(a);
    if (null !== a) if (b = Vb(a), null === b) a = null;
    else if (c = b.tag, 13 === c) {
      a = Wb(b);
      if (null !== a) return a;
      a = null;
    } else if (3 === c) {
      if (b.stateNode.current.memoizedState.isDehydrated) return 3 === b.tag ? b.stateNode.containerInfo : null;
      a = null;
    } else b !== a && (a = null);
    id2 = a;
    return null;
  }
  function jd(a) {
    switch (a) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (ec()) {
          case fc:
            return 1;
          case gc:
            return 4;
          case hc:
          case ic:
            return 16;
          case jc:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var kd = null, ld = null, md = null;
  function nd() {
    if (md) return md;
    var a, b = ld, c = b.length, d, e = "value" in kd ? kd.value : kd.textContent, f = e.length;
    for (a = 0; a < c && b[a] === e[a]; a++) ;
    var g = c - a;
    for (d = 1; d <= g && b[c - d] === e[f - d]; d++) ;
    return md = e.slice(a, 1 < d ? 1 - d : void 0);
  }
  function od(a) {
    var b = a.keyCode;
    "charCode" in a ? (a = a.charCode, 0 === a && 13 === b && (a = 13)) : a = b;
    10 === a && (a = 13);
    return 32 <= a || 13 === a ? a : 0;
  }
  function pd() {
    return true;
  }
  function qd() {
    return false;
  }
  function rd(a) {
    function b(b2, d, e, f, g) {
      this._reactName = b2;
      this._targetInst = e;
      this.type = d;
      this.nativeEvent = f;
      this.target = g;
      this.currentTarget = null;
      for (var c in a) a.hasOwnProperty(c) && (b2 = a[c], this[c] = b2 ? b2(f) : f[c]);
      this.isDefaultPrevented = (null != f.defaultPrevented ? f.defaultPrevented : false === f.returnValue) ? pd : qd;
      this.isPropagationStopped = qd;
      return this;
    }
    A(b.prototype, { preventDefault: function() {
      this.defaultPrevented = true;
      var a2 = this.nativeEvent;
      a2 && (a2.preventDefault ? a2.preventDefault() : "unknown" !== typeof a2.returnValue && (a2.returnValue = false), this.isDefaultPrevented = pd);
    }, stopPropagation: function() {
      var a2 = this.nativeEvent;
      a2 && (a2.stopPropagation ? a2.stopPropagation() : "unknown" !== typeof a2.cancelBubble && (a2.cancelBubble = true), this.isPropagationStopped = pd);
    }, persist: function() {
    }, isPersistent: pd });
    return b;
  }
  var sd = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(a) {
    return a.timeStamp || Date.now();
  }, defaultPrevented: 0, isTrusted: 0 }, td = rd(sd), ud = A({}, sd, { view: 0, detail: 0 }), vd = rd(ud), wd, xd, yd, Ad = A({}, ud, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: zd, button: 0, buttons: 0, relatedTarget: function(a) {
    return void 0 === a.relatedTarget ? a.fromElement === a.srcElement ? a.toElement : a.fromElement : a.relatedTarget;
  }, movementX: function(a) {
    if ("movementX" in a) return a.movementX;
    a !== yd && (yd && "mousemove" === a.type ? (wd = a.screenX - yd.screenX, xd = a.screenY - yd.screenY) : xd = wd = 0, yd = a);
    return wd;
  }, movementY: function(a) {
    return "movementY" in a ? a.movementY : xd;
  } }), Bd = rd(Ad), Cd = A({}, Ad, { dataTransfer: 0 }), Dd = rd(Cd), Ed = A({}, ud, { relatedTarget: 0 }), Fd = rd(Ed), Gd = A({}, sd, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), Hd = rd(Gd), Id = A({}, sd, { clipboardData: function(a) {
    return "clipboardData" in a ? a.clipboardData : window.clipboardData;
  } }), Jd = rd(Id), Kd = A({}, sd, { data: 0 }), Ld = rd(Kd), Md = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, Nd = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, Od = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
  function Pd(a) {
    var b = this.nativeEvent;
    return b.getModifierState ? b.getModifierState(a) : (a = Od[a]) ? !!b[a] : false;
  }
  function zd() {
    return Pd;
  }
  var Qd = A({}, ud, { key: function(a) {
    if (a.key) {
      var b = Md[a.key] || a.key;
      if ("Unidentified" !== b) return b;
    }
    return "keypress" === a.type ? (a = od(a), 13 === a ? "Enter" : String.fromCharCode(a)) : "keydown" === a.type || "keyup" === a.type ? Nd[a.keyCode] || "Unidentified" : "";
  }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: zd, charCode: function(a) {
    return "keypress" === a.type ? od(a) : 0;
  }, keyCode: function(a) {
    return "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
  }, which: function(a) {
    return "keypress" === a.type ? od(a) : "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
  } }), Rd = rd(Qd), Sd = A({}, Ad, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), Td = rd(Sd), Ud = A({}, ud, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: zd }), Vd = rd(Ud), Wd = A({}, sd, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), Xd = rd(Wd), Yd = A({}, Ad, {
    deltaX: function(a) {
      return "deltaX" in a ? a.deltaX : "wheelDeltaX" in a ? -a.wheelDeltaX : 0;
    },
    deltaY: function(a) {
      return "deltaY" in a ? a.deltaY : "wheelDeltaY" in a ? -a.wheelDeltaY : "wheelDelta" in a ? -a.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  }), Zd = rd(Yd), $d = [9, 13, 27, 32], ae = ia && "CompositionEvent" in window, be = null;
  ia && "documentMode" in document && (be = document.documentMode);
  var ce = ia && "TextEvent" in window && !be, de = ia && (!ae || be && 8 < be && 11 >= be), ee = String.fromCharCode(32), fe = false;
  function ge(a, b) {
    switch (a) {
      case "keyup":
        return -1 !== $d.indexOf(b.keyCode);
      case "keydown":
        return 229 !== b.keyCode;
      case "keypress":
      case "mousedown":
      case "focusout":
        return true;
      default:
        return false;
    }
  }
  function he(a) {
    a = a.detail;
    return "object" === typeof a && "data" in a ? a.data : null;
  }
  var ie = false;
  function je(a, b) {
    switch (a) {
      case "compositionend":
        return he(b);
      case "keypress":
        if (32 !== b.which) return null;
        fe = true;
        return ee;
      case "textInput":
        return a = b.data, a === ee && fe ? null : a;
      default:
        return null;
    }
  }
  function ke(a, b) {
    if (ie) return "compositionend" === a || !ae && ge(a, b) ? (a = nd(), md = ld = kd = null, ie = false, a) : null;
    switch (a) {
      case "paste":
        return null;
      case "keypress":
        if (!(b.ctrlKey || b.altKey || b.metaKey) || b.ctrlKey && b.altKey) {
          if (b.char && 1 < b.char.length) return b.char;
          if (b.which) return String.fromCharCode(b.which);
        }
        return null;
      case "compositionend":
        return de && "ko" !== b.locale ? null : b.data;
      default:
        return null;
    }
  }
  var le = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
  function me(a) {
    var b = a && a.nodeName && a.nodeName.toLowerCase();
    return "input" === b ? !!le[a.type] : "textarea" === b ? true : false;
  }
  function ne(a, b, c, d) {
    Eb(d);
    b = oe(b, "onChange");
    0 < b.length && (c = new td("onChange", "change", null, c, d), a.push({ event: c, listeners: b }));
  }
  var pe = null, qe = null;
  function re(a) {
    se(a, 0);
  }
  function te(a) {
    var b = ue(a);
    if (Wa(b)) return a;
  }
  function ve(a, b) {
    if ("change" === a) return b;
  }
  var we = false;
  if (ia) {
    var xe;
    if (ia) {
      var ye = "oninput" in document;
      if (!ye) {
        var ze = document.createElement("div");
        ze.setAttribute("oninput", "return;");
        ye = "function" === typeof ze.oninput;
      }
      xe = ye;
    } else xe = false;
    we = xe && (!document.documentMode || 9 < document.documentMode);
  }
  function Ae() {
    pe && (pe.detachEvent("onpropertychange", Be), qe = pe = null);
  }
  function Be(a) {
    if ("value" === a.propertyName && te(qe)) {
      var b = [];
      ne(b, qe, a, xb(a));
      Jb(re, b);
    }
  }
  function Ce(a, b, c) {
    "focusin" === a ? (Ae(), pe = b, qe = c, pe.attachEvent("onpropertychange", Be)) : "focusout" === a && Ae();
  }
  function De(a) {
    if ("selectionchange" === a || "keyup" === a || "keydown" === a) return te(qe);
  }
  function Ee(a, b) {
    if ("click" === a) return te(b);
  }
  function Fe(a, b) {
    if ("input" === a || "change" === a) return te(b);
  }
  function Ge(a, b) {
    return a === b && (0 !== a || 1 / a === 1 / b) || a !== a && b !== b;
  }
  var He = "function" === typeof Object.is ? Object.is : Ge;
  function Ie(a, b) {
    if (He(a, b)) return true;
    if ("object" !== typeof a || null === a || "object" !== typeof b || null === b) return false;
    var c = Object.keys(a), d = Object.keys(b);
    if (c.length !== d.length) return false;
    for (d = 0; d < c.length; d++) {
      var e = c[d];
      if (!ja.call(b, e) || !He(a[e], b[e])) return false;
    }
    return true;
  }
  function Je(a) {
    for (; a && a.firstChild; ) a = a.firstChild;
    return a;
  }
  function Ke(a, b) {
    var c = Je(a);
    a = 0;
    for (var d; c; ) {
      if (3 === c.nodeType) {
        d = a + c.textContent.length;
        if (a <= b && d >= b) return { node: c, offset: b - a };
        a = d;
      }
      a: {
        for (; c; ) {
          if (c.nextSibling) {
            c = c.nextSibling;
            break a;
          }
          c = c.parentNode;
        }
        c = void 0;
      }
      c = Je(c);
    }
  }
  function Le(a, b) {
    return a && b ? a === b ? true : a && 3 === a.nodeType ? false : b && 3 === b.nodeType ? Le(a, b.parentNode) : "contains" in a ? a.contains(b) : a.compareDocumentPosition ? !!(a.compareDocumentPosition(b) & 16) : false : false;
  }
  function Me() {
    for (var a = window, b = Xa(); b instanceof a.HTMLIFrameElement; ) {
      try {
        var c = "string" === typeof b.contentWindow.location.href;
      } catch (d) {
        c = false;
      }
      if (c) a = b.contentWindow;
      else break;
      b = Xa(a.document);
    }
    return b;
  }
  function Ne(a) {
    var b = a && a.nodeName && a.nodeName.toLowerCase();
    return b && ("input" === b && ("text" === a.type || "search" === a.type || "tel" === a.type || "url" === a.type || "password" === a.type) || "textarea" === b || "true" === a.contentEditable);
  }
  function Oe(a) {
    var b = Me(), c = a.focusedElem, d = a.selectionRange;
    if (b !== c && c && c.ownerDocument && Le(c.ownerDocument.documentElement, c)) {
      if (null !== d && Ne(c)) {
        if (b = d.start, a = d.end, void 0 === a && (a = b), "selectionStart" in c) c.selectionStart = b, c.selectionEnd = Math.min(a, c.value.length);
        else if (a = (b = c.ownerDocument || document) && b.defaultView || window, a.getSelection) {
          a = a.getSelection();
          var e = c.textContent.length, f = Math.min(d.start, e);
          d = void 0 === d.end ? f : Math.min(d.end, e);
          !a.extend && f > d && (e = d, d = f, f = e);
          e = Ke(c, f);
          var g = Ke(
            c,
            d
          );
          e && g && (1 !== a.rangeCount || a.anchorNode !== e.node || a.anchorOffset !== e.offset || a.focusNode !== g.node || a.focusOffset !== g.offset) && (b = b.createRange(), b.setStart(e.node, e.offset), a.removeAllRanges(), f > d ? (a.addRange(b), a.extend(g.node, g.offset)) : (b.setEnd(g.node, g.offset), a.addRange(b)));
        }
      }
      b = [];
      for (a = c; a = a.parentNode; ) 1 === a.nodeType && b.push({ element: a, left: a.scrollLeft, top: a.scrollTop });
      "function" === typeof c.focus && c.focus();
      for (c = 0; c < b.length; c++) a = b[c], a.element.scrollLeft = a.left, a.element.scrollTop = a.top;
    }
  }
  var Pe = ia && "documentMode" in document && 11 >= document.documentMode, Qe = null, Re = null, Se = null, Te = false;
  function Ue(a, b, c) {
    var d = c.window === c ? c.document : 9 === c.nodeType ? c : c.ownerDocument;
    Te || null == Qe || Qe !== Xa(d) || (d = Qe, "selectionStart" in d && Ne(d) ? d = { start: d.selectionStart, end: d.selectionEnd } : (d = (d.ownerDocument && d.ownerDocument.defaultView || window).getSelection(), d = { anchorNode: d.anchorNode, anchorOffset: d.anchorOffset, focusNode: d.focusNode, focusOffset: d.focusOffset }), Se && Ie(Se, d) || (Se = d, d = oe(Re, "onSelect"), 0 < d.length && (b = new td("onSelect", "select", null, b, c), a.push({ event: b, listeners: d }), b.target = Qe)));
  }
  function Ve(a, b) {
    var c = {};
    c[a.toLowerCase()] = b.toLowerCase();
    c["Webkit" + a] = "webkit" + b;
    c["Moz" + a] = "moz" + b;
    return c;
  }
  var We = { animationend: Ve("Animation", "AnimationEnd"), animationiteration: Ve("Animation", "AnimationIteration"), animationstart: Ve("Animation", "AnimationStart"), transitionend: Ve("Transition", "TransitionEnd") }, Xe = {}, Ye = {};
  ia && (Ye = document.createElement("div").style, "AnimationEvent" in window || (delete We.animationend.animation, delete We.animationiteration.animation, delete We.animationstart.animation), "TransitionEvent" in window || delete We.transitionend.transition);
  function Ze(a) {
    if (Xe[a]) return Xe[a];
    if (!We[a]) return a;
    var b = We[a], c;
    for (c in b) if (b.hasOwnProperty(c) && c in Ye) return Xe[a] = b[c];
    return a;
  }
  var $e = Ze("animationend"), af = Ze("animationiteration"), bf = Ze("animationstart"), cf = Ze("transitionend"), df = /* @__PURE__ */ new Map(), ef = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
  function ff(a, b) {
    df.set(a, b);
    fa(b, [a]);
  }
  for (var gf = 0; gf < ef.length; gf++) {
    var hf = ef[gf], jf = hf.toLowerCase(), kf = hf[0].toUpperCase() + hf.slice(1);
    ff(jf, "on" + kf);
  }
  ff($e, "onAnimationEnd");
  ff(af, "onAnimationIteration");
  ff(bf, "onAnimationStart");
  ff("dblclick", "onDoubleClick");
  ff("focusin", "onFocus");
  ff("focusout", "onBlur");
  ff(cf, "onTransitionEnd");
  ha("onMouseEnter", ["mouseout", "mouseover"]);
  ha("onMouseLeave", ["mouseout", "mouseover"]);
  ha("onPointerEnter", ["pointerout", "pointerover"]);
  ha("onPointerLeave", ["pointerout", "pointerover"]);
  fa("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
  fa("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
  fa("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
  fa("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
  fa("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
  fa("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
  var lf = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), mf = new Set("cancel close invalid load scroll toggle".split(" ").concat(lf));
  function nf(a, b, c) {
    var d = a.type || "unknown-event";
    a.currentTarget = c;
    Ub(d, b, void 0, a);
    a.currentTarget = null;
  }
  function se(a, b) {
    b = 0 !== (b & 4);
    for (var c = 0; c < a.length; c++) {
      var d = a[c], e = d.event;
      d = d.listeners;
      a: {
        var f = void 0;
        if (b) for (var g = d.length - 1; 0 <= g; g--) {
          var h = d[g], k = h.instance, l = h.currentTarget;
          h = h.listener;
          if (k !== f && e.isPropagationStopped()) break a;
          nf(e, h, l);
          f = k;
        }
        else for (g = 0; g < d.length; g++) {
          h = d[g];
          k = h.instance;
          l = h.currentTarget;
          h = h.listener;
          if (k !== f && e.isPropagationStopped()) break a;
          nf(e, h, l);
          f = k;
        }
      }
    }
    if (Qb) throw a = Rb, Qb = false, Rb = null, a;
  }
  function D(a, b) {
    var c = b[of];
    void 0 === c && (c = b[of] = /* @__PURE__ */ new Set());
    var d = a + "__bubble";
    c.has(d) || (pf(b, a, 2, false), c.add(d));
  }
  function qf(a, b, c) {
    var d = 0;
    b && (d |= 4);
    pf(c, a, d, b);
  }
  var rf = "_reactListening" + Math.random().toString(36).slice(2);
  function sf(a) {
    if (!a[rf]) {
      a[rf] = true;
      da.forEach(function(b2) {
        "selectionchange" !== b2 && (mf.has(b2) || qf(b2, false, a), qf(b2, true, a));
      });
      var b = 9 === a.nodeType ? a : a.ownerDocument;
      null === b || b[rf] || (b[rf] = true, qf("selectionchange", false, b));
    }
  }
  function pf(a, b, c, d) {
    switch (jd(b)) {
      case 1:
        var e = ed;
        break;
      case 4:
        e = gd;
        break;
      default:
        e = fd;
    }
    c = e.bind(null, b, c, a);
    e = void 0;
    !Lb || "touchstart" !== b && "touchmove" !== b && "wheel" !== b || (e = true);
    d ? void 0 !== e ? a.addEventListener(b, c, { capture: true, passive: e }) : a.addEventListener(b, c, true) : void 0 !== e ? a.addEventListener(b, c, { passive: e }) : a.addEventListener(b, c, false);
  }
  function hd(a, b, c, d, e) {
    var f = d;
    if (0 === (b & 1) && 0 === (b & 2) && null !== d) a: for (; ; ) {
      if (null === d) return;
      var g = d.tag;
      if (3 === g || 4 === g) {
        var h = d.stateNode.containerInfo;
        if (h === e || 8 === h.nodeType && h.parentNode === e) break;
        if (4 === g) for (g = d.return; null !== g; ) {
          var k = g.tag;
          if (3 === k || 4 === k) {
            if (k = g.stateNode.containerInfo, k === e || 8 === k.nodeType && k.parentNode === e) return;
          }
          g = g.return;
        }
        for (; null !== h; ) {
          g = Wc(h);
          if (null === g) return;
          k = g.tag;
          if (5 === k || 6 === k) {
            d = f = g;
            continue a;
          }
          h = h.parentNode;
        }
      }
      d = d.return;
    }
    Jb(function() {
      var d2 = f, e2 = xb(c), g2 = [];
      a: {
        var h2 = df.get(a);
        if (void 0 !== h2) {
          var k2 = td, n = a;
          switch (a) {
            case "keypress":
              if (0 === od(c)) break a;
            case "keydown":
            case "keyup":
              k2 = Rd;
              break;
            case "focusin":
              n = "focus";
              k2 = Fd;
              break;
            case "focusout":
              n = "blur";
              k2 = Fd;
              break;
            case "beforeblur":
            case "afterblur":
              k2 = Fd;
              break;
            case "click":
              if (2 === c.button) break a;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              k2 = Bd;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              k2 = Dd;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              k2 = Vd;
              break;
            case $e:
            case af:
            case bf:
              k2 = Hd;
              break;
            case cf:
              k2 = Xd;
              break;
            case "scroll":
              k2 = vd;
              break;
            case "wheel":
              k2 = Zd;
              break;
            case "copy":
            case "cut":
            case "paste":
              k2 = Jd;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              k2 = Td;
          }
          var t = 0 !== (b & 4), J = !t && "scroll" === a, x = t ? null !== h2 ? h2 + "Capture" : null : h2;
          t = [];
          for (var w = d2, u; null !== w; ) {
            u = w;
            var F = u.stateNode;
            5 === u.tag && null !== F && (u = F, null !== x && (F = Kb(w, x), null != F && t.push(tf(w, F, u))));
            if (J) break;
            w = w.return;
          }
          0 < t.length && (h2 = new k2(h2, n, null, c, e2), g2.push({ event: h2, listeners: t }));
        }
      }
      if (0 === (b & 7)) {
        a: {
          h2 = "mouseover" === a || "pointerover" === a;
          k2 = "mouseout" === a || "pointerout" === a;
          if (h2 && c !== wb && (n = c.relatedTarget || c.fromElement) && (Wc(n) || n[uf])) break a;
          if (k2 || h2) {
            h2 = e2.window === e2 ? e2 : (h2 = e2.ownerDocument) ? h2.defaultView || h2.parentWindow : window;
            if (k2) {
              if (n = c.relatedTarget || c.toElement, k2 = d2, n = n ? Wc(n) : null, null !== n && (J = Vb(n), n !== J || 5 !== n.tag && 6 !== n.tag)) n = null;
            } else k2 = null, n = d2;
            if (k2 !== n) {
              t = Bd;
              F = "onMouseLeave";
              x = "onMouseEnter";
              w = "mouse";
              if ("pointerout" === a || "pointerover" === a) t = Td, F = "onPointerLeave", x = "onPointerEnter", w = "pointer";
              J = null == k2 ? h2 : ue(k2);
              u = null == n ? h2 : ue(n);
              h2 = new t(F, w + "leave", k2, c, e2);
              h2.target = J;
              h2.relatedTarget = u;
              F = null;
              Wc(e2) === d2 && (t = new t(x, w + "enter", n, c, e2), t.target = u, t.relatedTarget = J, F = t);
              J = F;
              if (k2 && n) b: {
                t = k2;
                x = n;
                w = 0;
                for (u = t; u; u = vf(u)) w++;
                u = 0;
                for (F = x; F; F = vf(F)) u++;
                for (; 0 < w - u; ) t = vf(t), w--;
                for (; 0 < u - w; ) x = vf(x), u--;
                for (; w--; ) {
                  if (t === x || null !== x && t === x.alternate) break b;
                  t = vf(t);
                  x = vf(x);
                }
                t = null;
              }
              else t = null;
              null !== k2 && wf(g2, h2, k2, t, false);
              null !== n && null !== J && wf(g2, J, n, t, true);
            }
          }
        }
        a: {
          h2 = d2 ? ue(d2) : window;
          k2 = h2.nodeName && h2.nodeName.toLowerCase();
          if ("select" === k2 || "input" === k2 && "file" === h2.type) var na = ve;
          else if (me(h2)) if (we) na = Fe;
          else {
            na = De;
            var xa = Ce;
          }
          else (k2 = h2.nodeName) && "input" === k2.toLowerCase() && ("checkbox" === h2.type || "radio" === h2.type) && (na = Ee);
          if (na && (na = na(a, d2))) {
            ne(g2, na, c, e2);
            break a;
          }
          xa && xa(a, h2, d2);
          "focusout" === a && (xa = h2._wrapperState) && xa.controlled && "number" === h2.type && cb(h2, "number", h2.value);
        }
        xa = d2 ? ue(d2) : window;
        switch (a) {
          case "focusin":
            if (me(xa) || "true" === xa.contentEditable) Qe = xa, Re = d2, Se = null;
            break;
          case "focusout":
            Se = Re = Qe = null;
            break;
          case "mousedown":
            Te = true;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            Te = false;
            Ue(g2, c, e2);
            break;
          case "selectionchange":
            if (Pe) break;
          case "keydown":
          case "keyup":
            Ue(g2, c, e2);
        }
        var $a;
        if (ae) b: {
          switch (a) {
            case "compositionstart":
              var ba = "onCompositionStart";
              break b;
            case "compositionend":
              ba = "onCompositionEnd";
              break b;
            case "compositionupdate":
              ba = "onCompositionUpdate";
              break b;
          }
          ba = void 0;
        }
        else ie ? ge(a, c) && (ba = "onCompositionEnd") : "keydown" === a && 229 === c.keyCode && (ba = "onCompositionStart");
        ba && (de && "ko" !== c.locale && (ie || "onCompositionStart" !== ba ? "onCompositionEnd" === ba && ie && ($a = nd()) : (kd = e2, ld = "value" in kd ? kd.value : kd.textContent, ie = true)), xa = oe(d2, ba), 0 < xa.length && (ba = new Ld(ba, a, null, c, e2), g2.push({ event: ba, listeners: xa }), $a ? ba.data = $a : ($a = he(c), null !== $a && (ba.data = $a))));
        if ($a = ce ? je(a, c) : ke(a, c)) d2 = oe(d2, "onBeforeInput"), 0 < d2.length && (e2 = new Ld("onBeforeInput", "beforeinput", null, c, e2), g2.push({ event: e2, listeners: d2 }), e2.data = $a);
      }
      se(g2, b);
    });
  }
  function tf(a, b, c) {
    return { instance: a, listener: b, currentTarget: c };
  }
  function oe(a, b) {
    for (var c = b + "Capture", d = []; null !== a; ) {
      var e = a, f = e.stateNode;
      5 === e.tag && null !== f && (e = f, f = Kb(a, c), null != f && d.unshift(tf(a, f, e)), f = Kb(a, b), null != f && d.push(tf(a, f, e)));
      a = a.return;
    }
    return d;
  }
  function vf(a) {
    if (null === a) return null;
    do
      a = a.return;
    while (a && 5 !== a.tag);
    return a ? a : null;
  }
  function wf(a, b, c, d, e) {
    for (var f = b._reactName, g = []; null !== c && c !== d; ) {
      var h = c, k = h.alternate, l = h.stateNode;
      if (null !== k && k === d) break;
      5 === h.tag && null !== l && (h = l, e ? (k = Kb(c, f), null != k && g.unshift(tf(c, k, h))) : e || (k = Kb(c, f), null != k && g.push(tf(c, k, h))));
      c = c.return;
    }
    0 !== g.length && a.push({ event: b, listeners: g });
  }
  var xf = /\r\n?/g, yf = /\u0000|\uFFFD/g;
  function zf(a) {
    return ("string" === typeof a ? a : "" + a).replace(xf, "\n").replace(yf, "");
  }
  function Af(a, b, c) {
    b = zf(b);
    if (zf(a) !== b && c) throw Error(p(425));
  }
  function Bf() {
  }
  var Cf = null, Df = null;
  function Ef(a, b) {
    return "textarea" === a || "noscript" === a || "string" === typeof b.children || "number" === typeof b.children || "object" === typeof b.dangerouslySetInnerHTML && null !== b.dangerouslySetInnerHTML && null != b.dangerouslySetInnerHTML.__html;
  }
  var Ff = "function" === typeof setTimeout ? setTimeout : void 0, Gf = "function" === typeof clearTimeout ? clearTimeout : void 0, Hf = "function" === typeof Promise ? Promise : void 0, Jf = "function" === typeof queueMicrotask ? queueMicrotask : "undefined" !== typeof Hf ? function(a) {
    return Hf.resolve(null).then(a).catch(If);
  } : Ff;
  function If(a) {
    setTimeout(function() {
      throw a;
    });
  }
  function Kf(a, b) {
    var c = b, d = 0;
    do {
      var e = c.nextSibling;
      a.removeChild(c);
      if (e && 8 === e.nodeType) if (c = e.data, "/$" === c) {
        if (0 === d) {
          a.removeChild(e);
          bd(b);
          return;
        }
        d--;
      } else "$" !== c && "$?" !== c && "$!" !== c || d++;
      c = e;
    } while (c);
    bd(b);
  }
  function Lf(a) {
    for (; null != a; a = a.nextSibling) {
      var b = a.nodeType;
      if (1 === b || 3 === b) break;
      if (8 === b) {
        b = a.data;
        if ("$" === b || "$!" === b || "$?" === b) break;
        if ("/$" === b) return null;
      }
    }
    return a;
  }
  function Mf(a) {
    a = a.previousSibling;
    for (var b = 0; a; ) {
      if (8 === a.nodeType) {
        var c = a.data;
        if ("$" === c || "$!" === c || "$?" === c) {
          if (0 === b) return a;
          b--;
        } else "/$" === c && b++;
      }
      a = a.previousSibling;
    }
    return null;
  }
  var Nf = Math.random().toString(36).slice(2), Of = "__reactFiber$" + Nf, Pf = "__reactProps$" + Nf, uf = "__reactContainer$" + Nf, of = "__reactEvents$" + Nf, Qf = "__reactListeners$" + Nf, Rf = "__reactHandles$" + Nf;
  function Wc(a) {
    var b = a[Of];
    if (b) return b;
    for (var c = a.parentNode; c; ) {
      if (b = c[uf] || c[Of]) {
        c = b.alternate;
        if (null !== b.child || null !== c && null !== c.child) for (a = Mf(a); null !== a; ) {
          if (c = a[Of]) return c;
          a = Mf(a);
        }
        return b;
      }
      a = c;
      c = a.parentNode;
    }
    return null;
  }
  function Cb(a) {
    a = a[Of] || a[uf];
    return !a || 5 !== a.tag && 6 !== a.tag && 13 !== a.tag && 3 !== a.tag ? null : a;
  }
  function ue(a) {
    if (5 === a.tag || 6 === a.tag) return a.stateNode;
    throw Error(p(33));
  }
  function Db(a) {
    return a[Pf] || null;
  }
  var Sf = [], Tf = -1;
  function Uf(a) {
    return { current: a };
  }
  function E(a) {
    0 > Tf || (a.current = Sf[Tf], Sf[Tf] = null, Tf--);
  }
  function G(a, b) {
    Tf++;
    Sf[Tf] = a.current;
    a.current = b;
  }
  var Vf = {}, H = Uf(Vf), Wf = Uf(false), Xf = Vf;
  function Yf(a, b) {
    var c = a.type.contextTypes;
    if (!c) return Vf;
    var d = a.stateNode;
    if (d && d.__reactInternalMemoizedUnmaskedChildContext === b) return d.__reactInternalMemoizedMaskedChildContext;
    var e = {}, f;
    for (f in c) e[f] = b[f];
    d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = b, a.__reactInternalMemoizedMaskedChildContext = e);
    return e;
  }
  function Zf(a) {
    a = a.childContextTypes;
    return null !== a && void 0 !== a;
  }
  function $f() {
    E(Wf);
    E(H);
  }
  function ag(a, b, c) {
    if (H.current !== Vf) throw Error(p(168));
    G(H, b);
    G(Wf, c);
  }
  function bg(a, b, c) {
    var d = a.stateNode;
    b = b.childContextTypes;
    if ("function" !== typeof d.getChildContext) return c;
    d = d.getChildContext();
    for (var e in d) if (!(e in b)) throw Error(p(108, Ra(a) || "Unknown", e));
    return A({}, c, d);
  }
  function cg(a) {
    a = (a = a.stateNode) && a.__reactInternalMemoizedMergedChildContext || Vf;
    Xf = H.current;
    G(H, a);
    G(Wf, Wf.current);
    return true;
  }
  function dg(a, b, c) {
    var d = a.stateNode;
    if (!d) throw Error(p(169));
    c ? (a = bg(a, b, Xf), d.__reactInternalMemoizedMergedChildContext = a, E(Wf), E(H), G(H, a)) : E(Wf);
    G(Wf, c);
  }
  var eg = null, fg = false, gg = false;
  function hg(a) {
    null === eg ? eg = [a] : eg.push(a);
  }
  function ig(a) {
    fg = true;
    hg(a);
  }
  function jg() {
    if (!gg && null !== eg) {
      gg = true;
      var a = 0, b = C;
      try {
        var c = eg;
        for (C = 1; a < c.length; a++) {
          var d = c[a];
          do
            d = d(true);
          while (null !== d);
        }
        eg = null;
        fg = false;
      } catch (e) {
        throw null !== eg && (eg = eg.slice(a + 1)), ac(fc, jg), e;
      } finally {
        C = b, gg = false;
      }
    }
    return null;
  }
  var kg = [], lg = 0, mg = null, ng = 0, og = [], pg = 0, qg = null, rg = 1, sg = "";
  function tg(a, b) {
    kg[lg++] = ng;
    kg[lg++] = mg;
    mg = a;
    ng = b;
  }
  function ug(a, b, c) {
    og[pg++] = rg;
    og[pg++] = sg;
    og[pg++] = qg;
    qg = a;
    var d = rg;
    a = sg;
    var e = 32 - oc(d) - 1;
    d &= ~(1 << e);
    c += 1;
    var f = 32 - oc(b) + e;
    if (30 < f) {
      var g = e - e % 5;
      f = (d & (1 << g) - 1).toString(32);
      d >>= g;
      e -= g;
      rg = 1 << 32 - oc(b) + e | c << e | d;
      sg = f + a;
    } else rg = 1 << f | c << e | d, sg = a;
  }
  function vg(a) {
    null !== a.return && (tg(a, 1), ug(a, 1, 0));
  }
  function wg(a) {
    for (; a === mg; ) mg = kg[--lg], kg[lg] = null, ng = kg[--lg], kg[lg] = null;
    for (; a === qg; ) qg = og[--pg], og[pg] = null, sg = og[--pg], og[pg] = null, rg = og[--pg], og[pg] = null;
  }
  var xg = null, yg = null, I = false, zg = null;
  function Ag(a, b) {
    var c = Bg(5, null, null, 0);
    c.elementType = "DELETED";
    c.stateNode = b;
    c.return = a;
    b = a.deletions;
    null === b ? (a.deletions = [c], a.flags |= 16) : b.push(c);
  }
  function Cg(a, b) {
    switch (a.tag) {
      case 5:
        var c = a.type;
        b = 1 !== b.nodeType || c.toLowerCase() !== b.nodeName.toLowerCase() ? null : b;
        return null !== b ? (a.stateNode = b, xg = a, yg = Lf(b.firstChild), true) : false;
      case 6:
        return b = "" === a.pendingProps || 3 !== b.nodeType ? null : b, null !== b ? (a.stateNode = b, xg = a, yg = null, true) : false;
      case 13:
        return b = 8 !== b.nodeType ? null : b, null !== b ? (c = null !== qg ? { id: rg, overflow: sg } : null, a.memoizedState = { dehydrated: b, treeContext: c, retryLane: 1073741824 }, c = Bg(18, null, null, 0), c.stateNode = b, c.return = a, a.child = c, xg = a, yg = null, true) : false;
      default:
        return false;
    }
  }
  function Dg(a) {
    return 0 !== (a.mode & 1) && 0 === (a.flags & 128);
  }
  function Eg(a) {
    if (I) {
      var b = yg;
      if (b) {
        var c = b;
        if (!Cg(a, b)) {
          if (Dg(a)) throw Error(p(418));
          b = Lf(c.nextSibling);
          var d = xg;
          b && Cg(a, b) ? Ag(d, c) : (a.flags = a.flags & -4097 | 2, I = false, xg = a);
        }
      } else {
        if (Dg(a)) throw Error(p(418));
        a.flags = a.flags & -4097 | 2;
        I = false;
        xg = a;
      }
    }
  }
  function Fg(a) {
    for (a = a.return; null !== a && 5 !== a.tag && 3 !== a.tag && 13 !== a.tag; ) a = a.return;
    xg = a;
  }
  function Gg(a) {
    if (a !== xg) return false;
    if (!I) return Fg(a), I = true, false;
    var b;
    (b = 3 !== a.tag) && !(b = 5 !== a.tag) && (b = a.type, b = "head" !== b && "body" !== b && !Ef(a.type, a.memoizedProps));
    if (b && (b = yg)) {
      if (Dg(a)) throw Hg(), Error(p(418));
      for (; b; ) Ag(a, b), b = Lf(b.nextSibling);
    }
    Fg(a);
    if (13 === a.tag) {
      a = a.memoizedState;
      a = null !== a ? a.dehydrated : null;
      if (!a) throw Error(p(317));
      a: {
        a = a.nextSibling;
        for (b = 0; a; ) {
          if (8 === a.nodeType) {
            var c = a.data;
            if ("/$" === c) {
              if (0 === b) {
                yg = Lf(a.nextSibling);
                break a;
              }
              b--;
            } else "$" !== c && "$!" !== c && "$?" !== c || b++;
          }
          a = a.nextSibling;
        }
        yg = null;
      }
    } else yg = xg ? Lf(a.stateNode.nextSibling) : null;
    return true;
  }
  function Hg() {
    for (var a = yg; a; ) a = Lf(a.nextSibling);
  }
  function Ig() {
    yg = xg = null;
    I = false;
  }
  function Jg(a) {
    null === zg ? zg = [a] : zg.push(a);
  }
  var Kg = ua.ReactCurrentBatchConfig;
  function Lg(a, b, c) {
    a = c.ref;
    if (null !== a && "function" !== typeof a && "object" !== typeof a) {
      if (c._owner) {
        c = c._owner;
        if (c) {
          if (1 !== c.tag) throw Error(p(309));
          var d = c.stateNode;
        }
        if (!d) throw Error(p(147, a));
        var e = d, f = "" + a;
        if (null !== b && null !== b.ref && "function" === typeof b.ref && b.ref._stringRef === f) return b.ref;
        b = function(a2) {
          var b2 = e.refs;
          null === a2 ? delete b2[f] : b2[f] = a2;
        };
        b._stringRef = f;
        return b;
      }
      if ("string" !== typeof a) throw Error(p(284));
      if (!c._owner) throw Error(p(290, a));
    }
    return a;
  }
  function Mg(a, b) {
    a = Object.prototype.toString.call(b);
    throw Error(p(31, "[object Object]" === a ? "object with keys {" + Object.keys(b).join(", ") + "}" : a));
  }
  function Ng(a) {
    var b = a._init;
    return b(a._payload);
  }
  function Og(a) {
    function b(b2, c2) {
      if (a) {
        var d2 = b2.deletions;
        null === d2 ? (b2.deletions = [c2], b2.flags |= 16) : d2.push(c2);
      }
    }
    function c(c2, d2) {
      if (!a) return null;
      for (; null !== d2; ) b(c2, d2), d2 = d2.sibling;
      return null;
    }
    function d(a2, b2) {
      for (a2 = /* @__PURE__ */ new Map(); null !== b2; ) null !== b2.key ? a2.set(b2.key, b2) : a2.set(b2.index, b2), b2 = b2.sibling;
      return a2;
    }
    function e(a2, b2) {
      a2 = Pg(a2, b2);
      a2.index = 0;
      a2.sibling = null;
      return a2;
    }
    function f(b2, c2, d2) {
      b2.index = d2;
      if (!a) return b2.flags |= 1048576, c2;
      d2 = b2.alternate;
      if (null !== d2) return d2 = d2.index, d2 < c2 ? (b2.flags |= 2, c2) : d2;
      b2.flags |= 2;
      return c2;
    }
    function g(b2) {
      a && null === b2.alternate && (b2.flags |= 2);
      return b2;
    }
    function h(a2, b2, c2, d2) {
      if (null === b2 || 6 !== b2.tag) return b2 = Qg(c2, a2.mode, d2), b2.return = a2, b2;
      b2 = e(b2, c2);
      b2.return = a2;
      return b2;
    }
    function k(a2, b2, c2, d2) {
      var f2 = c2.type;
      if (f2 === ya) return m(a2, b2, c2.props.children, d2, c2.key);
      if (null !== b2 && (b2.elementType === f2 || "object" === typeof f2 && null !== f2 && f2.$$typeof === Ha && Ng(f2) === b2.type)) return d2 = e(b2, c2.props), d2.ref = Lg(a2, b2, c2), d2.return = a2, d2;
      d2 = Rg(c2.type, c2.key, c2.props, null, a2.mode, d2);
      d2.ref = Lg(a2, b2, c2);
      d2.return = a2;
      return d2;
    }
    function l(a2, b2, c2, d2) {
      if (null === b2 || 4 !== b2.tag || b2.stateNode.containerInfo !== c2.containerInfo || b2.stateNode.implementation !== c2.implementation) return b2 = Sg(c2, a2.mode, d2), b2.return = a2, b2;
      b2 = e(b2, c2.children || []);
      b2.return = a2;
      return b2;
    }
    function m(a2, b2, c2, d2, f2) {
      if (null === b2 || 7 !== b2.tag) return b2 = Tg(c2, a2.mode, d2, f2), b2.return = a2, b2;
      b2 = e(b2, c2);
      b2.return = a2;
      return b2;
    }
    function q(a2, b2, c2) {
      if ("string" === typeof b2 && "" !== b2 || "number" === typeof b2) return b2 = Qg("" + b2, a2.mode, c2), b2.return = a2, b2;
      if ("object" === typeof b2 && null !== b2) {
        switch (b2.$$typeof) {
          case va:
            return c2 = Rg(b2.type, b2.key, b2.props, null, a2.mode, c2), c2.ref = Lg(a2, null, b2), c2.return = a2, c2;
          case wa:
            return b2 = Sg(b2, a2.mode, c2), b2.return = a2, b2;
          case Ha:
            var d2 = b2._init;
            return q(a2, d2(b2._payload), c2);
        }
        if (eb(b2) || Ka(b2)) return b2 = Tg(b2, a2.mode, c2, null), b2.return = a2, b2;
        Mg(a2, b2);
      }
      return null;
    }
    function r(a2, b2, c2, d2) {
      var e2 = null !== b2 ? b2.key : null;
      if ("string" === typeof c2 && "" !== c2 || "number" === typeof c2) return null !== e2 ? null : h(a2, b2, "" + c2, d2);
      if ("object" === typeof c2 && null !== c2) {
        switch (c2.$$typeof) {
          case va:
            return c2.key === e2 ? k(a2, b2, c2, d2) : null;
          case wa:
            return c2.key === e2 ? l(a2, b2, c2, d2) : null;
          case Ha:
            return e2 = c2._init, r(
              a2,
              b2,
              e2(c2._payload),
              d2
            );
        }
        if (eb(c2) || Ka(c2)) return null !== e2 ? null : m(a2, b2, c2, d2, null);
        Mg(a2, c2);
      }
      return null;
    }
    function y(a2, b2, c2, d2, e2) {
      if ("string" === typeof d2 && "" !== d2 || "number" === typeof d2) return a2 = a2.get(c2) || null, h(b2, a2, "" + d2, e2);
      if ("object" === typeof d2 && null !== d2) {
        switch (d2.$$typeof) {
          case va:
            return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, k(b2, a2, d2, e2);
          case wa:
            return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, l(b2, a2, d2, e2);
          case Ha:
            var f2 = d2._init;
            return y(a2, b2, c2, f2(d2._payload), e2);
        }
        if (eb(d2) || Ka(d2)) return a2 = a2.get(c2) || null, m(b2, a2, d2, e2, null);
        Mg(b2, d2);
      }
      return null;
    }
    function n(e2, g2, h2, k2) {
      for (var l2 = null, m2 = null, u = g2, w = g2 = 0, x = null; null !== u && w < h2.length; w++) {
        u.index > w ? (x = u, u = null) : x = u.sibling;
        var n2 = r(e2, u, h2[w], k2);
        if (null === n2) {
          null === u && (u = x);
          break;
        }
        a && u && null === n2.alternate && b(e2, u);
        g2 = f(n2, g2, w);
        null === m2 ? l2 = n2 : m2.sibling = n2;
        m2 = n2;
        u = x;
      }
      if (w === h2.length) return c(e2, u), I && tg(e2, w), l2;
      if (null === u) {
        for (; w < h2.length; w++) u = q(e2, h2[w], k2), null !== u && (g2 = f(u, g2, w), null === m2 ? l2 = u : m2.sibling = u, m2 = u);
        I && tg(e2, w);
        return l2;
      }
      for (u = d(e2, u); w < h2.length; w++) x = y(u, e2, w, h2[w], k2), null !== x && (a && null !== x.alternate && u.delete(null === x.key ? w : x.key), g2 = f(x, g2, w), null === m2 ? l2 = x : m2.sibling = x, m2 = x);
      a && u.forEach(function(a2) {
        return b(e2, a2);
      });
      I && tg(e2, w);
      return l2;
    }
    function t(e2, g2, h2, k2) {
      var l2 = Ka(h2);
      if ("function" !== typeof l2) throw Error(p(150));
      h2 = l2.call(h2);
      if (null == h2) throw Error(p(151));
      for (var u = l2 = null, m2 = g2, w = g2 = 0, x = null, n2 = h2.next(); null !== m2 && !n2.done; w++, n2 = h2.next()) {
        m2.index > w ? (x = m2, m2 = null) : x = m2.sibling;
        var t2 = r(e2, m2, n2.value, k2);
        if (null === t2) {
          null === m2 && (m2 = x);
          break;
        }
        a && m2 && null === t2.alternate && b(e2, m2);
        g2 = f(t2, g2, w);
        null === u ? l2 = t2 : u.sibling = t2;
        u = t2;
        m2 = x;
      }
      if (n2.done) return c(
        e2,
        m2
      ), I && tg(e2, w), l2;
      if (null === m2) {
        for (; !n2.done; w++, n2 = h2.next()) n2 = q(e2, n2.value, k2), null !== n2 && (g2 = f(n2, g2, w), null === u ? l2 = n2 : u.sibling = n2, u = n2);
        I && tg(e2, w);
        return l2;
      }
      for (m2 = d(e2, m2); !n2.done; w++, n2 = h2.next()) n2 = y(m2, e2, w, n2.value, k2), null !== n2 && (a && null !== n2.alternate && m2.delete(null === n2.key ? w : n2.key), g2 = f(n2, g2, w), null === u ? l2 = n2 : u.sibling = n2, u = n2);
      a && m2.forEach(function(a2) {
        return b(e2, a2);
      });
      I && tg(e2, w);
      return l2;
    }
    function J(a2, d2, f2, h2) {
      "object" === typeof f2 && null !== f2 && f2.type === ya && null === f2.key && (f2 = f2.props.children);
      if ("object" === typeof f2 && null !== f2) {
        switch (f2.$$typeof) {
          case va:
            a: {
              for (var k2 = f2.key, l2 = d2; null !== l2; ) {
                if (l2.key === k2) {
                  k2 = f2.type;
                  if (k2 === ya) {
                    if (7 === l2.tag) {
                      c(a2, l2.sibling);
                      d2 = e(l2, f2.props.children);
                      d2.return = a2;
                      a2 = d2;
                      break a;
                    }
                  } else if (l2.elementType === k2 || "object" === typeof k2 && null !== k2 && k2.$$typeof === Ha && Ng(k2) === l2.type) {
                    c(a2, l2.sibling);
                    d2 = e(l2, f2.props);
                    d2.ref = Lg(a2, l2, f2);
                    d2.return = a2;
                    a2 = d2;
                    break a;
                  }
                  c(a2, l2);
                  break;
                } else b(a2, l2);
                l2 = l2.sibling;
              }
              f2.type === ya ? (d2 = Tg(f2.props.children, a2.mode, h2, f2.key), d2.return = a2, a2 = d2) : (h2 = Rg(f2.type, f2.key, f2.props, null, a2.mode, h2), h2.ref = Lg(a2, d2, f2), h2.return = a2, a2 = h2);
            }
            return g(a2);
          case wa:
            a: {
              for (l2 = f2.key; null !== d2; ) {
                if (d2.key === l2) if (4 === d2.tag && d2.stateNode.containerInfo === f2.containerInfo && d2.stateNode.implementation === f2.implementation) {
                  c(a2, d2.sibling);
                  d2 = e(d2, f2.children || []);
                  d2.return = a2;
                  a2 = d2;
                  break a;
                } else {
                  c(a2, d2);
                  break;
                }
                else b(a2, d2);
                d2 = d2.sibling;
              }
              d2 = Sg(f2, a2.mode, h2);
              d2.return = a2;
              a2 = d2;
            }
            return g(a2);
          case Ha:
            return l2 = f2._init, J(a2, d2, l2(f2._payload), h2);
        }
        if (eb(f2)) return n(a2, d2, f2, h2);
        if (Ka(f2)) return t(a2, d2, f2, h2);
        Mg(a2, f2);
      }
      return "string" === typeof f2 && "" !== f2 || "number" === typeof f2 ? (f2 = "" + f2, null !== d2 && 6 === d2.tag ? (c(a2, d2.sibling), d2 = e(d2, f2), d2.return = a2, a2 = d2) : (c(a2, d2), d2 = Qg(f2, a2.mode, h2), d2.return = a2, a2 = d2), g(a2)) : c(a2, d2);
    }
    return J;
  }
  var Ug = Og(true), Vg = Og(false), Wg = Uf(null), Xg = null, Yg = null, Zg = null;
  function $g() {
    Zg = Yg = Xg = null;
  }
  function ah(a) {
    var b = Wg.current;
    E(Wg);
    a._currentValue = b;
  }
  function bh(a, b, c) {
    for (; null !== a; ) {
      var d = a.alternate;
      (a.childLanes & b) !== b ? (a.childLanes |= b, null !== d && (d.childLanes |= b)) : null !== d && (d.childLanes & b) !== b && (d.childLanes |= b);
      if (a === c) break;
      a = a.return;
    }
  }
  function ch(a, b) {
    Xg = a;
    Zg = Yg = null;
    a = a.dependencies;
    null !== a && null !== a.firstContext && (0 !== (a.lanes & b) && (dh = true), a.firstContext = null);
  }
  function eh(a) {
    var b = a._currentValue;
    if (Zg !== a) if (a = { context: a, memoizedValue: b, next: null }, null === Yg) {
      if (null === Xg) throw Error(p(308));
      Yg = a;
      Xg.dependencies = { lanes: 0, firstContext: a };
    } else Yg = Yg.next = a;
    return b;
  }
  var fh = null;
  function gh(a) {
    null === fh ? fh = [a] : fh.push(a);
  }
  function hh(a, b, c, d) {
    var e = b.interleaved;
    null === e ? (c.next = c, gh(b)) : (c.next = e.next, e.next = c);
    b.interleaved = c;
    return ih(a, d);
  }
  function ih(a, b) {
    a.lanes |= b;
    var c = a.alternate;
    null !== c && (c.lanes |= b);
    c = a;
    for (a = a.return; null !== a; ) a.childLanes |= b, c = a.alternate, null !== c && (c.childLanes |= b), c = a, a = a.return;
    return 3 === c.tag ? c.stateNode : null;
  }
  var jh = false;
  function kh(a) {
    a.updateQueue = { baseState: a.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
  }
  function lh(a, b) {
    a = a.updateQueue;
    b.updateQueue === a && (b.updateQueue = { baseState: a.baseState, firstBaseUpdate: a.firstBaseUpdate, lastBaseUpdate: a.lastBaseUpdate, shared: a.shared, effects: a.effects });
  }
  function mh(a, b) {
    return { eventTime: a, lane: b, tag: 0, payload: null, callback: null, next: null };
  }
  function nh(a, b, c) {
    var d = a.updateQueue;
    if (null === d) return null;
    d = d.shared;
    if (0 !== (K & 2)) {
      var e = d.pending;
      null === e ? b.next = b : (b.next = e.next, e.next = b);
      d.pending = b;
      return ih(a, c);
    }
    e = d.interleaved;
    null === e ? (b.next = b, gh(d)) : (b.next = e.next, e.next = b);
    d.interleaved = b;
    return ih(a, c);
  }
  function oh(a, b, c) {
    b = b.updateQueue;
    if (null !== b && (b = b.shared, 0 !== (c & 4194240))) {
      var d = b.lanes;
      d &= a.pendingLanes;
      c |= d;
      b.lanes = c;
      Cc(a, c);
    }
  }
  function ph(a, b) {
    var c = a.updateQueue, d = a.alternate;
    if (null !== d && (d = d.updateQueue, c === d)) {
      var e = null, f = null;
      c = c.firstBaseUpdate;
      if (null !== c) {
        do {
          var g = { eventTime: c.eventTime, lane: c.lane, tag: c.tag, payload: c.payload, callback: c.callback, next: null };
          null === f ? e = f = g : f = f.next = g;
          c = c.next;
        } while (null !== c);
        null === f ? e = f = b : f = f.next = b;
      } else e = f = b;
      c = { baseState: d.baseState, firstBaseUpdate: e, lastBaseUpdate: f, shared: d.shared, effects: d.effects };
      a.updateQueue = c;
      return;
    }
    a = c.lastBaseUpdate;
    null === a ? c.firstBaseUpdate = b : a.next = b;
    c.lastBaseUpdate = b;
  }
  function qh(a, b, c, d) {
    var e = a.updateQueue;
    jh = false;
    var f = e.firstBaseUpdate, g = e.lastBaseUpdate, h = e.shared.pending;
    if (null !== h) {
      e.shared.pending = null;
      var k = h, l = k.next;
      k.next = null;
      null === g ? f = l : g.next = l;
      g = k;
      var m = a.alternate;
      null !== m && (m = m.updateQueue, h = m.lastBaseUpdate, h !== g && (null === h ? m.firstBaseUpdate = l : h.next = l, m.lastBaseUpdate = k));
    }
    if (null !== f) {
      var q = e.baseState;
      g = 0;
      m = l = k = null;
      h = f;
      do {
        var r = h.lane, y = h.eventTime;
        if ((d & r) === r) {
          null !== m && (m = m.next = {
            eventTime: y,
            lane: 0,
            tag: h.tag,
            payload: h.payload,
            callback: h.callback,
            next: null
          });
          a: {
            var n = a, t = h;
            r = b;
            y = c;
            switch (t.tag) {
              case 1:
                n = t.payload;
                if ("function" === typeof n) {
                  q = n.call(y, q, r);
                  break a;
                }
                q = n;
                break a;
              case 3:
                n.flags = n.flags & -65537 | 128;
              case 0:
                n = t.payload;
                r = "function" === typeof n ? n.call(y, q, r) : n;
                if (null === r || void 0 === r) break a;
                q = A({}, q, r);
                break a;
              case 2:
                jh = true;
            }
          }
          null !== h.callback && 0 !== h.lane && (a.flags |= 64, r = e.effects, null === r ? e.effects = [h] : r.push(h));
        } else y = { eventTime: y, lane: r, tag: h.tag, payload: h.payload, callback: h.callback, next: null }, null === m ? (l = m = y, k = q) : m = m.next = y, g |= r;
        h = h.next;
        if (null === h) if (h = e.shared.pending, null === h) break;
        else r = h, h = r.next, r.next = null, e.lastBaseUpdate = r, e.shared.pending = null;
      } while (1);
      null === m && (k = q);
      e.baseState = k;
      e.firstBaseUpdate = l;
      e.lastBaseUpdate = m;
      b = e.shared.interleaved;
      if (null !== b) {
        e = b;
        do
          g |= e.lane, e = e.next;
        while (e !== b);
      } else null === f && (e.shared.lanes = 0);
      rh |= g;
      a.lanes = g;
      a.memoizedState = q;
    }
  }
  function sh(a, b, c) {
    a = b.effects;
    b.effects = null;
    if (null !== a) for (b = 0; b < a.length; b++) {
      var d = a[b], e = d.callback;
      if (null !== e) {
        d.callback = null;
        d = c;
        if ("function" !== typeof e) throw Error(p(191, e));
        e.call(d);
      }
    }
  }
  var th = {}, uh = Uf(th), vh = Uf(th), wh = Uf(th);
  function xh(a) {
    if (a === th) throw Error(p(174));
    return a;
  }
  function yh(a, b) {
    G(wh, b);
    G(vh, a);
    G(uh, th);
    a = b.nodeType;
    switch (a) {
      case 9:
      case 11:
        b = (b = b.documentElement) ? b.namespaceURI : lb(null, "");
        break;
      default:
        a = 8 === a ? b.parentNode : b, b = a.namespaceURI || null, a = a.tagName, b = lb(b, a);
    }
    E(uh);
    G(uh, b);
  }
  function zh() {
    E(uh);
    E(vh);
    E(wh);
  }
  function Ah(a) {
    xh(wh.current);
    var b = xh(uh.current);
    var c = lb(b, a.type);
    b !== c && (G(vh, a), G(uh, c));
  }
  function Bh(a) {
    vh.current === a && (E(uh), E(vh));
  }
  var L = Uf(0);
  function Ch(a) {
    for (var b = a; null !== b; ) {
      if (13 === b.tag) {
        var c = b.memoizedState;
        if (null !== c && (c = c.dehydrated, null === c || "$?" === c.data || "$!" === c.data)) return b;
      } else if (19 === b.tag && void 0 !== b.memoizedProps.revealOrder) {
        if (0 !== (b.flags & 128)) return b;
      } else if (null !== b.child) {
        b.child.return = b;
        b = b.child;
        continue;
      }
      if (b === a) break;
      for (; null === b.sibling; ) {
        if (null === b.return || b.return === a) return null;
        b = b.return;
      }
      b.sibling.return = b.return;
      b = b.sibling;
    }
    return null;
  }
  var Dh = [];
  function Eh() {
    for (var a = 0; a < Dh.length; a++) Dh[a]._workInProgressVersionPrimary = null;
    Dh.length = 0;
  }
  var Fh = ua.ReactCurrentDispatcher, Gh = ua.ReactCurrentBatchConfig, Hh = 0, M = null, N = null, O = null, Ih = false, Jh = false, Kh = 0, Lh = 0;
  function P() {
    throw Error(p(321));
  }
  function Mh(a, b) {
    if (null === b) return false;
    for (var c = 0; c < b.length && c < a.length; c++) if (!He(a[c], b[c])) return false;
    return true;
  }
  function Nh(a, b, c, d, e, f) {
    Hh = f;
    M = b;
    b.memoizedState = null;
    b.updateQueue = null;
    b.lanes = 0;
    Fh.current = null === a || null === a.memoizedState ? Oh : Ph;
    a = c(d, e);
    if (Jh) {
      f = 0;
      do {
        Jh = false;
        Kh = 0;
        if (25 <= f) throw Error(p(301));
        f += 1;
        O = N = null;
        b.updateQueue = null;
        Fh.current = Qh;
        a = c(d, e);
      } while (Jh);
    }
    Fh.current = Rh;
    b = null !== N && null !== N.next;
    Hh = 0;
    O = N = M = null;
    Ih = false;
    if (b) throw Error(p(300));
    return a;
  }
  function Sh() {
    var a = 0 !== Kh;
    Kh = 0;
    return a;
  }
  function Th() {
    var a = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
    null === O ? M.memoizedState = O = a : O = O.next = a;
    return O;
  }
  function Uh() {
    if (null === N) {
      var a = M.alternate;
      a = null !== a ? a.memoizedState : null;
    } else a = N.next;
    var b = null === O ? M.memoizedState : O.next;
    if (null !== b) O = b, N = a;
    else {
      if (null === a) throw Error(p(310));
      N = a;
      a = { memoizedState: N.memoizedState, baseState: N.baseState, baseQueue: N.baseQueue, queue: N.queue, next: null };
      null === O ? M.memoizedState = O = a : O = O.next = a;
    }
    return O;
  }
  function Vh(a, b) {
    return "function" === typeof b ? b(a) : b;
  }
  function Wh(a) {
    var b = Uh(), c = b.queue;
    if (null === c) throw Error(p(311));
    c.lastRenderedReducer = a;
    var d = N, e = d.baseQueue, f = c.pending;
    if (null !== f) {
      if (null !== e) {
        var g = e.next;
        e.next = f.next;
        f.next = g;
      }
      d.baseQueue = e = f;
      c.pending = null;
    }
    if (null !== e) {
      f = e.next;
      d = d.baseState;
      var h = g = null, k = null, l = f;
      do {
        var m = l.lane;
        if ((Hh & m) === m) null !== k && (k = k.next = { lane: 0, action: l.action, hasEagerState: l.hasEagerState, eagerState: l.eagerState, next: null }), d = l.hasEagerState ? l.eagerState : a(d, l.action);
        else {
          var q = {
            lane: m,
            action: l.action,
            hasEagerState: l.hasEagerState,
            eagerState: l.eagerState,
            next: null
          };
          null === k ? (h = k = q, g = d) : k = k.next = q;
          M.lanes |= m;
          rh |= m;
        }
        l = l.next;
      } while (null !== l && l !== f);
      null === k ? g = d : k.next = h;
      He(d, b.memoizedState) || (dh = true);
      b.memoizedState = d;
      b.baseState = g;
      b.baseQueue = k;
      c.lastRenderedState = d;
    }
    a = c.interleaved;
    if (null !== a) {
      e = a;
      do
        f = e.lane, M.lanes |= f, rh |= f, e = e.next;
      while (e !== a);
    } else null === e && (c.lanes = 0);
    return [b.memoizedState, c.dispatch];
  }
  function Xh(a) {
    var b = Uh(), c = b.queue;
    if (null === c) throw Error(p(311));
    c.lastRenderedReducer = a;
    var d = c.dispatch, e = c.pending, f = b.memoizedState;
    if (null !== e) {
      c.pending = null;
      var g = e = e.next;
      do
        f = a(f, g.action), g = g.next;
      while (g !== e);
      He(f, b.memoizedState) || (dh = true);
      b.memoizedState = f;
      null === b.baseQueue && (b.baseState = f);
      c.lastRenderedState = f;
    }
    return [f, d];
  }
  function Yh() {
  }
  function Zh(a, b) {
    var c = M, d = Uh(), e = b(), f = !He(d.memoizedState, e);
    f && (d.memoizedState = e, dh = true);
    d = d.queue;
    $h(ai.bind(null, c, d, a), [a]);
    if (d.getSnapshot !== b || f || null !== O && O.memoizedState.tag & 1) {
      c.flags |= 2048;
      bi(9, ci.bind(null, c, d, e, b), void 0, null);
      if (null === Q) throw Error(p(349));
      0 !== (Hh & 30) || di(c, b, e);
    }
    return e;
  }
  function di(a, b, c) {
    a.flags |= 16384;
    a = { getSnapshot: b, value: c };
    b = M.updateQueue;
    null === b ? (b = { lastEffect: null, stores: null }, M.updateQueue = b, b.stores = [a]) : (c = b.stores, null === c ? b.stores = [a] : c.push(a));
  }
  function ci(a, b, c, d) {
    b.value = c;
    b.getSnapshot = d;
    ei(b) && fi(a);
  }
  function ai(a, b, c) {
    return c(function() {
      ei(b) && fi(a);
    });
  }
  function ei(a) {
    var b = a.getSnapshot;
    a = a.value;
    try {
      var c = b();
      return !He(a, c);
    } catch (d) {
      return true;
    }
  }
  function fi(a) {
    var b = ih(a, 1);
    null !== b && gi(b, a, 1, -1);
  }
  function hi(a) {
    var b = Th();
    "function" === typeof a && (a = a());
    b.memoizedState = b.baseState = a;
    a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: Vh, lastRenderedState: a };
    b.queue = a;
    a = a.dispatch = ii.bind(null, M, a);
    return [b.memoizedState, a];
  }
  function bi(a, b, c, d) {
    a = { tag: a, create: b, destroy: c, deps: d, next: null };
    b = M.updateQueue;
    null === b ? (b = { lastEffect: null, stores: null }, M.updateQueue = b, b.lastEffect = a.next = a) : (c = b.lastEffect, null === c ? b.lastEffect = a.next = a : (d = c.next, c.next = a, a.next = d, b.lastEffect = a));
    return a;
  }
  function ji() {
    return Uh().memoizedState;
  }
  function ki(a, b, c, d) {
    var e = Th();
    M.flags |= a;
    e.memoizedState = bi(1 | b, c, void 0, void 0 === d ? null : d);
  }
  function li(a, b, c, d) {
    var e = Uh();
    d = void 0 === d ? null : d;
    var f = void 0;
    if (null !== N) {
      var g = N.memoizedState;
      f = g.destroy;
      if (null !== d && Mh(d, g.deps)) {
        e.memoizedState = bi(b, c, f, d);
        return;
      }
    }
    M.flags |= a;
    e.memoizedState = bi(1 | b, c, f, d);
  }
  function mi(a, b) {
    return ki(8390656, 8, a, b);
  }
  function $h(a, b) {
    return li(2048, 8, a, b);
  }
  function ni(a, b) {
    return li(4, 2, a, b);
  }
  function oi(a, b) {
    return li(4, 4, a, b);
  }
  function pi(a, b) {
    if ("function" === typeof b) return a = a(), b(a), function() {
      b(null);
    };
    if (null !== b && void 0 !== b) return a = a(), b.current = a, function() {
      b.current = null;
    };
  }
  function qi(a, b, c) {
    c = null !== c && void 0 !== c ? c.concat([a]) : null;
    return li(4, 4, pi.bind(null, b, a), c);
  }
  function ri() {
  }
  function si(a, b) {
    var c = Uh();
    b = void 0 === b ? null : b;
    var d = c.memoizedState;
    if (null !== d && null !== b && Mh(b, d[1])) return d[0];
    c.memoizedState = [a, b];
    return a;
  }
  function ti(a, b) {
    var c = Uh();
    b = void 0 === b ? null : b;
    var d = c.memoizedState;
    if (null !== d && null !== b && Mh(b, d[1])) return d[0];
    a = a();
    c.memoizedState = [a, b];
    return a;
  }
  function ui(a, b, c) {
    if (0 === (Hh & 21)) return a.baseState && (a.baseState = false, dh = true), a.memoizedState = c;
    He(c, b) || (c = yc(), M.lanes |= c, rh |= c, a.baseState = true);
    return b;
  }
  function vi(a, b) {
    var c = C;
    C = 0 !== c && 4 > c ? c : 4;
    a(true);
    var d = Gh.transition;
    Gh.transition = {};
    try {
      a(false), b();
    } finally {
      C = c, Gh.transition = d;
    }
  }
  function wi() {
    return Uh().memoizedState;
  }
  function xi(a, b, c) {
    var d = yi(a);
    c = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
    if (zi(a)) Ai(b, c);
    else if (c = hh(a, b, c, d), null !== c) {
      var e = R();
      gi(c, a, d, e);
      Bi(c, b, d);
    }
  }
  function ii(a, b, c) {
    var d = yi(a), e = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
    if (zi(a)) Ai(b, e);
    else {
      var f = a.alternate;
      if (0 === a.lanes && (null === f || 0 === f.lanes) && (f = b.lastRenderedReducer, null !== f)) try {
        var g = b.lastRenderedState, h = f(g, c);
        e.hasEagerState = true;
        e.eagerState = h;
        if (He(h, g)) {
          var k = b.interleaved;
          null === k ? (e.next = e, gh(b)) : (e.next = k.next, k.next = e);
          b.interleaved = e;
          return;
        }
      } catch (l) {
      } finally {
      }
      c = hh(a, b, e, d);
      null !== c && (e = R(), gi(c, a, d, e), Bi(c, b, d));
    }
  }
  function zi(a) {
    var b = a.alternate;
    return a === M || null !== b && b === M;
  }
  function Ai(a, b) {
    Jh = Ih = true;
    var c = a.pending;
    null === c ? b.next = b : (b.next = c.next, c.next = b);
    a.pending = b;
  }
  function Bi(a, b, c) {
    if (0 !== (c & 4194240)) {
      var d = b.lanes;
      d &= a.pendingLanes;
      c |= d;
      b.lanes = c;
      Cc(a, c);
    }
  }
  var Rh = { readContext: eh, useCallback: P, useContext: P, useEffect: P, useImperativeHandle: P, useInsertionEffect: P, useLayoutEffect: P, useMemo: P, useReducer: P, useRef: P, useState: P, useDebugValue: P, useDeferredValue: P, useTransition: P, useMutableSource: P, useSyncExternalStore: P, useId: P, unstable_isNewReconciler: false }, Oh = { readContext: eh, useCallback: function(a, b) {
    Th().memoizedState = [a, void 0 === b ? null : b];
    return a;
  }, useContext: eh, useEffect: mi, useImperativeHandle: function(a, b, c) {
    c = null !== c && void 0 !== c ? c.concat([a]) : null;
    return ki(
      4194308,
      4,
      pi.bind(null, b, a),
      c
    );
  }, useLayoutEffect: function(a, b) {
    return ki(4194308, 4, a, b);
  }, useInsertionEffect: function(a, b) {
    return ki(4, 2, a, b);
  }, useMemo: function(a, b) {
    var c = Th();
    b = void 0 === b ? null : b;
    a = a();
    c.memoizedState = [a, b];
    return a;
  }, useReducer: function(a, b, c) {
    var d = Th();
    b = void 0 !== c ? c(b) : b;
    d.memoizedState = d.baseState = b;
    a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: a, lastRenderedState: b };
    d.queue = a;
    a = a.dispatch = xi.bind(null, M, a);
    return [d.memoizedState, a];
  }, useRef: function(a) {
    var b = Th();
    a = { current: a };
    return b.memoizedState = a;
  }, useState: hi, useDebugValue: ri, useDeferredValue: function(a) {
    return Th().memoizedState = a;
  }, useTransition: function() {
    var a = hi(false), b = a[0];
    a = vi.bind(null, a[1]);
    Th().memoizedState = a;
    return [b, a];
  }, useMutableSource: function() {
  }, useSyncExternalStore: function(a, b, c) {
    var d = M, e = Th();
    if (I) {
      if (void 0 === c) throw Error(p(407));
      c = c();
    } else {
      c = b();
      if (null === Q) throw Error(p(349));
      0 !== (Hh & 30) || di(d, b, c);
    }
    e.memoizedState = c;
    var f = { value: c, getSnapshot: b };
    e.queue = f;
    mi(ai.bind(
      null,
      d,
      f,
      a
    ), [a]);
    d.flags |= 2048;
    bi(9, ci.bind(null, d, f, c, b), void 0, null);
    return c;
  }, useId: function() {
    var a = Th(), b = Q.identifierPrefix;
    if (I) {
      var c = sg;
      var d = rg;
      c = (d & ~(1 << 32 - oc(d) - 1)).toString(32) + c;
      b = ":" + b + "R" + c;
      c = Kh++;
      0 < c && (b += "H" + c.toString(32));
      b += ":";
    } else c = Lh++, b = ":" + b + "r" + c.toString(32) + ":";
    return a.memoizedState = b;
  }, unstable_isNewReconciler: false }, Ph = {
    readContext: eh,
    useCallback: si,
    useContext: eh,
    useEffect: $h,
    useImperativeHandle: qi,
    useInsertionEffect: ni,
    useLayoutEffect: oi,
    useMemo: ti,
    useReducer: Wh,
    useRef: ji,
    useState: function() {
      return Wh(Vh);
    },
    useDebugValue: ri,
    useDeferredValue: function(a) {
      var b = Uh();
      return ui(b, N.memoizedState, a);
    },
    useTransition: function() {
      var a = Wh(Vh)[0], b = Uh().memoizedState;
      return [a, b];
    },
    useMutableSource: Yh,
    useSyncExternalStore: Zh,
    useId: wi,
    unstable_isNewReconciler: false
  }, Qh = { readContext: eh, useCallback: si, useContext: eh, useEffect: $h, useImperativeHandle: qi, useInsertionEffect: ni, useLayoutEffect: oi, useMemo: ti, useReducer: Xh, useRef: ji, useState: function() {
    return Xh(Vh);
  }, useDebugValue: ri, useDeferredValue: function(a) {
    var b = Uh();
    return null === N ? b.memoizedState = a : ui(b, N.memoizedState, a);
  }, useTransition: function() {
    var a = Xh(Vh)[0], b = Uh().memoizedState;
    return [a, b];
  }, useMutableSource: Yh, useSyncExternalStore: Zh, useId: wi, unstable_isNewReconciler: false };
  function Ci(a, b) {
    if (a && a.defaultProps) {
      b = A({}, b);
      a = a.defaultProps;
      for (var c in a) void 0 === b[c] && (b[c] = a[c]);
      return b;
    }
    return b;
  }
  function Di(a, b, c, d) {
    b = a.memoizedState;
    c = c(d, b);
    c = null === c || void 0 === c ? b : A({}, b, c);
    a.memoizedState = c;
    0 === a.lanes && (a.updateQueue.baseState = c);
  }
  var Ei = { isMounted: function(a) {
    return (a = a._reactInternals) ? Vb(a) === a : false;
  }, enqueueSetState: function(a, b, c) {
    a = a._reactInternals;
    var d = R(), e = yi(a), f = mh(d, e);
    f.payload = b;
    void 0 !== c && null !== c && (f.callback = c);
    b = nh(a, f, e);
    null !== b && (gi(b, a, e, d), oh(b, a, e));
  }, enqueueReplaceState: function(a, b, c) {
    a = a._reactInternals;
    var d = R(), e = yi(a), f = mh(d, e);
    f.tag = 1;
    f.payload = b;
    void 0 !== c && null !== c && (f.callback = c);
    b = nh(a, f, e);
    null !== b && (gi(b, a, e, d), oh(b, a, e));
  }, enqueueForceUpdate: function(a, b) {
    a = a._reactInternals;
    var c = R(), d = yi(a), e = mh(c, d);
    e.tag = 2;
    void 0 !== b && null !== b && (e.callback = b);
    b = nh(a, e, d);
    null !== b && (gi(b, a, d, c), oh(b, a, d));
  } };
  function Fi(a, b, c, d, e, f, g) {
    a = a.stateNode;
    return "function" === typeof a.shouldComponentUpdate ? a.shouldComponentUpdate(d, f, g) : b.prototype && b.prototype.isPureReactComponent ? !Ie(c, d) || !Ie(e, f) : true;
  }
  function Gi(a, b, c) {
    var d = false, e = Vf;
    var f = b.contextType;
    "object" === typeof f && null !== f ? f = eh(f) : (e = Zf(b) ? Xf : H.current, d = b.contextTypes, f = (d = null !== d && void 0 !== d) ? Yf(a, e) : Vf);
    b = new b(c, f);
    a.memoizedState = null !== b.state && void 0 !== b.state ? b.state : null;
    b.updater = Ei;
    a.stateNode = b;
    b._reactInternals = a;
    d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = e, a.__reactInternalMemoizedMaskedChildContext = f);
    return b;
  }
  function Hi(a, b, c, d) {
    a = b.state;
    "function" === typeof b.componentWillReceiveProps && b.componentWillReceiveProps(c, d);
    "function" === typeof b.UNSAFE_componentWillReceiveProps && b.UNSAFE_componentWillReceiveProps(c, d);
    b.state !== a && Ei.enqueueReplaceState(b, b.state, null);
  }
  function Ii(a, b, c, d) {
    var e = a.stateNode;
    e.props = c;
    e.state = a.memoizedState;
    e.refs = {};
    kh(a);
    var f = b.contextType;
    "object" === typeof f && null !== f ? e.context = eh(f) : (f = Zf(b) ? Xf : H.current, e.context = Yf(a, f));
    e.state = a.memoizedState;
    f = b.getDerivedStateFromProps;
    "function" === typeof f && (Di(a, b, f, c), e.state = a.memoizedState);
    "function" === typeof b.getDerivedStateFromProps || "function" === typeof e.getSnapshotBeforeUpdate || "function" !== typeof e.UNSAFE_componentWillMount && "function" !== typeof e.componentWillMount || (b = e.state, "function" === typeof e.componentWillMount && e.componentWillMount(), "function" === typeof e.UNSAFE_componentWillMount && e.UNSAFE_componentWillMount(), b !== e.state && Ei.enqueueReplaceState(e, e.state, null), qh(a, c, e, d), e.state = a.memoizedState);
    "function" === typeof e.componentDidMount && (a.flags |= 4194308);
  }
  function Ji(a, b) {
    try {
      var c = "", d = b;
      do
        c += Pa(d), d = d.return;
      while (d);
      var e = c;
    } catch (f) {
      e = "\nError generating stack: " + f.message + "\n" + f.stack;
    }
    return { value: a, source: b, stack: e, digest: null };
  }
  function Ki(a, b, c) {
    return { value: a, source: null, stack: null != c ? c : null, digest: null != b ? b : null };
  }
  function Li(a, b) {
    try {
      console.error(b.value);
    } catch (c) {
      setTimeout(function() {
        throw c;
      });
    }
  }
  var Mi = "function" === typeof WeakMap ? WeakMap : Map;
  function Ni(a, b, c) {
    c = mh(-1, c);
    c.tag = 3;
    c.payload = { element: null };
    var d = b.value;
    c.callback = function() {
      Oi || (Oi = true, Pi = d);
      Li(a, b);
    };
    return c;
  }
  function Qi(a, b, c) {
    c = mh(-1, c);
    c.tag = 3;
    var d = a.type.getDerivedStateFromError;
    if ("function" === typeof d) {
      var e = b.value;
      c.payload = function() {
        return d(e);
      };
      c.callback = function() {
        Li(a, b);
      };
    }
    var f = a.stateNode;
    null !== f && "function" === typeof f.componentDidCatch && (c.callback = function() {
      Li(a, b);
      "function" !== typeof d && (null === Ri ? Ri = /* @__PURE__ */ new Set([this]) : Ri.add(this));
      var c2 = b.stack;
      this.componentDidCatch(b.value, { componentStack: null !== c2 ? c2 : "" });
    });
    return c;
  }
  function Si(a, b, c) {
    var d = a.pingCache;
    if (null === d) {
      d = a.pingCache = new Mi();
      var e = /* @__PURE__ */ new Set();
      d.set(b, e);
    } else e = d.get(b), void 0 === e && (e = /* @__PURE__ */ new Set(), d.set(b, e));
    e.has(c) || (e.add(c), a = Ti.bind(null, a, b, c), b.then(a, a));
  }
  function Ui(a) {
    do {
      var b;
      if (b = 13 === a.tag) b = a.memoizedState, b = null !== b ? null !== b.dehydrated ? true : false : true;
      if (b) return a;
      a = a.return;
    } while (null !== a);
    return null;
  }
  function Vi(a, b, c, d, e) {
    if (0 === (a.mode & 1)) return a === b ? a.flags |= 65536 : (a.flags |= 128, c.flags |= 131072, c.flags &= -52805, 1 === c.tag && (null === c.alternate ? c.tag = 17 : (b = mh(-1, 1), b.tag = 2, nh(c, b, 1))), c.lanes |= 1), a;
    a.flags |= 65536;
    a.lanes = e;
    return a;
  }
  var Wi = ua.ReactCurrentOwner, dh = false;
  function Xi(a, b, c, d) {
    b.child = null === a ? Vg(b, null, c, d) : Ug(b, a.child, c, d);
  }
  function Yi(a, b, c, d, e) {
    c = c.render;
    var f = b.ref;
    ch(b, e);
    d = Nh(a, b, c, d, f, e);
    c = Sh();
    if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
    I && c && vg(b);
    b.flags |= 1;
    Xi(a, b, d, e);
    return b.child;
  }
  function $i(a, b, c, d, e) {
    if (null === a) {
      var f = c.type;
      if ("function" === typeof f && !aj(f) && void 0 === f.defaultProps && null === c.compare && void 0 === c.defaultProps) return b.tag = 15, b.type = f, bj(a, b, f, d, e);
      a = Rg(c.type, null, d, b, b.mode, e);
      a.ref = b.ref;
      a.return = b;
      return b.child = a;
    }
    f = a.child;
    if (0 === (a.lanes & e)) {
      var g = f.memoizedProps;
      c = c.compare;
      c = null !== c ? c : Ie;
      if (c(g, d) && a.ref === b.ref) return Zi(a, b, e);
    }
    b.flags |= 1;
    a = Pg(f, d);
    a.ref = b.ref;
    a.return = b;
    return b.child = a;
  }
  function bj(a, b, c, d, e) {
    if (null !== a) {
      var f = a.memoizedProps;
      if (Ie(f, d) && a.ref === b.ref) if (dh = false, b.pendingProps = d = f, 0 !== (a.lanes & e)) 0 !== (a.flags & 131072) && (dh = true);
      else return b.lanes = a.lanes, Zi(a, b, e);
    }
    return cj(a, b, c, d, e);
  }
  function dj(a, b, c) {
    var d = b.pendingProps, e = d.children, f = null !== a ? a.memoizedState : null;
    if ("hidden" === d.mode) if (0 === (b.mode & 1)) b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, G(ej, fj), fj |= c;
    else {
      if (0 === (c & 1073741824)) return a = null !== f ? f.baseLanes | c : c, b.lanes = b.childLanes = 1073741824, b.memoizedState = { baseLanes: a, cachePool: null, transitions: null }, b.updateQueue = null, G(ej, fj), fj |= a, null;
      b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null };
      d = null !== f ? f.baseLanes : c;
      G(ej, fj);
      fj |= d;
    }
    else null !== f ? (d = f.baseLanes | c, b.memoizedState = null) : d = c, G(ej, fj), fj |= d;
    Xi(a, b, e, c);
    return b.child;
  }
  function gj(a, b) {
    var c = b.ref;
    if (null === a && null !== c || null !== a && a.ref !== c) b.flags |= 512, b.flags |= 2097152;
  }
  function cj(a, b, c, d, e) {
    var f = Zf(c) ? Xf : H.current;
    f = Yf(b, f);
    ch(b, e);
    c = Nh(a, b, c, d, f, e);
    d = Sh();
    if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
    I && d && vg(b);
    b.flags |= 1;
    Xi(a, b, c, e);
    return b.child;
  }
  function hj(a, b, c, d, e) {
    if (Zf(c)) {
      var f = true;
      cg(b);
    } else f = false;
    ch(b, e);
    if (null === b.stateNode) ij(a, b), Gi(b, c, d), Ii(b, c, d, e), d = true;
    else if (null === a) {
      var g = b.stateNode, h = b.memoizedProps;
      g.props = h;
      var k = g.context, l = c.contextType;
      "object" === typeof l && null !== l ? l = eh(l) : (l = Zf(c) ? Xf : H.current, l = Yf(b, l));
      var m = c.getDerivedStateFromProps, q = "function" === typeof m || "function" === typeof g.getSnapshotBeforeUpdate;
      q || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== d || k !== l) && Hi(b, g, d, l);
      jh = false;
      var r = b.memoizedState;
      g.state = r;
      qh(b, d, g, e);
      k = b.memoizedState;
      h !== d || r !== k || Wf.current || jh ? ("function" === typeof m && (Di(b, c, m, d), k = b.memoizedState), (h = jh || Fi(b, c, h, d, r, k, l)) ? (q || "function" !== typeof g.UNSAFE_componentWillMount && "function" !== typeof g.componentWillMount || ("function" === typeof g.componentWillMount && g.componentWillMount(), "function" === typeof g.UNSAFE_componentWillMount && g.UNSAFE_componentWillMount()), "function" === typeof g.componentDidMount && (b.flags |= 4194308)) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), b.memoizedProps = d, b.memoizedState = k), g.props = d, g.state = k, g.context = l, d = h) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), d = false);
    } else {
      g = b.stateNode;
      lh(a, b);
      h = b.memoizedProps;
      l = b.type === b.elementType ? h : Ci(b.type, h);
      g.props = l;
      q = b.pendingProps;
      r = g.context;
      k = c.contextType;
      "object" === typeof k && null !== k ? k = eh(k) : (k = Zf(c) ? Xf : H.current, k = Yf(b, k));
      var y = c.getDerivedStateFromProps;
      (m = "function" === typeof y || "function" === typeof g.getSnapshotBeforeUpdate) || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== q || r !== k) && Hi(b, g, d, k);
      jh = false;
      r = b.memoizedState;
      g.state = r;
      qh(b, d, g, e);
      var n = b.memoizedState;
      h !== q || r !== n || Wf.current || jh ? ("function" === typeof y && (Di(b, c, y, d), n = b.memoizedState), (l = jh || Fi(b, c, l, d, r, n, k) || false) ? (m || "function" !== typeof g.UNSAFE_componentWillUpdate && "function" !== typeof g.componentWillUpdate || ("function" === typeof g.componentWillUpdate && g.componentWillUpdate(d, n, k), "function" === typeof g.UNSAFE_componentWillUpdate && g.UNSAFE_componentWillUpdate(d, n, k)), "function" === typeof g.componentDidUpdate && (b.flags |= 4), "function" === typeof g.getSnapshotBeforeUpdate && (b.flags |= 1024)) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), b.memoizedProps = d, b.memoizedState = n), g.props = d, g.state = n, g.context = k, d = l) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), d = false);
    }
    return jj(a, b, c, d, f, e);
  }
  function jj(a, b, c, d, e, f) {
    gj(a, b);
    var g = 0 !== (b.flags & 128);
    if (!d && !g) return e && dg(b, c, false), Zi(a, b, f);
    d = b.stateNode;
    Wi.current = b;
    var h = g && "function" !== typeof c.getDerivedStateFromError ? null : d.render();
    b.flags |= 1;
    null !== a && g ? (b.child = Ug(b, a.child, null, f), b.child = Ug(b, null, h, f)) : Xi(a, b, h, f);
    b.memoizedState = d.state;
    e && dg(b, c, true);
    return b.child;
  }
  function kj(a) {
    var b = a.stateNode;
    b.pendingContext ? ag(a, b.pendingContext, b.pendingContext !== b.context) : b.context && ag(a, b.context, false);
    yh(a, b.containerInfo);
  }
  function lj(a, b, c, d, e) {
    Ig();
    Jg(e);
    b.flags |= 256;
    Xi(a, b, c, d);
    return b.child;
  }
  var mj = { dehydrated: null, treeContext: null, retryLane: 0 };
  function nj(a) {
    return { baseLanes: a, cachePool: null, transitions: null };
  }
  function oj(a, b, c) {
    var d = b.pendingProps, e = L.current, f = false, g = 0 !== (b.flags & 128), h;
    (h = g) || (h = null !== a && null === a.memoizedState ? false : 0 !== (e & 2));
    if (h) f = true, b.flags &= -129;
    else if (null === a || null !== a.memoizedState) e |= 1;
    G(L, e & 1);
    if (null === a) {
      Eg(b);
      a = b.memoizedState;
      if (null !== a && (a = a.dehydrated, null !== a)) return 0 === (b.mode & 1) ? b.lanes = 1 : "$!" === a.data ? b.lanes = 8 : b.lanes = 1073741824, null;
      g = d.children;
      a = d.fallback;
      return f ? (d = b.mode, f = b.child, g = { mode: "hidden", children: g }, 0 === (d & 1) && null !== f ? (f.childLanes = 0, f.pendingProps = g) : f = pj(g, d, 0, null), a = Tg(a, d, c, null), f.return = b, a.return = b, f.sibling = a, b.child = f, b.child.memoizedState = nj(c), b.memoizedState = mj, a) : qj(b, g);
    }
    e = a.memoizedState;
    if (null !== e && (h = e.dehydrated, null !== h)) return rj(a, b, g, d, h, e, c);
    if (f) {
      f = d.fallback;
      g = b.mode;
      e = a.child;
      h = e.sibling;
      var k = { mode: "hidden", children: d.children };
      0 === (g & 1) && b.child !== e ? (d = b.child, d.childLanes = 0, d.pendingProps = k, b.deletions = null) : (d = Pg(e, k), d.subtreeFlags = e.subtreeFlags & 14680064);
      null !== h ? f = Pg(h, f) : (f = Tg(f, g, c, null), f.flags |= 2);
      f.return = b;
      d.return = b;
      d.sibling = f;
      b.child = d;
      d = f;
      f = b.child;
      g = a.child.memoizedState;
      g = null === g ? nj(c) : { baseLanes: g.baseLanes | c, cachePool: null, transitions: g.transitions };
      f.memoizedState = g;
      f.childLanes = a.childLanes & ~c;
      b.memoizedState = mj;
      return d;
    }
    f = a.child;
    a = f.sibling;
    d = Pg(f, { mode: "visible", children: d.children });
    0 === (b.mode & 1) && (d.lanes = c);
    d.return = b;
    d.sibling = null;
    null !== a && (c = b.deletions, null === c ? (b.deletions = [a], b.flags |= 16) : c.push(a));
    b.child = d;
    b.memoizedState = null;
    return d;
  }
  function qj(a, b) {
    b = pj({ mode: "visible", children: b }, a.mode, 0, null);
    b.return = a;
    return a.child = b;
  }
  function sj(a, b, c, d) {
    null !== d && Jg(d);
    Ug(b, a.child, null, c);
    a = qj(b, b.pendingProps.children);
    a.flags |= 2;
    b.memoizedState = null;
    return a;
  }
  function rj(a, b, c, d, e, f, g) {
    if (c) {
      if (b.flags & 256) return b.flags &= -257, d = Ki(Error(p(422))), sj(a, b, g, d);
      if (null !== b.memoizedState) return b.child = a.child, b.flags |= 128, null;
      f = d.fallback;
      e = b.mode;
      d = pj({ mode: "visible", children: d.children }, e, 0, null);
      f = Tg(f, e, g, null);
      f.flags |= 2;
      d.return = b;
      f.return = b;
      d.sibling = f;
      b.child = d;
      0 !== (b.mode & 1) && Ug(b, a.child, null, g);
      b.child.memoizedState = nj(g);
      b.memoizedState = mj;
      return f;
    }
    if (0 === (b.mode & 1)) return sj(a, b, g, null);
    if ("$!" === e.data) {
      d = e.nextSibling && e.nextSibling.dataset;
      if (d) var h = d.dgst;
      d = h;
      f = Error(p(419));
      d = Ki(f, d, void 0);
      return sj(a, b, g, d);
    }
    h = 0 !== (g & a.childLanes);
    if (dh || h) {
      d = Q;
      if (null !== d) {
        switch (g & -g) {
          case 4:
            e = 2;
            break;
          case 16:
            e = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            e = 32;
            break;
          case 536870912:
            e = 268435456;
            break;
          default:
            e = 0;
        }
        e = 0 !== (e & (d.suspendedLanes | g)) ? 0 : e;
        0 !== e && e !== f.retryLane && (f.retryLane = e, ih(a, e), gi(d, a, e, -1));
      }
      tj();
      d = Ki(Error(p(421)));
      return sj(a, b, g, d);
    }
    if ("$?" === e.data) return b.flags |= 128, b.child = a.child, b = uj.bind(null, a), e._reactRetry = b, null;
    a = f.treeContext;
    yg = Lf(e.nextSibling);
    xg = b;
    I = true;
    zg = null;
    null !== a && (og[pg++] = rg, og[pg++] = sg, og[pg++] = qg, rg = a.id, sg = a.overflow, qg = b);
    b = qj(b, d.children);
    b.flags |= 4096;
    return b;
  }
  function vj(a, b, c) {
    a.lanes |= b;
    var d = a.alternate;
    null !== d && (d.lanes |= b);
    bh(a.return, b, c);
  }
  function wj(a, b, c, d, e) {
    var f = a.memoizedState;
    null === f ? a.memoizedState = { isBackwards: b, rendering: null, renderingStartTime: 0, last: d, tail: c, tailMode: e } : (f.isBackwards = b, f.rendering = null, f.renderingStartTime = 0, f.last = d, f.tail = c, f.tailMode = e);
  }
  function xj(a, b, c) {
    var d = b.pendingProps, e = d.revealOrder, f = d.tail;
    Xi(a, b, d.children, c);
    d = L.current;
    if (0 !== (d & 2)) d = d & 1 | 2, b.flags |= 128;
    else {
      if (null !== a && 0 !== (a.flags & 128)) a: for (a = b.child; null !== a; ) {
        if (13 === a.tag) null !== a.memoizedState && vj(a, c, b);
        else if (19 === a.tag) vj(a, c, b);
        else if (null !== a.child) {
          a.child.return = a;
          a = a.child;
          continue;
        }
        if (a === b) break a;
        for (; null === a.sibling; ) {
          if (null === a.return || a.return === b) break a;
          a = a.return;
        }
        a.sibling.return = a.return;
        a = a.sibling;
      }
      d &= 1;
    }
    G(L, d);
    if (0 === (b.mode & 1)) b.memoizedState = null;
    else switch (e) {
      case "forwards":
        c = b.child;
        for (e = null; null !== c; ) a = c.alternate, null !== a && null === Ch(a) && (e = c), c = c.sibling;
        c = e;
        null === c ? (e = b.child, b.child = null) : (e = c.sibling, c.sibling = null);
        wj(b, false, e, c, f);
        break;
      case "backwards":
        c = null;
        e = b.child;
        for (b.child = null; null !== e; ) {
          a = e.alternate;
          if (null !== a && null === Ch(a)) {
            b.child = e;
            break;
          }
          a = e.sibling;
          e.sibling = c;
          c = e;
          e = a;
        }
        wj(b, true, c, null, f);
        break;
      case "together":
        wj(b, false, null, null, void 0);
        break;
      default:
        b.memoizedState = null;
    }
    return b.child;
  }
  function ij(a, b) {
    0 === (b.mode & 1) && null !== a && (a.alternate = null, b.alternate = null, b.flags |= 2);
  }
  function Zi(a, b, c) {
    null !== a && (b.dependencies = a.dependencies);
    rh |= b.lanes;
    if (0 === (c & b.childLanes)) return null;
    if (null !== a && b.child !== a.child) throw Error(p(153));
    if (null !== b.child) {
      a = b.child;
      c = Pg(a, a.pendingProps);
      b.child = c;
      for (c.return = b; null !== a.sibling; ) a = a.sibling, c = c.sibling = Pg(a, a.pendingProps), c.return = b;
      c.sibling = null;
    }
    return b.child;
  }
  function yj(a, b, c) {
    switch (b.tag) {
      case 3:
        kj(b);
        Ig();
        break;
      case 5:
        Ah(b);
        break;
      case 1:
        Zf(b.type) && cg(b);
        break;
      case 4:
        yh(b, b.stateNode.containerInfo);
        break;
      case 10:
        var d = b.type._context, e = b.memoizedProps.value;
        G(Wg, d._currentValue);
        d._currentValue = e;
        break;
      case 13:
        d = b.memoizedState;
        if (null !== d) {
          if (null !== d.dehydrated) return G(L, L.current & 1), b.flags |= 128, null;
          if (0 !== (c & b.child.childLanes)) return oj(a, b, c);
          G(L, L.current & 1);
          a = Zi(a, b, c);
          return null !== a ? a.sibling : null;
        }
        G(L, L.current & 1);
        break;
      case 19:
        d = 0 !== (c & b.childLanes);
        if (0 !== (a.flags & 128)) {
          if (d) return xj(a, b, c);
          b.flags |= 128;
        }
        e = b.memoizedState;
        null !== e && (e.rendering = null, e.tail = null, e.lastEffect = null);
        G(L, L.current);
        if (d) break;
        else return null;
      case 22:
      case 23:
        return b.lanes = 0, dj(a, b, c);
    }
    return Zi(a, b, c);
  }
  var zj, Aj, Bj, Cj;
  zj = function(a, b) {
    for (var c = b.child; null !== c; ) {
      if (5 === c.tag || 6 === c.tag) a.appendChild(c.stateNode);
      else if (4 !== c.tag && null !== c.child) {
        c.child.return = c;
        c = c.child;
        continue;
      }
      if (c === b) break;
      for (; null === c.sibling; ) {
        if (null === c.return || c.return === b) return;
        c = c.return;
      }
      c.sibling.return = c.return;
      c = c.sibling;
    }
  };
  Aj = function() {
  };
  Bj = function(a, b, c, d) {
    var e = a.memoizedProps;
    if (e !== d) {
      a = b.stateNode;
      xh(uh.current);
      var f = null;
      switch (c) {
        case "input":
          e = Ya(a, e);
          d = Ya(a, d);
          f = [];
          break;
        case "select":
          e = A({}, e, { value: void 0 });
          d = A({}, d, { value: void 0 });
          f = [];
          break;
        case "textarea":
          e = gb(a, e);
          d = gb(a, d);
          f = [];
          break;
        default:
          "function" !== typeof e.onClick && "function" === typeof d.onClick && (a.onclick = Bf);
      }
      ub(c, d);
      var g;
      c = null;
      for (l in e) if (!d.hasOwnProperty(l) && e.hasOwnProperty(l) && null != e[l]) if ("style" === l) {
        var h = e[l];
        for (g in h) h.hasOwnProperty(g) && (c || (c = {}), c[g] = "");
      } else "dangerouslySetInnerHTML" !== l && "children" !== l && "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && "autoFocus" !== l && (ea.hasOwnProperty(l) ? f || (f = []) : (f = f || []).push(l, null));
      for (l in d) {
        var k = d[l];
        h = null != e ? e[l] : void 0;
        if (d.hasOwnProperty(l) && k !== h && (null != k || null != h)) if ("style" === l) if (h) {
          for (g in h) !h.hasOwnProperty(g) || k && k.hasOwnProperty(g) || (c || (c = {}), c[g] = "");
          for (g in k) k.hasOwnProperty(g) && h[g] !== k[g] && (c || (c = {}), c[g] = k[g]);
        } else c || (f || (f = []), f.push(
          l,
          c
        )), c = k;
        else "dangerouslySetInnerHTML" === l ? (k = k ? k.__html : void 0, h = h ? h.__html : void 0, null != k && h !== k && (f = f || []).push(l, k)) : "children" === l ? "string" !== typeof k && "number" !== typeof k || (f = f || []).push(l, "" + k) : "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && (ea.hasOwnProperty(l) ? (null != k && "onScroll" === l && D("scroll", a), f || h === k || (f = [])) : (f = f || []).push(l, k));
      }
      c && (f = f || []).push("style", c);
      var l = f;
      if (b.updateQueue = l) b.flags |= 4;
    }
  };
  Cj = function(a, b, c, d) {
    c !== d && (b.flags |= 4);
  };
  function Dj(a, b) {
    if (!I) switch (a.tailMode) {
      case "hidden":
        b = a.tail;
        for (var c = null; null !== b; ) null !== b.alternate && (c = b), b = b.sibling;
        null === c ? a.tail = null : c.sibling = null;
        break;
      case "collapsed":
        c = a.tail;
        for (var d = null; null !== c; ) null !== c.alternate && (d = c), c = c.sibling;
        null === d ? b || null === a.tail ? a.tail = null : a.tail.sibling = null : d.sibling = null;
    }
  }
  function S(a) {
    var b = null !== a.alternate && a.alternate.child === a.child, c = 0, d = 0;
    if (b) for (var e = a.child; null !== e; ) c |= e.lanes | e.childLanes, d |= e.subtreeFlags & 14680064, d |= e.flags & 14680064, e.return = a, e = e.sibling;
    else for (e = a.child; null !== e; ) c |= e.lanes | e.childLanes, d |= e.subtreeFlags, d |= e.flags, e.return = a, e = e.sibling;
    a.subtreeFlags |= d;
    a.childLanes = c;
    return b;
  }
  function Ej(a, b, c) {
    var d = b.pendingProps;
    wg(b);
    switch (b.tag) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return S(b), null;
      case 1:
        return Zf(b.type) && $f(), S(b), null;
      case 3:
        d = b.stateNode;
        zh();
        E(Wf);
        E(H);
        Eh();
        d.pendingContext && (d.context = d.pendingContext, d.pendingContext = null);
        if (null === a || null === a.child) Gg(b) ? b.flags |= 4 : null === a || a.memoizedState.isDehydrated && 0 === (b.flags & 256) || (b.flags |= 1024, null !== zg && (Fj(zg), zg = null));
        Aj(a, b);
        S(b);
        return null;
      case 5:
        Bh(b);
        var e = xh(wh.current);
        c = b.type;
        if (null !== a && null != b.stateNode) Bj(a, b, c, d, e), a.ref !== b.ref && (b.flags |= 512, b.flags |= 2097152);
        else {
          if (!d) {
            if (null === b.stateNode) throw Error(p(166));
            S(b);
            return null;
          }
          a = xh(uh.current);
          if (Gg(b)) {
            d = b.stateNode;
            c = b.type;
            var f = b.memoizedProps;
            d[Of] = b;
            d[Pf] = f;
            a = 0 !== (b.mode & 1);
            switch (c) {
              case "dialog":
                D("cancel", d);
                D("close", d);
                break;
              case "iframe":
              case "object":
              case "embed":
                D("load", d);
                break;
              case "video":
              case "audio":
                for (e = 0; e < lf.length; e++) D(lf[e], d);
                break;
              case "source":
                D("error", d);
                break;
              case "img":
              case "image":
              case "link":
                D(
                  "error",
                  d
                );
                D("load", d);
                break;
              case "details":
                D("toggle", d);
                break;
              case "input":
                Za(d, f);
                D("invalid", d);
                break;
              case "select":
                d._wrapperState = { wasMultiple: !!f.multiple };
                D("invalid", d);
                break;
              case "textarea":
                hb(d, f), D("invalid", d);
            }
            ub(c, f);
            e = null;
            for (var g in f) if (f.hasOwnProperty(g)) {
              var h = f[g];
              "children" === g ? "string" === typeof h ? d.textContent !== h && (true !== f.suppressHydrationWarning && Af(d.textContent, h, a), e = ["children", h]) : "number" === typeof h && d.textContent !== "" + h && (true !== f.suppressHydrationWarning && Af(
                d.textContent,
                h,
                a
              ), e = ["children", "" + h]) : ea.hasOwnProperty(g) && null != h && "onScroll" === g && D("scroll", d);
            }
            switch (c) {
              case "input":
                Va(d);
                db(d, f, true);
                break;
              case "textarea":
                Va(d);
                jb(d);
                break;
              case "select":
              case "option":
                break;
              default:
                "function" === typeof f.onClick && (d.onclick = Bf);
            }
            d = e;
            b.updateQueue = d;
            null !== d && (b.flags |= 4);
          } else {
            g = 9 === e.nodeType ? e : e.ownerDocument;
            "http://www.w3.org/1999/xhtml" === a && (a = kb(c));
            "http://www.w3.org/1999/xhtml" === a ? "script" === c ? (a = g.createElement("div"), a.innerHTML = "<script><\/script>", a = a.removeChild(a.firstChild)) : "string" === typeof d.is ? a = g.createElement(c, { is: d.is }) : (a = g.createElement(c), "select" === c && (g = a, d.multiple ? g.multiple = true : d.size && (g.size = d.size))) : a = g.createElementNS(a, c);
            a[Of] = b;
            a[Pf] = d;
            zj(a, b, false, false);
            b.stateNode = a;
            a: {
              g = vb(c, d);
              switch (c) {
                case "dialog":
                  D("cancel", a);
                  D("close", a);
                  e = d;
                  break;
                case "iframe":
                case "object":
                case "embed":
                  D("load", a);
                  e = d;
                  break;
                case "video":
                case "audio":
                  for (e = 0; e < lf.length; e++) D(lf[e], a);
                  e = d;
                  break;
                case "source":
                  D("error", a);
                  e = d;
                  break;
                case "img":
                case "image":
                case "link":
                  D(
                    "error",
                    a
                  );
                  D("load", a);
                  e = d;
                  break;
                case "details":
                  D("toggle", a);
                  e = d;
                  break;
                case "input":
                  Za(a, d);
                  e = Ya(a, d);
                  D("invalid", a);
                  break;
                case "option":
                  e = d;
                  break;
                case "select":
                  a._wrapperState = { wasMultiple: !!d.multiple };
                  e = A({}, d, { value: void 0 });
                  D("invalid", a);
                  break;
                case "textarea":
                  hb(a, d);
                  e = gb(a, d);
                  D("invalid", a);
                  break;
                default:
                  e = d;
              }
              ub(c, e);
              h = e;
              for (f in h) if (h.hasOwnProperty(f)) {
                var k = h[f];
                "style" === f ? sb(a, k) : "dangerouslySetInnerHTML" === f ? (k = k ? k.__html : void 0, null != k && nb(a, k)) : "children" === f ? "string" === typeof k ? ("textarea" !== c || "" !== k) && ob(a, k) : "number" === typeof k && ob(a, "" + k) : "suppressContentEditableWarning" !== f && "suppressHydrationWarning" !== f && "autoFocus" !== f && (ea.hasOwnProperty(f) ? null != k && "onScroll" === f && D("scroll", a) : null != k && ta(a, f, k, g));
              }
              switch (c) {
                case "input":
                  Va(a);
                  db(a, d, false);
                  break;
                case "textarea":
                  Va(a);
                  jb(a);
                  break;
                case "option":
                  null != d.value && a.setAttribute("value", "" + Sa(d.value));
                  break;
                case "select":
                  a.multiple = !!d.multiple;
                  f = d.value;
                  null != f ? fb(a, !!d.multiple, f, false) : null != d.defaultValue && fb(
                    a,
                    !!d.multiple,
                    d.defaultValue,
                    true
                  );
                  break;
                default:
                  "function" === typeof e.onClick && (a.onclick = Bf);
              }
              switch (c) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  d = !!d.autoFocus;
                  break a;
                case "img":
                  d = true;
                  break a;
                default:
                  d = false;
              }
            }
            d && (b.flags |= 4);
          }
          null !== b.ref && (b.flags |= 512, b.flags |= 2097152);
        }
        S(b);
        return null;
      case 6:
        if (a && null != b.stateNode) Cj(a, b, a.memoizedProps, d);
        else {
          if ("string" !== typeof d && null === b.stateNode) throw Error(p(166));
          c = xh(wh.current);
          xh(uh.current);
          if (Gg(b)) {
            d = b.stateNode;
            c = b.memoizedProps;
            d[Of] = b;
            if (f = d.nodeValue !== c) {
              if (a = xg, null !== a) switch (a.tag) {
                case 3:
                  Af(d.nodeValue, c, 0 !== (a.mode & 1));
                  break;
                case 5:
                  true !== a.memoizedProps.suppressHydrationWarning && Af(d.nodeValue, c, 0 !== (a.mode & 1));
              }
            }
            f && (b.flags |= 4);
          } else d = (9 === c.nodeType ? c : c.ownerDocument).createTextNode(d), d[Of] = b, b.stateNode = d;
        }
        S(b);
        return null;
      case 13:
        E(L);
        d = b.memoizedState;
        if (null === a || null !== a.memoizedState && null !== a.memoizedState.dehydrated) {
          if (I && null !== yg && 0 !== (b.mode & 1) && 0 === (b.flags & 128)) Hg(), Ig(), b.flags |= 98560, f = false;
          else if (f = Gg(b), null !== d && null !== d.dehydrated) {
            if (null === a) {
              if (!f) throw Error(p(318));
              f = b.memoizedState;
              f = null !== f ? f.dehydrated : null;
              if (!f) throw Error(p(317));
              f[Of] = b;
            } else Ig(), 0 === (b.flags & 128) && (b.memoizedState = null), b.flags |= 4;
            S(b);
            f = false;
          } else null !== zg && (Fj(zg), zg = null), f = true;
          if (!f) return b.flags & 65536 ? b : null;
        }
        if (0 !== (b.flags & 128)) return b.lanes = c, b;
        d = null !== d;
        d !== (null !== a && null !== a.memoizedState) && d && (b.child.flags |= 8192, 0 !== (b.mode & 1) && (null === a || 0 !== (L.current & 1) ? 0 === T && (T = 3) : tj()));
        null !== b.updateQueue && (b.flags |= 4);
        S(b);
        return null;
      case 4:
        return zh(), Aj(a, b), null === a && sf(b.stateNode.containerInfo), S(b), null;
      case 10:
        return ah(b.type._context), S(b), null;
      case 17:
        return Zf(b.type) && $f(), S(b), null;
      case 19:
        E(L);
        f = b.memoizedState;
        if (null === f) return S(b), null;
        d = 0 !== (b.flags & 128);
        g = f.rendering;
        if (null === g) if (d) Dj(f, false);
        else {
          if (0 !== T || null !== a && 0 !== (a.flags & 128)) for (a = b.child; null !== a; ) {
            g = Ch(a);
            if (null !== g) {
              b.flags |= 128;
              Dj(f, false);
              d = g.updateQueue;
              null !== d && (b.updateQueue = d, b.flags |= 4);
              b.subtreeFlags = 0;
              d = c;
              for (c = b.child; null !== c; ) f = c, a = d, f.flags &= 14680066, g = f.alternate, null === g ? (f.childLanes = 0, f.lanes = a, f.child = null, f.subtreeFlags = 0, f.memoizedProps = null, f.memoizedState = null, f.updateQueue = null, f.dependencies = null, f.stateNode = null) : (f.childLanes = g.childLanes, f.lanes = g.lanes, f.child = g.child, f.subtreeFlags = 0, f.deletions = null, f.memoizedProps = g.memoizedProps, f.memoizedState = g.memoizedState, f.updateQueue = g.updateQueue, f.type = g.type, a = g.dependencies, f.dependencies = null === a ? null : { lanes: a.lanes, firstContext: a.firstContext }), c = c.sibling;
              G(L, L.current & 1 | 2);
              return b.child;
            }
            a = a.sibling;
          }
          null !== f.tail && B() > Gj && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
        }
        else {
          if (!d) if (a = Ch(g), null !== a) {
            if (b.flags |= 128, d = true, c = a.updateQueue, null !== c && (b.updateQueue = c, b.flags |= 4), Dj(f, true), null === f.tail && "hidden" === f.tailMode && !g.alternate && !I) return S(b), null;
          } else 2 * B() - f.renderingStartTime > Gj && 1073741824 !== c && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
          f.isBackwards ? (g.sibling = b.child, b.child = g) : (c = f.last, null !== c ? c.sibling = g : b.child = g, f.last = g);
        }
        if (null !== f.tail) return b = f.tail, f.rendering = b, f.tail = b.sibling, f.renderingStartTime = B(), b.sibling = null, c = L.current, G(L, d ? c & 1 | 2 : c & 1), b;
        S(b);
        return null;
      case 22:
      case 23:
        return Hj(), d = null !== b.memoizedState, null !== a && null !== a.memoizedState !== d && (b.flags |= 8192), d && 0 !== (b.mode & 1) ? 0 !== (fj & 1073741824) && (S(b), b.subtreeFlags & 6 && (b.flags |= 8192)) : S(b), null;
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(p(156, b.tag));
  }
  function Ij(a, b) {
    wg(b);
    switch (b.tag) {
      case 1:
        return Zf(b.type) && $f(), a = b.flags, a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
      case 3:
        return zh(), E(Wf), E(H), Eh(), a = b.flags, 0 !== (a & 65536) && 0 === (a & 128) ? (b.flags = a & -65537 | 128, b) : null;
      case 5:
        return Bh(b), null;
      case 13:
        E(L);
        a = b.memoizedState;
        if (null !== a && null !== a.dehydrated) {
          if (null === b.alternate) throw Error(p(340));
          Ig();
        }
        a = b.flags;
        return a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
      case 19:
        return E(L), null;
      case 4:
        return zh(), null;
      case 10:
        return ah(b.type._context), null;
      case 22:
      case 23:
        return Hj(), null;
      case 24:
        return null;
      default:
        return null;
    }
  }
  var Jj = false, U = false, Kj = "function" === typeof WeakSet ? WeakSet : Set, V = null;
  function Lj(a, b) {
    var c = a.ref;
    if (null !== c) if ("function" === typeof c) try {
      c(null);
    } catch (d) {
      W(a, b, d);
    }
    else c.current = null;
  }
  function Mj(a, b, c) {
    try {
      c();
    } catch (d) {
      W(a, b, d);
    }
  }
  var Nj = false;
  function Oj(a, b) {
    Cf = dd;
    a = Me();
    if (Ne(a)) {
      if ("selectionStart" in a) var c = { start: a.selectionStart, end: a.selectionEnd };
      else {
        c = (c = a.ownerDocument) && c.defaultView || window;
        var d = c.getSelection && c.getSelection();
        if (d && 0 !== d.rangeCount) {
          c = d.anchorNode;
          var e = d.anchorOffset, f = d.focusNode;
          d = d.focusOffset;
          var g = 0, h = -1, k = -1, l = 0, m = 0, q = a, r = null;
          b: for (; ; ) {
            for (var y; ; ) {
              q !== c || 0 !== e && 3 !== q.nodeType || (h = g + e);
              q !== f || 0 !== d && 3 !== q.nodeType || (k = g + d);
              3 === q.nodeType && (g += q.nodeValue.length);
              if (null === (y = q.firstChild)) break;
              r = q;
              q = y;
            }
            for (; ; ) {
              if (q === a) break b;
              r === c && ++l === e && (h = g);
              r === f && ++m === d && (k = g);
              if (null !== (y = q.nextSibling)) break;
              q = r;
              r = q.parentNode;
            }
            q = y;
          }
          c = -1 === h || -1 === k ? null : { start: h, end: k };
        } else c = null;
      }
      c = c || { start: 0, end: 0 };
    } else c = null;
    Df = { focusedElem: a, selectionRange: c };
    dd = false;
    for (V = b; null !== V; ) if (b = V, a = b.child, 0 !== (b.subtreeFlags & 1028) && null !== a) a.return = b, V = a;
    else for (; null !== V; ) {
      b = V;
      try {
        var n = b.alternate;
        if (0 !== (b.flags & 1024)) switch (b.tag) {
          case 0:
          case 11:
          case 15:
            break;
          case 1:
            if (null !== n) {
              var t = n.memoizedProps, J = n.memoizedState, x = b.stateNode, w = x.getSnapshotBeforeUpdate(b.elementType === b.type ? t : Ci(b.type, t), J);
              x.__reactInternalSnapshotBeforeUpdate = w;
            }
            break;
          case 3:
            var u = b.stateNode.containerInfo;
            1 === u.nodeType ? u.textContent = "" : 9 === u.nodeType && u.documentElement && u.removeChild(u.documentElement);
            break;
          case 5:
          case 6:
          case 4:
          case 17:
            break;
          default:
            throw Error(p(163));
        }
      } catch (F) {
        W(b, b.return, F);
      }
      a = b.sibling;
      if (null !== a) {
        a.return = b.return;
        V = a;
        break;
      }
      V = b.return;
    }
    n = Nj;
    Nj = false;
    return n;
  }
  function Pj(a, b, c) {
    var d = b.updateQueue;
    d = null !== d ? d.lastEffect : null;
    if (null !== d) {
      var e = d = d.next;
      do {
        if ((e.tag & a) === a) {
          var f = e.destroy;
          e.destroy = void 0;
          void 0 !== f && Mj(b, c, f);
        }
        e = e.next;
      } while (e !== d);
    }
  }
  function Qj(a, b) {
    b = b.updateQueue;
    b = null !== b ? b.lastEffect : null;
    if (null !== b) {
      var c = b = b.next;
      do {
        if ((c.tag & a) === a) {
          var d = c.create;
          c.destroy = d();
        }
        c = c.next;
      } while (c !== b);
    }
  }
  function Rj(a) {
    var b = a.ref;
    if (null !== b) {
      var c = a.stateNode;
      switch (a.tag) {
        case 5:
          a = c;
          break;
        default:
          a = c;
      }
      "function" === typeof b ? b(a) : b.current = a;
    }
  }
  function Sj(a) {
    var b = a.alternate;
    null !== b && (a.alternate = null, Sj(b));
    a.child = null;
    a.deletions = null;
    a.sibling = null;
    5 === a.tag && (b = a.stateNode, null !== b && (delete b[Of], delete b[Pf], delete b[of], delete b[Qf], delete b[Rf]));
    a.stateNode = null;
    a.return = null;
    a.dependencies = null;
    a.memoizedProps = null;
    a.memoizedState = null;
    a.pendingProps = null;
    a.stateNode = null;
    a.updateQueue = null;
  }
  function Tj(a) {
    return 5 === a.tag || 3 === a.tag || 4 === a.tag;
  }
  function Uj(a) {
    a: for (; ; ) {
      for (; null === a.sibling; ) {
        if (null === a.return || Tj(a.return)) return null;
        a = a.return;
      }
      a.sibling.return = a.return;
      for (a = a.sibling; 5 !== a.tag && 6 !== a.tag && 18 !== a.tag; ) {
        if (a.flags & 2) continue a;
        if (null === a.child || 4 === a.tag) continue a;
        else a.child.return = a, a = a.child;
      }
      if (!(a.flags & 2)) return a.stateNode;
    }
  }
  function Vj(a, b, c) {
    var d = a.tag;
    if (5 === d || 6 === d) a = a.stateNode, b ? 8 === c.nodeType ? c.parentNode.insertBefore(a, b) : c.insertBefore(a, b) : (8 === c.nodeType ? (b = c.parentNode, b.insertBefore(a, c)) : (b = c, b.appendChild(a)), c = c._reactRootContainer, null !== c && void 0 !== c || null !== b.onclick || (b.onclick = Bf));
    else if (4 !== d && (a = a.child, null !== a)) for (Vj(a, b, c), a = a.sibling; null !== a; ) Vj(a, b, c), a = a.sibling;
  }
  function Wj(a, b, c) {
    var d = a.tag;
    if (5 === d || 6 === d) a = a.stateNode, b ? c.insertBefore(a, b) : c.appendChild(a);
    else if (4 !== d && (a = a.child, null !== a)) for (Wj(a, b, c), a = a.sibling; null !== a; ) Wj(a, b, c), a = a.sibling;
  }
  var X = null, Xj = false;
  function Yj(a, b, c) {
    for (c = c.child; null !== c; ) Zj(a, b, c), c = c.sibling;
  }
  function Zj(a, b, c) {
    if (lc && "function" === typeof lc.onCommitFiberUnmount) try {
      lc.onCommitFiberUnmount(kc, c);
    } catch (h) {
    }
    switch (c.tag) {
      case 5:
        U || Lj(c, b);
      case 6:
        var d = X, e = Xj;
        X = null;
        Yj(a, b, c);
        X = d;
        Xj = e;
        null !== X && (Xj ? (a = X, c = c.stateNode, 8 === a.nodeType ? a.parentNode.removeChild(c) : a.removeChild(c)) : X.removeChild(c.stateNode));
        break;
      case 18:
        null !== X && (Xj ? (a = X, c = c.stateNode, 8 === a.nodeType ? Kf(a.parentNode, c) : 1 === a.nodeType && Kf(a, c), bd(a)) : Kf(X, c.stateNode));
        break;
      case 4:
        d = X;
        e = Xj;
        X = c.stateNode.containerInfo;
        Xj = true;
        Yj(a, b, c);
        X = d;
        Xj = e;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (!U && (d = c.updateQueue, null !== d && (d = d.lastEffect, null !== d))) {
          e = d = d.next;
          do {
            var f = e, g = f.destroy;
            f = f.tag;
            void 0 !== g && (0 !== (f & 2) ? Mj(c, b, g) : 0 !== (f & 4) && Mj(c, b, g));
            e = e.next;
          } while (e !== d);
        }
        Yj(a, b, c);
        break;
      case 1:
        if (!U && (Lj(c, b), d = c.stateNode, "function" === typeof d.componentWillUnmount)) try {
          d.props = c.memoizedProps, d.state = c.memoizedState, d.componentWillUnmount();
        } catch (h) {
          W(c, b, h);
        }
        Yj(a, b, c);
        break;
      case 21:
        Yj(a, b, c);
        break;
      case 22:
        c.mode & 1 ? (U = (d = U) || null !== c.memoizedState, Yj(a, b, c), U = d) : Yj(a, b, c);
        break;
      default:
        Yj(a, b, c);
    }
  }
  function ak(a) {
    var b = a.updateQueue;
    if (null !== b) {
      a.updateQueue = null;
      var c = a.stateNode;
      null === c && (c = a.stateNode = new Kj());
      b.forEach(function(b2) {
        var d = bk.bind(null, a, b2);
        c.has(b2) || (c.add(b2), b2.then(d, d));
      });
    }
  }
  function ck(a, b) {
    var c = b.deletions;
    if (null !== c) for (var d = 0; d < c.length; d++) {
      var e = c[d];
      try {
        var f = a, g = b, h = g;
        a: for (; null !== h; ) {
          switch (h.tag) {
            case 5:
              X = h.stateNode;
              Xj = false;
              break a;
            case 3:
              X = h.stateNode.containerInfo;
              Xj = true;
              break a;
            case 4:
              X = h.stateNode.containerInfo;
              Xj = true;
              break a;
          }
          h = h.return;
        }
        if (null === X) throw Error(p(160));
        Zj(f, g, e);
        X = null;
        Xj = false;
        var k = e.alternate;
        null !== k && (k.return = null);
        e.return = null;
      } catch (l) {
        W(e, b, l);
      }
    }
    if (b.subtreeFlags & 12854) for (b = b.child; null !== b; ) dk(b, a), b = b.sibling;
  }
  function dk(a, b) {
    var c = a.alternate, d = a.flags;
    switch (a.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        ck(b, a);
        ek(a);
        if (d & 4) {
          try {
            Pj(3, a, a.return), Qj(3, a);
          } catch (t) {
            W(a, a.return, t);
          }
          try {
            Pj(5, a, a.return);
          } catch (t) {
            W(a, a.return, t);
          }
        }
        break;
      case 1:
        ck(b, a);
        ek(a);
        d & 512 && null !== c && Lj(c, c.return);
        break;
      case 5:
        ck(b, a);
        ek(a);
        d & 512 && null !== c && Lj(c, c.return);
        if (a.flags & 32) {
          var e = a.stateNode;
          try {
            ob(e, "");
          } catch (t) {
            W(a, a.return, t);
          }
        }
        if (d & 4 && (e = a.stateNode, null != e)) {
          var f = a.memoizedProps, g = null !== c ? c.memoizedProps : f, h = a.type, k = a.updateQueue;
          a.updateQueue = null;
          if (null !== k) try {
            "input" === h && "radio" === f.type && null != f.name && ab(e, f);
            vb(h, g);
            var l = vb(h, f);
            for (g = 0; g < k.length; g += 2) {
              var m = k[g], q = k[g + 1];
              "style" === m ? sb(e, q) : "dangerouslySetInnerHTML" === m ? nb(e, q) : "children" === m ? ob(e, q) : ta(e, m, q, l);
            }
            switch (h) {
              case "input":
                bb(e, f);
                break;
              case "textarea":
                ib(e, f);
                break;
              case "select":
                var r = e._wrapperState.wasMultiple;
                e._wrapperState.wasMultiple = !!f.multiple;
                var y = f.value;
                null != y ? fb(e, !!f.multiple, y, false) : r !== !!f.multiple && (null != f.defaultValue ? fb(
                  e,
                  !!f.multiple,
                  f.defaultValue,
                  true
                ) : fb(e, !!f.multiple, f.multiple ? [] : "", false));
            }
            e[Pf] = f;
          } catch (t) {
            W(a, a.return, t);
          }
        }
        break;
      case 6:
        ck(b, a);
        ek(a);
        if (d & 4) {
          if (null === a.stateNode) throw Error(p(162));
          e = a.stateNode;
          f = a.memoizedProps;
          try {
            e.nodeValue = f;
          } catch (t) {
            W(a, a.return, t);
          }
        }
        break;
      case 3:
        ck(b, a);
        ek(a);
        if (d & 4 && null !== c && c.memoizedState.isDehydrated) try {
          bd(b.containerInfo);
        } catch (t) {
          W(a, a.return, t);
        }
        break;
      case 4:
        ck(b, a);
        ek(a);
        break;
      case 13:
        ck(b, a);
        ek(a);
        e = a.child;
        e.flags & 8192 && (f = null !== e.memoizedState, e.stateNode.isHidden = f, !f || null !== e.alternate && null !== e.alternate.memoizedState || (fk = B()));
        d & 4 && ak(a);
        break;
      case 22:
        m = null !== c && null !== c.memoizedState;
        a.mode & 1 ? (U = (l = U) || m, ck(b, a), U = l) : ck(b, a);
        ek(a);
        if (d & 8192) {
          l = null !== a.memoizedState;
          if ((a.stateNode.isHidden = l) && !m && 0 !== (a.mode & 1)) for (V = a, m = a.child; null !== m; ) {
            for (q = V = m; null !== V; ) {
              r = V;
              y = r.child;
              switch (r.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                  Pj(4, r, r.return);
                  break;
                case 1:
                  Lj(r, r.return);
                  var n = r.stateNode;
                  if ("function" === typeof n.componentWillUnmount) {
                    d = r;
                    c = r.return;
                    try {
                      b = d, n.props = b.memoizedProps, n.state = b.memoizedState, n.componentWillUnmount();
                    } catch (t) {
                      W(d, c, t);
                    }
                  }
                  break;
                case 5:
                  Lj(r, r.return);
                  break;
                case 22:
                  if (null !== r.memoizedState) {
                    gk(q);
                    continue;
                  }
              }
              null !== y ? (y.return = r, V = y) : gk(q);
            }
            m = m.sibling;
          }
          a: for (m = null, q = a; ; ) {
            if (5 === q.tag) {
              if (null === m) {
                m = q;
                try {
                  e = q.stateNode, l ? (f = e.style, "function" === typeof f.setProperty ? f.setProperty("display", "none", "important") : f.display = "none") : (h = q.stateNode, k = q.memoizedProps.style, g = void 0 !== k && null !== k && k.hasOwnProperty("display") ? k.display : null, h.style.display = rb("display", g));
                } catch (t) {
                  W(a, a.return, t);
                }
              }
            } else if (6 === q.tag) {
              if (null === m) try {
                q.stateNode.nodeValue = l ? "" : q.memoizedProps;
              } catch (t) {
                W(a, a.return, t);
              }
            } else if ((22 !== q.tag && 23 !== q.tag || null === q.memoizedState || q === a) && null !== q.child) {
              q.child.return = q;
              q = q.child;
              continue;
            }
            if (q === a) break a;
            for (; null === q.sibling; ) {
              if (null === q.return || q.return === a) break a;
              m === q && (m = null);
              q = q.return;
            }
            m === q && (m = null);
            q.sibling.return = q.return;
            q = q.sibling;
          }
        }
        break;
      case 19:
        ck(b, a);
        ek(a);
        d & 4 && ak(a);
        break;
      case 21:
        break;
      default:
        ck(
          b,
          a
        ), ek(a);
    }
  }
  function ek(a) {
    var b = a.flags;
    if (b & 2) {
      try {
        a: {
          for (var c = a.return; null !== c; ) {
            if (Tj(c)) {
              var d = c;
              break a;
            }
            c = c.return;
          }
          throw Error(p(160));
        }
        switch (d.tag) {
          case 5:
            var e = d.stateNode;
            d.flags & 32 && (ob(e, ""), d.flags &= -33);
            var f = Uj(a);
            Wj(a, f, e);
            break;
          case 3:
          case 4:
            var g = d.stateNode.containerInfo, h = Uj(a);
            Vj(a, h, g);
            break;
          default:
            throw Error(p(161));
        }
      } catch (k) {
        W(a, a.return, k);
      }
      a.flags &= -3;
    }
    b & 4096 && (a.flags &= -4097);
  }
  function hk(a, b, c) {
    V = a;
    ik(a);
  }
  function ik(a, b, c) {
    for (var d = 0 !== (a.mode & 1); null !== V; ) {
      var e = V, f = e.child;
      if (22 === e.tag && d) {
        var g = null !== e.memoizedState || Jj;
        if (!g) {
          var h = e.alternate, k = null !== h && null !== h.memoizedState || U;
          h = Jj;
          var l = U;
          Jj = g;
          if ((U = k) && !l) for (V = e; null !== V; ) g = V, k = g.child, 22 === g.tag && null !== g.memoizedState ? jk(e) : null !== k ? (k.return = g, V = k) : jk(e);
          for (; null !== f; ) V = f, ik(f), f = f.sibling;
          V = e;
          Jj = h;
          U = l;
        }
        kk(a);
      } else 0 !== (e.subtreeFlags & 8772) && null !== f ? (f.return = e, V = f) : kk(a);
    }
  }
  function kk(a) {
    for (; null !== V; ) {
      var b = V;
      if (0 !== (b.flags & 8772)) {
        var c = b.alternate;
        try {
          if (0 !== (b.flags & 8772)) switch (b.tag) {
            case 0:
            case 11:
            case 15:
              U || Qj(5, b);
              break;
            case 1:
              var d = b.stateNode;
              if (b.flags & 4 && !U) if (null === c) d.componentDidMount();
              else {
                var e = b.elementType === b.type ? c.memoizedProps : Ci(b.type, c.memoizedProps);
                d.componentDidUpdate(e, c.memoizedState, d.__reactInternalSnapshotBeforeUpdate);
              }
              var f = b.updateQueue;
              null !== f && sh(b, f, d);
              break;
            case 3:
              var g = b.updateQueue;
              if (null !== g) {
                c = null;
                if (null !== b.child) switch (b.child.tag) {
                  case 5:
                    c = b.child.stateNode;
                    break;
                  case 1:
                    c = b.child.stateNode;
                }
                sh(b, g, c);
              }
              break;
            case 5:
              var h = b.stateNode;
              if (null === c && b.flags & 4) {
                c = h;
                var k = b.memoizedProps;
                switch (b.type) {
                  case "button":
                  case "input":
                  case "select":
                  case "textarea":
                    k.autoFocus && c.focus();
                    break;
                  case "img":
                    k.src && (c.src = k.src);
                }
              }
              break;
            case 6:
              break;
            case 4:
              break;
            case 12:
              break;
            case 13:
              if (null === b.memoizedState) {
                var l = b.alternate;
                if (null !== l) {
                  var m = l.memoizedState;
                  if (null !== m) {
                    var q = m.dehydrated;
                    null !== q && bd(q);
                  }
                }
              }
              break;
            case 19:
            case 17:
            case 21:
            case 22:
            case 23:
            case 25:
              break;
            default:
              throw Error(p(163));
          }
          U || b.flags & 512 && Rj(b);
        } catch (r) {
          W(b, b.return, r);
        }
      }
      if (b === a) {
        V = null;
        break;
      }
      c = b.sibling;
      if (null !== c) {
        c.return = b.return;
        V = c;
        break;
      }
      V = b.return;
    }
  }
  function gk(a) {
    for (; null !== V; ) {
      var b = V;
      if (b === a) {
        V = null;
        break;
      }
      var c = b.sibling;
      if (null !== c) {
        c.return = b.return;
        V = c;
        break;
      }
      V = b.return;
    }
  }
  function jk(a) {
    for (; null !== V; ) {
      var b = V;
      try {
        switch (b.tag) {
          case 0:
          case 11:
          case 15:
            var c = b.return;
            try {
              Qj(4, b);
            } catch (k) {
              W(b, c, k);
            }
            break;
          case 1:
            var d = b.stateNode;
            if ("function" === typeof d.componentDidMount) {
              var e = b.return;
              try {
                d.componentDidMount();
              } catch (k) {
                W(b, e, k);
              }
            }
            var f = b.return;
            try {
              Rj(b);
            } catch (k) {
              W(b, f, k);
            }
            break;
          case 5:
            var g = b.return;
            try {
              Rj(b);
            } catch (k) {
              W(b, g, k);
            }
        }
      } catch (k) {
        W(b, b.return, k);
      }
      if (b === a) {
        V = null;
        break;
      }
      var h = b.sibling;
      if (null !== h) {
        h.return = b.return;
        V = h;
        break;
      }
      V = b.return;
    }
  }
  var lk = Math.ceil, mk = ua.ReactCurrentDispatcher, nk = ua.ReactCurrentOwner, ok = ua.ReactCurrentBatchConfig, K = 0, Q = null, Y = null, Z = 0, fj = 0, ej = Uf(0), T = 0, pk = null, rh = 0, qk = 0, rk = 0, sk = null, tk = null, fk = 0, Gj = Infinity, uk = null, Oi = false, Pi = null, Ri = null, vk = false, wk = null, xk = 0, yk = 0, zk = null, Ak = -1, Bk = 0;
  function R() {
    return 0 !== (K & 6) ? B() : -1 !== Ak ? Ak : Ak = B();
  }
  function yi(a) {
    if (0 === (a.mode & 1)) return 1;
    if (0 !== (K & 2) && 0 !== Z) return Z & -Z;
    if (null !== Kg.transition) return 0 === Bk && (Bk = yc()), Bk;
    a = C;
    if (0 !== a) return a;
    a = window.event;
    a = void 0 === a ? 16 : jd(a.type);
    return a;
  }
  function gi(a, b, c, d) {
    if (50 < yk) throw yk = 0, zk = null, Error(p(185));
    Ac(a, c, d);
    if (0 === (K & 2) || a !== Q) a === Q && (0 === (K & 2) && (qk |= c), 4 === T && Ck(a, Z)), Dk(a, d), 1 === c && 0 === K && 0 === (b.mode & 1) && (Gj = B() + 500, fg && jg());
  }
  function Dk(a, b) {
    var c = a.callbackNode;
    wc(a, b);
    var d = uc(a, a === Q ? Z : 0);
    if (0 === d) null !== c && bc(c), a.callbackNode = null, a.callbackPriority = 0;
    else if (b = d & -d, a.callbackPriority !== b) {
      null != c && bc(c);
      if (1 === b) 0 === a.tag ? ig(Ek.bind(null, a)) : hg(Ek.bind(null, a)), Jf(function() {
        0 === (K & 6) && jg();
      }), c = null;
      else {
        switch (Dc(d)) {
          case 1:
            c = fc;
            break;
          case 4:
            c = gc;
            break;
          case 16:
            c = hc;
            break;
          case 536870912:
            c = jc;
            break;
          default:
            c = hc;
        }
        c = Fk(c, Gk.bind(null, a));
      }
      a.callbackPriority = b;
      a.callbackNode = c;
    }
  }
  function Gk(a, b) {
    Ak = -1;
    Bk = 0;
    if (0 !== (K & 6)) throw Error(p(327));
    var c = a.callbackNode;
    if (Hk() && a.callbackNode !== c) return null;
    var d = uc(a, a === Q ? Z : 0);
    if (0 === d) return null;
    if (0 !== (d & 30) || 0 !== (d & a.expiredLanes) || b) b = Ik(a, d);
    else {
      b = d;
      var e = K;
      K |= 2;
      var f = Jk();
      if (Q !== a || Z !== b) uk = null, Gj = B() + 500, Kk(a, b);
      do
        try {
          Lk();
          break;
        } catch (h) {
          Mk(a, h);
        }
      while (1);
      $g();
      mk.current = f;
      K = e;
      null !== Y ? b = 0 : (Q = null, Z = 0, b = T);
    }
    if (0 !== b) {
      2 === b && (e = xc(a), 0 !== e && (d = e, b = Nk(a, e)));
      if (1 === b) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B()), c;
      if (6 === b) Ck(a, d);
      else {
        e = a.current.alternate;
        if (0 === (d & 30) && !Ok(e) && (b = Ik(a, d), 2 === b && (f = xc(a), 0 !== f && (d = f, b = Nk(a, f))), 1 === b)) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B()), c;
        a.finishedWork = e;
        a.finishedLanes = d;
        switch (b) {
          case 0:
          case 1:
            throw Error(p(345));
          case 2:
            Pk(a, tk, uk);
            break;
          case 3:
            Ck(a, d);
            if ((d & 130023424) === d && (b = fk + 500 - B(), 10 < b)) {
              if (0 !== uc(a, 0)) break;
              e = a.suspendedLanes;
              if ((e & d) !== d) {
                R();
                a.pingedLanes |= a.suspendedLanes & e;
                break;
              }
              a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), b);
              break;
            }
            Pk(a, tk, uk);
            break;
          case 4:
            Ck(a, d);
            if ((d & 4194240) === d) break;
            b = a.eventTimes;
            for (e = -1; 0 < d; ) {
              var g = 31 - oc(d);
              f = 1 << g;
              g = b[g];
              g > e && (e = g);
              d &= ~f;
            }
            d = e;
            d = B() - d;
            d = (120 > d ? 120 : 480 > d ? 480 : 1080 > d ? 1080 : 1920 > d ? 1920 : 3e3 > d ? 3e3 : 4320 > d ? 4320 : 1960 * lk(d / 1960)) - d;
            if (10 < d) {
              a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), d);
              break;
            }
            Pk(a, tk, uk);
            break;
          case 5:
            Pk(a, tk, uk);
            break;
          default:
            throw Error(p(329));
        }
      }
    }
    Dk(a, B());
    return a.callbackNode === c ? Gk.bind(null, a) : null;
  }
  function Nk(a, b) {
    var c = sk;
    a.current.memoizedState.isDehydrated && (Kk(a, b).flags |= 256);
    a = Ik(a, b);
    2 !== a && (b = tk, tk = c, null !== b && Fj(b));
    return a;
  }
  function Fj(a) {
    null === tk ? tk = a : tk.push.apply(tk, a);
  }
  function Ok(a) {
    for (var b = a; ; ) {
      if (b.flags & 16384) {
        var c = b.updateQueue;
        if (null !== c && (c = c.stores, null !== c)) for (var d = 0; d < c.length; d++) {
          var e = c[d], f = e.getSnapshot;
          e = e.value;
          try {
            if (!He(f(), e)) return false;
          } catch (g) {
            return false;
          }
        }
      }
      c = b.child;
      if (b.subtreeFlags & 16384 && null !== c) c.return = b, b = c;
      else {
        if (b === a) break;
        for (; null === b.sibling; ) {
          if (null === b.return || b.return === a) return true;
          b = b.return;
        }
        b.sibling.return = b.return;
        b = b.sibling;
      }
    }
    return true;
  }
  function Ck(a, b) {
    b &= ~rk;
    b &= ~qk;
    a.suspendedLanes |= b;
    a.pingedLanes &= ~b;
    for (a = a.expirationTimes; 0 < b; ) {
      var c = 31 - oc(b), d = 1 << c;
      a[c] = -1;
      b &= ~d;
    }
  }
  function Ek(a) {
    if (0 !== (K & 6)) throw Error(p(327));
    Hk();
    var b = uc(a, 0);
    if (0 === (b & 1)) return Dk(a, B()), null;
    var c = Ik(a, b);
    if (0 !== a.tag && 2 === c) {
      var d = xc(a);
      0 !== d && (b = d, c = Nk(a, d));
    }
    if (1 === c) throw c = pk, Kk(a, 0), Ck(a, b), Dk(a, B()), c;
    if (6 === c) throw Error(p(345));
    a.finishedWork = a.current.alternate;
    a.finishedLanes = b;
    Pk(a, tk, uk);
    Dk(a, B());
    return null;
  }
  function Qk(a, b) {
    var c = K;
    K |= 1;
    try {
      return a(b);
    } finally {
      K = c, 0 === K && (Gj = B() + 500, fg && jg());
    }
  }
  function Rk(a) {
    null !== wk && 0 === wk.tag && 0 === (K & 6) && Hk();
    var b = K;
    K |= 1;
    var c = ok.transition, d = C;
    try {
      if (ok.transition = null, C = 1, a) return a();
    } finally {
      C = d, ok.transition = c, K = b, 0 === (K & 6) && jg();
    }
  }
  function Hj() {
    fj = ej.current;
    E(ej);
  }
  function Kk(a, b) {
    a.finishedWork = null;
    a.finishedLanes = 0;
    var c = a.timeoutHandle;
    -1 !== c && (a.timeoutHandle = -1, Gf(c));
    if (null !== Y) for (c = Y.return; null !== c; ) {
      var d = c;
      wg(d);
      switch (d.tag) {
        case 1:
          d = d.type.childContextTypes;
          null !== d && void 0 !== d && $f();
          break;
        case 3:
          zh();
          E(Wf);
          E(H);
          Eh();
          break;
        case 5:
          Bh(d);
          break;
        case 4:
          zh();
          break;
        case 13:
          E(L);
          break;
        case 19:
          E(L);
          break;
        case 10:
          ah(d.type._context);
          break;
        case 22:
        case 23:
          Hj();
      }
      c = c.return;
    }
    Q = a;
    Y = a = Pg(a.current, null);
    Z = fj = b;
    T = 0;
    pk = null;
    rk = qk = rh = 0;
    tk = sk = null;
    if (null !== fh) {
      for (b = 0; b < fh.length; b++) if (c = fh[b], d = c.interleaved, null !== d) {
        c.interleaved = null;
        var e = d.next, f = c.pending;
        if (null !== f) {
          var g = f.next;
          f.next = e;
          d.next = g;
        }
        c.pending = d;
      }
      fh = null;
    }
    return a;
  }
  function Mk(a, b) {
    do {
      var c = Y;
      try {
        $g();
        Fh.current = Rh;
        if (Ih) {
          for (var d = M.memoizedState; null !== d; ) {
            var e = d.queue;
            null !== e && (e.pending = null);
            d = d.next;
          }
          Ih = false;
        }
        Hh = 0;
        O = N = M = null;
        Jh = false;
        Kh = 0;
        nk.current = null;
        if (null === c || null === c.return) {
          T = 1;
          pk = b;
          Y = null;
          break;
        }
        a: {
          var f = a, g = c.return, h = c, k = b;
          b = Z;
          h.flags |= 32768;
          if (null !== k && "object" === typeof k && "function" === typeof k.then) {
            var l = k, m = h, q = m.tag;
            if (0 === (m.mode & 1) && (0 === q || 11 === q || 15 === q)) {
              var r = m.alternate;
              r ? (m.updateQueue = r.updateQueue, m.memoizedState = r.memoizedState, m.lanes = r.lanes) : (m.updateQueue = null, m.memoizedState = null);
            }
            var y = Ui(g);
            if (null !== y) {
              y.flags &= -257;
              Vi(y, g, h, f, b);
              y.mode & 1 && Si(f, l, b);
              b = y;
              k = l;
              var n = b.updateQueue;
              if (null === n) {
                var t = /* @__PURE__ */ new Set();
                t.add(k);
                b.updateQueue = t;
              } else n.add(k);
              break a;
            } else {
              if (0 === (b & 1)) {
                Si(f, l, b);
                tj();
                break a;
              }
              k = Error(p(426));
            }
          } else if (I && h.mode & 1) {
            var J = Ui(g);
            if (null !== J) {
              0 === (J.flags & 65536) && (J.flags |= 256);
              Vi(J, g, h, f, b);
              Jg(Ji(k, h));
              break a;
            }
          }
          f = k = Ji(k, h);
          4 !== T && (T = 2);
          null === sk ? sk = [f] : sk.push(f);
          f = g;
          do {
            switch (f.tag) {
              case 3:
                f.flags |= 65536;
                b &= -b;
                f.lanes |= b;
                var x = Ni(f, k, b);
                ph(f, x);
                break a;
              case 1:
                h = k;
                var w = f.type, u = f.stateNode;
                if (0 === (f.flags & 128) && ("function" === typeof w.getDerivedStateFromError || null !== u && "function" === typeof u.componentDidCatch && (null === Ri || !Ri.has(u)))) {
                  f.flags |= 65536;
                  b &= -b;
                  f.lanes |= b;
                  var F = Qi(f, h, b);
                  ph(f, F);
                  break a;
                }
            }
            f = f.return;
          } while (null !== f);
        }
        Sk(c);
      } catch (na) {
        b = na;
        Y === c && null !== c && (Y = c = c.return);
        continue;
      }
      break;
    } while (1);
  }
  function Jk() {
    var a = mk.current;
    mk.current = Rh;
    return null === a ? Rh : a;
  }
  function tj() {
    if (0 === T || 3 === T || 2 === T) T = 4;
    null === Q || 0 === (rh & 268435455) && 0 === (qk & 268435455) || Ck(Q, Z);
  }
  function Ik(a, b) {
    var c = K;
    K |= 2;
    var d = Jk();
    if (Q !== a || Z !== b) uk = null, Kk(a, b);
    do
      try {
        Tk();
        break;
      } catch (e) {
        Mk(a, e);
      }
    while (1);
    $g();
    K = c;
    mk.current = d;
    if (null !== Y) throw Error(p(261));
    Q = null;
    Z = 0;
    return T;
  }
  function Tk() {
    for (; null !== Y; ) Uk(Y);
  }
  function Lk() {
    for (; null !== Y && !cc(); ) Uk(Y);
  }
  function Uk(a) {
    var b = Vk(a.alternate, a, fj);
    a.memoizedProps = a.pendingProps;
    null === b ? Sk(a) : Y = b;
    nk.current = null;
  }
  function Sk(a) {
    var b = a;
    do {
      var c = b.alternate;
      a = b.return;
      if (0 === (b.flags & 32768)) {
        if (c = Ej(c, b, fj), null !== c) {
          Y = c;
          return;
        }
      } else {
        c = Ij(c, b);
        if (null !== c) {
          c.flags &= 32767;
          Y = c;
          return;
        }
        if (null !== a) a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null;
        else {
          T = 6;
          Y = null;
          return;
        }
      }
      b = b.sibling;
      if (null !== b) {
        Y = b;
        return;
      }
      Y = b = a;
    } while (null !== b);
    0 === T && (T = 5);
  }
  function Pk(a, b, c) {
    var d = C, e = ok.transition;
    try {
      ok.transition = null, C = 1, Wk(a, b, c, d);
    } finally {
      ok.transition = e, C = d;
    }
    return null;
  }
  function Wk(a, b, c, d) {
    do
      Hk();
    while (null !== wk);
    if (0 !== (K & 6)) throw Error(p(327));
    c = a.finishedWork;
    var e = a.finishedLanes;
    if (null === c) return null;
    a.finishedWork = null;
    a.finishedLanes = 0;
    if (c === a.current) throw Error(p(177));
    a.callbackNode = null;
    a.callbackPriority = 0;
    var f = c.lanes | c.childLanes;
    Bc(a, f);
    a === Q && (Y = Q = null, Z = 0);
    0 === (c.subtreeFlags & 2064) && 0 === (c.flags & 2064) || vk || (vk = true, Fk(hc, function() {
      Hk();
      return null;
    }));
    f = 0 !== (c.flags & 15990);
    if (0 !== (c.subtreeFlags & 15990) || f) {
      f = ok.transition;
      ok.transition = null;
      var g = C;
      C = 1;
      var h = K;
      K |= 4;
      nk.current = null;
      Oj(a, c);
      dk(c, a);
      Oe(Df);
      dd = !!Cf;
      Df = Cf = null;
      a.current = c;
      hk(c);
      dc();
      K = h;
      C = g;
      ok.transition = f;
    } else a.current = c;
    vk && (vk = false, wk = a, xk = e);
    f = a.pendingLanes;
    0 === f && (Ri = null);
    mc(c.stateNode);
    Dk(a, B());
    if (null !== b) for (d = a.onRecoverableError, c = 0; c < b.length; c++) e = b[c], d(e.value, { componentStack: e.stack, digest: e.digest });
    if (Oi) throw Oi = false, a = Pi, Pi = null, a;
    0 !== (xk & 1) && 0 !== a.tag && Hk();
    f = a.pendingLanes;
    0 !== (f & 1) ? a === zk ? yk++ : (yk = 0, zk = a) : yk = 0;
    jg();
    return null;
  }
  function Hk() {
    if (null !== wk) {
      var a = Dc(xk), b = ok.transition, c = C;
      try {
        ok.transition = null;
        C = 16 > a ? 16 : a;
        if (null === wk) var d = false;
        else {
          a = wk;
          wk = null;
          xk = 0;
          if (0 !== (K & 6)) throw Error(p(331));
          var e = K;
          K |= 4;
          for (V = a.current; null !== V; ) {
            var f = V, g = f.child;
            if (0 !== (V.flags & 16)) {
              var h = f.deletions;
              if (null !== h) {
                for (var k = 0; k < h.length; k++) {
                  var l = h[k];
                  for (V = l; null !== V; ) {
                    var m = V;
                    switch (m.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Pj(8, m, f);
                    }
                    var q = m.child;
                    if (null !== q) q.return = m, V = q;
                    else for (; null !== V; ) {
                      m = V;
                      var r = m.sibling, y = m.return;
                      Sj(m);
                      if (m === l) {
                        V = null;
                        break;
                      }
                      if (null !== r) {
                        r.return = y;
                        V = r;
                        break;
                      }
                      V = y;
                    }
                  }
                }
                var n = f.alternate;
                if (null !== n) {
                  var t = n.child;
                  if (null !== t) {
                    n.child = null;
                    do {
                      var J = t.sibling;
                      t.sibling = null;
                      t = J;
                    } while (null !== t);
                  }
                }
                V = f;
              }
            }
            if (0 !== (f.subtreeFlags & 2064) && null !== g) g.return = f, V = g;
            else b: for (; null !== V; ) {
              f = V;
              if (0 !== (f.flags & 2048)) switch (f.tag) {
                case 0:
                case 11:
                case 15:
                  Pj(9, f, f.return);
              }
              var x = f.sibling;
              if (null !== x) {
                x.return = f.return;
                V = x;
                break b;
              }
              V = f.return;
            }
          }
          var w = a.current;
          for (V = w; null !== V; ) {
            g = V;
            var u = g.child;
            if (0 !== (g.subtreeFlags & 2064) && null !== u) u.return = g, V = u;
            else b: for (g = w; null !== V; ) {
              h = V;
              if (0 !== (h.flags & 2048)) try {
                switch (h.tag) {
                  case 0:
                  case 11:
                  case 15:
                    Qj(9, h);
                }
              } catch (na) {
                W(h, h.return, na);
              }
              if (h === g) {
                V = null;
                break b;
              }
              var F = h.sibling;
              if (null !== F) {
                F.return = h.return;
                V = F;
                break b;
              }
              V = h.return;
            }
          }
          K = e;
          jg();
          if (lc && "function" === typeof lc.onPostCommitFiberRoot) try {
            lc.onPostCommitFiberRoot(kc, a);
          } catch (na) {
          }
          d = true;
        }
        return d;
      } finally {
        C = c, ok.transition = b;
      }
    }
    return false;
  }
  function Xk(a, b, c) {
    b = Ji(c, b);
    b = Ni(a, b, 1);
    a = nh(a, b, 1);
    b = R();
    null !== a && (Ac(a, 1, b), Dk(a, b));
  }
  function W(a, b, c) {
    if (3 === a.tag) Xk(a, a, c);
    else for (; null !== b; ) {
      if (3 === b.tag) {
        Xk(b, a, c);
        break;
      } else if (1 === b.tag) {
        var d = b.stateNode;
        if ("function" === typeof b.type.getDerivedStateFromError || "function" === typeof d.componentDidCatch && (null === Ri || !Ri.has(d))) {
          a = Ji(c, a);
          a = Qi(b, a, 1);
          b = nh(b, a, 1);
          a = R();
          null !== b && (Ac(b, 1, a), Dk(b, a));
          break;
        }
      }
      b = b.return;
    }
  }
  function Ti(a, b, c) {
    var d = a.pingCache;
    null !== d && d.delete(b);
    b = R();
    a.pingedLanes |= a.suspendedLanes & c;
    Q === a && (Z & c) === c && (4 === T || 3 === T && (Z & 130023424) === Z && 500 > B() - fk ? Kk(a, 0) : rk |= c);
    Dk(a, b);
  }
  function Yk(a, b) {
    0 === b && (0 === (a.mode & 1) ? b = 1 : (b = sc, sc <<= 1, 0 === (sc & 130023424) && (sc = 4194304)));
    var c = R();
    a = ih(a, b);
    null !== a && (Ac(a, b, c), Dk(a, c));
  }
  function uj(a) {
    var b = a.memoizedState, c = 0;
    null !== b && (c = b.retryLane);
    Yk(a, c);
  }
  function bk(a, b) {
    var c = 0;
    switch (a.tag) {
      case 13:
        var d = a.stateNode;
        var e = a.memoizedState;
        null !== e && (c = e.retryLane);
        break;
      case 19:
        d = a.stateNode;
        break;
      default:
        throw Error(p(314));
    }
    null !== d && d.delete(b);
    Yk(a, c);
  }
  var Vk;
  Vk = function(a, b, c) {
    if (null !== a) if (a.memoizedProps !== b.pendingProps || Wf.current) dh = true;
    else {
      if (0 === (a.lanes & c) && 0 === (b.flags & 128)) return dh = false, yj(a, b, c);
      dh = 0 !== (a.flags & 131072) ? true : false;
    }
    else dh = false, I && 0 !== (b.flags & 1048576) && ug(b, ng, b.index);
    b.lanes = 0;
    switch (b.tag) {
      case 2:
        var d = b.type;
        ij(a, b);
        a = b.pendingProps;
        var e = Yf(b, H.current);
        ch(b, c);
        e = Nh(null, b, d, a, e, c);
        var f = Sh();
        b.flags |= 1;
        "object" === typeof e && null !== e && "function" === typeof e.render && void 0 === e.$$typeof ? (b.tag = 1, b.memoizedState = null, b.updateQueue = null, Zf(d) ? (f = true, cg(b)) : f = false, b.memoizedState = null !== e.state && void 0 !== e.state ? e.state : null, kh(b), e.updater = Ei, b.stateNode = e, e._reactInternals = b, Ii(b, d, a, c), b = jj(null, b, d, true, f, c)) : (b.tag = 0, I && f && vg(b), Xi(null, b, e, c), b = b.child);
        return b;
      case 16:
        d = b.elementType;
        a: {
          ij(a, b);
          a = b.pendingProps;
          e = d._init;
          d = e(d._payload);
          b.type = d;
          e = b.tag = Zk(d);
          a = Ci(d, a);
          switch (e) {
            case 0:
              b = cj(null, b, d, a, c);
              break a;
            case 1:
              b = hj(null, b, d, a, c);
              break a;
            case 11:
              b = Yi(null, b, d, a, c);
              break a;
            case 14:
              b = $i(null, b, d, Ci(d.type, a), c);
              break a;
          }
          throw Error(p(
            306,
            d,
            ""
          ));
        }
        return b;
      case 0:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), cj(a, b, d, e, c);
      case 1:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), hj(a, b, d, e, c);
      case 3:
        a: {
          kj(b);
          if (null === a) throw Error(p(387));
          d = b.pendingProps;
          f = b.memoizedState;
          e = f.element;
          lh(a, b);
          qh(b, d, null, c);
          var g = b.memoizedState;
          d = g.element;
          if (f.isDehydrated) if (f = { element: d, isDehydrated: false, cache: g.cache, pendingSuspenseBoundaries: g.pendingSuspenseBoundaries, transitions: g.transitions }, b.updateQueue.baseState = f, b.memoizedState = f, b.flags & 256) {
            e = Ji(Error(p(423)), b);
            b = lj(a, b, d, c, e);
            break a;
          } else if (d !== e) {
            e = Ji(Error(p(424)), b);
            b = lj(a, b, d, c, e);
            break a;
          } else for (yg = Lf(b.stateNode.containerInfo.firstChild), xg = b, I = true, zg = null, c = Vg(b, null, d, c), b.child = c; c; ) c.flags = c.flags & -3 | 4096, c = c.sibling;
          else {
            Ig();
            if (d === e) {
              b = Zi(a, b, c);
              break a;
            }
            Xi(a, b, d, c);
          }
          b = b.child;
        }
        return b;
      case 5:
        return Ah(b), null === a && Eg(b), d = b.type, e = b.pendingProps, f = null !== a ? a.memoizedProps : null, g = e.children, Ef(d, e) ? g = null : null !== f && Ef(d, f) && (b.flags |= 32), gj(a, b), Xi(a, b, g, c), b.child;
      case 6:
        return null === a && Eg(b), null;
      case 13:
        return oj(a, b, c);
      case 4:
        return yh(b, b.stateNode.containerInfo), d = b.pendingProps, null === a ? b.child = Ug(b, null, d, c) : Xi(a, b, d, c), b.child;
      case 11:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), Yi(a, b, d, e, c);
      case 7:
        return Xi(a, b, b.pendingProps, c), b.child;
      case 8:
        return Xi(a, b, b.pendingProps.children, c), b.child;
      case 12:
        return Xi(a, b, b.pendingProps.children, c), b.child;
      case 10:
        a: {
          d = b.type._context;
          e = b.pendingProps;
          f = b.memoizedProps;
          g = e.value;
          G(Wg, d._currentValue);
          d._currentValue = g;
          if (null !== f) if (He(f.value, g)) {
            if (f.children === e.children && !Wf.current) {
              b = Zi(a, b, c);
              break a;
            }
          } else for (f = b.child, null !== f && (f.return = b); null !== f; ) {
            var h = f.dependencies;
            if (null !== h) {
              g = f.child;
              for (var k = h.firstContext; null !== k; ) {
                if (k.context === d) {
                  if (1 === f.tag) {
                    k = mh(-1, c & -c);
                    k.tag = 2;
                    var l = f.updateQueue;
                    if (null !== l) {
                      l = l.shared;
                      var m = l.pending;
                      null === m ? k.next = k : (k.next = m.next, m.next = k);
                      l.pending = k;
                    }
                  }
                  f.lanes |= c;
                  k = f.alternate;
                  null !== k && (k.lanes |= c);
                  bh(
                    f.return,
                    c,
                    b
                  );
                  h.lanes |= c;
                  break;
                }
                k = k.next;
              }
            } else if (10 === f.tag) g = f.type === b.type ? null : f.child;
            else if (18 === f.tag) {
              g = f.return;
              if (null === g) throw Error(p(341));
              g.lanes |= c;
              h = g.alternate;
              null !== h && (h.lanes |= c);
              bh(g, c, b);
              g = f.sibling;
            } else g = f.child;
            if (null !== g) g.return = f;
            else for (g = f; null !== g; ) {
              if (g === b) {
                g = null;
                break;
              }
              f = g.sibling;
              if (null !== f) {
                f.return = g.return;
                g = f;
                break;
              }
              g = g.return;
            }
            f = g;
          }
          Xi(a, b, e.children, c);
          b = b.child;
        }
        return b;
      case 9:
        return e = b.type, d = b.pendingProps.children, ch(b, c), e = eh(e), d = d(e), b.flags |= 1, Xi(a, b, d, c), b.child;
      case 14:
        return d = b.type, e = Ci(d, b.pendingProps), e = Ci(d.type, e), $i(a, b, d, e, c);
      case 15:
        return bj(a, b, b.type, b.pendingProps, c);
      case 17:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), ij(a, b), b.tag = 1, Zf(d) ? (a = true, cg(b)) : a = false, ch(b, c), Gi(b, d, e), Ii(b, d, e, c), jj(null, b, d, true, a, c);
      case 19:
        return xj(a, b, c);
      case 22:
        return dj(a, b, c);
    }
    throw Error(p(156, b.tag));
  };
  function Fk(a, b) {
    return ac(a, b);
  }
  function $k(a, b, c, d) {
    this.tag = a;
    this.key = c;
    this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
    this.index = 0;
    this.ref = null;
    this.pendingProps = b;
    this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
    this.mode = d;
    this.subtreeFlags = this.flags = 0;
    this.deletions = null;
    this.childLanes = this.lanes = 0;
    this.alternate = null;
  }
  function Bg(a, b, c, d) {
    return new $k(a, b, c, d);
  }
  function aj(a) {
    a = a.prototype;
    return !(!a || !a.isReactComponent);
  }
  function Zk(a) {
    if ("function" === typeof a) return aj(a) ? 1 : 0;
    if (void 0 !== a && null !== a) {
      a = a.$$typeof;
      if (a === Da) return 11;
      if (a === Ga) return 14;
    }
    return 2;
  }
  function Pg(a, b) {
    var c = a.alternate;
    null === c ? (c = Bg(a.tag, b, a.key, a.mode), c.elementType = a.elementType, c.type = a.type, c.stateNode = a.stateNode, c.alternate = a, a.alternate = c) : (c.pendingProps = b, c.type = a.type, c.flags = 0, c.subtreeFlags = 0, c.deletions = null);
    c.flags = a.flags & 14680064;
    c.childLanes = a.childLanes;
    c.lanes = a.lanes;
    c.child = a.child;
    c.memoizedProps = a.memoizedProps;
    c.memoizedState = a.memoizedState;
    c.updateQueue = a.updateQueue;
    b = a.dependencies;
    c.dependencies = null === b ? null : { lanes: b.lanes, firstContext: b.firstContext };
    c.sibling = a.sibling;
    c.index = a.index;
    c.ref = a.ref;
    return c;
  }
  function Rg(a, b, c, d, e, f) {
    var g = 2;
    d = a;
    if ("function" === typeof a) aj(a) && (g = 1);
    else if ("string" === typeof a) g = 5;
    else a: switch (a) {
      case ya:
        return Tg(c.children, e, f, b);
      case za:
        g = 8;
        e |= 8;
        break;
      case Aa:
        return a = Bg(12, c, b, e | 2), a.elementType = Aa, a.lanes = f, a;
      case Ea:
        return a = Bg(13, c, b, e), a.elementType = Ea, a.lanes = f, a;
      case Fa:
        return a = Bg(19, c, b, e), a.elementType = Fa, a.lanes = f, a;
      case Ia:
        return pj(c, e, f, b);
      default:
        if ("object" === typeof a && null !== a) switch (a.$$typeof) {
          case Ba:
            g = 10;
            break a;
          case Ca:
            g = 9;
            break a;
          case Da:
            g = 11;
            break a;
          case Ga:
            g = 14;
            break a;
          case Ha:
            g = 16;
            d = null;
            break a;
        }
        throw Error(p(130, null == a ? a : typeof a, ""));
    }
    b = Bg(g, c, b, e);
    b.elementType = a;
    b.type = d;
    b.lanes = f;
    return b;
  }
  function Tg(a, b, c, d) {
    a = Bg(7, a, d, b);
    a.lanes = c;
    return a;
  }
  function pj(a, b, c, d) {
    a = Bg(22, a, d, b);
    a.elementType = Ia;
    a.lanes = c;
    a.stateNode = { isHidden: false };
    return a;
  }
  function Qg(a, b, c) {
    a = Bg(6, a, null, b);
    a.lanes = c;
    return a;
  }
  function Sg(a, b, c) {
    b = Bg(4, null !== a.children ? a.children : [], a.key, b);
    b.lanes = c;
    b.stateNode = { containerInfo: a.containerInfo, pendingChildren: null, implementation: a.implementation };
    return b;
  }
  function al(a, b, c, d, e) {
    this.tag = b;
    this.containerInfo = a;
    this.finishedWork = this.pingCache = this.current = this.pendingChildren = null;
    this.timeoutHandle = -1;
    this.callbackNode = this.pendingContext = this.context = null;
    this.callbackPriority = 0;
    this.eventTimes = zc(0);
    this.expirationTimes = zc(-1);
    this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
    this.entanglements = zc(0);
    this.identifierPrefix = d;
    this.onRecoverableError = e;
    this.mutableSourceEagerHydrationData = null;
  }
  function bl(a, b, c, d, e, f, g, h, k) {
    a = new al(a, b, c, h, k);
    1 === b ? (b = 1, true === f && (b |= 8)) : b = 0;
    f = Bg(3, null, null, b);
    a.current = f;
    f.stateNode = a;
    f.memoizedState = { element: d, isDehydrated: c, cache: null, transitions: null, pendingSuspenseBoundaries: null };
    kh(f);
    return a;
  }
  function cl(a, b, c) {
    var d = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
    return { $$typeof: wa, key: null == d ? null : "" + d, children: a, containerInfo: b, implementation: c };
  }
  function dl(a) {
    if (!a) return Vf;
    a = a._reactInternals;
    a: {
      if (Vb(a) !== a || 1 !== a.tag) throw Error(p(170));
      var b = a;
      do {
        switch (b.tag) {
          case 3:
            b = b.stateNode.context;
            break a;
          case 1:
            if (Zf(b.type)) {
              b = b.stateNode.__reactInternalMemoizedMergedChildContext;
              break a;
            }
        }
        b = b.return;
      } while (null !== b);
      throw Error(p(171));
    }
    if (1 === a.tag) {
      var c = a.type;
      if (Zf(c)) return bg(a, c, b);
    }
    return b;
  }
  function el(a, b, c, d, e, f, g, h, k) {
    a = bl(c, d, true, a, e, f, g, h, k);
    a.context = dl(null);
    c = a.current;
    d = R();
    e = yi(c);
    f = mh(d, e);
    f.callback = void 0 !== b && null !== b ? b : null;
    nh(c, f, e);
    a.current.lanes = e;
    Ac(a, e, d);
    Dk(a, d);
    return a;
  }
  function fl(a, b, c, d) {
    var e = b.current, f = R(), g = yi(e);
    c = dl(c);
    null === b.context ? b.context = c : b.pendingContext = c;
    b = mh(f, g);
    b.payload = { element: a };
    d = void 0 === d ? null : d;
    null !== d && (b.callback = d);
    a = nh(e, b, g);
    null !== a && (gi(a, e, g, f), oh(a, e, g));
    return g;
  }
  function gl(a) {
    a = a.current;
    if (!a.child) return null;
    switch (a.child.tag) {
      case 5:
        return a.child.stateNode;
      default:
        return a.child.stateNode;
    }
  }
  function hl(a, b) {
    a = a.memoizedState;
    if (null !== a && null !== a.dehydrated) {
      var c = a.retryLane;
      a.retryLane = 0 !== c && c < b ? c : b;
    }
  }
  function il(a, b) {
    hl(a, b);
    (a = a.alternate) && hl(a, b);
  }
  function jl() {
    return null;
  }
  var kl = "function" === typeof reportError ? reportError : function(a) {
    console.error(a);
  };
  function ll(a) {
    this._internalRoot = a;
  }
  ml.prototype.render = ll.prototype.render = function(a) {
    var b = this._internalRoot;
    if (null === b) throw Error(p(409));
    fl(a, b, null, null);
  };
  ml.prototype.unmount = ll.prototype.unmount = function() {
    var a = this._internalRoot;
    if (null !== a) {
      this._internalRoot = null;
      var b = a.containerInfo;
      Rk(function() {
        fl(null, a, null, null);
      });
      b[uf] = null;
    }
  };
  function ml(a) {
    this._internalRoot = a;
  }
  ml.prototype.unstable_scheduleHydration = function(a) {
    if (a) {
      var b = Hc();
      a = { blockedOn: null, target: a, priority: b };
      for (var c = 0; c < Qc.length && 0 !== b && b < Qc[c].priority; c++) ;
      Qc.splice(c, 0, a);
      0 === c && Vc(a);
    }
  };
  function nl(a) {
    return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType);
  }
  function ol(a) {
    return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType && (8 !== a.nodeType || " react-mount-point-unstable " !== a.nodeValue));
  }
  function pl() {
  }
  function ql(a, b, c, d, e) {
    if (e) {
      if ("function" === typeof d) {
        var f = d;
        d = function() {
          var a2 = gl(g);
          f.call(a2);
        };
      }
      var g = el(b, d, a, 0, null, false, false, "", pl);
      a._reactRootContainer = g;
      a[uf] = g.current;
      sf(8 === a.nodeType ? a.parentNode : a);
      Rk();
      return g;
    }
    for (; e = a.lastChild; ) a.removeChild(e);
    if ("function" === typeof d) {
      var h = d;
      d = function() {
        var a2 = gl(k);
        h.call(a2);
      };
    }
    var k = bl(a, 0, false, null, null, false, false, "", pl);
    a._reactRootContainer = k;
    a[uf] = k.current;
    sf(8 === a.nodeType ? a.parentNode : a);
    Rk(function() {
      fl(b, k, c, d);
    });
    return k;
  }
  function rl(a, b, c, d, e) {
    var f = c._reactRootContainer;
    if (f) {
      var g = f;
      if ("function" === typeof e) {
        var h = e;
        e = function() {
          var a2 = gl(g);
          h.call(a2);
        };
      }
      fl(b, g, a, e);
    } else g = ql(c, b, a, e, d);
    return gl(g);
  }
  Ec = function(a) {
    switch (a.tag) {
      case 3:
        var b = a.stateNode;
        if (b.current.memoizedState.isDehydrated) {
          var c = tc(b.pendingLanes);
          0 !== c && (Cc(b, c | 1), Dk(b, B()), 0 === (K & 6) && (Gj = B() + 500, jg()));
        }
        break;
      case 13:
        Rk(function() {
          var b2 = ih(a, 1);
          if (null !== b2) {
            var c2 = R();
            gi(b2, a, 1, c2);
          }
        }), il(a, 1);
    }
  };
  Fc = function(a) {
    if (13 === a.tag) {
      var b = ih(a, 134217728);
      if (null !== b) {
        var c = R();
        gi(b, a, 134217728, c);
      }
      il(a, 134217728);
    }
  };
  Gc = function(a) {
    if (13 === a.tag) {
      var b = yi(a), c = ih(a, b);
      if (null !== c) {
        var d = R();
        gi(c, a, b, d);
      }
      il(a, b);
    }
  };
  Hc = function() {
    return C;
  };
  Ic = function(a, b) {
    var c = C;
    try {
      return C = a, b();
    } finally {
      C = c;
    }
  };
  yb = function(a, b, c) {
    switch (b) {
      case "input":
        bb(a, c);
        b = c.name;
        if ("radio" === c.type && null != b) {
          for (c = a; c.parentNode; ) c = c.parentNode;
          c = c.querySelectorAll("input[name=" + JSON.stringify("" + b) + '][type="radio"]');
          for (b = 0; b < c.length; b++) {
            var d = c[b];
            if (d !== a && d.form === a.form) {
              var e = Db(d);
              if (!e) throw Error(p(90));
              Wa(d);
              bb(d, e);
            }
          }
        }
        break;
      case "textarea":
        ib(a, c);
        break;
      case "select":
        b = c.value, null != b && fb(a, !!c.multiple, b, false);
    }
  };
  Gb = Qk;
  Hb = Rk;
  var sl = { usingClientEntryPoint: false, Events: [Cb, ue, Db, Eb, Fb, Qk] }, tl = { findFiberByHostInstance: Wc, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" };
  var ul = { bundleType: tl.bundleType, version: tl.version, rendererPackageName: tl.rendererPackageName, rendererConfig: tl.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: ua.ReactCurrentDispatcher, findHostInstanceByFiber: function(a) {
    a = Zb(a);
    return null === a ? null : a.stateNode;
  }, findFiberByHostInstance: tl.findFiberByHostInstance || jl, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
  if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) {
    var vl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!vl.isDisabled && vl.supportsFiber) try {
      kc = vl.inject(ul), lc = vl;
    } catch (a) {
    }
  }
  reactDom_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = sl;
  reactDom_production_min.createPortal = function(a, b) {
    var c = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
    if (!nl(b)) throw Error(p(200));
    return cl(a, b, null, c);
  };
  reactDom_production_min.createRoot = function(a, b) {
    if (!nl(a)) throw Error(p(299));
    var c = false, d = "", e = kl;
    null !== b && void 0 !== b && (true === b.unstable_strictMode && (c = true), void 0 !== b.identifierPrefix && (d = b.identifierPrefix), void 0 !== b.onRecoverableError && (e = b.onRecoverableError));
    b = bl(a, 1, false, null, null, c, false, d, e);
    a[uf] = b.current;
    sf(8 === a.nodeType ? a.parentNode : a);
    return new ll(b);
  };
  reactDom_production_min.findDOMNode = function(a) {
    if (null == a) return null;
    if (1 === a.nodeType) return a;
    var b = a._reactInternals;
    if (void 0 === b) {
      if ("function" === typeof a.render) throw Error(p(188));
      a = Object.keys(a).join(",");
      throw Error(p(268, a));
    }
    a = Zb(b);
    a = null === a ? null : a.stateNode;
    return a;
  };
  reactDom_production_min.flushSync = function(a) {
    return Rk(a);
  };
  reactDom_production_min.hydrate = function(a, b, c) {
    if (!ol(b)) throw Error(p(200));
    return rl(null, a, b, true, c);
  };
  reactDom_production_min.hydrateRoot = function(a, b, c) {
    if (!nl(a)) throw Error(p(405));
    var d = null != c && c.hydratedSources || null, e = false, f = "", g = kl;
    null !== c && void 0 !== c && (true === c.unstable_strictMode && (e = true), void 0 !== c.identifierPrefix && (f = c.identifierPrefix), void 0 !== c.onRecoverableError && (g = c.onRecoverableError));
    b = el(b, null, a, 1, null != c ? c : null, e, false, f, g);
    a[uf] = b.current;
    sf(a);
    if (d) for (a = 0; a < d.length; a++) c = d[a], e = c._getVersion, e = e(c._source), null == b.mutableSourceEagerHydrationData ? b.mutableSourceEagerHydrationData = [c, e] : b.mutableSourceEagerHydrationData.push(
      c,
      e
    );
    return new ml(b);
  };
  reactDom_production_min.render = function(a, b, c) {
    if (!ol(b)) throw Error(p(200));
    return rl(null, a, b, false, c);
  };
  reactDom_production_min.unmountComponentAtNode = function(a) {
    if (!ol(a)) throw Error(p(40));
    return a._reactRootContainer ? (Rk(function() {
      rl(null, null, a, false, function() {
        a._reactRootContainer = null;
        a[uf] = null;
      });
    }), true) : false;
  };
  reactDom_production_min.unstable_batchedUpdates = Qk;
  reactDom_production_min.unstable_renderSubtreeIntoContainer = function(a, b, c, d) {
    if (!ol(c)) throw Error(p(200));
    if (null == a || void 0 === a._reactInternals) throw Error(p(38));
    return rl(a, b, c, false, d);
  };
  reactDom_production_min.version = "18.3.1-next-f1338f8080-20240426";
  return reactDom_production_min;
}
var hasRequiredReactDom;
function requireReactDom() {
  if (hasRequiredReactDom) return reactDom.exports;
  hasRequiredReactDom = 1;
  function checkDCE() {
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") {
      return;
    }
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
    } catch (err) {
      console.error(err);
    }
  }
  {
    checkDCE();
    reactDom.exports = /* @__PURE__ */ requireReactDom_production_min();
  }
  return reactDom.exports;
}
var hasRequiredClient;
function requireClient() {
  if (hasRequiredClient) return client;
  hasRequiredClient = 1;
  var m = /* @__PURE__ */ requireReactDom();
  {
    client.createRoot = m.createRoot;
    client.hydrateRoot = m.hydrateRoot;
  }
  return client;
}
var clientExports = /* @__PURE__ */ requireClient();
const safe_path_params = (path, params) => path.split("/").map((part) => {
  if (part.startsWith(":")) {
    return params[part.slice(1)];
  } else {
    return part;
  }
}).join("/");
const routeParameters = Symbol("routeParameters");
const groupRouteParameters = Symbol("groupRouteParameters");
const groupBase = Symbol("groupBase");
const to_kebab_case = (key) => key.replace(/[A-Z]/g, (c) => "-" + c.toLowerCase());
let f7router;
const bindF7Router = (router) => {
  f7router = router;
};
class SafeF7Routes {
  constructor(cs = {}) {
    this.cs = cs;
    this.exportNavigater = func_remember(() => safeNavigater(this.exportControllers()));
    Reflect.set(cs, groupRouteParameters, exportF7Routes(cs));
    Reflect.set(cs, groupBase, "");
  }
  addRoute(configs) {
    const sub = buildCs(configs);
    return new SafeF7Routes({ ...this.cs, ...sub.cs });
  }
  addRoutes(routesmap) {
    const csmap = {};
    for (const key in routesmap) {
      const routes = routesmap[key];
      if (routes instanceof SafeF7Routes) {
        const self_base = `/${to_kebab_case(key)}`;
        const base_path = Reflect.get(this.cs, groupBase) + self_base;
        csmap[key] = {
          ...csAddBase(routes.exportControllers(), base_path),
          [routeParameters]: {
            path: self_base,
            routes: routes.exportF7Routes()
          }
        };
      }
    }
    return new SafeF7Routes({ ...this.cs, ...csmap });
  }
  exportControllers() {
    return this.cs;
  }
  exportF7Routes() {
    return Reflect.get(this.cs, groupRouteParameters);
  }
}
const safeNavigater = (obj) => {
  const res = {};
  for (const key in obj) {
    const val2 = obj[key];
    if (val2 && typeof val2 === "object" && "nav" in val2 && typeof val2.nav === "function") {
      res[key] = (...args) => val2.nav(...args);
    } else {
      res[key] = safeNavigater(val2);
    }
  }
  return res;
};
const buildCs = (configs) => {
  const cs = {};
  for (const key in configs) {
    const config = configs[key];
    const params = config.params;
    const query = config.query;
    let path;
    if (config.path) {
      path = config.path;
    } else {
      path = `/${to_kebab_case(key)}`;
      if (params && params.shape) {
        const path_params = [];
        for (const paramKey in params.shape) {
          path_params.push(`/:${paramKey}`);
        }
        path += path_params.join("/") + "/";
      }
    }
    cs[key] = {
      [routeParameters]: {
        ...obj_omit(config, "params"),
        path
      },
      zParams: params,
      zQuery: query,
      base: "",
      nav(opts) {
        const { params: params2, query: query2, ...options } = opts ?? {};
        const full_path = this.base + this[routeParameters].path;
        const url = params2 ? safe_path_params(full_path, params2) : full_path;
        console.log("navigate to ", url);
        if (query2) {
          f7router?.navigate({ path: url, query: query2 }, options);
        } else {
          f7router?.navigate(url, options);
        }
      }
    };
  }
  return new SafeF7Routes(cs);
};
const exportF7Routes = (cs) => {
  const rs = [];
  for (const key in cs) {
    const controller = cs[key];
    if (controller && routeParameters in controller) {
      rs.push(controller[routeParameters]);
    }
  }
  return rs;
};
const csAddBase = (cs, new_base) => {
  const old_base = cs[groupBase];
  const new_cs = {
    ...obj_omit(cs, groupRouteParameters, groupBase)
  };
  for (const key in new_cs) {
    const child = new_cs[key];
    if (groupBase in child) {
      const new_group_base = child[groupBase].replace(old_base, new_base);
      new_cs[key] = {
        ...csAddBase(child, new_group_base),
        [groupBase]: new_group_base
      };
    } else {
      new_cs[key] = { ...child, base: new_base };
    }
  }
  new_cs[groupBase] = new_base;
  return new_cs;
};
const appRoutes = new SafeF7Routes().addRoute({
  adminLogin: {
    asyncComponent: () => __vitePreload(() => import("./admin-login.page-CauKL65s.js"), true ? __vite__mapDeps([0,1,2,3]) : void 0)
  },
  adminMain: {
    asyncComponent: () => __vitePreload(() => import("./admin-main.page-2ayzS7mL.js"), true ? __vite__mapDeps([4,1,2,3,5]) : void 0)
  },
  login: {
    asyncComponent: () => __vitePreload(() => import("./login.page-6FVI0_5x.js"), true ? __vite__mapDeps([6,1,2,3]) : void 0)
  },
  tabs: {
    asyncComponent: () => __vitePreload(() => import("./tabs.page-CeSuLwtt.js"), true ? __vite__mapDeps([7,3,2,5]) : void 0)
  },
  registry: {
    asyncComponent: () => __vitePreload(() => import("./registry.page-B7lX67nG.js"), true ? __vite__mapDeps([8,1,2,3]) : void 0)
  },
  nofound: {
    path: "/404",
    asyncComponent: () => __vitePreload(() => import("./404-vys3s6VW.js"), true ? __vite__mapDeps([9,3]) : void 0)
  },
  any: {
    path: "(.*)",
    redirect: "/404"
  }
});
const f7Routes = appRoutes.exportF7Routes();
console.log("f7Routes", f7Routes);
const App = () => {
  const f7BrowserHistory = false;
  return /* @__PURE__ */ React.createElement(
    App$1,
    {
      theme: "ios",
      name: "My App",
      routes: f7Routes,
      popup: { closeOnEscape: true },
      sheet: { closeOnEscape: true },
      popover: { closeOnEscape: true },
      actions: { closeOnEscape: true }
    },
    /* @__PURE__ */ React.createElement(
      View2,
      {
        main: true,
        url: "/",
        masterDetailBreakpoint: 768,
        browserHistory: f7BrowserHistory,
        browserHistoryInitialMatch: f7BrowserHistory,
        preloadPreviousPage: true,
        iosSwipeBack: false,
        mdSwipeBack: false
      }
    )
  );
};
setupEsm().then((f7react2) => {
  f7react2.f7ready(() => {
    f7react2.f7.setColorTheme(colors.primary);
  });
});
const container = document.getElementById("app");
const root = clientExports.createRoot(container);
root.render(React.createElement(App));
export {
  $jsx as $,
  Button as B,
  Card as C,
  Icon as I,
  List as L,
  Modal$1 as M,
  Navbar as N,
  Page as P,
  React as R,
  Toolbar as T,
  Views as V,
  getDocument as a,
  $ as b,
  ModalMethods as c,
  getWindow as d,
  extend$1 as e,
  ListInput as f,
  getDevice as g,
  ListItem as h,
  iosPreloaderContent as i,
  f7 as j,
  Preloader as k,
  CardHeader as l,
  mdPreloaderContent as m,
  nextTick as n,
  obj_assign_props as o,
  CardContent as p,
  PageContent as q,
  reactExports as r,
  setupDialog as s,
  View2 as t,
  obj_pick as u,
  setupToast as v,
  bindF7Router as w,
  appRoutes as x
};
