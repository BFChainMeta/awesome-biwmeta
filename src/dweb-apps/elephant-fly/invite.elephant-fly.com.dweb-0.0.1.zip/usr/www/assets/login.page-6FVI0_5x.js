import { R as React, P as Page, L as List, f as ListInput, B as Button } from "./index-CvggWz_h.js";
import { b as biwApi } from "./api-uUGDDCgf.js";
import { d as definePage, b as appUserInfoFlow } from "./page-wJ61H8A2.js";
import { u as useEasyState } from "./toast-DllnHs3T.js";
const login_page = definePage((args) => {
  const account = useEasyState("");
  const pwd = useEasyState("");
  const logining = useEasyState(false);
  const login = async () => {
    try {
      logining.value = true;
      if (!account.value || !pwd.value) {
        return;
      }
      const user = await biwApi.user.login.mutate({ areaCode: "+86", phone: account.value, password: pwd.value });
      appUserInfoFlow.value = user;
      args.safeF7Navigater.tabs({
        reloadAll: true
      });
    } finally {
      logining.value = false;
    }
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "login" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col w-full min-h-full items-center justify-center" }, /* @__PURE__ */ React.createElement("img", { src: "./images/logo.webp", className: "w-24 h-24 rounded-4", alt: "logo" }), /* @__PURE__ */ React.createElement(
    "div",
    {
      className: "w-full max-w-[360px] px-4",
      onKeyDown: (e) => {
        if (e.key == "Enter") {
          login();
        }
      }
    },
    /* @__PURE__ */ React.createElement(List, { strongIos: true, dividersIos: true, insetIos: true }, /* @__PURE__ */ React.createElement(
      ListInput,
      {
        label: "+86",
        type: "tel",
        placeholder: "请输入手机号",
        clearButton: true,
        value: account.value,
        validateOnBlur: true,
        validate: true,
        pattern: "^(13[0-9]|14[579]|15[0-3,5-9]|16[2567]|17[0-8]|18[0-9]|19[189])\\d{8}$",
        errorMessage: "手机号格式错误",
        onInput: (e) => {
          account.value = e.target.value;
        }
      }
    ), /* @__PURE__ */ React.createElement(
      ListInput,
      {
        label: "登录密码",
        type: "password",
        placeholder: "请输入登录密码",
        clearButton: true,
        value: pwd.value,
        validateOnBlur: true,
        validate: true,
        pattern: ".{6,}$",
        errorMessage: "最少6个字符",
        onInput: (e) => {
          pwd.value = e.target.value;
        }
      }
    )),
    /* @__PURE__ */ React.createElement("div", { className: "flex flex-col gap-2 px-4" }, /* @__PURE__ */ React.createElement(Button, { type: "button", roundIos: true, fillIos: true, largeIos: true, onClick: login, loading: logining.value }, "登录"), /* @__PURE__ */ React.createElement(Button, { type: "link", onClick: () => args.safeF7Navigater.registry({ reloadAll: true }) }, "没有飞象卡账号，去注册"))
  )));
});
export {
  login_page as default
};
