import { w as bindF7Router, r as reactExports, x as appRoutes } from "./index-CvggWz_h.js";
const canGoBack = (pageParams) => {
  const f7router = "f7router" in pageParams ? pageParams.f7router : pageParams;
  if (f7router.history.length > 1) {
    return "Back";
  }
  return false;
};
const route_state_url = Symbol.for("url");
const iter_map_async_try = (values, callbackfn) => {
  const result = [];
  let index = 0;
  for (const item of values) {
    result.push(callbackfn(item, index++, values));
  }
  return Promise.allSettled(result);
};
const iter_map_not_null = (values, callbackfn) => {
  const result = [];
  let index = 0;
  for (const value of values) {
    const r = callbackfn(value, index++, values);
    if (r != null) {
      result.push(r);
    }
  }
  return result;
};
const obj_lazify = (obj, target = obj) => {
  for (const [prop, desp] of obj_all_descriptors(obj)) {
    _set_lazify(target, prop, desp);
  }
  return target;
};
const _set_lazify = (target, prop, desp) => {
  if (desp.get !== void 0 && desp.set === void 0 && desp.configurable) {
    const source_get = desp.get;
    const cache_get = function() {
      const cache = source_get.call(this);
      delete desp.get;
      delete desp.set;
      desp.value = cache;
      Object.defineProperty(target, prop, desp);
      return cache;
    };
    desp.get = cache_get;
    Object.defineProperty(target, prop, desp);
  }
};
const obj_all_descriptors = (obj) => {
  const desps = Object.getOwnPropertyDescriptors(obj);
  return Reflect.ownKeys(desps).map((prop) => [
    prop,
    desps[prop]
  ]);
};
const obj_delegate_by = (target, proto, getBy = () => proto, options) => {
  const recursive = false;
  const omit = new Set(options?.omit);
  _delegate_by(target, proto, getBy, recursive, omit);
  return omit;
};
const _delegate_by = (target, proto, getBy, recursive, omit) => {
  for (const [prop, desp] of obj_all_descriptors(proto)) {
    if (omit.has(prop)) {
      continue;
    }
    omit.add(prop);
    let can_delegate = false;
    if (desp.get != null) {
      can_delegate = true;
      const source_get = desp.get;
      desp.get = function() {
        return source_get.call(getBy(this));
      };
    }
    if (desp.set != null) {
      can_delegate = true;
      const source_set = desp.set;
      desp.set = function(value) {
        return source_set.call(getBy(this), value);
      };
    }
    if (typeof desp.value === "function") {
      can_delegate = true;
      const source_func = desp.value;
      desp.value = function(...args) {
        return source_func.apply(getBy(this), args);
      };
    } else {
      delete desp.value;
      desp.set = function(value) {
        return Reflect.set(getBy(this), prop, value, this);
      };
      desp.get = function() {
        return Reflect.get(getBy(this), prop, this);
      };
    }
    if (can_delegate) {
      Object.defineProperty(target, prop, desp);
    }
  }
};
const promise_try = async (fn) => {
  try {
    const value = await fn();
    return {
      status: "fulfilled",
      value
    };
  } catch (reason) {
    return {
      status: "rejected",
      reason
    };
  }
};
const withController = (strategy) => {
  const result = obj_lazify({
    get onPull() {
      return new PureEvent();
    },
    get onCancel() {
      return new PureEvent();
    }
  });
  result.stream = new ReadableStream({
    start(controller) {
      result.controller = controller;
    },
    pull() {
      result.onPull.emit();
    },
    cancel(reason) {
      result.onCancel.emit(reason);
    },
    type: strategy?.type
  }, strategy);
  return result;
};
class PureEvent {
  //#region 核心
  /** 监听表 */
  events = /* @__PURE__ */ new Map();
  /** 有多少监听 */
  get size() {
    return this.events.size;
  }
  /** 判断是否已经存在指定监听 */
  has(key) {
    return this.events.has(key);
  }
  /**
     * 附加监听
     * 可以自定义唯一索引 key，如果重复，会移除之前的监听
     */
  on(cb, options) {
    const key = options?.key ?? cb;
    this.off(key);
    let onDispose = options?.onDispose;
    if (typeof onDispose !== "function") {
      onDispose = void 0;
    }
    const off = () => this.off(key);
    this.events.set(key, {
      cb,
      onDispose,
      off
    });
    return off;
  }
  /**
     * 移除指定监听
     * 如果没有指定事件，那么返回false
     * 否则，如果没有自定义 移除监听器（onDispose），那么直接返回true
     * 否则返回 PromiseSettledResult
     */
  off(key) {
    const event = this.events.get(key);
    if (event == null) {
      return false;
    }
    this.events.delete(key);
    if (event.onDispose == null) {
      return true;
    }
    return promise_try(event.onDispose);
  }
  /**
     * 清理所有的监听
     * 会返回所有被清理的事件的 key
     * 如果自定义了 移除监听器（onDispose）, 那么会在 disposeReturn 中携带结果
     */
  cleanSync() {
    const dels = iter_map_not_null(this.events, ([key, event]) => {
      this.events.delete(key);
      return {
        key,
        disposeReturn: event.onDispose ? promise_try(event.onDispose) : void 0
      };
    });
    return dels;
  }
  /**
     * 清理所有的监听，
     * 并等待所有的 disposeReturn 返回结果
     */
  async clean() {
    const dels = this.cleanSync();
    const results = [];
    for (const del of dels) {
      const disposeReturn = await del.disposeReturn;
      results.push({
        key: del.key,
        disposeReturn
      });
    }
    return results;
  }
  async emit(data) {
    if (this.size === 0) {
      return;
    }
    const errors = [];
    const results = await iter_map_async_try(this.events.values(), (cb) => cb.cb(data));
    for (const item of results) {
      if (item.status === "rejected") {
        errors.push(...item.reason);
      }
    }
    if (errors.length > 0) {
      throw new AggregateError(errors, "emit error");
    }
  }
  once(cb_or_options, options) {
    let cb;
    if (typeof cb_or_options === "function") {
      cb = cb_or_options;
    } else if (cb_or_options != null) {
      options = cb_or_options;
    }
    const filter = options?.filter ?? (() => true);
    if (cb == null) {
      const onDispose = options?.onDispose;
      const off2 = this.on((data) => {
        if (filter(data)) {
          promiseWithResolvers.resolve(data);
          off2();
        }
      }, {
        ...options,
        onDispose() {
          if (false === resolved) {
            promiseWithResolvers.reject(new Error("listener dispose"));
          }
          onDispose?.();
        }
      });
      const job = Promise.withResolvers();
      let resolved = false;
      const promiseWithResolvers = Object.assign(job.promise, {
        resolve(data) {
          resolved = true;
          job.resolve(data);
        },
        reject(reason) {
          job.reject(reason);
        }
      });
      return promiseWithResolvers;
    }
    const off = this.on(async (data) => {
      if (filter(data)) {
        const disposeReturn = off();
        if (disposeReturn !== false) {
          try {
            return cb(data);
          } finally {
            if (disposeReturn instanceof Promise) {
              await disposeReturn;
            }
          }
        }
      }
    }, options);
    return off;
  }
}
class PureEventDelegate extends PureEvent {
  byPureEvent;
  constructor(byPureEvent = new PureEvent()) {
    super();
    this.byPureEvent = byPureEvent;
  }
}
obj_delegate_by(PureEventDelegate.prototype, PureEvent.prototype, (target) => target.byPureEvent);
var _computedKey;
_computedKey = Symbol.asyncIterator;
class SharedFlow extends PureEventDelegate {
  constructor(by = new PureEvent()) {
    super(by);
  }
  /**
     * 将事件以流的方式发出
     * 和使用 `for await (const data of flow)` 的方式来隐性触发流监听不同，这里的 stream 函数在调用的时候，就会立刻进行数据监听，因此可以避免一些执行顺序的误会
     */
  stream(options) {
    const readable = withController();
    const off = this.on(async (data) => {
      readable.controller.enqueue(data);
      if ((readable.controller.desiredSize ?? 1) <= 0) {
        await readable.onPull.once();
      }
    }, {
      ...options,
      onDispose() {
        stream.return();
        options?.onDispose?.();
      }
    });
    readable.onCancel.once(() => {
      readable.onPull.clean();
      off();
    });
    const stream = this.#stream(readable);
    return stream;
  }
  async *#stream(readable) {
    try {
      const reader = readable.stream.getReader();
      while (true) {
        const item = await reader.read();
        if (item.done) {
          break;
        }
        yield item.value;
      }
    } catch (e) {
      console.log("catch", e);
      readable.controller.error(e);
    } finally {
      console.log("finally");
      readable.controller.close();
    }
  }
  [_computedKey]() {
    return this.stream();
  }
}
class StateFlow extends SharedFlow {
  constructor(initialValue, by) {
    super(by);
    this.#value = initialValue;
  }
  #value;
  get value() {
    return this.#value;
  }
  set value(value) {
    this.emit(value);
  }
  emit(value) {
    if (this.#value !== value) {
      this.#value = value;
      super.emit(value);
    }
    return Promise.resolve();
  }
}
const storeFlow = async (key, defaultValue, options = {}) => {
  const { transformer = JSON, storage = localStorage } = options;
  const getDefaultValue = typeof defaultValue === "function" ? defaultValue : () => defaultValue;
  const initialValue = await (async () => {
    let _userInfo;
    let useInfo_json = await storage.getItem(key);
    if (useInfo_json) {
      try {
        _userInfo = transformer.parse(useInfo_json);
      } catch (err) {
        console.warn("useInfo_json parse error:", err, useInfo_json);
      }
    }
    let userInfo;
    if (_userInfo == null) {
      userInfo = getDefaultValue();
      storage.setItem(key, transformer.stringify(userInfo));
    } else {
      userInfo = _userInfo;
    }
    let dirty = false;
    const person = new Proxy(userInfo, {
      get: function(target, prop) {
        return Reflect.get(userInfo, prop);
      },
      set: function(target, prop, value) {
        Reflect.set(userInfo, prop, value);
        if (false === dirty) {
          dirty = true;
          queueMicrotask(() => {
            const new_useInfo_json = transformer.stringify(userInfo);
            if (new_useInfo_json !== useInfo_json) {
              flow.emit(userInfo);
            }
            dirty = false;
          });
        }
        return true;
      }
    });
    return person;
  })();
  const flow = new StateFlow(initialValue);
  flow.on((newUserInfo) => {
    const new_useInfo_json = transformer.stringify(newUserInfo);
    if (new_useInfo_json === void 0 || new_useInfo_json === "null") {
      return storage.removeItem(key);
    } else {
      return storage.setItem(key, new_useInfo_json);
    }
  });
  return flow;
};
const SAVE_APP_USER_INFO_KEY = "👨‍👩‍👦‍👦appUserInfo";
const appUserInfoFlow = await storeFlow(SAVE_APP_USER_INFO_KEY, () => ({}));
const appAdminInfoFlow = await storeFlow(
  SAVE_APP_USER_INFO_KEY,
  () => ({})
);
const routeStatesFlow = new StateFlow([]);
Object.assign(globalThis, { routeStatesFlow });
const usePageParams = (params, options) => {
  const { f7route, f7router } = params;
  bindF7Router(f7router);
  const [backLink, setBackLink] = reactExports.useState(false);
  const routeState = reactExports.useMemo(() => {
    if (params.routeState) {
      return params.routeState;
    }
    const routeStates = routeStatesFlow.value;
    const lastRouteState = routeStates.findLast((r) => r[route_state_url] === params.f7route.url);
    if (lastRouteState) {
      if (lastRouteState[route_state_url] === params.f7route.url) {
        return { ...lastRouteState };
      }
    }
    const routeState2 = { [route_state_url]: params.f7route.url };
    return routeState2;
  }, []);
  reactExports.useEffect(() => {
    if (f7router.currentRoute == f7route) {
      setBackLink(canGoBack(f7router));
      const routeStates = routeStatesFlow.value;
      routeStates[f7router.history.length - 1] = routeState;
      routeStates.length = f7router.history.length;
    }
  }, [f7route, f7router]);
  const isCurrentRouteFlow = reactExports.useMemo(() => new StateFlow(false), []);
  const isPageInFlow = reactExports.useMemo(() => new StateFlow(false), []);
  const paramsx = {
    ...params,
    backLink,
    routeState,
    safeF7Navigater: appRoutes.exportNavigater(),
    isCurrentRouteFlow,
    isPageInFlow,
    pageProps: {
      ...params.pageProps
      // onPageMounted(page) {
      //   console.log("QAQ onPageMounted", page.name);
      // },
      // onPageAfterIn(page) {
      //   console.log("QAQ onPageAfterIn", page.name);
      // },
      // onPageAfterOut(page) {
      //   console.log("QAQ onPageAfterOut", page.name);
      // },
      // onPageInit(page) {
      //   console.log("QAQ onPageInit", page.name);
      // },
      // onPageBeforeUnmount(page) {
      //   console.log("QAQ onPageBeforeUnmount", page.name);
      // },
      // onPageBeforeRemove(page) {
      //   console.log("QAQ onPageBeforeRemove", page.name);
      // },
      // onPageBeforeIn(page) {
      //   console.log("QAQ onPageBeforeIn", page.name);
      //   // isPageInFlow.value = true;
      // },
      // onPageBeforeOut(page) {
      //   console.log("QAQ onPageBeforeOut", page.name);
      //   // isPageInFlow.value = false;
      // },
      // onPageReinit(page) {
      //   console.log("QAQ onPageBeforeOut", page.name);
      // },
      // onPageTabHide(...args) {
      //   console.log("QAQ onPageTabHide", args);
      // },
      // onPageTabShow(...args) {
      //   console.log("QAQ onPageTabShow", args);
      // },
    }
  };
  return paramsx;
};
const definePage = (render, options = {}) => {
  return (params) => {
    const params_x = usePageParams(params);
    return render(params_x);
  };
};
export {
  StateFlow as S,
  appAdminInfoFlow as a,
  appUserInfoFlow as b,
  definePage as d
};
