import { R as React, P as Page, L as List, f as ListInput, B as Button } from "./index-CvggWz_h.js";
import { b as biwApi } from "./api-uUGDDCgf.js";
import { d as definePage, b as appUserInfoFlow } from "./page-wJ61H8A2.js";
import { u as useEasyState, t as toast } from "./toast-DllnHs3T.js";
const registry_page = definePage((args) => {
  const account = useEasyState("");
  const pwd = useEasyState("");
  const pwd2 = useEasyState("");
  const inputPwd2 = useEasyState(false);
  const invCode = useEasyState("");
  const email = useEasyState("");
  const weChat = useEasyState("");
  const loading = useEasyState(false);
  const registry = async () => {
    try {
      let validateEmail = function(email2) {
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return emailRegex.test(email2);
      };
      loading.value = true;
      if (!account.value || !pwd.value) {
        return;
      }
      if (pwd.value !== pwd2.value) {
        toast("两次密码输入不一致");
        return;
      }
      if (email.value && !validateEmail(email.value)) {
        toast("邮箱格式错误");
        return;
      }
      const user = await biwApi.user.register.mutate({
        areaCode: "+86",
        phone: account.value.trim(),
        password: pwd.value,
        invitationCode: invCode.value.trim(),
        email: email.value,
        weChat: weChat.value
      });
      appUserInfoFlow.value = user;
      args.safeF7Navigater.tabs({
        reloadAll: true
      });
    } finally {
      loading.value = false;
    }
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "registry" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col w-full min-h-full py-4 items-center justify-center" }, /* @__PURE__ */ React.createElement("img", { src: "./images/logo.webp", className: "w-24 h-24 rounded-4", alt: "logo" }), /* @__PURE__ */ React.createElement("div", { className: "w-full max-w-[360px] px-4" }, /* @__PURE__ */ React.createElement(List, { strongIos: true, dividersIos: true, insetIos: true }, /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: "+86",
      type: "tel",
      placeholder: "请输入手机号",
      clearButton: true,
      value: account.value,
      validateOnBlur: true,
      validate: true,
      pattern: "^(13[0-9]|14[579]|15[0-3,5-9]|16[2567]|17[0-8]|18[0-9]|19[189])\\d{8}$",
      errorMessage: "手机号格式错误",
      onInput: (e) => {
        account.value = e.target.value;
      }
    }
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: "登录密码",
      type: "password",
      placeholder: "请输入登录密码",
      clearButton: true,
      value: pwd.value,
      validateOnBlur: true,
      validate: true,
      pattern: ".{6,}$",
      errorMessage: "最少6个字符",
      onInput: (e) => {
        pwd.value = e.target.value;
      }
    }
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: "确认密码",
      type: "password",
      placeholder: "请再次输入密码",
      clearButton: true,
      value: pwd2.value,
      errorMessageForce: !inputPwd2.value && pwd2.value !== pwd.value,
      errorMessage: "两次密码不匹配",
      onInput: (e) => {
        pwd2.value = e.target.value;
      },
      onFocus: () => inputPwd2.value = true,
      onBlur: () => inputPwd2.value = false
    }
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: "邀请码",
      type: "text",
      inputmode: "numeric",
      placeholder: "请输入邀请码",
      clearButton: true,
      value: invCode.value,
      validateOnBlur: true,
      validate: true,
      pattern: "\\d*",
      errorMessage: "请输入邀请码",
      onInput: (e) => {
        invCode.value = e.target.value;
      }
    }
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: "微信号",
      type: "text",
      placeholder: "请输入微信号（选填）",
      clearButton: true,
      onInput: (e) => {
        weChat.value = e.target.value;
      }
    }
  ), /* @__PURE__ */ React.createElement(
    ListInput,
    {
      label: "邮箱",
      type: "email",
      placeholder: "请输入邮箱（选填）",
      onInput: (e) => {
        email.value = e.target.value;
      }
    }
  )), /* @__PURE__ */ React.createElement("div", { className: "flex flex-col gap-2 px-4" }, /* @__PURE__ */ React.createElement(Button, { type: "button", roundIos: true, fillIos: true, largeIos: true, onClick: registry, loading: loading.value }, "注册"), /* @__PURE__ */ React.createElement(Button, { type: "link", onClick: () => args.safeF7Navigater.login({ reloadAll: true }) }, "已有飞象卡账号，去登录")))));
});
export {
  registry_page as default
};
