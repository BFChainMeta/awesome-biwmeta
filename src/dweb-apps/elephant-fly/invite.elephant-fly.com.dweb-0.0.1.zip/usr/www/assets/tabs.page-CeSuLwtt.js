import { d as definePage, b as appUserInfoFlow, S as StateFlow } from "./page-wJ61H8A2.js";
import { R as React, j as f7, r as reactExports, o as obj_assign_props, k as Preloader$1, P as Page, L as List, h as ListItem, B as Button, N as Navbar, C as Card, l as CardHeader, p as CardContent, I as Icon, s as setupDialog, q as PageContent, V as Views, T as Toolbar, t as View } from "./index-CvggWz_h.js";
import { t as toast } from "./toast-DllnHs3T.js";
import { u as useFlow } from "./use_flow-v6XFM-bj.js";
const renderBuilder = (isReady, content, error) => {
  return (contents) => {
    if (isReady) {
      const errorNode = error == null ? null : contents.error?.(error);
      if (contents.listItem) {
        if (Array.isArray(content) && content.length > 0) {
          const listNode = content.map(contents.listItem);
          if (errorNode) {
            return /* @__PURE__ */ React.createElement(React.Fragment, null, listNode, errorNode);
          }
          return listNode;
        } else {
          if (errorNode) {
            return errorNode;
          }
          return contents.listEmpty?.();
        }
      } else if (contents.content) {
        const contentNode = contents.content(content);
        if (errorNode) {
          return /* @__PURE__ */ React.createElement(React.Fragment, null, contentNode, errorNode);
        }
        return contentNode;
      }
    } else {
      return contents.loading?.();
    }
  };
};
const f7PtrFactory = (doRefresh) => {
  return (page) => {
    const ptr = f7.ptr.get(
      page.$pageEl.find(".ptr-content")
    );
    if (ptr) {
      ptr.refresh();
    } else {
      void doRefresh();
    }
  };
};
const useFunQueryState = (initValue, api, exec = (api2, input) => api2(...input)) => {
  const [isLoading, setIsLoading] = reactExports.useState(false);
  const [value, setValue] = reactExports.useState(initValue);
  const [error, setError] = reactExports.useState(null);
  const doQuery = async (input, opts) => {
    setIsLoading(true);
    try {
      const output = await exec(api, input, opts);
      setValue(output);
      setError(null);
      return output;
    } catch (err) {
      setError(err);
    } finally {
      setIsLoading(false);
    }
  };
  const queryWithDestructor = (input) => {
    const aborter = new AbortController();
    doQuery(input, {
      signal: aborter.signal
    });
    return () => aborter.abort("cancel");
  };
  const useQuery = (input, deps) => {
    reactExports.useEffect(() => queryWithDestructor(input), deps ?? input);
    return result;
  };
  const f7OnPageInit = (input) => f7PtrFactory(() => doQuery(input));
  const f7OnPtrRefresh = (input) => {
    return (done) => {
      doQuery(input).finally(done);
    };
  };
  const result = obj_assign_props(
    {
      get value() {
        return value;
      },
      set value(value2) {
        setValue(value2);
      }
    },
    Object.freeze({
      isLoading,
      doQuery,
      queryWithDestructor,
      useQuery,
      f7OnPtrRefresh,
      f7OnPageInit,
      get render() {
        return renderBuilder(!isLoading, value, error);
      }
    })
  );
  return result;
};
const Preloader = (props) => {
  return /* @__PURE__ */ React.createElement(Preloader$1, { size: 24, ...props });
};
function r(e) {
  var t, f, n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;
  else if ("object" == typeof e) if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  } else for (f in e) e[f] && (n && (n += " "), n += f);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}
const MainPage = definePage((args) => {
  const userInfo = useFlow(appUserInfoFlow).value;
  reactExports.useEffect(() => {
    if (!userInfo.account) {
      args.safeF7Navigater.login({
        reloadAll: true
      });
    }
  }, [userInfo.account]);
  const copy = () => {
    navigator.clipboard.writeText(userInfo.userInvitationCode);
    toast("邀请码复制成功");
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "main" }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col w-full min-h-full py-4 items-center justify-around" }, /* @__PURE__ */ React.createElement("img", { src: "./images/logo.webp", className: "w-24 h-24 rounded-4 mx-auto", alt: "" }), /* @__PURE__ */ React.createElement("div", { className: "w-full max-w-[360px] min-h-[360px] px-2" }, /* @__PURE__ */ React.createElement(List, { dividersIos: true, simpleList: true, strong: true, inset: true }, /* @__PURE__ */ React.createElement(ListItem, null, userInfo.account), /* @__PURE__ */ React.createElement(ListItem, { onClick: copy }, "我的邀请码：", userInfo.userInvitationCode), /* @__PURE__ */ React.createElement(ListItem, null, "我邀请人数：", `${userInfo.userInvitationInvitaionNumber || 0}`), userInfo.weChat && /* @__PURE__ */ React.createElement(ListItem, null, "微信号：", `${userInfo.weChat}`), userInfo.email && /* @__PURE__ */ React.createElement(ListItem, null, "邮箱：", `${userInfo.email}`)), /* @__PURE__ */ React.createElement(
    Button,
    {
      className: "bg-primary text-white w-auto mx-4",
      onClick: () => {
        appUserInfoFlow.value = {};
      }
    },
    "退出登录"
  ))));
});
const isDweb = () => {
  const isDweb2 = self.navigator.userAgent.includes("Dweb");
  const isPlaoc = self.__native_close_watcher_kit__ !== void 0;
  if (isDweb2 || isPlaoc) {
    return true;
  }
  const userAgentData = self.navigator.userAgentData;
  if (!userAgentData) {
    return false;
  }
  const brands = userAgentData.brands.filter((value) => {
    return value.brand === "DwebBrowser";
  });
  return Array.isArray(brands) && brands.length > 0;
};
const dwebTarget = () => {
  if (isDweb()) {
    const userAgentData = self.navigator.userAgentData;
    if (!userAgentData) {
      return 2;
    }
    const brands = userAgentData.brands.filter((value) => {
      return value.brand === "jmm.browser.dweb";
    });
    if (Array.isArray(brands) && brands.length > 0) {
      return parseFloat(brands[0].version);
    }
  }
  return 1;
};
const log = (...args) => {
  const formattedArgs = args.map((arg) => `(${arg})`).join(" ");
  console.log(formattedArgs);
};
class EnvironmentConfig {
  constructor() {
    this.Browser_bigVersion = 0;
    const domain = window.location.href.split("/")[2];
    const isTest = domain.indexOf("test") > -1;
    this.currentEnv = isTest ? "test" : "production";
    this.us = navigator.userAgent;
    this.isDweb = isDweb();
    this.isIos = /iPhone|iPad|iPod|iOS/i.test(navigator.userAgent);
    if (this.isDweb) {
      this.Browser_bigVersion = dwebTarget();
    }
    this.logAll();
  }
  isTest() {
    return this.currentEnv === "test";
  }
  isDwebBrowser() {
    return this.isDweb;
  }
  bigVersion() {
    return this.Browser_bigVersion;
  }
  dewebTarget() {
    return dwebTarget();
  }
  logAll() {
    log("us", this.us);
    log("isTest", this.currentEnv, "isLocalTest", this.currentEnv);
    log("isIos", this.isIos);
    log("判断是否dweb", this.isDweb);
    log("获取大版本号", this.Browser_bigVersion);
  }
}
const envConfig = new EnvironmentConfig();
class DwebApp {
  constructor() {
    this.jsonsUrl = [
      `https://source.dwebdapp.com/dweb-browser-apps/dweb-apps/nilai-list.json?time=${(/* @__PURE__ */ new Date()).getTime()}`,
      `https://source.biw-meta.io/dwebbrowser-apps/dweb-apps/applist.json?time=${(/* @__PURE__ */ new Date()).getTime()}`
    ];
    this.init_task = Promise.withResolvers();
    this.data = {
      nilai: void 0,
      nikolax: void 0,
      biwmeta: void 0,
      biwdex: void 0
    };
    this.getDataRuning = false;
    window.addEventListener("visibilitychange", () => {
      console.log("visibile change", document.visibilityState);
      if (document.visibilityState === "hidden" && this.timer) {
        console.log("clear timer");
        clearTimeout(this.timer);
      }
    });
  }
  async getApplist() {
    try {
      if (this.getDataRuning) {
        await this.init_task.promise;
        return this.data;
      }
      this.getDataRuning = true;
      const jsons = await Promise.all(
        this.jsonsUrl.map(
          (url) => fetch(url, {
            cache: "no-cache"
          }).then((res) => res.json()).then((data) => this.dataFormat(data.base_config, data))
        )
      );
      this.data.nilai = jsons[0].find((item) => item.name === "NiLai");
      this.data.nikolax = jsons[1].find((item) => item.name === "NikolaX Dex");
      this.data.biwmeta = jsons[1].find((item) => item.name === "BIWMeta");
      this.data.biwdex = jsons[1].find((item) => item.name === "BIWDex");
      this.init_task.resolve(true);
      return this.data;
    } catch (err) {
      console.error(err);
      this.getDataRuning = false;
      this.init_task.reject(false);
      this.init_task = Promise.withResolvers();
      throw err;
    }
  }
  /**
  * @param applist 应用列表
  * @param appConfig app配置文件
  * @param isTest  是否测试环境
  * @param isDweb  是否dweb环境
  * @param Browser_bigVersion dweb大版本号
  * @returns
  */
  dataFormat(baseConfg, data) {
    const isTest = envConfig.isTest();
    const isDweb2 = envConfig.isDwebBrowser();
    const Browser_bigVersion = envConfig.bigVersion();
    const { base_url, assets_path, app_test_path, app_prod_path } = baseConfg;
    const base_url_assent = base_url + assets_path;
    const base_url_app = isTest ? base_url + app_test_path : base_url + app_prod_path;
    const apps_all = Object.keys(data.applist).map((key) => {
      let { name, description, logo, metadata, ...rest } = data.applist[key];
      const appname = metadata && metadata.split("/")[1];
      let version = rest["latest"];
      if (isDweb2 && rest["dwebTarget" + Browser_bigVersion]) {
        version = rest["dwebTarget" + Browser_bigVersion];
      }
      metadata = metadata && base_url_app + metadata.replace(`/${appname}/`, `/${appname}/${version}/`);
      return {
        name,
        description,
        logo: base_url_assent + logo,
        metadata,
        ...rest
      };
    });
    return apps_all;
  }
  /** 跳转页面 */
  jumpWebpage(webpage) {
    if (!webpage) {
      return;
    }
    if (envConfig.isDwebBrowser() && envConfig.dewebTarget() > 1) {
      const url = "dweb://openinbrowser?url=" + webpage;
      window.open(url);
    } else {
      window.open(webpage, "_blank");
    }
  }
  /** 跳转app */
  jumpApp(appInfo, appStore, failCallback) {
    if (envConfig.isDwebBrowser()) {
      const appUrl = `dweb://install?url=${appInfo.metadata}`;
      console.log("跳转app的 url", appUrl);
      window.open(appUrl);
    } else {
      const appUrl = `dweb://openinbrowser?url=${appStore}`;
      console.log("跳转app的 url", appUrl);
      window.location.href = appUrl;
    }
    if (envConfig.isDwebBrowser() === false) {
      this.timer = setTimeout(() => {
        failCallback && failCallback();
      }, 2e3);
    }
  }
}
const dwebApp = new DwebApp();
const verifyBrand = () => {
  const userAgent = navigator.userAgent.toLowerCase();
  const isIphone = userAgent.match(/(iphone|ipad|ipod)/i);
  const isHuawei = userAgent.match(/huawei/i);
  const isHonor = userAgent.match(/honor/i);
  const isOppo = userAgent.match(/oppo/i);
  const isOppoR15 = userAgent.match(/PACM00/i);
  const isVivo = userAgent.match(/vivo/i);
  const isXiaomi = userAgent.match(/mi\s/i);
  const isXIAOMI = userAgent.match(/xiaomi/i);
  const isXiaomi2s = userAgent.match(/mix\s/i);
  const isRedmi = userAgent.match(/redmi/i);
  if (isIphone) {
    return "iphone";
  } else if (isHuawei || isHonor) {
    return "huawei";
  } else if (isOppo || isOppoR15) {
    return "oppo";
  } else if (isVivo) {
    return "vivo";
  } else if (isXiaomi || isRedmi || isXiaomi2s || isXIAOMI) {
    return "xiaomi";
  } else {
    return "other";
  }
};
const downloadApp = (packagename, iosLinkUrl) => {
  const huaweiUrl = `appmarket://details?id=${packagename}`;
  const oppoUrl = `oppomarket://details?packagename=${packagename}`;
  const vivoUrl = `vivomarket://details?id=${packagename}`;
  const xiaomiUrl = `mimarket://details?id=${packagename}`;
  const defaultUrl = `market://details?id=${packagename}`;
  switch (verifyBrand()) {
    case "iphone":
      window.location.href = iosLinkUrl;
      break;
    case "xiaomi":
      window.location.href = xiaomiUrl;
      break;
    case "huawei":
      window.location.href = huaweiUrl;
      break;
    case "vivo":
      window.location.href = vivoUrl;
      break;
    case "oppo":
      window.location.href = oppoUrl;
      break;
    default:
      window.location.href = defaultUrl;
      break;
  }
};
const Web3Page = definePage((args) => {
  const appInfo = useFunQueryState(
    {
      nilai: void 0,
      nikolax: void 0,
      biwmeta: void 0,
      biwdex: void 0
    },
    async () => {
      const info = await dwebApp.getApplist();
      return info;
    }
  ).useQuery([]);
  const openApp = (app, appStore) => {
    dwebApp.jumpApp(app, appStore, async () => {
      console.log("拉起dewebrower失败, 弹窗下载app");
      const f7_dialog = await setupDialog();
      const dialog = f7_dialog.create({
        /** Dialog title. */
        title: "当前系统未安装 DwebBrowser 程序",
        /** Dialog inner text. */
        text: "请先安装 DwebBrowser 后重试",
        buttons: [
          {
            text: "取消"
          },
          {
            text: "前往安装",
            onClick: () => {
              const packagename = "info.bagen.dwebbrowser";
              const iosLinkUrl = `https://apps.apple.com/cn/app/6443558874`;
              downloadApp(packagename, iosLinkUrl);
            }
          }
        ]
      });
      dialog.open();
    });
  };
  return /* @__PURE__ */ React.createElement(Page, { name: "web3" }, /* @__PURE__ */ React.createElement(Navbar, { title: "Web3 Club" }), appInfo.render({
    loading: () => /* @__PURE__ */ React.createElement("div", { className: "flex justify-center mt-8" }, /* @__PURE__ */ React.createElement(Preloader, { size: 32 })),
    listEmpty: () => /* @__PURE__ */ React.createElement("div", { className: "text-title text-lg mt-8 text-center" }, "暂无数据"),
    content: () => /* @__PURE__ */ React.createElement(React.Fragment, null, " ", appInfo.value.biwmeta && /* @__PURE__ */ React.createElement(Card, { outline: true }, /* @__PURE__ */ React.createElement(CardHeader, null, /* @__PURE__ */ React.createElement("div", { className: "flex items-center text-base font-bold" }, /* @__PURE__ */ React.createElement("div", { className: " rounded-3 p-2 border-title/30 border-tiny mr-3" }, /* @__PURE__ */ React.createElement("img", { src: "./images/biw_logo.webp", alt: "", className: "w-10 h-auto" })), "BIWMeta")), /* @__PURE__ */ React.createElement(CardContent, { className: "pt-0" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-2 medium-grid-cols-4 grid-gap text-sm" }, /* @__PURE__ */ React.createElement(
      Button,
      {
        className: "bg-primary/10",
        onClick: () => {
          dwebApp.jumpWebpage("https://www.biw-meta.com/");
        }
      },
      /* @__PURE__ */ React.createElement(Icon, { f7: "house", className: "mr-1 font-bold", size: 16 }),
      "官网"
    ), /* @__PURE__ */ React.createElement(
      Button,
      {
        className: "bg-primary/10",
        onClick: () => {
          dwebApp.jumpWebpage("https://www.biw-meta.info/");
        }
      },
      /* @__PURE__ */ React.createElement(Icon, { f7: "globe", className: "mr-1", size: 16 }),
      "浏览器"
    ), /* @__PURE__ */ React.createElement(
      Button,
      {
        className: "bg-primary/10",
        onClick: () => {
          openApp(appInfo.value.biwmeta, "https://biw-meta.io/");
        }
      },
      /* @__PURE__ */ React.createElement("div", { className: "!bg-white rounded-0.5 overflow-hidden mr-1" }, /* @__PURE__ */ React.createElement("img", { src: "./images/biw_logo.webp", alt: "", className: "w-4 h-auto " })),
      "钱包下载"
    ), /* @__PURE__ */ React.createElement(
      Button,
      {
        className: "bg-primary/10 no-uppercase",
        onClick: () => {
          openApp(appInfo.value.biwdex, "https://biw-meta.io/");
        }
      },
      /* @__PURE__ */ React.createElement("div", { className: "!bg-white rounded-0.5 overflow-hidden mr-1" }, /* @__PURE__ */ React.createElement("img", { src: "./images/biw_dex_logo.webp", alt: "", className: "w-4 h-4 " })),
      "BIW Dex下载"
    )))), appInfo.value.nikolax && /* @__PURE__ */ React.createElement(Card, { outline: true }, /* @__PURE__ */ React.createElement(CardHeader, null, /* @__PURE__ */ React.createElement("div", { className: "flex items-center text-base font-bold" }, /* @__PURE__ */ React.createElement("div", { className: " rounded-3 p-2 border-title/30 border-tiny mr-3" }, /* @__PURE__ */ React.createElement("img", { src: "./images/nikolax_logo.webp", alt: "", className: "w-10 h-10" })), "NikolaX Dex")), /* @__PURE__ */ React.createElement(CardContent, { className: "pt-0" }, /* @__PURE__ */ React.createElement(
      Button,
      {
        className: "bg-primary/10",
        onClick: () => {
          openApp(appInfo.value.nikolax, "https://biw-meta.io/");
        }
      },
      /* @__PURE__ */ React.createElement(Icon, { f7: "square_arrow_down", className: "mr-1 font-bold", size: 16 }),
      "下载"
    ))), appInfo.value.nilai && /* @__PURE__ */ React.createElement(Card, { outline: true }, /* @__PURE__ */ React.createElement(CardHeader, null, /* @__PURE__ */ React.createElement("div", { className: "flex items-center text-base font-bold" }, /* @__PURE__ */ React.createElement("div", { className: " rounded-3 p-2 border-title/30 border-tiny mr-3" }, /* @__PURE__ */ React.createElement("img", { src: "./images/nilai_logo.webp", alt: "", className: "w-10 h-10" })), "尼来")), /* @__PURE__ */ React.createElement(CardContent, { className: "pt-0" }, /* @__PURE__ */ React.createElement(
      Button,
      {
        className: "bg-primary/10",
        onClick: () => {
          openApp(appInfo.value.nilai, "https://dweb.ni-lai.com/");
        }
      },
      /* @__PURE__ */ React.createElement(Icon, { f7: "square_arrow_down", className: "mr-1 font-bold", size: 16 }),
      "下载"
    ))))
  }));
});
const activeTabFlow = new StateFlow(
  "main"
  /* Main */
);
const tabs_page = definePage((args) => {
  const [activeTab, setActiveTab] = useFlow(activeTabFlow);
  const isActiveMain = activeTab === "main";
  const isActiveWeb3 = activeTab === "web3";
  const tabs = reactExports.useMemo(
    () => [
      {
        state: "main",
        title: "我的",
        isActived: isActiveMain
      },
      {
        state: "web3",
        title: "Web3 Club",
        isActived: isActiveWeb3
      }
    ],
    [isActiveMain, isActiveWeb3]
  );
  return /* @__PURE__ */ React.createElement(Page, { pageContent: false }, /* @__PURE__ */ React.createElement(Navbar, { hidden: true }), /* @__PURE__ */ React.createElement(PageContent, { className: "p-0" }, /* @__PURE__ */ React.createElement(Views, { tabs: true, className: "fixPageAni" }, /* @__PURE__ */ React.createElement(Toolbar, { bottom: true, tabbar: true }, tabs.map((tab) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: tab.state,
      className: clsx(
        "flex flex-col items-center duration-300",
        tab.isActived ? "!text-primary" : "!text-subtext"
      ),
      onClick: () => {
        setActiveTab(tab.state);
      }
    },
    /* @__PURE__ */ React.createElement("span", { className: "text-base" }, tab.title)
  ))), /* @__PURE__ */ React.createElement(View, { id: "main", tab: true, tabActive: isActiveMain }, /* @__PURE__ */ React.createElement(MainPage, { ...args })), /* @__PURE__ */ React.createElement(View, { id: "web3", tab: true, tabActive: isActiveWeb3 }, /* @__PURE__ */ React.createElement(Web3Page, { ...args })))));
});
export {
  tabs_page as default
};
