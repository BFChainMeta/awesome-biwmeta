import { M as Modal, e as extend, d as getWindow, b as $, n as nextTick, $ as $jsx, c as ModalMethods } from "./index-CvggWz_h.js";
class Toast extends Modal {
  constructor(app, params) {
    const extendedParams = extend({
      on: {}
    }, app.params.toast, params);
    super(app, extendedParams);
    const toast2 = this;
    const window = getWindow();
    toast2.app = app;
    toast2.params = extendedParams;
    const {
      closeButton,
      closeTimeout
    } = toast2.params;
    let $el;
    if (!toast2.params.el) {
      const toastHtml = toast2.render();
      $el = $(toastHtml);
    } else {
      $el = $(toast2.params.el);
    }
    if ($el && $el.length > 0 && $el[0].f7Modal) {
      return $el[0].f7Modal;
    }
    if ($el.length === 0) {
      return toast2.destroy();
    }
    extend(toast2, {
      $el,
      el: $el[0],
      type: "toast"
    });
    $el[0].f7Modal = toast2;
    if (closeButton) {
      $el.find(".toast-button").on("click", () => {
        toast2.emit("local::closeButtonClick toastCloseButtonClick", toast2);
        toast2.close();
      });
      toast2.on("beforeDestroy", () => {
        $el.find(".toast-button").off("click");
      });
    }
    let timeoutId;
    toast2.on("open", () => {
      $(".toast.modal-in").each((openedEl) => {
        const toastInstance = app.toast.get(openedEl);
        if (openedEl !== toast2.el && toastInstance) {
          toastInstance.close();
        }
      });
      if (closeTimeout) {
        timeoutId = nextTick(() => {
          toast2.close();
        }, closeTimeout);
      }
    });
    toast2.on("close", () => {
      window.clearTimeout(timeoutId);
    });
    if (toast2.params.destroyOnClose) {
      toast2.once("closed", () => {
        setTimeout(() => {
          toast2.destroy();
        }, 0);
      });
    }
    return toast2;
  }
  render() {
    const toast2 = this;
    if (toast2.params.render) return toast2.params.render.call(toast2, toast2);
    const {
      position,
      horizontalPosition,
      cssClass,
      icon,
      text,
      closeButton,
      closeButtonColor,
      closeButtonText
    } = toast2.params;
    const horizontalClass = position === "top" || position === "bottom" ? `toast-horizontal-${horizontalPosition}` : "";
    return $jsx("div", {
      class: `toast toast-${position} ${horizontalClass} ${cssClass || ""} ${icon ? "toast-with-icon" : ""}`
    }, $jsx("div", {
      class: "toast-content"
    }, icon && $jsx("div", {
      class: "toast-icon"
    }, icon), $jsx("div", {
      class: "toast-text"
    }, text), closeButton && !icon && $jsx("a", {
      class: `toast-button button ${closeButtonColor ? `color-${closeButtonColor}` : ""}`
    }, closeButtonText)));
  }
}
const toast = {
  name: "toast",
  static: {
    Toast
  },
  create() {
    const app = this;
    app.toast = extend({}, ModalMethods({
      app,
      constructor: Toast,
      defaultSelector: ".toast.modal-in"
    }), {
      // Shortcuts
      show(params) {
        extend(params, {
          destroyOnClose: true
        });
        return new Toast(app, params).open();
      }
    });
  },
  params: {
    toast: {
      icon: null,
      text: null,
      position: "bottom",
      horizontalPosition: "left",
      closeButton: false,
      closeButtonColor: null,
      closeButtonText: "Ok",
      closeTimeout: null,
      cssClass: null,
      render: null,
      containerEl: null
    }
  }
};
export {
  toast as default
};
