import { o as obj_assign_props, r as reactExports, v as setupToast } from "./index-CvggWz_h.js";
const easy_state_proto = obj_assign_props([], {
  get value() {
    return this[0];
  },
  set value(value) {
    this[1](value);
  }
});
const useEasyState = (initialState) => {
  const state = reactExports.useState(initialState);
  Object.setPrototypeOf(state, easy_state_proto);
  return state;
};
const toast = async (text, options = { open: true, autoDestroy: true }) => {
  const f7_toast = await setupToast();
  const totasRef = f7_toast.create({
    text,
    position: options.position || "bottom",
    closeTimeout: options.closeTimeout || 2e3,
    cssClass: options.cssClass || "!bg-primary"
  });
  if (options.autoDestroy) {
    totasRef.once("closed", () => {
      totasRef.destroy();
    });
  }
  let closed_job;
  totasRef.on("open", () => {
    closed_job?.reject("open");
    closed_job = Promise.withResolvers();
  });
  totasRef.on("closed", () => {
    closed_job?.resolve();
    closed_job = void 0;
  });
  if (options.open) {
    totasRef.open();
  }
  return obj_assign_props(totasRef, {
    get closed() {
      return closed_job?.promise;
    }
  });
};
export {
  easy_state_proto as e,
  toast as t,
  useEasyState as u
};
