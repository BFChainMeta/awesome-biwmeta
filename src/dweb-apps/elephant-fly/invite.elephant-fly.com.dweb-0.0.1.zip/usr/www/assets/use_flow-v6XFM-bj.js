import { r as reactExports } from "./index-CvggWz_h.js";
import { e as easy_state_proto } from "./toast-DllnHs3T.js";
import { S as StateFlow } from "./page-wJ61H8A2.js";
const useFlow = (flow, state) => {
  if (state == null) {
    state = flow instanceof StateFlow ? reactExports.useState(flow.value) : reactExports.useState();
  }
  const [value, setValue] = state;
  const setValue2 = (valAc) => {
    flow.emit(
      typeof valAc === "function" ? valAc(value) : valAc
    );
  };
  reactExports.useEffect(() => {
    const off = flow.on(setValue);
    return () => void off();
  }, [flow]);
  return Object.setPrototypeOf(
    [value, setValue2],
    easy_state_proto
  );
};
export {
  useFlow as u
};
