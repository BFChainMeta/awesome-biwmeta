import {
  d as S,
  y as J,
  N as z,
  B as u,
  D as c,
  F as t,
  a1 as H,
  a2 as X,
  f as r,
  _ as L,
  G as i,
  H as f,
  E as e,
  an as R,
  v as _,
  r as W,
  Q as T,
  P as F,
  R as $,
  T as ee,
  J as te,
  aL as se,
  ar as oe,
  I as Q,
  aM as ne,
  aD as re,
  aF as ie,
  V as ae,
} from "./index-0085351d.js";
import "./index-f81b7dd3.js";
import { P as le } from "./index-507b837f.js";
import { U as ue } from "./index-cc00d73d.js";
import { _ as Ae } from "./index.vue_vue_type_script_setup_true_lang-1f3350dc.js";
import { _ as l } from "./index.vue_vue_type_script_setup_true_lang-d7333f39.js";
import { u as ce } from "./useGroupMemberList-d99b6774.js";
import { C as pe } from "./data-7f4000cb.js";
import { M as Y } from "./data-2e062955.js";
import {
  u as de,
  a as me,
  _ as ge,
} from "./useConversationMsgDestruct-6765ef35.js";
import { u as Ce } from "./useCurrentMemberRole-3ba2452e.js";
import { s as he } from "./function-call-b9717455.js";
import "./use-id-f9988c90.js";
import "./use-sync-prop-ref-17d54694.js";
import "./function-call-6d0a9231.js";
import "./index-fa95a9d8.js";
import "./arrows_left-58dc349e.js";
import "./index-903f55d0.js";
import "./back-099fa84a.js";
import "./index-df8775be.js";
const fe =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAAAXNSR0IArs4c6QAAAolJREFUWEftmE9o03AUx78v7aCg4A6DCQpu4MGbHndwOG+CqK3CYKdt4AJlXtI6hyfjSWQ28VaWCZsnL0JTRfDmPAiCJ28eBCt00MOEHSp0NsmT1CbbatP2FxrodLmF3++93ycv7883IQzYRQPGAx9IM8wXYEyEAaxL9uTywq2ytmp+C2PPxOWsnJp0bfcDvQMwFcYh2TyupFMlzTA5jD2AUkZOjh8eIGZYRCgHPi3zCIiOe+ttI8RcBdF2kA9mnCZCvLneNUL+hnYOdcNcZ2CuExABG4qcnA8C0oxGvo0JAel6YZiPxc57Th0pVrp7++p3EaAnz96ckRzbOxj00/6sKKmdUEAr+cJULEZusjcuIlKVhRsPRYD0teIDZlY9H7bNl5fSqc0jIC+H+hqhR/nCWCIuzXrhZqbNjHz9vcgr04xXl4jY7281y3l+/0/PEk/qoAoRAepLlTFQI+Bjhx5yjggnO5U9MypE+BLoA5ggINFr2QtNgP9vdAiFx+1PUQxXUYio9vvy4+lacdSiuJdkQudVy5+2VFW13DHhGSaGdqt3Zm/+CKyy/OtTzpDUGK5S3bEy6WtbkcqPfg9XoQi1y6F/HIi5SkQvOzS1iwDOtjZGt4P7Y4ZQgUN7jdHa/ZBZnP7qreuGuQJgpHm/rcjJpU45FEqg7X+AnFGYI9AeIHg+K6c2uuVCkMhvAIkO18iBRAXaoQbKteRQtpccijJCofSQqq4nTowO+zIDNey4Aj1ID4m8slBAogItSqBu1XlgvZdO3RrVlgO6figeAf31s0FfLepMfEEoNM3NVv3XzL3F6YpmmP5HJQNvs3LysecvZ5jLBFwJ8F/JyMmZA6MjDEgUNgP3B+03Yq/XQxgsydYAAAAASUVORK5CYII=",
  ve =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAXpJREFUSEu9lT1Lw1AUht+TtuKg4lg33foTHPwDomLp4Ae6ONhanGxwNs4l7aTQuAp+gJJiRUcHwdVNN90UR+sg2N4jp9BSSmvuTYuZEu7J87w3h5tDAOAe+ctQcIiQkOegixk1WFi3N5Nn3Wqdg/ORsdjQFYBxKnrlNQYfSyEz3onwHSRorCuVzW2lbjtrBT4ajd0Q0QyAO3I9/4mABNfVgp1NVbTgPYra4cx8X639zFLB81mS25nkxKDhzvbSV0MA4DWXTk6FFXRLLnDh9S34C963IAjel0AHHlqgCw8l0IW7np8Hc9yoybpwSV7w/BcAk9oCE7ixwBRuJAgDNxK4hxfTFI08NP8tzRMadOqNeiCS6sfno+Ns6P1pwzQ5KHHnutEOTOFGPQgD/3/BIAZO507dkv9GhHhrZBLT/E5m8TrsJ2l/r1gqzzFxhYFnynuXKxFYJ62hD82h3yMJA8OSXJbrUKskNyKxYO3J8B/EDiS5gtrfTadOfwE4iGe/WLiWCwAAAABJRU5ErkJggg==",
  we =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAAAXNSR0IArs4c6QAAAyxJREFUSEu1lk1IVFEUx3+XFDSKKF20CFJScOFGskzSsjToQyIpqYhyDKJFUApGQkFCioGGtYwWjrQwSTDKLNDKMLAPo4UtDI0UXGoaSRlZN8776s1zZt6o9XYz7577e+fc/zn3r/B5tNZxQA5QDGwBUoBkK2wCGAVeAp3AK6XUXLQtVaSXFugYUGNB/L5N3gu8RinVEmlxWKDWegNwB8iWwJEpuDcMT8Zg6DNMfDO3S14OGWugcD0cSIe01Q5mADiilProBc8Daq23A+2yn4Dq+iH4PpbkIJAJF3MdsJT7kFLquTs6BGjBeoA4yeh4J8z8jA1mr1oRD7eLzYwBOc8iN9QBaq3TgH7J7PoAVD5dGMi7umknVBgHgmSaq5QakR8G0BKIwLIls5KOpcHs6I4SJ9MBpdQmN7AMCMqZZQUXXsYLOVCzFXrGzGOY/mEipbzvAs6ZBkS9yspuWKRf3hW7QOwsEpZB92HIW2f+462QCKl5r/FKWiZdgHlAn2SXfmthpTyTBS2Wgh+VmtC53xDfGLrP8Ckny3wB1gPVja/hfG/sQFsUL8Zhz10zTqDtH+DG29B9GgqgarPxX60A+4A8CXr8KTagS4FGgA2dnYM5PX+P3anmxwC9AhRMSupNGP3iD/TC7Igj96FtKHx8yir4dNo8RwF+BxJWNvmrMxKs4sn8MrrRotavlcY/Mw4w8RrM/oqc4WJhdnu4gb4lrd8G1XIxeR6/zOzl3pIaotnVZjau9zm3Ea4XLh4mkV7RRGyLzGQYPLk0mES72uJq1Ma/kg+XckOBsZbRHeVtfLEQxmgLdP2dHBLw5gRkrzVDZYJUPYuuxnCSK8uEoHu0ySKtdQBo9g7vqbMwMm3Ox5ZBGJ/x71NvO8iRiGiAcqVU8L9eTw8OQrGYFQi9nqws/9kFHKegYUeUC9gug9a6AOheqsVo3e9kJhZjl1LKuRbCmSiByvw3TFRtf6iQop2iCEQuYuvMxFqUumESG8kmSnlbvTZRBsPQJEzK9AWSEiEjCYrC28Sjto9xf2REI+xS7+UFGGExSnWixkiViAq0oNKnMkn3+Vj9h2L5/az+HwXMXLQL5pCMAAAAAElFTkSuQmCC",
  xe =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAABJ1JREFUeF7tncFvG0UUh2d21+s0dkjZtFGbYlFcqYK2AiEEB4QEJ/4U98CpqERNw2EkaEpF05x6qP+ZgpBAChIIDkVCamnVpk1DYhJlHdvr3dlqXTa0iRt5n18Yp/n56v29Z3/fvnHGUTJS7PCoVG7kPK9W1ENWwRKuK4V2bNuyd8rs9+eiSEexsEItgsBq6nqt5vnV6tn2i7jIbk8k4A9OrB62hf2Kbdtdr9nvoHt9/1EUxTJnry3fG17uJmIb3MnJKyPuSH5CiNjqtQmu64WA1E6UW1DqM//Zq58ToNQ1ryX0OO76XoBmvyaZhqawlubU57U0vSlAqevFlmi8BvjZwWZJJBLy4sCDdBI6ApI1f7y0WhbCxbKThSb12lagl5Zu36lWq+2OgEl1ZcK13VFqPeSyE9CWWJ2ZPvdIViqV3NjEyRNYerJD7CeRLEUrD/+8LS9cvvyqEw4d6acYsjQCYb25KKenZ0tyyCrSSiDVD4EgCtblBTVXdmyR76cQsjQCYSRackrNnsTXCzSA/aaSry3kl1/NvdVvIeTpBCCAzo4lCQEsGOlFIIDOjiUJASwY6UUggM6OJQkBLBjpRSCAzo4lCQEsGOlFIIDOjiUJASwY6UUggM6OJQkBLBjpRSCAzo4lCQEsGOlFIIDOjiUJASwY6UUggM6OJQkBLBjpRSCAzo4lCQEsGOlFIIDOjiUJASwY6UUggM6OJQkBLBjpRfasgMZGQ87/9N2pul8fKxQLKx998ukt27ZjOgozyT0r4Ldf5o8+fHDvzRRb6fXyrTPvvPfYDEZ61z0rYP7H74+vLC+9kb71sUPjf33w4cd36SjMJCHADPfNrhAAATQCWIJo3NhSEMCGklYIAmjc2FIQwIZye6F0k+Wv1w9ZVv//s0JrqYsjheVB3KwN5E9BWzdZXK4HcbM2kAJ+//XnIwv377L/7dqx0vE/3n73/UUuoRx1BlJAFDXkDzdvnq77G2McS5DQUg9jCeK4X/6rgQ9hXp6Zq0FAZmS8AQjg5Zm5GgRkRsYbgABenpmrQUBmZLwBCODlmbna1s3aIG6yenlTA7kR6+WFp5u1jfqGh1/K90IM13QlsGcn4GXxCQGGTUIABBgmYLg9JgACDBMw3B4TAAGGCRhujwmAAMMEDLfHBECAYQKG22MCIMAwAcPtMQEQYJiA4faYAAgwTMBwe0wABBgmYLg9JgACDBMw3B4TAAGGCRhuj4PcDAroHOSm1Fw5xFGGRjQ4yVGG01/PlmSMwzxNGIil9nGcrQny//YMneYiDnQ2JGDzQOek/8WLl45aB4YPGnot+7KtbojVmZlzjzpnyiulnJYYKeNY2//nXkh++smL9TtKqbAjIHmcP/9tIVeUJZwtv7sSkqWn7cf3r179op502hTwdBKueS2hxyFhdyQk8ON8+/E3U1P/pB2eE/BUwvViGPrHRN61dudl7NeqgXaixoJSyn+WwDYB6WdCkBs9HLejUUxDfzdMctfLnL3mttf+Ttb8rdW6CkgvqlRu5DyvVtRDVsESriuFdvBBvbOQ5AM2FlaoRRBYTV2v1Ty/Wj3bflHqCSl4MnqNsXuSAAAAAElFTkSuQmCC",
  Be =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAABBVJREFUeF7tnc9OE1EUxu+9M51WKaI1EkXrAhMSY/QBfAIX7nyHunClUSLi4iYqahRZubDP4M6Nb+Be44YEE/8raoVYQjuduWNutQQVCT1z8GD4uu1832l/v54paUKuVus8arUHhUqlUXYlM2BUFGnlwiAwwXqZ7f5cmro0UyZxKo5Nyy01GpVmvX628zcueq0nPPjdIwv7AhXsCoJgzWu2O+iNvv80TTNdCBY/v9z5eS0Rf8AdH789GA0WR5TKzEaH4LqNENAuTAtvrT3XXH31LwKsvVdpKzeMT/1GgPZ/jd+GljLzM/ZCo5deEWDt/XJbLR8C/P7B9pPwEopqx5veJnQF+Hv+cHVhVKkIt51+aFKvbcdufn7uRb1e73QFjNvbI1EQDVH7kOufgDNqYWry/Htdq9UKe0fGjuDW0z/EPAl/K/rybnZOX755c0+YlPbnKUOWRiBZan3Qk5PTVV0yZVoFUnkIxGn8TV+2M6NhoIp5ipClEUhS1dYTdnoMPy/QAOZN+Z8t9NVrM0fzFiFPJwABdHYsSQhgwUgvgQA6O5YkBLBgpJdAAJ0dSxICWDDSSyCAzo4lCQEsGOklEEBnx5KEABaM9BIIoLNjSUIAC0Z6CQTQ2bEkIYAFI70EAujsWJIQwIKRXgIBdHYsSQhgwUgvgQA6O5YkBLBgpJdAAJ0dSxICWDDSSyCAzo4lCQEsGOklEEBnx5KEABaM9BIIoLNjSUIAC0Z6CQTQ2bEkIYAFI70EAujsWJIQwIKRXgIBdHYsyS0n4PnTZ3tfv5ody5wrcbxDbUyrenhs9tiJ4184+rg7tpyAx48ensyyjPWfBr2EU6fPPOGGx9EHARwUc3RsOQG4BeWwiWj/BLbcBvT/Fv7vBAQI+4MACBAmIDweGwABwgSEx2MDIECYgPB4bAAECBMQHo8NgABhAsLjsQEQIExAeDw2AAKECQiPxwZAgDAB4fHYAAgQJiA8HhsAAcIEhMdjAyBAmIDweGwABAgTEB6PDYAAYQLC47EBECBMQHg8NgAChAkIj8cGSAvAQW5yBroHuVk7M5rgKEMRC6E/ynDy+nRVZzjMU8JApl0Tx9lKkP85MwlbH3Cgs5CAlQOd/fwrV24cMDt27hZ6LdtyrFtWC1NT5993z5S31oZtNTiKY23/zWfB//VTVN9eWGuTrgD/uHjxzkChrKs4W35zJfhbT6eZvb5799KSn7Qi4Mcm3Ku0lRuGhM2R4OFnxc7HWxMTX3sTfhHwQ8L9cpI0D6piZDbnZWzX1tiF6fJba21zNYE/BPS+E+LC0L6skw5hG/J9YPynXheCxaiz+Mnf839vW1NA76Ja7UGhUmmUXckMGBVFWrkQX9TrC/FfsJkyiVNxbFpuqdGoNOv1s52/pb4DskmTa9mBcBEAAAAASUVORK5CYII=",
  ke = { class: "mt-3 flex flex-wrap" },
  Ie = {
    class:
      "flex w-[42px] shrink-0 grow-0 basis-1/5 flex-col items-center justify-center px-[6px] pb-[10px]",
  },
  Ee = { class: "relative h-12 w-12" },
  Ge = {
    key: 0,
    class:
      "absolute bottom-0 flex w-12 items-center justify-center rounded-md bg-[#E8EAEF] text-xs text-primary",
  },
  be = { class: "mt-0.5 w-[42px] truncate text-center text-xs text-sub-text" },
  De = {
    class:
      "flex w-[42px] shrink-0 grow-0 basis-1/5 flex-col items-center justify-center px-[6px] pb-[10px]",
  },
  Qe = ["src", "onClick"],
  Se = { class: "mt-0.5 w-[42px] truncate text-center text-xs text-sub-text" },
  ye = {
    key: 0,
    class:
      "flex w-[42px] shrink-0 grow-0 basis-1/5 flex-col items-center justify-center px-[6px] pb-[10px]",
  },
  Ue = ["src", "onClick"],
  Me = { class: "mt-0.5 w-[42px] truncate text-center text-xs text-sub-text" },
  Ne = S({
    __name: "GroupMemberRow",
    props: { memberCount: null, isNomal: { type: Boolean } },
    setup(x) {
      const n = J(),
        d = z(),
        { fetchState: I } = ce(void 0, !0),
        E = () => {
          n.push({
            path: "chooseUser",
            state: {
              chooseType: pe.InviteGroup,
              extraData: d.storeCurrentGroupInfo.groupID,
            },
          });
        },
        G = () => {
          n.push({
            path: "groupMemberList",
            state: {
              groupID: d.storeCurrentGroupInfo.groupID,
              action: Y.Kickout,
            },
          });
        },
        b = () => {
          n.push({
            path: "groupMemberList",
            state: {
              groupID: d.storeCurrentGroupInfo.groupID,
              action: Y.Preview,
            },
          });
        };
      return (m, y) => (
        u(),
        c(
          "div",
          {
            class:
              "mx-[10px] mt-[10px] overflow-hidden rounded-md bg-white px-1 pt-2",
            onClick: b,
          },
          [
            t("div", ke, [
              (u(!0),
              c(
                H,
                null,
                X(
                  e(I).groupMemberList.slice(0, x.isNomal ? 9 : 8),
                  (g) => (
                    u(),
                    c("div", Ie, [
                      t("div", Ee, [
                        r(
                          L,
                          { src: g.faceURL, desc: g.nickname, size: 48 },
                          null,
                          8,
                          ["src", "desc"]
                        ),
                        g.roleLevel === 100
                          ? (u(), c("div", Ge, i(m.$t("groupOwner")), 1))
                          : f("", !0),
                      ]),
                      t("span", be, i(g.nickname), 1),
                    ])
                  )
                ),
                256
              )),
              t("div", De, [
                t(
                  "img",
                  {
                    class: "h-12 w-12",
                    src: e(xe),
                    alt: "",
                    onClick: R(E, ["stop"]),
                  },
                  null,
                  8,
                  Qe
                ),
                t("span", Se, i(m.$t("add")), 1),
              ]),
              x.isNomal
                ? f("", !0)
                : (u(),
                  c("div", ye, [
                    t(
                      "img",
                      {
                        class: "h-12 w-12",
                        src: e(Be),
                        alt: "",
                        onClick: R(G, ["stop"]),
                      },
                      null,
                      8,
                      Ue
                    ),
                    t("span", Me, i(m.$t("buttons.remove")), 1),
                  ])),
            ]),
            r(
              l,
              {
                class: "border-t",
                title: `${m.$t("allGroupMember")}(${x.memberCount})`,
              },
              null,
              8,
              ["title"]
            ),
          ]
        )
      );
    },
  }),
  Re = { class: "page_container" },
  Te = { class: "flex-1 overflow-y-auto" },
  Fe = {
    class: "mx-[10px] mt-[10px] flex items-center rounded-md bg-white p-4",
  },
  Ye = { class: "relative h-12 w-12" },
  Je = ["src"],
  Le = { class: "flex items-center justify-start" },
  Oe = { class: "text-base" },
  Ke = { class: "text-base" },
  Ve = { class: "text-base" },
  je = t("span", { class: "text-base" }, i(")"), -1),
  Pe = ["src"],
  Ze = { class: "mt-1 text-sm text-sub-text" },
  qe = ["src"],
  ze = { class: "mx-[10px] mt-[10px] overflow-hidden rounded-md bg-white" },
  He = { class: "mx-[10px] mt-[10px] overflow-hidden rounded-md bg-white" },
  Xe = { class: "mx-[10px] mt-[10px] overflow-hidden rounded-md bg-white" },
  _e = { class: "m-[10px] overflow-hidden rounded-md bg-white" },
  We = { class: "m-[10px] overflow-hidden rounded-md bg-white" },
  $e = { class: "px-4 pt-6" },
  et = { class: "mb-1" },
  tt = { class: "text-xs text-sub-text" },
  st = { class: "mb-4 flex items-center justify-end px-4 py-2" },
  ot = S({ name: "groupSetting" }),
  It = S({
    ...ot,
    setup(x) {
      const {
          conversationStore: n,
          switchLoading: d,
          updateConversationPinState: I,
          updateConversationRecvMsgState: E,
          clearLogs: G,
        } = de(),
        {
          onChange: b,
          timeOptions: m,
          destructLoading: y,
          destructTimeStr: g,
          showDestructTime: v,
          updateDestructDuration: O,
          updateDestructDurationTime: U,
        } = me(),
        { isNomal: B, isOwner: C, isAdmin: D } = Ce(),
        w = J(),
        { t: k } = _(),
        M = W(),
        K = (s) => {
          var p, h;
          const o = Array.isArray(s) ? s[0] : s,
            A = oe({ message: k("uploading"), forbidClick: !0, duration: 0 });
          Q.uploadFile({
            name:
              new Date().getTime() +
              ne(((p = o.file) == null ? void 0 : p.name) ?? ""),
            contentType: (h = o.file) == null ? void 0 : h.type,
            uuid: re(),
            file: o.file,
          })
            .then((a) => {
              Q.setGroupInfo({
                groupID: n.storeCurrentConversation.groupID,
                faceURL: a.data.url,
              }).finally(() => A.close());
            })
            .catch(() => {
              (A.message = k("messageTip.uploadFailed")),
                setTimeout(() => {
                  A.close();
                }, 200);
            })
            .finally(() => A.close());
        },
        V = () => {
          var s;
          B.value || (s = M.value) == null || s.chooseFile();
        },
        N = (s) => {
          (s && B.value) ||
            w.push({
              path: "changeName",
              query: {
                originData: JSON.stringify(
                  s ? n.storeCurrentGroupInfo : n.storeCurrentMemberInGroup
                ),
              },
            });
        },
        j = () => {
          w.push({
            path: "groupAnnouncement",
            query: { isNomal: B.value + "" },
          });
        },
        P = () => {
          w.push("/groupManage");
        },
        Z = () => {
          w.push({ path: "selfOrGroupQr", query: { isGroup: "true" } });
        },
        q = () => {
          const s = C.value ? "dismissGroup" : "quitGroup",
            o = k(C.value ? "messageTip.disbandGroup" : "messageTip.quitGroup");
          he({
            message: o,
            beforeClose: (A) =>
              new Promise((p) => {
                if (A !== "confirm") {
                  p(!0);
                  return;
                }
                Q[s](n.currentConversation.groupID)
                  .then(() => w.push("/conversation"))
                  .catch((h) => ae({ error: h }))
                  .finally(() => p(!0));
              }),
          });
        };
      return (s, o) => {
        const A = ue,
          p = le,
          h = ie;
        return (
          u(),
          c("div", Re, [
            r(Ae, { title: s.$t("groupSetting") }, null, 8, ["title"]),
            t("div", Te, [
              t("div", Fe, [
                t("div", Ye, [
                  r(
                    L,
                    {
                      size: 48,
                      src: e(n).currentConversation.faceURL,
                      "is-group": "",
                      onClick: V,
                    },
                    null,
                    8,
                    ["src"]
                  ),
                  e(C) || e(D)
                    ? (u(),
                      c(
                        "img",
                        {
                          key: 0,
                          class:
                            "absolute right-[-4px] bottom-[-4px] h-[14px] w-[14px]",
                          src: e(we),
                          alt: "",
                        },
                        null,
                        8,
                        Je
                      ))
                    : f("", !0),
                ]),
                t(
                  "div",
                  {
                    class:
                      "ml-[10px] flex h-[48px] flex-1 flex-col items-start",
                    onClick: o[0] || (o[0] = (a) => N(!0)),
                  },
                  [
                    t("div", Le, [
                      t("span", Oe, i(e(n).currentConversation.showName), 1),
                      t("span", Ke, i("("), 1),
                      t(
                        "span",
                        Ve,
                        i(e(n).storeCurrentGroupInfo.memberCount),
                        1
                      ),
                      je,
                      e(C) || e(D)
                        ? (u(),
                          c(
                            "img",
                            {
                              key: 0,
                              class: "ml-1.5 h-[12px] w-[12px]",
                              src: e(ve),
                              alt: "",
                            },
                            null,
                            8,
                            Pe
                          ))
                        : f("", !0),
                    ]),
                    t("span", Ze, i(e(n).storeCurrentGroupInfo.groupID), 1),
                  ]
                ),
                t(
                  "img",
                  {
                    class: "h-[18px] w-[18px]",
                    onClick: Z,
                    src: e(fe),
                    alt: "",
                  },
                  null,
                  8,
                  qe
                ),
              ]),
              r(
                Ne,
                {
                  "member-count": e(n).storeCurrentGroupInfo.memberCount,
                  "is-nomal": e(B),
                },
                null,
                8,
                ["member-count", "is-nomal"]
              ),
              r(ge),
              t("div", ze, [
                r(
                  l,
                  { title: s.$t("popover.groupAnnouncement"), onClick: j },
                  null,
                  8,
                  ["title"]
                ),
                e(C) || e(D)
                  ? (u(),
                    T(
                      l,
                      { key: 0, title: s.$t("groupManage"), onClick: P },
                      null,
                      8,
                      ["title"]
                    ))
                  : f("", !0),
              ]),
              t("div", He, [
                r(
                  l,
                  {
                    title: s.$t("groupNickname"),
                    "sub-title": e(n).storeCurrentMemberInGroup.nickname,
                    onClick: o[1] || (o[1] = (a) => N()),
                  },
                  null,
                  8,
                  ["title", "sub-title"]
                ),
              ]),
              t("div", Xe, [
                r(
                  l,
                  {
                    title: s.$t("groupPin"),
                    "show-switch": "",
                    loading: e(d).pinLoading,
                    checked: e(n).storeCurrentConversation.isPinned,
                    onUpdateValue: e(I),
                  },
                  null,
                  8,
                  ["title", "loading", "checked", "onUpdateValue"]
                ),
                r(
                  l,
                  {
                    title: s.$t("checks.notDisturb"),
                    "show-switch": "",
                    loading: e(d).recvMsgLoading,
                    checked:
                      e(n).storeCurrentConversation.recvMsgOpt ===
                      e(F).NotNotify,
                    onUpdateValue:
                      o[2] || (o[2] = (a) => e(E)(a, e(F).NotNotify)),
                  },
                  null,
                  8,
                  ["title", "loading", "checked"]
                ),
              ]),
              t("div", _e, [
                r(
                  l,
                  {
                    title: s.$t("messageDestruct"),
                    "show-switch": "",
                    loading: e(y),
                    checked: e(n).storeCurrentConversation.isMsgDestruct,
                    onUpdateValue: e(O),
                  },
                  null,
                  8,
                  ["title", "loading", "checked", "onUpdateValue"]
                ),
                e(n).storeCurrentConversation.isMsgDestruct
                  ? (u(),
                    T(
                      l,
                      {
                        key: 0,
                        title: s.$t("messageDestructTime"),
                        subTitle: e(g),
                        onClick: o[3] || (o[3] = (a) => (v.value = !0)),
                      },
                      null,
                      8,
                      ["title", "subTitle"]
                    ))
                  : f("", !0),
              ]),
              t("div", We, [
                r(
                  l,
                  {
                    danger: "",
                    title: s.$t("popover.clearModalTitle"),
                    onClickItem: e(G),
                  },
                  null,
                  8,
                  ["title", "onClickItem"]
                ),
                r(
                  l,
                  {
                    danger: "",
                    title: e(C)
                      ? s.$t("buttons.disbandGroup")
                      : s.$t("buttons.quitGroup"),
                    onClickItem: q,
                  },
                  null,
                  8,
                  ["title"]
                ),
              ]),
            ]),
            $(
              r(
                A,
                {
                  ref_key: "uploaderRef",
                  ref: M,
                  accept: "image/*",
                  capture: "camcorder",
                  "preview-image": !1,
                  multiple: !1,
                  "after-read": K,
                },
                null,
                512
              ),
              [[ee, !1]]
            ),
            r(
              h,
              {
                show: e(v),
                "onUpdate:show":
                  o[6] || (o[6] = (a) => (se(v) ? (v.value = a) : null)),
                round: "",
              },
              {
                default: te(() => [
                  t("div", $e, [
                    t("div", et, i(s.$t("messageDestruct")), 1),
                    t("div", tt, i(s.$t("messageDestructToast")), 1),
                  ]),
                  r(
                    p,
                    {
                      onChange: e(b),
                      "show-toolbar": !1,
                      columns: e(m),
                      class: "w-full",
                    },
                    null,
                    8,
                    ["onChange", "columns"]
                  ),
                  t("div", st, [
                    t(
                      "span",
                      {
                        class: "mr-3 cursor-pointer",
                        onClick: o[4] || (o[4] = (a) => (v.value = !1)),
                      },
                      i(s.$t("buttons.cancel")),
                      1
                    ),
                    t(
                      "span",
                      {
                        class: "mr-1 cursor-pointer text-primary",
                        onClick: o[5] || (o[5] = (...a) => e(U) && e(U)(...a)),
                      },
                      i(s.$t("buttons.confirm")),
                      1
                    ),
                  ]),
                ]),
                _: 1,
              },
              8,
              ["show"]
            ),
          ])
        );
      };
    },
  });
export { It as default };
