import {
  d as h,
  v as B,
  x as V,
  al as N,
  j as g,
  a as F,
  B as I,
  D as R,
  f as s,
  F as w,
  J as b,
  E as M,
  aL as v,
  bo as n,
  P as c,
  dX as O,
  a6 as A,
  I as T,
  V as C,
} from "./index-0085351d.js";
import { S as L } from "./index-903f55d0.js";
import { _ as U } from "./index.vue_vue_type_script_setup_true_lang-1f3350dc.js";
import { _ as t } from "./index.vue_vue_type_script_setup_true_lang-e2498643.js";
import { s as y } from "./function-call-b9717455.js";
import "./index-fa95a9d8.js";
import "./arrows_left-58dc349e.js";
import "./back-099fa84a.js";
import "./index-df8775be.js";
const H = { class: "page_container" },
  P = { class: "mx-3 mt-2 overflow-hidden rounded-md" },
  z = { class: "mx-3 mt-2 overflow-hidden rounded-md" },
  D = { class: "mx-3 mt-2 overflow-hidden rounded-md" },
  Y = h({
    __name: "index",
    setup(k) {
      const { t: i } = B(),
        d = V(),
        S = N(),
        u = g(() => d.storeSelfInfo.globalRecvMsgOpt === c.NotNotify),
        p = g(() => d.storeSelfInfo.allowBeep === n.Allow),
        f = g(() => d.storeSelfInfo.allowAddFriend === n.NotAllow),
        r = F({ allowBeep: !1, globalRecvMsgOpt: !1, allowAddFriend: !1 }),
        m = (l, e) => {
          const a = {};
          (r[e] = !0),
            e === "allowBeep" && (a[e] = l ? n.Allow : n.NotAllow),
            e === "globalRecvMsgOpt" && (a[e] = l ? c.NotNotify : c.Nomal),
            e === "allowAddFriend" && (a[e] = l ? n.NotAllow : n.Allow),
            O(a)
              .then(() => {
                d.updateSelfInfo({ ...a }), A(i("messageTip.nomalSuccess"));
              })
              .catch((o) => A(o.errMsg || i("messageTip.nomalFailed")))
              .finally(() => (r[e] = !1));
        },
        $ = () => {
          y({
            title: i("profileMenu.clearChatHistory"),
            message: i("popover.clearChatHistory"),
            beforeClose: (l) =>
              new Promise((e) => {
                if (l !== "confirm") {
                  e(!0);
                  return;
                }
                T.deleteAllMsgFromLocalAndSvr()
                  .then(() => {
                    S.clearHistoryMessage(), C();
                  })
                  .catch((a) => C({ error: a }))
                  .finally(() => e(!0));
              }),
          });
        };
      return (l, e) => {
        const a = L;
        return (
          I(),
          R("div", H, [
            s(U, { title: l.$t("profileMenu.accountSetting") }, null, 8, [
              "title",
            ]),
            w("div", P, [
              s(
                t,
                { lable: l.$t("profileMenu.disturbMode") },
                {
                  default: b(() => [
                    s(
                      a,
                      {
                        size: "20",
                        loading: r.globalRecvMsgOpt,
                        modelValue: M(u),
                        "onUpdate:modelValue":
                          e[0] || (e[0] = (o) => (v(u) ? (u.value = o) : null)),
                        onChange:
                          e[1] || (e[1] = (o) => m(o, "globalRecvMsgOpt")),
                      },
                      null,
                      8,
                      ["loading", "modelValue"]
                    ),
                  ]),
                  _: 1,
                },
                8,
                ["lable"]
              ),
              s(
                t,
                { lable: l.$t("profileMenu.newMessageSound") },
                {
                  default: b(() => [
                    s(
                      a,
                      {
                        size: "20",
                        loading: r.allowBeep,
                        modelValue: M(p),
                        "onUpdate:modelValue":
                          e[2] || (e[2] = (o) => (v(p) ? (p.value = o) : null)),
                        onChange: e[3] || (e[3] = (o) => m(o, "allowBeep")),
                      },
                      null,
                      8,
                      ["loading", "modelValue"]
                    ),
                  ]),
                  _: 1,
                },
                8,
                ["lable"]
              ),
            ]),
            w("div", z, [
              s(
                t,
                { lable: l.$t("profileMenu.disallowAddMe") },
                {
                  default: b(() => [
                    s(
                      a,
                      {
                        size: "20",
                        loading: r.allowAddFriend,
                        modelValue: M(f),
                        "onUpdate:modelValue":
                          e[4] || (e[4] = (o) => (v(f) ? (f.value = o) : null)),
                        onChange:
                          e[5] || (e[5] = (o) => m(o, "allowAddFriend")),
                      },
                      null,
                      8,
                      ["loading", "modelValue"]
                    ),
                  ]),
                  _: 1,
                },
                8,
                ["lable"]
              ),
              s(
                t,
                {
                  arrow: "",
                  lable: l.$t("profileMenu.blacklist"),
                  onClick: e[6] || (e[6] = (o) => l.$router.push("blackList")),
                },
                null,
                8,
                ["lable"]
              ),
              s(
                t,
                {
                  arrow: "",
                  lable: l.$t("profileMenu.language"),
                  onClick: e[7] || (e[7] = (o) => l.$router.push("/language")),
                },
                null,
                8,
                ["lable"]
              ),
            ]),
            w("div", D, [
              // s(
              //   t,
              //   {
              //     arrow: "",
              //     lable: l.$t("changePassword"),
              //     onClick:
              //       e[8] || (e[8] = (o) => l.$router.push("/changePassword")),
              //   },
              //   null,
              //   8,
              //   ["lable"]
              // ),
              s(
                t,
                {
                  arrow: "",
                  danger: "",
                  lable: l.$t("profileMenu.clearChatHistory"),
                  onClick: $,
                },
                null,
                8,
                ["lable"]
              ),
            ]),
          ])
        );
      };
    },
  });
export { Y as default };
