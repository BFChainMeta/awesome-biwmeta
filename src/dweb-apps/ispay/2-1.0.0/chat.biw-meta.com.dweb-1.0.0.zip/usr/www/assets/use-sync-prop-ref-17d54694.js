import{r as c,w as o}from"./index-0085351d.js";const n=(s,a)=>{const f=c(s());return o(s,r=>{r!==f.value&&(f.value=r)}),o(f,r=>{r!==s()&&a(r)}),f};export{n as u};
