import { encode } from "../../../../deps/deno.land/x/cbor@v1.5.4/index.js";
import { IpcRequest } from "../ipc/IpcRequest.js";
import { IpcResponse } from "../ipc/IpcResponse.js";
import { IPC_ROLE } from "../ipc/const.js";
import { Ipc } from "../ipc/ipc.js";
import { $messagePackToIpcMessage } from "./$messagePackToIpcMessage.js";
import { $jsonToIpcMessage, $messageToIpcMessage, $uint8ArrayToIpcMessage } from "./$messageToIpcMessage.js";
export class MessagePortIpc extends Ipc {
    constructor(port, remote, role = IPC_ROLE.CLIENT, self_support_protocols = {
        raw: true,
        cbor: true,
        protobuf: false,
    }) {
        super();
        Object.defineProperty(this, "port", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: port
        });
        Object.defineProperty(this, "remote", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: remote
        });
        Object.defineProperty(this, "role", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: role
        });
        Object.defineProperty(this, "self_support_protocols", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: self_support_protocols
        });
        /** messageport内置JS对象解码，但也要看对方是否支持接受，比如Android层就只能接受String类型的数据 */
        this._support_raw = self_support_protocols.raw && this.remote.ipc_support_protocols.raw;
        /** JS 环境里支持 cbor 协议，但也要看对等方是否支持 */
        this._support_cbor = self_support_protocols.cbor && this.remote.ipc_support_protocols.cbor;
        port.addEventListener("message", (event) => {
            const message = this.support_raw
                ? $messageToIpcMessage(event.data, this)
                : event.data instanceof Uint8Array
                    ? $uint8ArrayToIpcMessage(event.data, this)
                    : this.support_cbor
                        ? $messagePackToIpcMessage(event.data, this)
                        : $jsonToIpcMessage(event.data, this);
            if (message === undefined) {
                console.error("MessagePortIpc.cts unkonwn message", event.data);
                return;
            }
            if (message === "pong") {
                return;
            }
            if (message === "close") {
                this.close();
                return;
            }
            if (message === "ping") {
                this.port.postMessage("pong");
                return;
            }
            this._messageSignal.emit(message, this);
        });
        port.start();
    }
    _doPostMessage(message) {
        // deno-lint-ignore no-explicit-any
        let message_data;
        // deno-lint-ignore no-explicit-any
        let message_raw;
        if (message instanceof IpcRequest) {
            message_raw = message.ipcReqMessage();
        }
        else if (message instanceof IpcResponse) {
            message_raw = message.ipcResMessage();
        }
        else {
            message_raw = message;
        }
        if (this.support_raw) {
            message_data = message_raw;
        }
        else if (this.support_cbor) {
            message_data = encode(message_raw);
        }
        else {
            message_data = JSON.stringify(message_raw);
        }
        this.port.postMessage(message_data);
    }
    _doClose() {
        this.port.postMessage("close");
        this.port.close();
    }
}
