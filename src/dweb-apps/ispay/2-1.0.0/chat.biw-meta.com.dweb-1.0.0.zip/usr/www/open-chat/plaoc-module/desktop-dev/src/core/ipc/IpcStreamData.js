var _IpcStreamData_binary, _IpcStreamData_text, _IpcStreamData_jsonAble;
import { __classPrivateFieldGet } from "../../../../../tslib/modules/index.js";
import { CacheGetter } from "../../helper/cacheGetter.js";
import { simpleDecoder } from "../../helper/encoding.js";
import { $dataToBinary, $dataToText, IPC_DATA_ENCODING, IPC_MESSAGE_TYPE, IpcMessage } from "./const.js";
export class IpcStreamData extends IpcMessage {
    constructor(stream_id, data, encoding) {
        super(IPC_MESSAGE_TYPE.STREAM_DATA);
        Object.defineProperty(this, "stream_id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: stream_id
        });
        Object.defineProperty(this, "data", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: data
        });
        Object.defineProperty(this, "encoding", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: encoding
        });
        _IpcStreamData_binary.set(this, new CacheGetter(() => $dataToBinary(this.data, this.encoding)));
        _IpcStreamData_text.set(this, new CacheGetter(() => $dataToText(this.data, this.encoding)));
        _IpcStreamData_jsonAble.set(this, new CacheGetter(() => {
            if (this.encoding === IPC_DATA_ENCODING.BINARY) {
                return IpcStreamData.fromBase64(this.stream_id, this.data);
            }
            return this;
        }));
    }
    static fromBase64(stream_id, data) {
        return new IpcStreamData(stream_id, simpleDecoder(data, "base64"), IPC_DATA_ENCODING.BASE64);
    }
    static fromBinary(stream_id, data) {
        return new IpcStreamData(stream_id, data, IPC_DATA_ENCODING.BINARY);
    }
    static fromUtf8(stream_id, data) {
        return new IpcStreamData(stream_id, simpleDecoder(data, "utf8"), IPC_DATA_ENCODING.UTF8);
    }
    get binary() {
        return __classPrivateFieldGet(this, _IpcStreamData_binary, "f").value;
    }
    get text() {
        return __classPrivateFieldGet(this, _IpcStreamData_text, "f").value;
    }
    get jsonAble() {
        return __classPrivateFieldGet(this, _IpcStreamData_jsonAble, "f").value;
    }
    toJSON() {
        return { ...this.jsonAble };
    }
}
_IpcStreamData_binary = new WeakMap(), _IpcStreamData_text = new WeakMap(), _IpcStreamData_jsonAble = new WeakMap();
