import { PromiseOut } from "../../helper/PromiseOut.js";
import { streamRead } from "../../helper/stream/readableStreamHelper.js";
import { IPC_DATA_ENCODING, IpcEvent } from "./index.js";
export class PureChannel {
    constructor(income, outgoing) {
        Object.defineProperty(this, "income", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: income
        });
        Object.defineProperty(this, "outgoing", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: outgoing
        });
        Object.defineProperty(this, "_startLock", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new PromiseOut()
        });
        Object.defineProperty(this, "_reverse", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    afterStart() {
        return this._startLock.promise;
    }
    start() {
        this._startLock.resolve();
    }
    close() {
        this.income.controller.close();
        this.outgoing.controller.close();
    }
    reverse() {
        if (this._reverse === undefined) {
            this._reverse = new PureChannel(this.outgoing, this.income);
            this._reverse._reverse = this;
        }
        return this._reverse;
    }
}
export var PureFrameType;
(function (PureFrameType) {
    PureFrameType[PureFrameType["Text"] = 0] = "Text";
    PureFrameType[PureFrameType["Binary"] = 1] = "Binary";
})(PureFrameType || (PureFrameType = {}));
export class PureFrame {
    constructor(type) {
        Object.defineProperty(this, "type", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: type
        });
    }
}
export class PureTextFrame extends PureFrame {
    constructor(data) {
        super(PureFrameType.Text);
        Object.defineProperty(this, "data", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: data
        });
    }
}
export class PureBinaryFrame extends PureFrame {
    constructor(data) {
        super(PureFrameType.Binary);
        Object.defineProperty(this, "data", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: data
        });
    }
}
export const ipcEventToPureFrame = (ipcEvent) => {
    switch (ipcEvent.encoding) {
        case IPC_DATA_ENCODING.UTF8:
            return new PureTextFrame(ipcEvent.data);
        case IPC_DATA_ENCODING.BINARY:
            return new PureBinaryFrame(ipcEvent.binary);
        case IPC_DATA_ENCODING.BASE64:
            return new PureBinaryFrame(ipcEvent.binary);
    }
};
export const pureFrameToIpcEvent = (eventName, pureFrame) => {
    if (pureFrame.type === PureFrameType.Text) {
        return IpcEvent.fromText(eventName, pureFrame.data);
    }
    return IpcEvent.fromBinary(eventName, pureFrame.data);
};
export const pureChannelToIpcEvent = async (channelId, ipc, pureChannel, 
/**收到ipcEvent时，需要对其进行接收的 channel*/
channelWriteIn, 
/**收到pureFrame时，需要将其转发给ipc的 channel*/
channelReadOut, waitReadyToStart) => {
    const eventStart = `${channelId}/start`;
    const eventData = `${channelId}/data`;
    const eventClose = `${channelId}/close`;
    const started = new PromiseOut();
    const off = ipc.onEvent((ipcEvent) => {
        switch (ipcEvent.name) {
            case eventStart:
                started.resolve(ipcEvent);
                break;
            case eventData:
                channelWriteIn.enqueue(ipcEventToPureFrame(ipcEvent));
                break;
            case eventClose:
                pureChannel.close();
                break;
        }
    });
    ipc.postMessage(IpcEvent.fromText(eventStart, ""));
    void (async () => {
        ipc.postMessage(await started.promise);
        for await (const pureFrame of streamRead(channelReadOut)) {
            ipc.postMessage(pureFrameToIpcEvent(eventData, pureFrame));
        }
        // 关闭的时候，发一个信号给对面
        const ipcCloseEvent = IpcEvent.fromText(eventClose, "");
        ipc.postMessage(ipcCloseEvent);
        off(); // 移除事件监听
    })();
};
