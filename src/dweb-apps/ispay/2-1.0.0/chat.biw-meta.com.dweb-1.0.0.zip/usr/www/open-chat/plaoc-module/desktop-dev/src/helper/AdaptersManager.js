export class AdaptersManager {
    constructor() {
        Object.defineProperty(this, "adapterOrderMap", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "orderdAdapters", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
    }
    _reorder() {
        this.orderdAdapters = [...this.adapterOrderMap]
            .sort((a, b) => b[1] - a[1]) // order 越大越靠前
            .map((a) => a[0]);
    }
    get adapters() {
        return this.orderdAdapters;
    }
    /**
     *
     * @param adapter
     * @param order 越大优先级越高
     * @returns
     */
    append(adapter, order = 0) {
        this.adapterOrderMap.set(adapter, order);
        this._reorder();
        return () => this.remove(adapter);
    }
    remove(adapter) {
        if (this.adapterOrderMap.delete(adapter) != null) {
            this._reorder();
            return true;
        }
        return false;
    }
}
