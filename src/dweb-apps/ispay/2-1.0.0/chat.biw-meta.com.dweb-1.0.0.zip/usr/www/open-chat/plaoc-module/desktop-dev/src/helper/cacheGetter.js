export const cacheGetter = () => {
    return (target, prop, desp) => {
        const source_fun = desp.get;
        if (source_fun === undefined) {
            throw new Error(`${target}.${prop} should has getter`);
        }
        desp.get = function () {
            const result = source_fun.call(this);
            if (desp.set) {
                desp.get = () => result;
            }
            else {
                delete desp.set;
                delete desp.get;
                desp.value = result;
                desp.writable = false;
            }
            Object.defineProperty(this, prop, desp);
            return result;
        };
        return desp;
    };
};
export class CacheGetter {
    constructor(getter) {
        Object.defineProperty(this, "getter", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: getter
        });
        Object.defineProperty(this, "_first", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
        });
        Object.defineProperty(this, "_value", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    get value() {
        if (this._first) {
            this._first = false;
            this._value = this.getter();
        }
        return this._value;
    }
    reset() {
        this._first = true;
        this._value = undefined;
    }
}
