// deno-lint-ignore no-explicit-any
export const createSignal = (autoStart) => {
    return new Signal(autoStart);
};
// deno-lint-ignore no-explicit-any
export class Signal {
    constructor(autoStart = true) {
        Object.defineProperty(this, "_cbs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Set()
        });
        Object.defineProperty(this, "_started", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        Object.defineProperty(this, "_cachedEmits", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "start", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: () => {
                if (this._started) {
                    return;
                }
                this._started = true;
                if (this._cachedEmits.length) {
                    for (const args of this._cachedEmits) {
                        this._emit(args, this._cbs);
                    }
                    this._cachedEmits.length = 0;
                }
            }
        });
        Object.defineProperty(this, "listen", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (cb) => {
                this._cbs.add(cb);
                this.start();
                return () => this._cbs.delete(cb);
            }
        });
        Object.defineProperty(this, "emit", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (...args) => {
                if (this._started) {
                    this._emit(args, this._cbs);
                }
                else {
                    this._cachedEmits.push(args);
                }
            }
        });
        Object.defineProperty(this, "emitAndClear", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (...args) => {
                if (this._started) {
                    const cbs = [...this._cbs];
                    this._cbs.clear();
                    this._emit(args, cbs);
                }
                else {
                    this._cachedEmits.push(args);
                }
            }
        });
        Object.defineProperty(this, "_emit", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (args, cbs) => {
                for (const cb of cbs) {
                    try {
                        cb.apply(null, args);
                    }
                    catch (reason) {
                        // ignore
                        console.warn(reason);
                    }
                }
            }
        });
        Object.defineProperty(this, "clear", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: () => {
                this._cbs.clear();
            }
        });
        if (autoStart) {
            this.start();
        }
    }
}
