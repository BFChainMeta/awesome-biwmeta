export var X_PLAOC_QUERY;
(function (X_PLAOC_QUERY) {
    X_PLAOC_QUERY["PROXY"] = "X-Plaoc-Proxy";
    X_PLAOC_QUERY["EXTERNAL_URL"] = "X-Plaoc-External-Url";
    X_PLAOC_QUERY["SESSION_ID"] = "X-Plaoc-Session-Id";
    X_PLAOC_QUERY["GET_CONFIG_URL"] = "x-Plaoc-Config-Url";
})(X_PLAOC_QUERY || (X_PLAOC_QUERY = {}));
