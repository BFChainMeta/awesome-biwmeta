import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { InsetsPlugin } from "./InsetsPlugin.js";
/**
 * 条栏的风格
 * Light 代表文字为黑色
 * Dark 代表文字为白色
 */
export var BAR_STYLE;
(function (BAR_STYLE) {
    /**
     * Light text for dark backgrounds.
     *
     */
    BAR_STYLE["Dark"] = "DARK";
    /**
     * Dark text for light backgrounds.
     *
     */
    BAR_STYLE["Light"] = "LIGHT";
    /**
     * The style is based on the device appearance.
     * If the device is using Dark mode, the bar text will be light.
     * If the device is using Light mode, the bar text will be dark.
     * On Android the default will be the one the app was launched with.
     *
     */
    BAR_STYLE["Default"] = "DEFAULT";
})(BAR_STYLE || (BAR_STYLE = {}));
export class BarPlugin extends InsetsPlugin {
    /**
     * 设置 Bar 背景色
     * Hex
     */
    setColor(color) {
        return this.setStateByKey("color", color);
    }
    /**
     *  获取背景颜色
     */
    async getColor() {
        return (await this.state.getState()).color;
    }
    /**
     * 设置 Bar 风格
     * // 支持 light | dark | defalt
     * 据观测
     * 在系统主题为 Light 的时候, Default 意味着 白色字体
     * 在系统主题为 Dark 的手, Default 因为这 黑色字体
     * 这兴许与设置有关系, 无论如何, 尽可能避免使用 Default 带来的不确定性
     *
     * @param style
     */
    setStyle(style) {
        return this.setStateByKey("style", style);
    }
    /**
     * 获取当前style
     * @returns
     */
    async getStyle() {
        return (await this.state.getState()).style;
    }
    /**
     * 显示 Bar
     */
    show() {
        return this.setVisible(true);
    }
    /**
     * Hide the bar.
     */
    hide() {
        return this.setVisible(false);
    }
    setVisible(visible) {
        return this.setStateByKey("visible", visible);
    }
    async getVisible() {
        return (await this.state.getState()).visible;
    }
    /**
     * 设置 Bar 是否应该覆盖 webview 以允许使用
     * 它下面的空间。
     *
     */
    setOverlay(overlay) {
        return this.setStateByKey("overlay", overlay);
    }
    async getOverlay() {
        return (await this.state.getState()).overlay;
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], BarPlugin.prototype, "setColor", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BarPlugin.prototype, "getColor", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], BarPlugin.prototype, "setStyle", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BarPlugin.prototype, "getStyle", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], BarPlugin.prototype, "show", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], BarPlugin.prototype, "hide", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", void 0)
], BarPlugin.prototype, "setVisible", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BarPlugin.prototype, "getVisible", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", void 0)
], BarPlugin.prototype, "setOverlay", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BarPlugin.prototype, "getOverlay", null);
