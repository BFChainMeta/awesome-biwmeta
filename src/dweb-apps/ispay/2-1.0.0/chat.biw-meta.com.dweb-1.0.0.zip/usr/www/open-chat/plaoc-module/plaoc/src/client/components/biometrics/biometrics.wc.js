import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { biometricsPlugin } from "./biometrics.plugin.js";
class HTMLDwebBiometricsElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: biometricsPlugin
        });
    }
    get check() {
        return this.plugin.check;
    }
    get biometrics() {
        return this.plugin.biometrics;
    }
}
Object.defineProperty(HTMLDwebBiometricsElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-biometrics"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebBiometricsElement.prototype, "check", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebBiometricsElement.prototype, "biometrics", null);
export { HTMLDwebBiometricsElement };
if (!customElements.get(HTMLDwebBiometricsElement.tagName)) {
    customElements.define(HTMLDwebBiometricsElement.tagName, HTMLDwebBiometricsElement);
}
