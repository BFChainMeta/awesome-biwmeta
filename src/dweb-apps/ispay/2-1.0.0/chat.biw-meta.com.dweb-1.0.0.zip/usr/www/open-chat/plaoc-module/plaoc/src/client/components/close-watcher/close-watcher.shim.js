var _a, _Watcher_acc_id, _CloseWatcherShim_instances, _CloseWatcherShim_id, _CloseWatcherShim_init, _CloseWatcherShim_onclose;
import { __classPrivateFieldGet, __classPrivateFieldSet } from "../../../../../../tslib/modules/index.js";
/// <reference lib="dom"/>
import * as dntShim from "../../../../../_dnt.shims.js";
import { PromiseOut } from "../../helper/PromiseOut.js";
import "./close-watcher.type.js";
let native_close_watcher_kit = self.__native_close_watcher_kit__;
if (native_close_watcher_kit) {
    native_close_watcher_kit._watchers ?? (native_close_watcher_kit._watchers = new Map());
    native_close_watcher_kit._tasks ?? (native_close_watcher_kit._tasks = new Map());
}
else if ("webkit" in dntShim.dntGlobalThis) {
    // 仅适用于iOS平台
    Object.assign(dntShim.dntGlobalThis, {
        __native_close_watcher_kit__: {
            registryToken(token) {
                try {
                    // deno-lint-ignore no-explicit-any
                    dntShim.dntGlobalThis.webkit.messageHandlers.closeWatcher.postMessage({
                        token,
                    });
                }
                catch {
                    // 非iOS平台才有可能会触发
                }
            },
            tryClose(id) {
                try {
                    // deno-lint-ignore no-explicit-any
                    dntShim.dntGlobalThis.webkit.messageHandlers.closeWatcher.postMessage({
                        id,
                    });
                }
                catch {
                    // 非iOS平台才有可能会触发
                }
            },
            _watchers: new Map(),
            _tasks: new Map(),
        },
    });
    native_close_watcher_kit = self.__native_close_watcher_kit__;
}
else {
    /// 桌面 平台使用 esc 按钮作为返回键
    const consuming = new Set();
    const watchers = new Array();
    class Watcher {
        constructor() {
            var _b, _c, _d;
            Object.defineProperty(this, "_destoryed", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: false
            });
            Object.defineProperty(this, "id", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: `#cw-${__classPrivateFieldSet(_b = Watcher, _a, (_d = __classPrivateFieldGet(_b, _a, "f", _Watcher_acc_id), _c = _d++, _d), "f", _Watcher_acc_id), _c}`
            });
        }
        tryClose() {
            if (this._destoryed) {
                return false;
            }
            native_close_watcher_kit._watchers.get(this.id)?.dispatchEvent(new CloseEvent("close"));
            this._destoryed = true;
            return true;
        }
    }
    _a = Watcher;
    _Watcher_acc_id = { value: 0 };
    const closeWatcherController = new (class CloseWatcher {
        /**
         * 申请一个 CloseWatcher
         */
        apply(isUserGesture) {
            if (isUserGesture || watchers.length === 0) {
                const watcher = new Watcher();
                watchers.push(watcher);
            }
            return watchers.at(-1);
        }
        resolveToken(consumeToken, watcher) {
            native_close_watcher_kit._tasks.get(consumeToken)?.(watcher.id);
        }
        get canClose() {
            return watchers.length > 0;
        }
        close(watcher = watchers.at(-1)) {
            if (watcher?.tryClose()) {
                const index = watchers.indexOf(watcher);
                if (index !== -1) {
                    watchers.splice(index, 1);
                    return true;
                }
            }
            return false;
        }
    })();
    // @ts-ignore
    if (typeof navigation === "object") {
        // @ts-ignore
        navigation.addEventListener("navigate", (event) => {
            if (closeWatcherController.canClose) {
                event.intercept({
                    async hanlder() {
                        closeWatcherController.close();
                    },
                });
            }
        });
    }
    if (typeof document === "object")
        document.addEventListener("keypress", (event) => {
            if (event.key === "Escape") {
                console.log("Esc键被按下");
                closeWatcherController.close();
            }
        });
    Object.assign(dntShim.dntGlobalThis, {
        __native_close_watcher_kit__: {
            async registryToken(token) {
                consuming.add(token);
                /// 模拟移动端的 open(token)
                if ((await (await fetch(token)).text()) === "create-close-watcher") {
                    const watcher = closeWatcherController.apply(navigator.userActivation.isActive);
                    closeWatcherController.resolveToken(token, watcher);
                }
            },
            tryClose(id) {
                for (const w of watchers.slice()) {
                    if (w.id === id) {
                        closeWatcherController.close(w);
                    }
                }
            },
            _watchers: new Map(),
            _tasks: new Map(),
        },
    });
    native_close_watcher_kit = self.__native_close_watcher_kit__;
}
export class CloseWatcherShim extends EventTarget {
    constructor() {
        super();
        _CloseWatcherShim_instances.add(this);
        _CloseWatcherShim_id.set(this, new PromiseOut());
        Object.defineProperty(this, "_closed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        _CloseWatcherShim_onclose.set(this, void 0);
        void __classPrivateFieldGet(this, _CloseWatcherShim_instances, "m", _CloseWatcherShim_init).call(this);
    }
    async close() {
        if (this._closed) {
            return;
        }
        const id = await __classPrivateFieldGet(this, _CloseWatcherShim_id, "f").promise;
        const native_close_watcher_kit = self.__native_close_watcher_kit__;
        native_close_watcher_kit.tryClose(id);
    }
    get onclose() {
        return __classPrivateFieldGet(this, _CloseWatcherShim_onclose, "f") ?? null;
    }
    set onclose(value) {
        if (typeof value === "function") {
            __classPrivateFieldSet(this, _CloseWatcherShim_onclose, value, "f");
        }
        else {
            __classPrivateFieldSet(this, _CloseWatcherShim_onclose, undefined, "f");
        }
    }
    addEventListener() {
        // deno-lint-ignore no-explicit-any
        return super.addEventListener(...arguments);
    }
    removeEventListener() {
        // deno-lint-ignore no-explicit-any
        return super.addEventListener(...arguments);
    }
}
_CloseWatcherShim_id = new WeakMap(), _CloseWatcherShim_onclose = new WeakMap(), _CloseWatcherShim_instances = new WeakSet(), _CloseWatcherShim_init = async function _CloseWatcherShim_init() {
    const token = URL.createObjectURL(new Blob(["create-close-watcher"], { type: "text/html" }));
    const native_close_watcher_kit = self.__native_close_watcher_kit__;
    const tasks = native_close_watcher_kit._tasks;
    const po = __classPrivateFieldGet(this, _CloseWatcherShim_id, "f");
    // 注册回调
    tasks.set(token, po.resolve);
    // 注册指令，如果在移动端，会发起 self.open(token) ，从而获得
    native_close_watcher_kit.registryToken(token);
    // 等待响应
    const id = await po.promise;
    // 等到响应，删除注册的回掉
    tasks.delete(token);
    // 注册实例
    native_close_watcher_kit._watchers.set(id, this);
    console.log("close watcher created");
    this.addEventListener("close", (event) => {
        console.log("close watcher closed");
        __classPrivateFieldGet(this, _CloseWatcherShim_onclose, "f")?.call(this, event);
        native_close_watcher_kit._watchers.delete(id);
        this._closed = true;
    }, { once: true });
};
if (typeof self.CloseWatcher === "undefined") {
    Object.assign(self, { CloseWatcher: CloseWatcherShim });
}
export const CloseWatcher = self.CloseWatcher;
