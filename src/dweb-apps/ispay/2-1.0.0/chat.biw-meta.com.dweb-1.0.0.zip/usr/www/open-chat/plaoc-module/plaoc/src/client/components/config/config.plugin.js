import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
import { dwebServiceWorker } from "../index.js";
export class ConfigPlugin extends BasePlugin {
    constructor() {
        super("config.sys.dweb");
    }
    /**
     * 设置语言
     * @param lang 语言
     * @param isReload 是否重新加载
     * @returns
     */
    async setLang(lang, isReload = true) {
        const res = await this.fetchApi(`/setLang`, {
            search: {
                lang: lang,
            },
        }).boolean();
        if (res && isReload) {
            dwebServiceWorker.restart();
        }
        return res;
    }
    async getLang() {
        return this.fetchApi("/getLang", { base: location.href }).text();
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ConfigPlugin.prototype, "setLang", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ConfigPlugin.prototype, "getLang", null);
export const configPlugin = new ConfigPlugin();
