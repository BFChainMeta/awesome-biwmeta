import { devicePlugin } from "./device.plugin.js";
class HTMLDeviceElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: devicePlugin
        });
    }
    getUUID() {
        return this.plugin.getUUID();
    }
}
Object.defineProperty(HTMLDeviceElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-device"
});
export { HTMLDeviceElement };
if (!customElements.get(HTMLDeviceElement.tagName)) {
    customElements.define(HTMLDeviceElement.tagName, HTMLDeviceElement);
}
