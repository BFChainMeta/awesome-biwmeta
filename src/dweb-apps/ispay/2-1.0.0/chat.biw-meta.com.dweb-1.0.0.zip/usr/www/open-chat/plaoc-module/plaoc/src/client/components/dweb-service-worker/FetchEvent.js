import { IpcResponse } from "../../../../../desktop-dev/src/core/ipc/index.js";
export class ServiceWorkerFetchEvent extends Event {
    constructor(fetchEvent, plugin) {
        super("fetch");
        Object.defineProperty(this, "fetchEvent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: fetchEvent
        });
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: plugin
        });
    }
    get request() {
        return this.fetchEvent.request;
    }
    /**查询连接者的信息 */
    async getRemoteManifest() {
        const { request } = this.fetchEvent;
        // 获取来建立连接的人的mmid
        const mmid = request.headers.get("X-External-Dweb-Host");
        console.log("getRemoteManifest查询id=>", mmid);
        const res = await this.plugin.buildApiRequest("/query", {
            pathPrefix: "dns.std.dweb",
            search: {
                mmid: mmid
            }
        }).fetch();
        return await res.json();
    }
    /**
     * 回复消息
     * @param body
     * @param init
     */
    async respondWith(body, init) {
        const response = new Response(body, init);
        const { ipc, ipcRequest } = this.fetchEvent;
        ipc.postMessage(await IpcResponse.fromResponse(ipcRequest.req_id, response, ipc));
    }
}
