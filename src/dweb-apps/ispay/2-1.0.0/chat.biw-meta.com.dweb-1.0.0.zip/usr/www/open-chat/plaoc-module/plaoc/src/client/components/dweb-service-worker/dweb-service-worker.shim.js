import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { ServiceWorkerFetchEvent } from "./FetchEvent.js";
import { dwebServiceWorkerPlugin } from "./dweb-service-worker.plugin.js";
class DwebServiceWorker extends EventTarget {
    constructor() {
        super();
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: dwebServiceWorkerPlugin
        });
        Object.defineProperty(this, "ws", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "messageQueue", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "isRegister", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        this.plugin.ipcPromise.then((ipc) => {
            ipc.onFetch((event) => {
                console.log("收到消息", event.pathname, this.isRegister);
                const serviceEvent = new ServiceWorkerFetchEvent(event, this.plugin);
                if (!this.isRegister) {
                    this.messageQueue.push(serviceEvent);
                }
                this.dispatchEvent(serviceEvent);
            });
        });
    }
    // 模拟messagePort 的start
    start() {
        console.log("触发缓存消息", this.messageQueue.length);
        while (this.messageQueue.length > 0) {
            const event = this.messageQueue.shift();
            console.log("派发消息", event, "当前消息：", this.messageQueue.length);
            event && this.dispatchEvent(event);
        }
    }
    get externalFetch() {
        return this.plugin.externalFetch;
    }
    get canOpenUrl() {
        return this.plugin.canOpenUrl;
    }
    get close() {
        return this.plugin.close;
    }
    get restart() {
        return this.plugin.restart;
    }
    /**
     *  dwebview 注册一个监听事件
     * @param eventName
     * @param listenerFunc
     * @returns
     */
    addEventListener(eventName, listenerFunc, options) {
        void super.addEventListener(eventName, listenerFunc, options);
        if (eventName === "fetch") {
            this.isRegister = true;
            this.start();
        }
    }
    /**移除监听器 */
    removeEventListener(eventName, listenerFunc, options) {
        if (eventName === "fetch") {
            this.isRegister = false;
        }
        return super.removeEventListener(eventName, listenerFunc, options);
    }
}
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], DwebServiceWorker.prototype, "externalFetch", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], DwebServiceWorker.prototype, "canOpenUrl", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], DwebServiceWorker.prototype, "close", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], DwebServiceWorker.prototype, "restart", null);
export const dwebServiceWorker = new DwebServiceWorker();
