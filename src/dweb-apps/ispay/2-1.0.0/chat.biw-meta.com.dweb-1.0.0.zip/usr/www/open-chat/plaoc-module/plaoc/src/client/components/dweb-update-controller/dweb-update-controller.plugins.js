import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
// import { ReadableStreamIpc } from "dweb/core/ipc-web/index.ts";
// import { createMockModuleServerIpc } from "../../common/websocketIpc.ts";
import { bindThis } from "../../helper/bindThis.js";
// import { ListenerCallback } from "../base/BaseEvent.ts";
import { BasePlugin } from "../base/BasePlugin.js";
// import { $MMID } from "../index.ts";
// import { UpdateControllerEvent, UpdateControllerMap } from "./dweb-update-controller.type.ts";
class UpdateControllerPlugin extends BasePlugin {
    constructor() {
        super("jmm.browser.dweb");
        Object.defineProperty(this, "tagName", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "dweb-update-controller"
        });
    }
    // 获取监听的消息
    // listen = new UpdateController();
    /**
     *  调出下载界面
     * @param metadataUrl 传递需要下载的metadata.json地址
     * @returns
     */
    async download(metadataUrl) {
        return this.fetchApi(`/install`, {
            search: {
                url: metadataUrl,
            },
        }).boolean();
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UpdateControllerPlugin.prototype, "download", null);
// class UpdateController extends EventTarget {
//   mmid: $MMID = "download.browser.dweb";
//   readonly ipcPromise: Promise<ReadableStreamIpc> = this.createIpc();
//   constructor() {
//     super();
//     this.ipcPromise.then((ipc) => {
//       ipc.onEvent((event) => {
//         if (event.name === UpdateControllerEvent.progress) {
//           return this.dispatchEvent(new CustomEvent(event.name, { detail: { progress: event.text } }));
//         }
//         // start/end/cancel
//         this.dispatchEvent(new Event(event.name));
//       });
//     });
//   }
//   private async createIpc() {
//     const api_url = BasePlugin.api_url;
//     const url = new URL(api_url.replace(/^http/, "ws"));
//     url.pathname = `${this.mmid}/watch/progress`;
//     // url.searchParams.append()
//     const ipc = await createMockModuleServerIpc(url, {
//       mmid: this.mmid,
//       ipc_support_protocols: {
//         cbor: false,
//         protobuf: false,
//         raw: false,
//       },
//       dweb_deeplinks: [],
//       categories: [],
//       name: this.mmid,
//     });
//     return ipc;
//   }
//   /**
//    *  dwebview 注册一个监听事件
//    * @param eventName
//    * @param listenerFunc
//    * @returns
//    */
//   override addEventListener<K extends keyof UpdateControllerMap>(
//     eventName: K,
//     listenerFunc: ListenerCallback<UpdateControllerMap[K]>,
//     options?: boolean | AddEventListenerOptions
//   ) {
//     return super.addEventListener(eventName, listenerFunc as EventListenerOrEventListenerObject, options);
//   }
//   /**移除监听器 */
//   override removeEventListener<K extends keyof UpdateControllerMap>(
//     eventName: K,
//     listenerFunc: ListenerCallback<UpdateControllerMap[K]>,
//     options?: boolean | EventListenerOptions
//   ) {
//     return super.removeEventListener(eventName, listenerFunc as EventListenerOrEventListenerObject, options);
//   }
// }
export const updateControllerPlugin = new UpdateControllerPlugin();
