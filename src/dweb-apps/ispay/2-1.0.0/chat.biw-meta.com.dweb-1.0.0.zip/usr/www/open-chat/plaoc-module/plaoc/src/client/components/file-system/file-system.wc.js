import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { fileSystemPlugin } from "./file-system.plugin.js";
class HTMLDwebFileSystemElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: fileSystemPlugin
        });
    }
    get writeFile() {
        return this.plugin.writeFile;
    }
    get getUri() {
        return this.plugin.getUri;
    }
}
Object.defineProperty(HTMLDwebFileSystemElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-file-system"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebFileSystemElement.prototype, "writeFile", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebFileSystemElement.prototype, "getUri", null);
export { HTMLDwebFileSystemElement };
if (!customElements.get(HTMLDwebFileSystemElement.tagName)) {
    customElements.define(HTMLDwebFileSystemElement.tagName, HTMLDwebFileSystemElement);
}
