export var ImpactStyle;
(function (ImpactStyle) {
    /**
     * 大而重的用户界面元素之间的碰撞
     *
     * @since 1.0.0
     */
    ImpactStyle["Heavy"] = "HEAVY";
    /**
     * 中等大小的用户界面元素之间的冲突
     *
     * @since 1.0.0
     */
    ImpactStyle["Medium"] = "MEDIUM";
    /**
     * 小而轻的用户界面元素之间的碰撞
     *
     * @since 1.0.0
     */
    ImpactStyle["Light"] = "LIGHT";
})(ImpactStyle || (ImpactStyle = {}));
export var NotificationType;
(function (NotificationType) {
    /**
     * 表示任务已成功完成的通知反馈类型
     *
     * @since 1.0.0
     */
    NotificationType["Success"] = "SUCCESS";
    /**
     * 指示任务已产生警告的通知反馈类型
     *
     * @since 1.0.0
     */
    NotificationType["Warning"] = "WARNING";
    /**
     * 任务失败的通知反馈类型
     *
     * @since 1.0.0
     */
    NotificationType["Error"] = "ERROR";
})(NotificationType || (NotificationType = {}));
/**
 * @deprecated Use `NotificationType`.
 * @since 1.0.0
 */
export const HapticsNotificationType = NotificationType;
/**
 * @deprecated Use `ImpactStyle`.
 * @since 1.0.0
 */
export const HapticsImpactStyle = ImpactStyle;
