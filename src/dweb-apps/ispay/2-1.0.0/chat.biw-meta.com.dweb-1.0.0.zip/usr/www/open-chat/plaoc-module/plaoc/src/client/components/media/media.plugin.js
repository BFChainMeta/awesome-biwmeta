var _MediaPlugin_instances, _MediaPlugin_encodeFileData;
import { __classPrivateFieldGet, __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { encode } from "../../../../../deps/deno.land/x/cbor@v1.5.4/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { FileDataEncode, normalToBase64String } from "../../util/file.js";
import { BasePlugin } from "../base/BasePlugin.js";
export class MediaPlugin extends BasePlugin {
    constructor() {
        super("media.file.sys.dweb");
        _MediaPlugin_instances.add(this);
    }
    /**
     * 保存图片到相册
     * @compatibility android/ios only
     * @param options
     * @returns
     */
    async savePictures(options) {
        const fileList = await __classPrivateFieldGet(this, _MediaPlugin_instances, "m", _MediaPlugin_encodeFileData).call(this, options);
        const shareBody = encode(fileList);
        return this.buildApiRequest("/savePictures", {
            search: {
                saveLocation: options.saveLocation,
            },
            headers: {
                "Content-Type": "application/cbor",
                "Content-Length": shareBody.length,
            },
            method: "POST",
            body: shareBody,
        }).fetch();
    }
}
_MediaPlugin_instances = new WeakSet(), _MediaPlugin_encodeFileData = 
/**
 * 生成fileData
 * @param options
 * @returns
 */
async function _MediaPlugin_encodeFileData(options) {
    const fileList = [];
    if (options.file && options.file.type.startsWith("image/")) {
        const data = await normalToBase64String(options.file);
        fileList.push({
            name: options.file.name,
            type: options.file.type,
            size: options.file.size,
            encoding: FileDataEncode.BASE64,
            data,
        });
    }
    return fileList;
};
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], MediaPlugin.prototype, "savePictures", null);
export const mediaPlugin = new MediaPlugin();
