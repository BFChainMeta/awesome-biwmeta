import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { mediaPlugin } from "./media.plugin.js";
class HTMLDwebMediaElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: mediaPlugin
        });
    }
    get savePictures() {
        return this.plugin.savePictures;
    }
}
Object.defineProperty(HTMLDwebMediaElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-media"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebMediaElement.prototype, "savePictures", null);
export { HTMLDwebMediaElement };
if (!customElements.get(HTMLDwebMediaElement.tagName)) {
    customElements.define(HTMLDwebMediaElement.tagName, HTMLDwebMediaElement);
}
