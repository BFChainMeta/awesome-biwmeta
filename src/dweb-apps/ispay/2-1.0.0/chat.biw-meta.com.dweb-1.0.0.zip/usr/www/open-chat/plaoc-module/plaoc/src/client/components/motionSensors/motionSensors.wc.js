import { motionSensorsPlugin } from "./motionSensors.plugin.js";
class HTMLDwebMotionSensorsElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: motionSensorsPlugin
        });
    }
    startAccelerometer(fps) {
        motionSensorsPlugin.startAccelerometer(fps);
        motionSensorsPlugin.onAccelerometer((axis) => {
            this.dispatchEvent(new CustomEvent("readAccelerometer", { detail: axis }));
        });
    }
    startGyroscope(fps) {
        motionSensorsPlugin.startGyroscope(fps);
        motionSensorsPlugin.onGyroscope((axis) => {
            this.dispatchEvent(new CustomEvent("readGyroscope", { detail: axis }));
        });
    }
}
Object.defineProperty(HTMLDwebMotionSensorsElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-motion-sensors"
});
export { HTMLDwebMotionSensorsElement };
customElements.define(HTMLDwebMotionSensorsElement.tagName, HTMLDwebMotionSensorsElement);
