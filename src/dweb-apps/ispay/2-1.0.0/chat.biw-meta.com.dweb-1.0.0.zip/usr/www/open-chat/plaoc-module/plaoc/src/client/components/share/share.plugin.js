var _SharePlugin_instances, _SharePlugin_multipartShare, _SharePlugin_blobToBase64String, _SharePlugin_cborNormalShareFileList, _SharePlugin_cborCanvasCompressShareFileList, _SharePlugin_cborImageListPost;
import { __classPrivateFieldGet, __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { encode } from "../../../../../deps/deno.land/x/cbor@v1.5.4/index.js";
import { PromiseOut } from "../../helper/PromiseOut.js";
import { bindThis } from "../../helper/bindThis.js";
import { FileDataEncode, normalToBase64String } from "../../util/file.js";
import { BasePlugin } from "../base/BasePlugin.js";
export class SharePlugin extends BasePlugin {
    constructor() {
        super("share.sys.dweb");
        _SharePlugin_instances.add(this);
    }
    /**
     *(desktop Only)
     * 判断是否能分享
     * @returns
     */
    // deno-lint-ignore require-await
    async canShare() {
        if (typeof navigator === "undefined" || !navigator.share) {
            return false;
        }
        else {
            return true;
        }
    }
    /**
     * 分享
     * @param options
     * @returns
     */
    async share(options) {
        if ((options.file && options.file.type.startsWith("image/")) ||
            (options.files && options.files[0].type.startsWith("image/"))) {
            return await __classPrivateFieldGet(this, _SharePlugin_instances, "m", _SharePlugin_cborImageListPost).call(this, options);
        }
        return await __classPrivateFieldGet(this, _SharePlugin_instances, "m", _SharePlugin_multipartShare).call(this, options);
    }
}
_SharePlugin_instances = new WeakSet(), _SharePlugin_multipartShare = 
/**
 * 分享
 * @param options
 * @returns
 */
async function _SharePlugin_multipartShare(options) {
    const data = new FormData();
    if (options.files && options.files.length !== 0) {
        for (let i = 0; i < options.files.length; i++) {
            const file = options.files.item(i);
            data.append("files", file);
        }
    }
    if (options.file) {
        data.append("files", options.file);
    }
    const result = await this.buildApiRequest("/share", {
        search: {
            title: options?.title,
            text: options?.text,
            url: options?.url,
        },
        method: "POST",
        body: data,
    })
        .fetch()
        .object();
    return result;
}, _SharePlugin_blobToBase64String = async function _SharePlugin_blobToBase64String(file, blobOptions) {
    const reader = new FileReader();
    const po = new PromiseOut();
    reader.onload = (ev) => {
        const img = new Image();
        img.onload = () => {
            const width = img.width, height = img.height;
            const canvas = document.createElement("canvas");
            const ctx = canvas.getContext("2d");
            canvas.width = width;
            canvas.height = height;
            ctx?.drawImage(img, 0, 0, width, height);
            canvas.toBlob((blob) => {
                const imgReader = new FileReader();
                imgReader.onloadend = () => {
                    let binary = "";
                    const bytes = new Uint8Array(imgReader.result);
                    for (const byte of bytes) {
                        binary += String.fromCharCode(byte);
                    }
                    po.resolve(btoa(binary));
                };
                imgReader.readAsArrayBuffer(blob);
            }, blobOptions.type.startsWith("image/") ? blobOptions.type : "image/jpeg", blobOptions.quality > 0 && blobOptions.quality <= 1 ? blobOptions.quality : 0.8);
        };
        img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
    return await po.promise;
}, _SharePlugin_cborNormalShareFileList = async function _SharePlugin_cborNormalShareFileList(options) {
    const fileList = [];
    if (options.files && options.files.length !== 0) {
        for (let i = 0; i < options.files.length; i++) {
            const file = options.files.item(i);
            const data = await normalToBase64String(file);
            fileList.push({
                name: file.name,
                type: file.type,
                size: file.size,
                encoding: FileDataEncode.BASE64,
                data,
            });
        }
    }
    if (options.file) {
        const data = await normalToBase64String(options.file);
        fileList.push({
            name: options.file.name,
            type: options.file.type,
            size: options.file.size,
            encoding: FileDataEncode.BASE64,
            data,
        });
    }
    return fileList;
}, _SharePlugin_cborCanvasCompressShareFileList = async function _SharePlugin_cborCanvasCompressShareFileList(options) {
    const fileList = [];
    if (options.files && options.files.length !== 0) {
        for (let i = 0; i < options.files.length; i++) {
            const file = options.files.item(i);
            const data = await __classPrivateFieldGet(this, _SharePlugin_instances, "m", _SharePlugin_blobToBase64String).call(this, file, options.imageBlobOptions);
            fileList.push({
                name: file.name,
                type: file.type,
                size: file.size,
                encoding: FileDataEncode.BASE64,
                data,
            });
        }
    }
    if (options.file) {
        const data = await __classPrivateFieldGet(this, _SharePlugin_instances, "m", _SharePlugin_blobToBase64String).call(this, options.file, options.imageBlobOptions);
        fileList.push({
            name: options.file.name,
            type: options.file.type,
            size: options.file.size,
            encoding: FileDataEncode.BASE64,
            data,
        });
    }
    return fileList;
}, _SharePlugin_cborImageListPost = async function _SharePlugin_cborImageListPost(options) {
    let fileList = [];
    if (options.imageBlobOptions) {
        fileList = await __classPrivateFieldGet(this, _SharePlugin_instances, "m", _SharePlugin_cborCanvasCompressShareFileList).call(this, options);
    }
    else {
        fileList = await __classPrivateFieldGet(this, _SharePlugin_instances, "m", _SharePlugin_cborNormalShareFileList).call(this, options);
    }
    const shareBody = encode(fileList);
    const result = await this.buildApiRequest("/share", {
        search: {
            title: options?.title,
            text: options?.text,
            url: options?.url,
        },
        headers: {
            "Content-Type": "application/cbor",
            "Content-Length": shareBody.length,
        },
        method: "POST",
        body: shareBody,
    })
        .fetch()
        .object();
    return result;
};
__decorate([
    bindThis
    // deno-lint-ignore require-await
    ,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SharePlugin.prototype, "canShare", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SharePlugin.prototype, "share", null);
export const sharePlugin = new SharePlugin();
