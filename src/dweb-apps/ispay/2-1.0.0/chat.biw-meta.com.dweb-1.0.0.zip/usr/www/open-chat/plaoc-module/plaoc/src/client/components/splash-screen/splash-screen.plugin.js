import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
export class SplashScreenPlugin extends BasePlugin {
    constructor() {
        super("splash-screen.nativeui.browser.dweb");
    }
    /**
     * 显示启动页
     * @param options
     */
    async show(options) {
        return await this.fetchApi(`/show`, {
            search: {
                autoHide: options?.autoHide,
                showDuration: options?.showDuration,
                fadeOutDuration: options?.fadeOutDuration,
                fadeInDuration: options?.fadeInDuration,
            },
        }).boolean();
    }
    /**
     * 隐藏启动页
     * @param options
     */
    async hide(options) {
        return await this.fetchApi(`/hide`, {
            search: {
                fadeOutDuration: options?.fadeOutDuration,
            },
        }).boolean();
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SplashScreenPlugin.prototype, "show", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SplashScreenPlugin.prototype, "hide", null);
export const splashScreenPlugin = new SplashScreenPlugin();
