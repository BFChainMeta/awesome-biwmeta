import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { splashScreenPlugin } from "./splash-screen.plugin.js";
class HTMLDwebSplashScreenElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: splashScreenPlugin
        });
    }
    get show() {
        return splashScreenPlugin.show;
    }
    get hide() {
        return splashScreenPlugin.hide;
    }
}
Object.defineProperty(HTMLDwebSplashScreenElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-splash-screen"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebSplashScreenElement.prototype, "show", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebSplashScreenElement.prototype, "hide", null);
export { HTMLDwebSplashScreenElement };
if (!customElements.get(HTMLDwebSplashScreenElement.tagName)) {
    customElements.define(HTMLDwebSplashScreenElement.tagName, HTMLDwebSplashScreenElement);
}
