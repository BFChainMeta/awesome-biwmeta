var _a;
import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { DOMInsets } from "../../util/insets.js";
import { BAR_STYLE } from "../base/BarPlugin.js";
import { BasePlugin } from "../base/BasePlugin.js";
import { windowPlugin } from "../index.js";
/**
 * 访问 status-bar 能力的插件
 */
export class StatusBarPlugin extends BasePlugin {
    constructor() {
        super("window.sys.dweb");
    }
    async setState(state) {
        let topBarContentColor = undefined;
        switch (state.style) {
            case BAR_STYLE.Dark:
                topBarContentColor = "#000000";
                break;
            case BAR_STYLE.Light:
                topBarContentColor = "#FFFFFF";
                break;
            default:
                topBarContentColor = "auto";
        }
        windowPlugin.setStyle({
            topBarBackgroundColor: state.color,
            topBarContentColor,
            topBarOverlay: state.overlay,
        });
    }
    setStateByKey(key, value) {
        return this.setState({
            [key]: value,
        });
    }
    async getState() {
        const winState = await windowPlugin.getState();
        let style = BAR_STYLE.Default;
        switch (winState.topBarContentColor) {
            case "#FFFFFF":
                style = BAR_STYLE.Light;
                break;
            case "#000000":
                style = BAR_STYLE.Dark;
                break;
        }
        return {
            color: winState.topBarBackgroundColor,
            style,
            overlay: winState.topBarOverlay,
            visible: true,
            insets: new DOMInsets(0, 0, 0, 0),
        };
    }
    setColor(color) {
        return this.setStateByKey("color", color);
    }
    async getColor() {
        return (await this.getState()).color;
    }
    setStyle(style) {
        return this.setState({ style });
    }
    async getStyle() {
        return (await this.getState()).style;
    }
    setOverlay(overlay) {
        return this.setState({ overlay });
    }
    async getOverlay() {
        return (await this.getState()).overlay;
    }
    setVisible(visible) {
        return this.setState({ visible });
    }
    async getVisible() {
        return (await this.getState()).visible;
    }
    async show() { }
    async hide() { }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], StatusBarPlugin.prototype, "setState", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof K !== "undefined" && K) === "function" ? _a : Object, Object]),
    __metadata("design:returntype", void 0)
], StatusBarPlugin.prototype, "setStateByKey", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatusBarPlugin.prototype, "getState", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], StatusBarPlugin.prototype, "setColor", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatusBarPlugin.prototype, "getColor", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], StatusBarPlugin.prototype, "setStyle", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatusBarPlugin.prototype, "getStyle", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", void 0)
], StatusBarPlugin.prototype, "setOverlay", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatusBarPlugin.prototype, "getOverlay", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", void 0)
], StatusBarPlugin.prototype, "setVisible", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatusBarPlugin.prototype, "getVisible", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatusBarPlugin.prototype, "show", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], StatusBarPlugin.prototype, "hide", null);
export const statusBarPlugin = new StatusBarPlugin();
