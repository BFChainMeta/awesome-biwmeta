import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
/**
 * 访问 toast 能力的插件
 */
export class ToastPlugin extends BasePlugin {
    constructor() {
        super("toast.sys.dweb");
    }
    /**
     * toast信息显示
     * @param message 消息
     * @param duration 时长 'long' | 'short'
     * @returns
     */
    async show(options) {
        const { text: message, duration = "long", position = "bottom" } = options;
        await this.fetchApi(`/show`, {
            search: { message, duration, position },
        });
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ToastPlugin.prototype, "show", null);
export const toastPlugin = new ToastPlugin();
