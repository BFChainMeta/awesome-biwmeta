import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { toastPlugin } from "./toast.plugin.js";
class HTMLDwebToastElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: toastPlugin
        });
    }
    get show() {
        return toastPlugin.show;
    }
}
Object.defineProperty(HTMLDwebToastElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-toast"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebToastElement.prototype, "show", null);
export { HTMLDwebToastElement };
if (!customElements.get(HTMLDwebToastElement.tagName)) {
    customElements.define(HTMLDwebToastElement.tagName, HTMLDwebToastElement);
}
