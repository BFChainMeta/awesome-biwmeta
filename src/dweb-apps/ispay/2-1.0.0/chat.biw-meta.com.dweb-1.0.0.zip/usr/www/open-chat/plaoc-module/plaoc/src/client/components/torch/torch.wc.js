import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { torchPlugin } from "./torch.plugin.js";
class HTMLDwebTorchElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: torchPlugin
        });
    }
    get toggleTorch() {
        return torchPlugin.toggleTorch;
    }
    get getTorchState() {
        return torchPlugin.getTorchState;
    }
}
Object.defineProperty(HTMLDwebTorchElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-torch"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebTorchElement.prototype, "toggleTorch", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebTorchElement.prototype, "getTorchState", null);
export { HTMLDwebTorchElement };
if (!customElements.get(HTMLDwebTorchElement.tagName)) {
    customElements.define(HTMLDwebTorchElement.tagName, HTMLDwebTorchElement);
}
