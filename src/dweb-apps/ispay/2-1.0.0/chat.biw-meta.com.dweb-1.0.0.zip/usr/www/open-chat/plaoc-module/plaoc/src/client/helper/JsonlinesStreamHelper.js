import { BasePlugin } from "../components/base/BasePlugin.js";
import { JsonlinesStream } from "./JsonlinesStream.js";
import { ReadableStreamOut, streamRead } from "./readableStreamHelper.js";
export class JsonlinesStreamResponse {
    constructor(plugin, coder, buildWsUrl = async (ws_url) => ws_url) {
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: plugin
        });
        Object.defineProperty(this, "coder", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: coder
        });
        Object.defineProperty(this, "buildWsUrl", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: buildWsUrl
        });
        Object.defineProperty(this, "_ws", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    async *jsonlines(path, options) {
        const api_url = BasePlugin.api_url;
        const url = new URL(api_url.replace(/^http/, "ws"));
        // 内部的监听
        url.pathname = `/${this.plugin.mmid}${path}`;
        options?.searchParams?.forEach((v, k) => {
            url.searchParams.append(k, v);
        });
        const ws = new WebSocket((await this.buildWsUrl(url)) ?? url);
        this._ws = ws;
        ws.binaryType = "arraybuffer";
        const streamout = new ReadableStreamOut();
        ws.onmessage = (event) => {
            const data = event.data;
            streamout.controller.enqueue(data);
        };
        ws.onclose = () => {
            streamout.controller.close();
        };
        ws.onerror = (event) => {
            streamout.controller.error(event);
        };
        for await (const state of streamRead(streamout.stream.pipeThrough(new JsonlinesStream(this.coder.decode)), options)) {
            yield state;
        }
    }
    close() {
        this._ws?.close();
    }
}
