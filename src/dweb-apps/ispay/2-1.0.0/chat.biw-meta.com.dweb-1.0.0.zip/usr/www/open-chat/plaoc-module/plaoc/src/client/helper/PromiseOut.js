class PromiseOut {
    constructor() {
        Object.defineProperty(this, "_value", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "_readyState", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: PromiseOut.PENDING
        });
        Object.defineProperty(this, "resolve", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "reject", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "promise", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Promise((resolve, reject) => {
                this.resolve = resolve;
                this.reject = reject;
            }).then((res) => {
                this._value = res;
                this._readyState = PromiseOut.RESOLVED;
                return res;
            }, (err) => {
                this._readyState = PromiseOut.REJECTED;
                throw err;
            })
        });
    }
    static resolve(v) {
        const po = new PromiseOut();
        po.resolve(v);
        return po;
    }
    get value() {
        return this._value;
    }
    get readyState() {
        return this._readyState;
    }
}
Object.defineProperty(PromiseOut, "PENDING", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: 0
});
Object.defineProperty(PromiseOut, "RESOLVED", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: 1
});
Object.defineProperty(PromiseOut, "REJECTED", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: 2
});
export { PromiseOut };
