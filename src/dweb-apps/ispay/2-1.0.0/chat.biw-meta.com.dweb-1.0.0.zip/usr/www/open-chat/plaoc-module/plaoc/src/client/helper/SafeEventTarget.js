export class SafeEventTarget extends EventTarget {
    addEventListener(type, listener, options) {
        super.addEventListener(type, listener, options);
    }
    removeEventListener(type, callback, options) {
        super.removeEventListener(type, callback, options);
    }
    dispatchEvent(event) {
        const hanlder = Reflect.get(this, "on" + event.type);
        if (typeof hanlder === "function") {
            try {
                hanlder.call(this, event);
            }
            catch { }
        }
        return super.dispatchEvent(event);
    }
}
export class SafeMessageEvent extends MessageEvent {
    constructor(type, eventInitDict) {
        super(type, eventInitDict);
    }
}
export class SafeEvent extends Event {
    constructor(type, eventInitDict) {
        super(type, eventInitDict);
    }
}
export class SafeStateEvent extends Event {
    constructor(type, eventInitDict) {
        super(type, eventInitDict);
        Object.defineProperty(this, "state", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.state = eventInitDict.state;
    }
}
