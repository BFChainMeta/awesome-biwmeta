import { __decorate, __metadata } from "../../../../../tslib/modules/index.js";
import { BasePlugin } from "../components/base/BasePlugin.js";
import { JsonlinesStream } from "../helper/JsonlinesStream.js";
import { bindThis } from "../helper/bindThis.js";
import { createSignal } from "../helper/createSignal.js";
import { ReadableStreamOut, streamRead } from "../helper/readableStreamHelper.js";
/**
 * 提供了一个状态的读取与更新的功能
 */
export class StateObserver {
    constructor(plugin, fetcher, coder, buildWsUrl = async (ws_url) => ws_url) {
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: plugin
        });
        Object.defineProperty(this, "fetcher", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: fetcher
        });
        Object.defineProperty(this, "coder", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: coder
        });
        Object.defineProperty(this, "buildWsUrl", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: buildWsUrl
        });
        Object.defineProperty(this, "_ws", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "_currentState", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "_signalCurrentStateChange", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: createSignal()
        });
        Object.defineProperty(this, "onChange", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: this._signalCurrentStateChange.listen
        });
    }
    async *jsonlines(options) {
        const api_url = BasePlugin.api_url;
        const url = new URL(api_url.replace(/^http/, "ws"));
        // 内部的监听
        url.pathname = `/${this.plugin.mmid}/observe`;
        const ws = new WebSocket((await this.buildWsUrl(url)) ?? url);
        this._ws = ws;
        ws.binaryType = "arraybuffer";
        const streamout = new ReadableStreamOut();
        ws.onmessage = async (event) => {
            const data = event.data;
            streamout.controller.enqueue(data);
        };
        ws.onclose = async () => {
            streamout.controller.close();
        };
        ws.onerror = async (event) => {
            streamout.controller.error(event);
        };
        for await (const state of streamRead(streamout.stream.pipeThrough(new TextDecoderStream()).pipeThrough(new JsonlinesStream(this.coder.decode)), options)) {
            this.currentState = state;
            yield state;
        }
    }
    stopObserve() {
        this._ws?.close();
    }
    /**
     * 当前的状态集合
     */
    get currentState() {
        return this._currentState;
    }
    set currentState(state) {
        this._currentState = state;
        if (state) {
            this._signalCurrentStateChange.emit(state);
        }
    }
    /**
     * 获取当前状态栏的完整信息
     * @returns
     */
    async getState(force_update = false) {
        if (force_update || this.currentState === undefined) {
            return await this._updateCurrentState();
        }
        return this.currentState;
    }
    /**
     * 刷新获取有关状态栏当前状态的信息。
     */
    async _updateCurrentState() {
        const raw = await this.fetcher();
        return (this.currentState = this.coder.decode(raw));
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], StateObserver.prototype, "getState", null);
