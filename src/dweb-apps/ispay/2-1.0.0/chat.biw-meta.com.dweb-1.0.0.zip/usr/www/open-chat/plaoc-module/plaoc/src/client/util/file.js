import { PromiseOut } from "../helper/PromiseOut.js";
export var FileDataEncode;
(function (FileDataEncode) {
    FileDataEncode["UTF8"] = "utf8";
    FileDataEncode["BASE64"] = "base64";
    FileDataEncode["BINARY"] = "binary";
})(FileDataEncode || (FileDataEncode = {}));
export async function normalToBase64String(file) {
    const reader = new FileReader();
    const po = new PromiseOut();
    reader.onloadend = () => {
        let binary = "";
        const bytes = new Uint8Array(reader.result);
        for (const byte of bytes) {
            binary += String.fromCharCode(byte);
        }
        po.resolve(btoa(binary));
    };
    reader.readAsArrayBuffer(file);
    return await po.promise;
}
