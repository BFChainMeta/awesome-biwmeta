import { getInjectionToken } from "./common.js";
import { Resolve } from "./Resolve.js";
import { FACTORY_CUSTOM_INJECT_MODULE_MAP, getInstanceModules, INJECTPROP_AFERTINIT_MATE_KEY, INJECTPROP_ONINIT_MATE_KEY, } from "./_inner.js";
/**
 * 主动要求注入的模块
 * 如果我们依赖的是一个`Interface`，那么这种情况没有可用的构造函数可以让我们使用`@Injectable`去修饰模块
 * 这时候就必须在主动地声明依赖的名称，并在使用`Resolve`初始化的时候将对于的模块注入
 *
 * 也可以配合`@Injectable`实现依赖反转
 *
 * @param module_name
 */
export function Inject(inject_module, conf) {
    return (target, prop_name, index) => {
        if (typeof index === "number") {
            const module_name = typeof inject_module === "function"
                ? getInjectionToken(inject_module)
                : inject_module;
            if (module_name !== undefined) {
                const modules = FACTORY_CUSTOM_INJECT_MODULE_MAP.get(target) || new Map();
                FACTORY_CUSTOM_INJECT_MODULE_MAP.set(target, modules);
                modules.set(index, { id: module_name, conf });
            }
        }
        else {
            if (inject_module === undefined) {
                throw new ReferenceError("inject_moudle should not be empty");
            }
            return InjectProp(inject_module, conf)(target, prop_name, index);
        }
    };
}
/**
 * 脏注入。
 * 一般用于模块循环依赖时，不建议使用，建议梳理清楚项目结构
 * @param inject_module_getter
 * @param conf
 * @returns
 */
export function DirtyInjectProp(inject_module_getter, conf) {
    return (target, prop_name, des) => {
        const prop = {
            configurable: true,
            enumerable: true,
            get() {
                const inject_module = inject_module_getter();
                InjectProp(inject_module, conf)(target, prop_name, des);
                return this[prop_name];
            },
        };
        Object.defineProperty(target, prop_name, prop);
    };
}
function getInjectPropsMetadataMap(target, matedataKey) {
    let map = Reflect.getMetadata(matedataKey, target);
    if (!map) {
        map = new Map();
        Reflect.metadata(matedataKey, map)(target);
    }
    return map;
}
export function InjectProp(inject_module, conf = {}) {
    const { dynamics: dynamicsGSetter, optional: allowUndefined, autoResolve, writable = true, } = conf;
    let autoResolvePlot;
    if (autoResolve === false) {
        autoResolvePlot = 0 /* AUTO_RESOLVE_PLOT.NO_RESOLVE */;
    }
    else if (autoResolve === true || autoResolve === undefined) {
        autoResolvePlot = 1 /* AUTO_RESOLVE_PLOT.ON_GETTER */;
    }
    else {
        autoResolvePlot = autoResolve;
    }
    const module_name = typeof inject_module === "function"
        ? getInjectionToken(inject_module)
        : inject_module;
    if (module_name === undefined) {
        throw new TypeError(`module name is undefined`);
    }
    return (target, prop_name, des) => {
        if (autoResolvePlot !== 0 /* AUTO_RESOLVE_PLOT.NO_RESOLVE */ &&
            autoResolvePlot !== 1 /* AUTO_RESOLVE_PLOT.ON_GETTER */) {
            if (typeof inject_module !== "function") {
                throw new TypeError(`${target} could not resolve prop '${prop_name}', inject_module not an function.`);
            }
            if (autoResolvePlot === 3 /* AUTO_RESOLVE_PLOT.AFTER_INIT */) {
                getInjectPropsMetadataMap(target, INJECTPROP_AFERTINIT_MATE_KEY).set(prop_name, {
                    injectModel: inject_module,
                });
            }
            else if (autoResolvePlot === 2 /* AUTO_RESOLVE_PLOT.ON_INIT */) {
                getInjectPropsMetadataMap(target, INJECTPROP_ONINIT_MATE_KEY).set(prop_name, {
                    injectModel: inject_module,
                });
            }
        }
        const getModule = (ins) => {
            const module_map = getInstanceModules(ins);
            if (!module_map) {
                throw new ReferenceError(`instance of ${ins.constructor.name} is not an instance which is created by Resolve`);
            }
            return module_map;
        };
        const moduleSetter = (ins, value) => {
            const module_map = getModule(ins);
            module_map.set(module_name, value);
        };
        const moduleGetter = (ins) => {
            const module_map = getModule(ins);
            if (module_map.has(module_name)) {
                return module_map.get(module_name);
            }
            else if (autoResolvePlot !== 0 /* AUTO_RESOLVE_PLOT.NO_RESOLVE */ &&
                typeof inject_module === "function") {
                return Resolve(inject_module, module_map);
            }
            else if (!allowUndefined) {
                throw new ReferenceError(`module of ${String(module_name)} must been Injected first.`);
            }
        };
        const prop = {
            configurable: true,
            enumerable: true,
        };
        if (dynamicsGSetter) {
            /// 动态属性
            if (writable) {
                prop.set = function (value) {
                    moduleSetter(this, value);
                    // des?.set?.call(this, value);
                };
            }
            prop.get = function () {
                // des?.get?.call(this, value);
                return moduleGetter(this);
            };
        }
        else {
            const freezeGSetter = (ins, value) => {
                Object.defineProperty(ins, prop_name, {
                    value,
                    writable,
                    configurable: true,
                    enumerable: true,
                });
            };
            /// 静态属性
            if (writable) {
                prop.set = function (value) {
                    moduleSetter(this, value);
                    freezeGSetter(this, value);
                };
            }
            prop.get = function () {
                const module_ins = moduleGetter(this);
                freezeGSetter(this, module_ins);
                return module_ins;
            };
        }
        Object.defineProperty(target, prop_name, prop);
    };
}
