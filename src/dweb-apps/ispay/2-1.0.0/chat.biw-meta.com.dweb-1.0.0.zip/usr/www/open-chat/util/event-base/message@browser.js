export default (message, style) => {
    return ["%c" + message, style];
};
