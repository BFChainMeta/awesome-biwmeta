import { __decorate, __metadata } from "../../tslib/modules/index.js";
import { PromiseOut } from "../extends-promise-out/index.js";
import { cacheGetter, isDev, GetCallerInfo, eventDebugStyle, EVENT_DESCRIPTION_SYMBOL, } from "../event-base/index.js";
import { MapEventEmitter, } from "../event-map_emitter/index.js";
export class MapEventEmitterPro extends MapEventEmitter {
    constructor() {
        super(...arguments);
        //#region on emit any event
        /**是否有过监听通用事件处理 */
        Object.defineProperty(this, "_hasCommonEmitHandlerMap", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        //#endregion
        //#region after
        /**是否有使用过after监听器 */
        Object.defineProperty(this, "_hasAfterTaskMap", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        //#endregion
        //#region before
        /**是否有使用过before监听器 */
        Object.defineProperty(this, "_hasBeforeTaskMap", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        //#endregion
    }
    /**
     * 触发事件
     * @param eventname
     * @param args
     */
    _emit(eventname, args) {
        /**
         * 处理前置的任务
         */
        if (this._hasBeforeTaskMap) {
            const task = this._beforeTasks[eventname];
            if (task) {
                delete this._beforeTasks[eventname];
                task.resolve(args);
            }
        }
        /**
         * 处理通用监听器
         */
        if (this._hasCommonEmitHandlerMap) {
            if (isDev) {
                if (this._commonEmitHandlerMap.size) {
                    console.log(...eventDebugStyle.head("%s EMIT WILDCARDS * [%s]", eventDebugStyle.MIDNIGHTBLUE_BOLD_UNDERLINE), this[EVENT_DESCRIPTION_SYMBOL] || this, { eventname, args });
                }
            }
            for (const [commonHanlder, opts] of this._commonEmitHandlerMap) {
                try {
                    if (isDev) {
                        const { taskname = commonHanlder.name } = opts;
                        console.log(...eventDebugStyle.head("RUN [%s]", eventDebugStyle.MIDNIGHTBLUE_BOLD_UNDERLINE), taskname);
                    }
                    const res = commonHanlder({ eventname, args });
                    if (res instanceof Promise) {
                        res.catch((err) => this._emitErrorHanlder(err, eventname, args));
                    }
                }
                catch (err) {
                    this._emitErrorHanlder(err, eventname, args);
                }
                finally {
                    if (opts.once) {
                        this._commonEmitHandlerMap.delete(commonHanlder);
                    }
                }
            }
        }
        /// 触发事件
        super._emit(eventname, args);
        /**
         * 处理后置的任务
         */
        if (this._hasAfterTaskMap) {
            const task = this._afterTasks[eventname];
            if (task) {
                delete this._afterTasks[eventname];
                task.resolve(args);
            }
        }
    }
    /**
     * 移除所有的事件
     */
    clear(opts = {}) {
        super.clear(opts);
        const { ignoreCommonErrorHanlder, ignoreBeforeTask, ignoreAfterTask } = opts;
        if (!ignoreCommonErrorHanlder && this._hasCommonEmitHandlerMap) {
            /// 默认清理掉通用监听的回调合集
            this._commonEmitHandlerMap.clear();
        }
        if (!ignoreBeforeTask && this._hasBeforeTaskMap) {
            /// 默认清理掉once的监听
            const error = new Error("Remove all listeners");
            for (const eventname in this._beforeTasks) {
                this._beforeTasks[eventname].reject(error);
            }
        }
        if (!ignoreAfterTask && this._hasAfterTaskMap) {
            /// 默认清理掉once的监听
            const error = new Error("Remove all listeners");
            for (const eventname in this._afterTasks) {
                this._afterTasks[eventname].reject(error);
            }
        }
    }
    get _commonEmitHandlerMap() {
        this._hasCommonEmitHandlerMap = true;
        return new Map();
    }
    /**
     * 监听所有事件
     * @param commonHanlder
     * @param taskname
     */
    onEmit(commonHanlder, opts = {}) {
        if (this._commonEmitHandlerMap.has(commonHanlder)) {
            console.warn(`hanlder '${commonHanlder.name}' already exits in common hanlder event set.`);
        }
        if (opts.taskname === undefined) {
            opts.taskname = GetCallerInfo(this.onEmit);
        }
        this._commonEmitHandlerMap.set(commonHanlder, opts);
    }
    /**
     * 移除所有事件的监听
     * @param commonHanlder
     */
    offEmit(commonHanlder) {
        if (!this._hasCommonEmitHandlerMap) {
            return false;
        }
        if (commonHanlder) {
            return this._commonEmitHandlerMap.delete(commonHanlder);
        }
        this._commonEmitHandlerMap.clear();
        return true;
    }
    get _afterTasks() {
        this._hasAfterTaskMap = true;
        return Object.create(null);
    }
    /**
     * 与once不同，返回promise
     * 这里与常规的监听不同，不需要提供回调函数
     * 在清理事件的时候，它会被触发abort事件
     *
     * 这样设计是因为once事件的行为往往不是为了处理一个事件
     * 而是在等待一个事件，如果基于回调，很容易在清理掉事件的时候，伴随着也将这种等待也清理了
     * 从而陷入了无限的等待，而这往往不是我们所要的
     *
     * 我们当然可以在on函数上增加“被清理时的回调”，这将会更加通用，但同时也意味着清理行为的复杂性增加
     * 我们不需要为那2%的功能牺牲太多，取舍之间，我们选择这样的简单方案来定义`once`的行为
     *
     * @param eventname
     * @param handler
     * @param taskname
     */
    after(eventname) {
        let task = this._afterTasks[eventname];
        if (!task) {
            task = this._afterTasks[eventname] = new PromiseOut();
        }
        return task.promise;
    }
    /**
     * 中断一次性监听器
     * @param eventname
     * @param err
     */
    abortAfter(eventname, err) {
        const task = this._afterTasks[eventname];
        if (task) {
            task.reject(err);
        }
        return task;
    }
    get _beforeTasks() {
        this._hasBeforeTaskMap = true;
        return Object.create(null);
    }
    /**
     * 与after类似，只是触发的时机不同
     *
     * @param eventname
     * @param handler
     * @param taskname
     */
    before(eventname) {
        let task = this._beforeTasks[eventname];
        if (!task) {
            task = this._beforeTasks[eventname] = new PromiseOut();
        }
        return task.promise;
    }
    /**
     * 中断一次性监听器
     * @param eventname
     * @param err
     */
    abortBefore(eventname, err) {
        const task = this._beforeTasks[eventname];
        if (task) {
            task.reject(err);
        }
        return task;
    }
}
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], MapEventEmitterPro.prototype, "_commonEmitHandlerMap", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], MapEventEmitterPro.prototype, "_afterTasks", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], MapEventEmitterPro.prototype, "_beforeTasks", null);
