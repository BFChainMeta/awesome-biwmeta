import { loggerCreater as lc, LOGGER_LEVEL } from "../logger/index.js";
// const lc: any = {};
// const LOGGER_LEVEL: any = {};
import { cacheObjectGetter } from "../extends-object/index.js";
// const cacheObjectGetter: any = {};
import { typeColorHashMap } from "./typeColor@browser.js";
function createPrinter(nsp, color, level) {
    const logger = lc.create(nsp);
    if (color === undefined) {
        logger.forceSetUseColors(false);
    }
    else {
        logger.forceSetUseColors(true);
    }
    return logger.createPrinter(color === "inherit" ? logger.color : color, level);
}
//#region 日志工具
export function LogGenerator(nsp) {
    const loggerHashMap = {
        get log() {
            return createPrinter(nsp, typeColorHashMap.log, LOGGER_LEVEL.log);
        },
        get info() {
            return createPrinter(nsp, typeColorHashMap.info, LOGGER_LEVEL.info);
        },
        get warn() {
            return createPrinter(nsp, typeColorHashMap.warn, LOGGER_LEVEL.warn);
        },
        get success() {
            return createPrinter(nsp, typeColorHashMap.success, LOGGER_LEVEL.success);
        },
        get trace() {
            return createPrinter(nsp, typeColorHashMap.trace, LOGGER_LEVEL.trace);
        },
        get error() {
            return createPrinter(nsp, typeColorHashMap.error, LOGGER_LEVEL.error);
        },
    };
    return cacheObjectGetter(loggerHashMap);
}
export const exceptionLoggerCreater = lc;
//#endregion
