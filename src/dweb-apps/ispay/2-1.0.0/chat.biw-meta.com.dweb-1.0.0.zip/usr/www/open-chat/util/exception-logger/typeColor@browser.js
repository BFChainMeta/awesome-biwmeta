export const typeColorHashMap = {
    log: "inherit",
    info: "inherit",
    trace: "inherit",
    success: "inherit",
    warn: "inherit",
    error: "inherit", // "darkred",
};
