import { safePromiseThen } from "./safePromiseThen.js";
import { PromiseOut } from "../extends-promise-out/index.js";
/**
 * Promise 竞争器
 */
export class PromiseRace {
    constructor(options) {
        /**配置 */
        Object.defineProperty(this, "options", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /**排名列表
         * 在输出结果后，将其保存到排行榜上，可以用race函数来获取名单
         */
        Object.defineProperty(this, "rankList", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        /**
         * 等待获取最新的 rank 信息的候选者
         */
        Object.defineProperty(this, "quota", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /**回调列表 */
        Object.defineProperty(this, "thenedMap", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Map()
        });
        Object.defineProperty(this, "_cter", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
        });
        this.options = PromiseRace.mergeOptions(options);
    }
    /**合并选项 */
    static mergeOptions(options) {
        const defaultOptions = {
            throwWhenNoRacer: false,
        };
        return Object.assign(defaultOptions, options);
    }
    resolve(value) {
        if (this.quota) {
            this.quota.resolve(value);
            this.quota = undefined;
        }
        else {
            this.rankList.push({ type: 1 /* RANK_TYPE.Resolved */, value });
        }
    }
    reject(reason) {
        if (this.quota) {
            this.quota.reject(reason);
            this.quota = undefined;
        }
        else {
            this.rankList.push({ type: 0 /* RANK_TYPE.Rejected */, value: reason });
        }
    }
    /**增加竞争者 */
    addRacer(promise) {
        const thended = this.thenedMap.get(promise);
        if (!thended) {
            const onfulfilled = (value) => {
                this.resolve(value);
                this.thenedMap.delete(promise);
            };
            const onrejected = (reason) => {
                this.reject(reason);
                this.thenedMap.delete(promise);
            };
            const { thened, toPromise } = safePromiseThen(promise, onfulfilled, onrejected);
            if (thened.cbs) {
                this.thenedMap.set(promise, {
                    cbs: thened.cbs,
                    onfulfilled,
                    onrejected,
                    toPromise,
                });
            }
            return toPromise;
        }
        return thended.toPromise;
    }
    /**
     * 移除竞争者
     */
    removeRacer(promise) {
        const thened = this.thenedMap.get(promise);
        if (thened) {
            this._removeRacer(promise, thened);
            this._checkToEndRace();
            return true;
        }
        return false;
    }
    _removeRacer(promise, thened) {
        thened.cbs.resolves.delete(thened.onfulfilled);
        thened.cbs.rejects.delete(thened.onrejected);
        this.thenedMap.delete(promise);
    }
    /**判断是否存在某一个竞争者 */
    hasRacer(promise) {
        return this.thenedMap.has(promise);
    }
    /**竞争者数量 */
    get size() {
        return this.thenedMap.size;
    }
    _queneToCheck() { }
    /**检查竞赛名单，如果没有可用名单，则直接终结竞赛 */
    _checkToEndRace() {
        /**队列为空时才触发判断 */
        if (this.options.throwWhenNoRacer &&
            this._cter === false &&
            this.thenedMap.size === 0) {
            this._cter = true;
            queueMicrotask(() => {
                /**如果队列为空，且有任务竞赛在执行，直接抛出错误 */
                if (this.thenedMap.size === 0 &&
                    this.quota &&
                    this.quota.is_finished === false) {
                    this.quota.reject(new RangeError("no racer to race"));
                }
            });
        }
    }
    static isNoRacerException(exception) {
        return (exception instanceof RangeError &&
            exception.message === "no racer to race");
    }
    /**进行竞赛 */
    race(outter) {
        /// 获取已经有的排名列表
        const inRank = this.rankList.shift();
        if (!inRank) {
            /// 如果有自定义输出，那么将之与候选名单进行绑定
            if (outter) {
                if (this.quota) {
                    if (this.quota !== outter) {
                        this.quota.promise.then(outter.resolve, outter.reject);
                    }
                }
                else {
                    this.quota = outter;
                }
                return outter.promise;
            }
            /// 检查 空竞赛的异常
            this._checkToEndRace();
            /// 如果没有自定义输出，那么启用候选名单
            return (this.quota || (this.quota = new PromiseOut())).promise;
        }
        if (inRank.type === 1 /* RANK_TYPE.Resolved */) {
            return inRank.value;
        }
        else {
            throw inRank.value;
        }
    }
    /**
     * 清场
     */
    clear(reason) {
        for (const item of this.thenedMap) {
            this._removeRacer(item[0], item[1]);
        }
        this.rankList.length = 0;
        if (this.quota) {
            this.quota.reject(reason);
            this.quota = undefined;
        }
    }
}
/**
 * 避免由于某一个promise不终结导致的不释放其它promise引用的维妮塔
 */
export function safePromiseRace(maybePromises) {
    const res = new PromiseOut();
    /**
     * 如果存在非promise对象，那么可以直接返回了
     */
    let isAllPromise = true;
    const promises = [];
    for (const p of maybePromises) {
        if (typeof p === "object" &&
            p !== null &&
            typeof p.then === "function") {
            promises.push(p);
        }
        else {
            isAllPromise = false;
            res.resolve(p);
            break;
        }
    }
    /**
     * 如果全都是promise那么尝试去等待每一个任务
     */
    if (isAllPromise) {
        if (promises.length === 0) {
            console.warn("safePromiseRace got empty array");
            /// 空长度就是会返回一个pendding的promise
        }
        else {
            const race = new PromiseRace();
            /// 这里只需要一次性竞赛，完成后就清场
            res.onFinished(() => race.clear());
            for (const p of promises) {
                race.addRacer(p);
            }
            race.race(res);
        }
    }
    return res.promise;
}
// safePromiseRace([1, 2, "s", Promise.reject(), Promise.resolve(), Promise.resolve({ a: 1 })]);
