const SLEEP_TASK_TI_WM = new WeakMap();
export const sleep = (ms, onresolve) => {
    let ti;
    if (ms <= 0) {
        ms = 1;
    }
    const task = new Promise((resolve) => (ti = setTimeout(() => {
        SLEEP_TASK_TI_WM.delete(task);
        resolve();
    }, ms))).then(onresolve);
    SLEEP_TASK_TI_WM.set(task, ti);
    return task;
};
export const unsleep = (task) => {
    const ti = SLEEP_TASK_TI_WM.get(task);
    if (ti !== undefined) {
        SLEEP_TASK_TI_WM.delete(task);
        clearTimeout(ti);
    }
};
