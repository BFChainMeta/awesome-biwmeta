export const isNodejs = false;
export const isWin32 = false;
