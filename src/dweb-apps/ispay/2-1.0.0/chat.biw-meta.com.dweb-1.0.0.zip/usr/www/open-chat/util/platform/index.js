///<reference lib="dom" />
export * from "./common.js";
export * from "./diff@browser.js";
