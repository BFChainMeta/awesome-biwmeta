import { PromiseOut } from "../extends-promise-out/index.js";
const ABORT_SIGNAL = Symbol("abort-signal");
export class ReactiveArray extends Array {
    constructor() {
        super();
        Object.defineProperty(this, "_subs", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    emitChanged(start, count = 1) {
        if (this._subs === undefined) {
            return;
        }
        const end = start + count;
        for (const sub of this._subs) {
            if (sub.changed === true) {
                continue;
            }
            if (false === (start > sub.end || end < sub.start)) {
                if (sub.changed instanceof PromiseOut) {
                    sub.changed.resolve();
                }
                sub.changed = true;
            }
        }
    }
    async *_subscription(sub) {
        if (this._subs === undefined) {
            this._subs = new Set();
        }
        this._subs.add(sub);
        try {
            do {
                if (sub.changed === true) {
                    sub.changed = false;
                    yield this.slice(sub.start, sub.end);
                }
                if (sub.changed === false) {
                    sub.changed = new PromiseOut();
                    await sub.changed.promise;
                    sub.changed = true;
                }
            } while (true);
        }
        catch (err) {
            if (err !== ABORT_SIGNAL) {
                throw err;
            }
        }
        finally {
            this._subs.delete(sub);
        }
    }
    subscription(start = 0, end = Infinity, takeCurrent = true) {
        const sub = { start, end, changed: takeCurrent };
        const subject = this._subscription(sub);
        const _return = subject.return;
        /// 重写 return 函数，确保能够直接地释放掉这个订阅
        subject.return = (arg) => {
            if (sub.changed instanceof PromiseOut) {
                sub.changed.reject(ABORT_SIGNAL);
            }
            return _return.call(subject, arg);
        };
        const _throw = subject.throw;
        subject.throw = (err) => {
            if (sub.changed instanceof PromiseOut) {
                sub.changed.reject(err);
            }
            return _throw.call(subject, err);
        };
        return subject;
    }
    push(...args) {
        if (args.length > 0) {
            this.emitChanged(this.length, args.length);
        }
        return super.push(...args);
    }
    pop() {
        if (this.length > 0) {
            this.emitChanged(this.length - 1, 1);
        }
        return super.pop();
    }
    unshift(...args) {
        if (args.length > 0) {
            this.emitChanged(0, this.length + args.length);
        }
        return super.unshift(...args);
    }
    shift() {
        if (this.length > 0) {
            this.emitChanged(0, this.length);
        }
        return super.shift();
    }
    splice(start = 0, deleteCount = 0, ...items) {
        if (Number.isFinite(start) === false) {
            start = 0;
        }
        if (start < 0) {
            start = (start % this.length) + this.length;
        }
        if (Number.isFinite(deleteCount) === false || deleteCount < 0) {
            deleteCount = 0;
        }
        /// deleteCount > 0 || items.length > 0
        if (deleteCount + items.length > 0) {
            /// 已经影响到数组后面的所有元素
            if (deleteCount !== items.length) {
                this.emitChanged(start, Math.max(deleteCount, items.length, this.length - start));
            }
            /// 只影响到被删除的几个元素
            else {
                this.emitChanged(start, items.length);
            }
        }
        return super.splice(start, deleteCount, ...items);
    }
    sort(compareFn) {
        this.emitChanged(0, this.length);
        return super.sort(compareFn);
    }
}
