export const sample = (notifier) => {
    const currentSample = [];
    return new TransformStream({
        start: async (controller) => {
            do {
                await notifier.next();
                if (currentSample.length !== 0) {
                    controller.enqueue(currentSample.shift());
                }
            } while (true);
        },
        transform: (chunk) => {
            currentSample[0] = chunk;
        },
    });
};
