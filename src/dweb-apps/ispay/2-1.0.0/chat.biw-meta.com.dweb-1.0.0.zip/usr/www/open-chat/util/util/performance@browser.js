export default () => performance;
