var TimeHelper_1;
import { __decorate, __metadata, __param } from "../../tslib/modules/index.js";
import { Inject, Injectable } from "../dep_inject/index.js";
import { UtilExceptionGenerator } from "../exception/index.js";
import { sleep } from "../extends-promise/index.js";
import { PlatformHelper } from "./platformHelper.js";
const { info } = UtilExceptionGenerator("util", "TimeHelper");
export const TIME_HELPER_ARGS = {
    TIME_SPEED: "TIME_SPEED",
};
/**区块链时间模块 */
let TimeHelper = TimeHelper_1 = class TimeHelper {
    /**
     * @param platformHelper
     * @param TIME_SPEED 时间速度
     */
    constructor(platformHelper, TIME_SPEED = 1) {
        Object.defineProperty(this, "platformHelper", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: platformHelper
        });
        Object.defineProperty(this, "TIME_SPEED", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: TIME_SPEED
        });
        Object.defineProperty(this, "clearTimeout", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: clearTimeout
        });
        Object.defineProperty(this, "clearInterval", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: clearInterval
        });
        /**系统启动时间 */
        Object.defineProperty(this, "SYSTEM_START_TIME", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /**时间偏移量，毫秒 */
        Object.defineProperty(this, "time_offset_ms", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        this.SYSTEM_START_TIME = this.platformHelper.performance.timeOrigin;
        if (!(typeof TIME_SPEED === "number" && TIME_SPEED > 0)) {
            this.TIME_SPEED = 1;
        }
        info("TIME SPPED × %d.", this.TIME_SPEED);
    }
    /**定时器 */
    setTimeout(fun, ms) {
        return setTimeout(fun, ms / this.TIME_SPEED);
    }
    setInterval(fun, ms) {
        return setInterval(fun, ms / this.TIME_SPEED);
    }
    sleep(ms, onresolve) {
        return sleep(ms / this.TIME_SPEED, onresolve);
    }
    get BLOCKCHAIN_SYSTEM_START_TIME() {
        return this.SYSTEM_START_TIME + this.time_offset_ms;
    }
    /**获取当前区块链时间
     * PS: performance.now()+timeOrigin不能用来替代Date.now()
     * 但是Date.now又有可能被操作系统影响
     * 至少我们不希望时间回退，这会带来很多问题，但是允许时间前进到未来
     * 所以这里基于二者，来将时间强行卡在未来
     * 可以通过修改time_offset_ms来进行调整
     */
    now(forceRounding = false) {
        const pnow = this.platformHelper.performance.now() +
            this.SYSTEM_START_TIME +
            this.time_offset_ms;
        const dnow = Date.now();
        const diff = dnow - pnow;
        if (diff > 1) {
            this.time_offset_ms += diff;
        }
        const result = this.SYSTEM_START_TIME +
            (this.platformHelper.performance.now() + this.time_offset_ms) *
                this.TIME_SPEED;
        if (!forceRounding) {
            return result;
        }
        return parseInt(result.toString());
    }
    /**
     * 穿梭时间
     * @param diffMs 正数，往未来。负数，往过去
     */
    changeNowByDiff(diffMs) {
        const { NOW_DIFF_SYMBOL } = TimeHelper_1;
        const oldDiff = Reflect.get(Date, NOW_DIFF_SYMBOL);
        // 调整timeHelper.now的返回
        this.time_offset_ms += diffMs - (oldDiff || 0);
        /// 重写Date.now
        if (diffMs !== 0) {
            if (oldDiff === undefined) {
                const sourceNow = Date.now;
                const customNow = (Date.now = () => sourceNow() + Reflect.get(Date, NOW_DIFF_SYMBOL));
                Reflect.set(customNow, "source", sourceNow);
            }
            Reflect.set(Date, NOW_DIFF_SYMBOL, diffMs);
        }
        else {
            /// 恢复Date.now
            const customNow = Date.now;
            const sourceNow = Reflect.get(customNow, "source");
            if (sourceNow !== undefined) {
                Date.now = sourceNow;
                Reflect.deleteProperty(Date, NOW_DIFF_SYMBOL);
            }
        }
    }
    changeNowByTime(time) {
        const { NOW_DIFF_SYMBOL } = TimeHelper_1;
        const oldDiff = Reflect.get(Date, NOW_DIFF_SYMBOL) || 0;
        const newDiff = time - (Date.now() - oldDiff);
        return this.changeNowByDiff(newDiff);
    }
    //#endregion
    //#region 通用的格式化时间
    formatDate(date, format = "yyyy-MM-dd hh:mm:ss") {
        const moon = date.getMonth() + 1;
        const rule = {
            "M+": moon,
            "d+": date.getDate(),
            "h+": date.getHours(),
            "m+": date.getMinutes(),
            "s+": date.getSeconds(),
            "q+": Math.floor((date.getMonth() + 3) / 3),
            E: ["冬", "春", "夏", "秋"][Math.floor((moon % 12) / 3)],
            W: ["日", "一", "二", "三", "四", "五", "六"][date.getDay()],
            S: date.getMilliseconds(), // 毫秒
        };
        let formatRes = format;
        if (/(y+)/.test(formatRes))
            formatRes = formatRes.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length)); // 年
        for (const analytical in rule) {
            if (new RegExp("(" + analytical + ")").test(formatRes)) {
                formatRes = formatRes.replace(RegExp.$1, RegExp.$1.length === 1
                    ? "" + rule[analytical]
                    : ("00" + rule[analytical]).substr(("" + rule[analytical]).length));
            }
        }
        return formatRes;
    }
    formatDateTime(time = this.now()) {
        return this.formatDate(new Date(time));
    }
    formatYMDHMS(year, month, day, h, m, s) {
        const ps = (num, maxLength = 2) => String(num).padStart(maxLength, "0");
        return `${ps(year, 4)}-${ps(month)}-${ps(day)} ${ps(h)}:${ps(m)}:${ps(s)}`;
    }
};
Object.defineProperty(TimeHelper, "NOW_DIFF_SYMBOL", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: Symbol("now-diff-ms")
});
TimeHelper = TimeHelper_1 = __decorate([
    Injectable(),
    __param(1, Inject(TIME_HELPER_ARGS.TIME_SPEED, { optional: true })),
    __metadata("design:paramtypes", [PlatformHelper, Object])
], TimeHelper);
export { TimeHelper };
