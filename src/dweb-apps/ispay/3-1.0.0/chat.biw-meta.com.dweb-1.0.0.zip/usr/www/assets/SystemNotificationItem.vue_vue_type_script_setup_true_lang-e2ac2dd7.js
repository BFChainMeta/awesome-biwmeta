import {
  aW as ne,
  n as $,
  d as M,
  ab as re,
  aX as Pe,
  a7 as ce,
  r as I,
  j as C,
  f as w,
  $ as Te,
  a9 as H,
  c as le,
  a8 as Ne,
  w as Z,
  l as ie,
  aY as de,
  aU as Fe,
  aZ as Ue,
  ad as Ye,
  a_ as Ve,
  ag as Qe,
  i as Oe,
  ao as m,
  a$ as Ke,
  b0 as ue,
  b1 as Xe,
  B as d,
  D as A,
  E as n,
  M as N,
  z as se,
  g as Ge,
  F as u,
  U as Q,
  G as k,
  as as ge,
  at as me,
  y as P,
  a0 as Ae,
  _ as te,
  v as q,
  b2 as V,
  H as S,
  b3 as Je,
  Q as D,
  b4 as pe,
  b5 as Le,
  aT as fe,
  b6 as ve,
  N as G,
  I as O,
  aV as he,
  al as J,
  b7 as ze,
  J as X,
  aI as Ze,
  L as ke,
  S as T,
  a1 as ee,
  a2 as Ce,
  b8 as be,
  a as qe,
  aw as He,
  R as je,
  T as We,
  b9 as z,
  ah as ae,
  aK as $e,
  x as Me,
  ax as es,
  a5 as ss,
  aG as Se,
  aP as ts,
  an as ye,
  V as j,
  ba as as,
  ar as ns,
  bb as os,
  bc as rs,
  aO as cs,
  bd as ls,
} from "./index-0085351d.js";
import { u as is } from "./useCurrentMemberRole-3ba2452e.js";
import { p as _e } from "./chating_message_video_play-2b29053c.js";
import { s as xe } from "./function-call-6d0a9231.js";
import { u as ds } from "./useSendMessage-7be453b1.js";
import { P as us } from "./index-5417b32f.js";
import { C as gs } from "./data-7f4000cb.js";
const we = {
  name: ne,
  disabled: Boolean,
  iconSize: $,
  modelValue: ne,
  checkedColor: String,
  labelPosition: String,
  labelDisabled: Boolean,
};
var ms = M({
  props: re({}, we, {
    bem: Pe(Function),
    role: String,
    shape: String,
    parent: Object,
    checked: Boolean,
    bindGroup: ce,
    indeterminate: { type: Boolean, default: null },
  }),
  emits: ["click", "toggle"],
  setup(s, { emit: e, slots: r }) {
    const a = I(),
      c = (l) => {
        if (s.parent && s.bindGroup) return s.parent.props[l];
      },
      t = C(() => {
        if (s.parent && s.bindGroup) {
          const l = c("disabled") || s.disabled;
          if (s.role === "checkbox") {
            const h = c("modelValue").length,
              y = c("max"),
              x = y && h >= +y;
            return l || (x && !s.checked);
          }
          return l;
        }
        return s.disabled;
      }),
      i = C(() => c("direction")),
      o = C(() => {
        const l = s.checkedColor || c("checkedColor");
        if (l && s.checked && !t.value)
          return { borderColor: l, backgroundColor: l };
      }),
      g = C(() => s.shape || c("shape") || "round"),
      v = (l) => {
        const { target: h } = l,
          y = a.value,
          x = y === h || (y == null ? void 0 : y.contains(h));
        !t.value && (x || !s.labelDisabled) && e("toggle"), e("click", l);
      },
      p = () => {
        var l, h;
        const { bem: y, checked: x, indeterminate: R } = s,
          b = s.iconSize || c("iconSize");
        return w(
          "div",
          {
            ref: a,
            class: y("icon", [
              g.value,
              { disabled: t.value, checked: x, indeterminate: R },
            ]),
            style:
              g.value !== "dot"
                ? { fontSize: H(b) }
                : {
                    width: H(b),
                    height: H(b),
                    borderColor: (l = o.value) == null ? void 0 : l.borderColor,
                  },
          },
          [
            r.icon
              ? r.icon({ checked: x, disabled: t.value })
              : g.value !== "dot"
              ? w(Te, { name: R ? "minus" : "success", style: o.value }, null)
              : w(
                  "div",
                  {
                    class: y("icon--dot__icon"),
                    style: {
                      backgroundColor:
                        (h = o.value) == null ? void 0 : h.backgroundColor,
                    },
                  },
                  null
                ),
          ]
        );
      },
      f = () => {
        const { checked: l } = s;
        if (r.default)
          return w(
            "span",
            { class: s.bem("label", [s.labelPosition, { disabled: t.value }]) },
            [r.default({ checked: l, disabled: t.value })]
          );
      };
    return () => {
      const l = s.labelPosition === "left" ? [f(), p()] : [p(), f()];
      return w(
        "div",
        {
          role: s.role,
          class: s.bem([
            { disabled: t.value, "label-disabled": s.labelDisabled },
            i.value,
          ]),
          tabindex: t.value ? void 0 : 0,
          "aria-checked": s.checked,
          onClick: v,
        },
        [l]
      );
    };
  },
});
const [Ee, As] = le("checkbox-group"),
  ps = {
    max: $,
    shape: Fe("round"),
    disabled: Boolean,
    iconSize: $,
    direction: String,
    modelValue: Ue(),
    checkedColor: String,
  },
  Be = Symbol(Ee);
M({
  name: Ee,
  props: ps,
  emits: ["change", "update:modelValue"],
  setup(s, { emit: e, slots: r }) {
    const { children: a, linkChildren: c } = Ne(Be),
      t = (o) => e("update:modelValue", o),
      i = (o = {}) => {
        typeof o == "boolean" && (o = { checked: o });
        const { checked: g, skipDisabled: v } = o,
          f = a
            .filter((l) =>
              l.props.bindGroup
                ? l.props.disabled && v
                  ? l.checked.value
                  : g ?? !l.checked.value
                : !1
            )
            .map((l) => l.name);
        t(f);
      };
    return (
      Z(
        () => s.modelValue,
        (o) => e("change", o)
      ),
      ie({ toggleAll: i }),
      de(() => s.modelValue),
      c({ props: s, updateValue: t }),
      () => {
        var o;
        return w("div", { class: As([s.direction]) }, [
          (o = r.default) == null ? void 0 : o.call(r),
        ]);
      }
    );
  },
});
const [fs, vs] = le("checkbox"),
  hs = re({}, we, {
    shape: String,
    bindGroup: ce,
    indeterminate: { type: Boolean, default: null },
  });
var ks = M({
  name: fs,
  props: hs,
  emits: ["change", "update:modelValue"],
  setup(s, { emit: e, slots: r }) {
    const { parent: a } = Ye(Be),
      c = (o) => {
        const { name: g } = s,
          { max: v, modelValue: p } = a.props,
          f = p.slice();
        if (o)
          !(v && f.length >= +v) &&
            !f.includes(g) &&
            (f.push(g), s.bindGroup && a.updateValue(f));
        else {
          const l = f.indexOf(g);
          l !== -1 && (f.splice(l, 1), s.bindGroup && a.updateValue(f));
        }
      },
      t = C(() =>
        a && s.bindGroup
          ? a.props.modelValue.indexOf(s.name) !== -1
          : !!s.modelValue
      ),
      i = (o = !t.value) => {
        a && s.bindGroup ? c(o) : e("update:modelValue", o),
          s.indeterminate !== null && e("change", o);
      };
    return (
      Z(
        () => s.modelValue,
        (o) => {
          s.indeterminate === null && e("change", o);
        }
      ),
      ie({ toggle: i, props: s, checked: t }),
      de(() => s.modelValue),
      () =>
        w(
          ms,
          Qe(
            {
              bem: vs,
              role: "checkbox",
              parent: a,
              checked: t.value,
              onToggle: i,
            },
            s
          ),
          Ve(r, ["default", "icon"])
        )
    );
  },
});
const Cs = Oe(ks),
  bs =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAiJJREFUaEPtmM9V20AQxn/DIdeYCnAqCFSAqSCUkFQAnGSfgBOIC+4A0wGpICmBEtIBzi1w0PDGG8cy/jeKJKN9T3vV7Oz3zTczuyMh8iWR46cl8N4Ktgq0CpSMQJtCJQNYevt2FbjVDn/oMJBfpZH/dbAdAgb8hRPgYnKuMqIv36ogUT+BK+0h3CF05wBnHDGQn2VJ1EcgRP0OOF4B8pJEgiIlVj0EUj0FzoHOGmwNJHCj+2TcIvQcQW0QgbdF6kAPzAhcaXdSJ8o9Axn5tgcrfwptzuki55ptnkCPHX4AYzIOirRZP4FUrWMcFkXproFrfUT4DNyTyFfvOT4CIfpPXqdOu/kasHYbVIAP7HImY48fH4G8c49Xn81iEadqN/QecEYiQ4+bphGwe+Ec5Tt9WXV/zPFqFoGZ0mMS2Y1PAUOcqk6AJ+IKrsuIbdVAnkDGJ087bQl48nSFzfKnRNQpNE1V5Td9WfcQ/BeTZqVQqpG30dousuifEqG9RfyYMwKmwjMjhC8lOk9+6+Jz2opX2ff0/6kjXxFvQhxSbDpGbrKefp8RCPsfyBjVN9B4YNlIqdgr0jM3NGikfEvOhnrlAuGje6DxBGiJTTUptOzwMOcO19RMgxXIE0rV3vWWVjaozFbjf2zlwYYOZillvxdtFZp712VXfSm07NRof+7+Z4F6tm1XAQ+igjYtgYIBq9y8VaDykBZ02CpQMGCVm0evwCvcHtoxJ2+HtwAAAABJRU5ErkJggg==";
const Ms = ["innerHTML"],
  Ss = M({
    __name: "TextMessageRenderer",
    props: { message: null },
    setup(s) {
      const e = s,
        r = C(() => {
          let a = "";
          return (
            e.message.contentType === m.QuoteMessage &&
              (a = e.message.quoteElem.text),
            e.message.contentType === m.AtTextMessage &&
              (a = Ke(e.message.atTextElem)),
            e.message.contentType === m.TextMessage &&
              (a = e.message.textElem.content),
            ue(Xe(a))
          );
        });
      return (a, c) => (
        d(),
        A(
          "div",
          { class: "text_content need_bg", innerHTML: n(r) },
          null,
          8,
          Ms
        )
      );
    },
  });
const ys = N(Ss, [["__scopeId", "data-v-3fecf2b7"]]),
  _s = (s) => (ge("data-v-0dc34815"), (s = s()), me(), s),
  xs = { class: "cricleplay" },
  ws = _s(() => u("div", { class: "small" }, null, -1)),
  Es = { class: "text-sm" },
  Bs = M({
    __name: "AudioMessageRenderer",
    props: { message: null, isSelfMsg: { type: Boolean } },
    setup(s) {
      const e = s,
        r = I(!1),
        a = I(!1),
        c = I(),
        t = () => {
          var i, o;
          r.value
            ? ((i = c.value) == null || i.pause(), (r.value = !1))
            : (a.value || (c.value.src = e.message.soundElem.sourceUrl),
              (o = c.value) == null || o.play(),
              (a.value = !1));
        };
      return (
        se(() => {
          Ge(() => {
            c.value &&
              ((c.value.onplay = () => {
                r.value = !0;
              }),
              (c.value.onpause = () => {
                (a.value = !0), (r.value = !1);
              }),
              (c.value.onended = () => {
                (a.value = !1), (r.value = !1);
              }));
          });
        }),
        (i, o) => (
          d(),
          A(
            "div",
            {
              onClick: t,
              class: Q([
                "audio_message_container need_bg",
                { audio_message_container_self: s.isSelfMsg },
              ]),
            },
            [
              u("div", xs, [
                ws,
                u(
                  "div",
                  { class: Q(["middle", { stopanimate: !r.value }]) },
                  null,
                  2
                ),
                u(
                  "div",
                  { class: Q(["large", { stopanimate: !r.value }]) },
                  null,
                  2
                ),
              ]),
              u("span", Es, k(s.message.soundElem.duration) + "''", 1),
              u("audio", { ref_key: "audioRef", ref: c }, null, 512),
            ],
            2
          )
        )
      );
    },
  });
const Rs = N(Bs, [["__scopeId", "data-v-0dc34815"]]),
  Is = { class: "card_info" },
  Ds = { class: "ml-3 truncate" },
  Ps = { class: "pl-5 text-[#999]" },
  Ts = { class: "text-xs" },
  Ns = M({
    __name: "CardMessageRenderer",
    props: { message: null, disabled: { type: Boolean } },
    setup(s) {
      const e = s;
      P();
      const r = Ae(),
        a = C(() => {
          let t = {};
          try {
            t = e.message.cardElem;
          } catch {}
          return t;
        }),
        c = () => {
          e.disabled || r.getUserCardData(a.value.userID);
        };
      return (t, i) => (
        d(),
        A(
          "div",
          {
            onClick: c,
            class:
              "card_message_container w-[220px] border border-[#E8EAEF] !bg-white",
          },
          [
            u("div", Is, [
              w(
                te,
                { src: n(a).faceURL, desc: n(a).nickname, size: 44 },
                null,
                8,
                ["src", "desc"]
              ),
              u("span", Ds, k(n(a).nickname), 1),
            ]),
            u("div", Ps, [u("span", Ts, k(t.$t("contactCard")), 1)]),
          ]
        )
      );
    },
  });
const Fs = N(Ns, [["__scopeId", "data-v-ac391bad"]]),
  Us =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAAAXNSR0IArs4c6QAABGdJREFUWEftl19oW3UUx7/nl9z0NolQuhXT3jz0YeAss2uTDnxYYUKFihUqTJywgYOBPih2DMGHPQjigzDYZH0QpjhxMKTKBlNaGbKJFQclN90fZgVFxNx0c3voQ26zJvf+jvxuki5NkyZbk7GH3afkd38558P3nN/3d0J4zB56zHjwBKheRTZUqK2n/xk/+ScBDBBoQUqeWF40E/WCbuZ9TSAPRmiXCYisJmDO5NkZWklf+2MzSTf6bVWgchjJ+JZy2XcR0E8R0RgYC5lcdhfu3My0AmodUCXMspV4A4CDrr5wONA+B8J2gM9nUuarjwQoFI1NE2hUKbMKU8wc6IlvDxDPgSgsmY8uW+bHzYZap1AoGs8SI5OxEt2eMhVP0IiNCaILzHDyTn4wd/vajWZCrQcy4v8SuCNjmU/VShSOxk8BOMSQH9ip5CctBQpHY+cAGnclhrPpxGyVZP6QEb9IhD0MTNipxKctBQoZsTeJ6EtmPm1b5sGKZP6gET8rCHuZkbJt9zkszS+1FAjo1UPRLX+DsdXJ8bMrd8w/SwmDRnxKwYA54zp4MXvbvNJMGBWrqg+FjPgRIhwrnrTX1MZg9+CQ8Ik59ZldPmAvmmeaDVMTCIA/HI39DtA2ye7YsjX/g7dmxK8rH2LmM7ZlHniUQAj1DI6QEBe9XmEMIp24q0cG9vj9vksKxHXl3uxi8rtmQ214uQajsZMC9A5LnrHT5kte6YprAC/lV7CrvMeaAVdnHvIafI6AHfedWa11/kKgIe9eYwwr9ZoBs1EPrcZv64pt0wL0GwhbIXlfJm1+0270RwVpCjQC5tmMLV9p1vFvaGLUewZHfCSmQXCkdEey6flf1b2mCVwqQGHBkXL03mLynzVKdQx0BEPidQKFHc5/38jY0hCQSlIyTM+DWI5WgbrLkvfbi+aPan9xuJshol7PKhgOgz+sdyE3DORBRePvEXCiHCrU1RehgH4ORM976jA+cyl/WkA776kn8TkEp5jpKBH8nrflsgdrzVMPBFRQqmCaCsoBj9+zkj8V3L3zIzBNqKSlsjHzCdsyD6vvnmX4fFOqFxm44eQwvvJf4q/Kw/DAQOVKeWVg+fZyOvmFWm/v2blbCN9xdQIZfMxOme+XJ9QjA70+v++COrXKNqSLkcoZ/aGAPD8yYm8RaFIpUlRCJVfzk7/d6I9krWupqlbQ1RcOavrXQtA4GLMZKzFcvu+hgTylumOjJDClJkh1/F1y92VTV616nhR4un9HQNOuM3DLTnmD4OqzKSAVRQXXNO1sqQzMcsK25r+qCeXN5vo0iHYzeMZOFW6A0rNpIC+QV4a240KIQ8XAlwtgyatrwNbA4FZe4oVcOrHQfKBixKCxc4zgO1nyHvXvhJknbSv5M7r69PvKVIdRYZqj0BoZevWg0XlEgCa866ZoisrlCdBV31RTprklq9owvXqwe8t+4eOXmTFAhA4GruQlHa4sU8tKVu90NfK+BSVrJG3tPU+A6un3P3Xa9zRfxexgAAAAAElFTkSuQmCC",
  Ys =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAAAXNSR0IArs4c6QAAAmVJREFUWEftlz9oE1Ecx7+/y9GkzQ0drNQkm05OvQsOgoLuggUdFCJYFw0qDi4dBOsgdXDr4FQSUSFOOrrFwTXX4CAdOkS4i4FCmyEvyYXkfuZS8k9rr0ljkuFue7zf+92H7/u93/s+wpR9NGU88IDcdsRTaDiF5pfmFQVLbouPmi9ZtW3s/igMmqN/yxbOK8GZwAZAMSLIgyY7JP4zW5W4GACsF0hWwloaRJdGANJNwdguicZFFLPF4+TtAAUjWoxA75hRZ9iPy+Z+EshVj5PkkBh5dlFd9vkoASLFZn5WNvWX7Tj/6ehZeca+CZbqqFU+9CrYAVIi2ieAlpk5JUz99pAgfcuCIXWdJGmVGVlhZlRnci6s3ZeA1w6oM2agULf4srWr7zjjHqBoGsCVZshaydBfjAQorN0logQz5wTThSBxgoiutUAYBgEBEE4xc1KY+soYgex9kGQRsHgAwykh7LiiSE+amqw1hfhaMjJX/zvQXEi9R0SbRO2N4GLD5nglv5Vyfq5EtOdjBQpG1FWCtN7afuZv9YZ9p1rI5trlMDEgZraEqTtFXO+tzckBAVVhZGb/PCgeULuG2FPoH120qxBbwpiiou4ce5tj1V9bPyd27J3GKEm02b2hnMaIB5W8/nEyjbFzl/11dbwXtWpc8QeejrdTn+xyHY/9UELaQxBeudqPfoPGj8rm3tsTGbQz6nWfRMmWQbN5rZzvWhr/gnZO9vONIw0aAFkJR9MgTIeFbR3FA5P/BqBbozD5DP4Cq7oyrMnvtrcRPIMaZXunsvfdGNR5ei9XN8U8hTyF3BRwm/8NVLPENMG0Xt4AAAAASUVORK5CYII=",
  Vs = { class: "need_bg flex flex-row items-center justify-center" },
  Qs = ["src"],
  Os = { class: "ml-2" },
  Ks = { key: 0, class: "ml-1" },
  Xs = M({
    __name: "RtcMessageRenderer",
    props: {
      message: null,
      disabled: { type: Boolean },
      isSelfMsg: { type: Boolean },
    },
    setup(s) {
      const e = s,
        { t: r } = q(),
        a = JSON.parse(e.message.customElem.data).data,
        c = () => {
          switch (a.status) {
            case V.Canceled:
              return r("rtc.canceled");
            case V.Refused:
              return r("rtc.refused");
            case V.Timeout:
              return r("rtc.timeout");
            case V.Successed:
              return r("rtc.callDuration");
            case V.HandleByOtherDevice:
              return r("rtc.handleByOtherDevice");
            default:
              return "";
          }
        },
        t = () => (a.mediaType === "video" ? Ys : Us);
      return (i, o) => (
        d(),
        A("div", Vs, [
          u(
            "img",
            { class: "h-[18px] w-[18px]", src: t(), alt: "icon" },
            null,
            8,
            Qs
          ),
          u("span", Os, k(c()), 1),
          n(a).status === n(V).Successed
            ? (d(), A("span", Ks, k(n(a).duration), 1))
            : S("", !0),
        ])
      );
    },
  }),
  Gs = {},
  Js = { class: "need_bg" };
function Ls(s, e) {
  return d(), A("div", Js, k(s.$t("messageDescription.notSupMessage")), 1);
}
const Re = N(Gs, [["render", Ls]]),
  zs = M({
    __name: "CustomMessageSwitcherer",
    props: {
      message: null,
      disabled: { type: Boolean },
      isSelfMsg: { type: Boolean },
    },
    setup(s) {
      const r = JSON.parse(s.message.customElem.data),
        a = C(() => {
          switch (r.customType) {
            case Je.Call:
              return Xs;
            default:
              return Re;
          }
        });
      return (c, t) => (
        d(),
        D(
          pe(n(a)),
          {
            message: s.message,
            "is-self-msg": s.isSelfMsg,
            disabled: s.disabled,
          },
          null,
          8,
          ["message", "is-self-msg", "disabled"]
        )
      );
    },
  }),
  Zs = {
    class:
      "flex h-[64px] w-[220px] items-center justify-center rounded-md border border-[#E8EAEF] !bg-white",
  },
  qs = { class: "truncate" },
  Hs = { class: "text-xs text-[#999]" },
  js = ["src"],
  Ws = M({
    __name: "FileMessageRenderer",
    props: { message: null, disabled: { type: Boolean } },
    setup(s) {
      const e = s,
        r = Le(e.message.fileElem.fileSize),
        a = () => {
          e.disabled ||
            ve(e.message.fileElem.sourceUrl, e.message.fileElem.fileName);
        };
      return (c, t) => (
        d(),
        A("div", Zs, [
          u(
            "div",
            { onClick: a, class: "mr-3 flex max-w-[140px] flex-1 flex-col" },
            [
              u("text", qs, k(s.message.fileElem.fileName), 1),
              u("text", Hs, k(n(r)), 1),
            ]
          ),
          u(
            "img",
            {
              class: "h-[44px] w-[38px]",
              src: n(fe)(s.message.fileElem.fileName),
              alt: "",
            },
            null,
            8,
            js
          ),
        ])
      );
    },
  }),
  $s = { class: "flex items-center" },
  et = ["src"],
  st = { class: "text-primary" },
  tt = { class: "mt-2 break-all text-sm" },
  at = M({
    __name: "GroupAnnounceRenderer",
    props: { announceContent: null },
    setup(s) {
      const e = P(),
        { isNomal: r } = is(),
        a = G(),
        c = () => {
          O.resetConversationGroupAtType(
            a.storeCurrentConversation.conversationID
          ),
            e.push({
              path: "groupAnnouncement",
              query: { isNomal: r.value + "" },
            });
        };
      return (t, i) => (
        d(),
        A(
          "div",
          {
            class: "need_bg w-[220px] border border-[#E8EAEF] !bg-white",
            onClick: c,
          },
          [
            u("div", $s, [
              u("img", { class: "mr-2 h-6 w-6", src: n(bs) }, null, 8, et),
              u("span", st, k(t.$t("popover.groupAnnouncement")), 1),
            ]),
            u("div", tt, k(s.announceContent), 1),
          ]
        )
      );
    },
  }),
  nt = { class: "px-3 py-3 text-[#333]" },
  ot = { class: "truncate" },
  rt = { class: "truncate" },
  ct = M({
    __name: "LocationMessageRenderer",
    props: { message: null, disabled: { type: Boolean } },
    setup(s) {
      const e = s,
        r = P(),
        a = C(() => {
          let t = {};
          try {
            t = JSON.parse(e.message.locationElem.description);
          } catch {}
          return t;
        }),
        c = () => {
          e.disabled ||
            r.push({
              path: "previewLocation",
              state: { message: JSON.stringify(e.message) },
            });
        };
      return (t, i) => {
        const o = he;
        return (
          d(),
          A(
            "div",
            {
              onClick: c,
              class:
                "w-[222px] rounded-md border border-solid border-[#e6e6e6] bg-[#fff]",
            },
            [
              u("div", nt, [
                u("div", ot, k(n(a).name), 1),
                u("div", rt, k(n(a).addr), 1),
              ]),
              w(
                o,
                { width: "222", height: "111", fit: "contain", src: n(a).url },
                null,
                8,
                ["src"]
              ),
            ]
          )
        );
      };
    },
  }),
  lt = ["src"],
  it = { key: 1, class: "video_duration" },
  dt = M({
    __name: "MediaMessageRenderer",
    props: { message: null, disabled: { type: Boolean } },
    setup(s) {
      const e = s,
        r = J(),
        a = P(),
        c = I(!1),
        t = e.message.contentType === m.VideoMessage,
        i = t
          ? e.message.videoElem.snapshotUrl
          : e.message.pictureElem.snapshotPicture.url,
        o = t ? ze(e.message.videoElem.duration) : 0,
        g = () => {
          if (!e.disabled)
            if (t)
              a.push({
                path: "/previewVideo",
                query: {
                  url: e.message.videoElem.videoUrl,
                  poster: e.message.videoElem.snapshotUrl,
                },
              });
            else {
              const v = r.storePreviewImgList.findIndex(
                (p) => p === e.message.pictureElem.sourcePicture.url
              );
              xe({
                images: r.storePreviewImgList,
                startPosition: v > -1 ? v : 0,
                loop: !1,
              });
            }
        };
      return (v, p) => {
        const f = ke,
          l = he;
        return (
          d(),
          A("div", { onClick: g, class: "media_message_container" }, [
            w(
              l,
              {
                class: Q([
                  "need_preload_message max-w-[32vw]",
                  { "h-8 w-8": c.value },
                ]),
                fit: "contain",
                radius: "6",
                src: n(i),
                onError: p[0] || (p[0] = (h) => (c.value = !0)),
              },
              {
                loading: X(() => [w(f, { type: "spinner", size: "20" })]),
                error: X(() => [Ze(k(v.$t("failLoad")), 1)]),
                _: 1,
              },
              8,
              ["class", "src"]
            ),
            t
              ? (d(),
                A(
                  "img",
                  { key: 0, class: "play_icon", src: n(_e), alt: "" },
                  null,
                  8,
                  lt
                ))
              : S("", !0),
            t ? (d(), A("text", it, k(n(o)), 1)) : S("", !0),
          ])
        );
      };
    },
  });
const ut = N(dt, [["__scopeId", "data-v-33933715"]]),
  gt = { class: "border-b border-solid border-b-[#E8EAEF] px-2.5 py-2" },
  mt = { class: "break-words" },
  At = { class: "flex flex-col px-2.5 pt-0.5 pb-1.5 text-xs text-sub-text" },
  pt = M({
    __name: "MergeMessageRenderer",
    props: { message: null, disabled: { type: Boolean } },
    setup(s) {
      const e = s,
        r = P(),
        a = C(() =>
          e.message.mergeElem.multiMessage[0].sessionType === T.Single
            ? e.message.senderNickname + e.message.mergeElem.title
            : e.message.mergeElem.title
        ),
        c = () => {
          e.disabled ||
            !e.message.mergeElem.multiMessage ||
            r.push({
              path: "previewMergeMessage/" + Date.now(),
              state: { mergeData: JSON.stringify(e.message.mergeElem) },
            });
        };
      return (t, i) => (
        d(),
        A(
          "div",
          {
            onClick: c,
            class: "need_bg w-[220px] border border-[#E8EAEF] !bg-white !p-0",
          },
          [
            u("div", gt, [u("span", mt, k(n(a)), 1)]),
            u("div", At, [
              (d(!0),
              A(
                ee,
                null,
                Ce(
                  s.message.mergeElem.abstractList,
                  (o, g) => (
                    d(),
                    A(
                      ee,
                      null,
                      [
                        g < 4
                          ? (d(),
                            A(
                              "text",
                              { key: g, class: "mt-1 break-all line-clamp-3" },
                              k(o),
                              1
                            ))
                          : S("", !0),
                      ],
                      64
                    )
                  )
                ),
                256
              )),
            ]),
          ]
        )
      );
    },
  }),
  W = G(),
  ft = J();
function vt({
  messageContainerRef: s,
  isSelfMsg: e,
  isRead: r,
  isPreView: a,
  isGroupAnnounce: c,
  clientMsgID: t,
  message: i,
}) {
  const o = () => {
      W.storeCurrentConversation.unreadCount > 0 &&
        O.markConversationMessageAsRead(
          W.storeCurrentConversation.conversationID
        ),
        i.groupID &&
          O.sendGroupMessageReadReceipt({
            conversationID: W.storeCurrentConversation.conversationID ?? "",
            clientMsgIDList: [t],
          }),
        ft.updateOneMessage({ clientMsgID: t, isRead: !0, isAppend: !1 });
    },
    g = () => {
      if (e.value || r || a || c) return;
      const { stop: v } = be(s, ([{ isIntersecting: p }], f) => {
        p && (o(), v());
      });
    };
  se(() => {
    g();
  });
}
const ht = M({
    __name: "MessageReadState",
    props: { message: null, disabled: { type: Boolean } },
    setup(s) {
      const e = s,
        r = P(),
        { t: a } = q(),
        c = C(() => {
          var o;
          return e.message.sessionType === T.Single
            ? 0
            : ((o = e.message.attachedInfoElem) == null
                ? void 0
                : o.groupHasReadInfo.unreadCount) ?? 0;
        }),
        t = C(() => {
          if (e.message.sessionType === T.Single)
            return e.message.isRead ? a("readed") : a("unread");
          if (e.message.sessionType !== T.Notification)
            return c.value < 1
              ? a("allReaded")
              : a("someUnread", { count: c.value });
        }),
        i = () => {
          e.disabled ||
            e.message.sessionType === T.Single ||
            r.push({
              path: "groupMessageRead",
              state: {
                choosedMessage: JSON.stringify(e.message),
                clientMsgID: e.message.clientMsgID,
              },
            });
        };
      return (o, g) => (
        d(),
        A(
          "div",
          {
            class: Q([
              "mt-0.5 text-[12px] text-[#999]",
              { "!text-[#006AFF]": n(c) !== 0 },
            ]),
            onClick: i,
          },
          k(n(t)),
          3
        )
      );
    },
  }),
  kt =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAA6NJREFUWEe1l39oVWUYxz/Pubv+CIVYGTl3z4QGlUqYm7uzUd6kAiH7IcWURaSJlaDBiFEa27SVOKpBFqKlI2gVIhKUECUkpm43p5ZU/mNid3etaf1TIzfdPU+c+97ptnvbznub71+Hc57P9/mel/d53+cVAg6dPXsKt6YeQp37EJ0PUorqLWlc5ALoWVS+R7zD/B76Ss6f7w8iLeMF6d2RIibRhDhPANPHi898/xv19jHobJITv/aMxfynAV1UPJWUU4dQh8gNAROPDFP9B6WZkNcs7clLuTRyGtDyyDxCThvCXXklzoL0FJev1MjJnjOjP2UZ0LKiOwgXHASZNTHJMyqqSQY1Jie6fhmuO8KAlhW5hMPfAu6EJr8mlkAHqyTenRx6ddWAQoioewyRikDJ398P8xaY0NOd8Jy/RgMM1aPEE4sFUukCGkK0wm3AkcYAEiZkexuUV5nn9m+gdlVgFE8b5bvE5qsGdEFxKZNCPwKTA6s0fwD3PmDCv/4c6tcHRoEBUjpHjifOpWdAo24rIs/YKLDlHXjwEYN89jFs22iFo94eiXc9KzpnxjSmT+21rvWN22BZtUnatgvefcPOANrHX5dmikYjKxDnE0saahvhycyk7XoLWrdbS6DeSt/AbsRZbU2/UAdPrzNYy2bY22otgepO0Uo3DgFLb3iKVRtgba150/QSHNiXhwE6RKPuRURutqZXroENrxrslefh0JfWEkCvaGWJf0hMsaYfr4G61w22vgY6j1pLAP35G1i6HOrfNklXPwpnfsjbwAVghjUdWwpbdxisegkkzllLoNqT/yKsXAwtH5qkDy+EPy/mYcAswp2IrLWm51fAjr0Gu/9O6M/Zb4wtmy7DhZFqQs6n1gZuLISqJQbLpwR9LuWtyH8rtnY8Gshsxf5rjZbsQbA4TzFHcdN7oB5sWgcnOywtebulo2uNOQ3LIrcRdn6yOo6/OA43ZYqntxsey/QGwWwMcMWb67dn1xqSqFuPSLpJCDQOdEJhZgP9oxeWRQNh6SDVBokntviP+bdki2LQ0AIKNL4I8cPBDKgeIZ6IZbVkZi3MKkYK/D31+jWlkrpH2pPdQ26z2/LyotsJFRxEpDjYLwWN0m7Ei0l78uxwIvfFxCzK/TBBFxPlNIPe8tF3ghFrIKtKS5lMofvy/7qa+W2Xx5v0JbbKz1zONVfjX07LSmYS1nrgKZBpwSZc+4CPGNDX5FTXb2Mx4xoYgq/X9fxflsJBOWhVB8sAAAAASUVORK5CYII=",
  Ct = ["src"],
  bt = { key: 1, class: "mx-1 text-xs text-[#999]" },
  oe = M({
    __name: "MessageSendState",
    props: { message: null },
    setup(s) {
      const e = s,
        r = J(),
        a = G(),
        { sendMessage: c } = ds(),
        t = qe({ timer: null, count: 0 }),
        i = a.currentConversation.conversationID,
        o = C(() => {
          var l;
          return (
            ((l = e.message.attachedInfoElem) == null
              ? void 0
              : l.isPrivateChat) && e.message.isRead
          );
        }),
        g = () => {
          r.updateOneMessage({ ...e.message, status: z.Sending }),
            c({ message: e.message, needOpreateMessage: !1 });
        },
        v = () => {
          t.timer = setInterval(() => {
            t.count > 0 ? (t.count -= 1) : p();
          }, 1e3);
        },
        p = () => {
          var l;
          (l = e.message.attachedInfoElem) != null && l.isPrivateChat && f(),
            t.timer && clearInterval(t.timer);
        },
        f = () => {
          r.deleteOneMessage(e.message),
            O.deleteMessage({
              conversationID: i,
              clientMsgID: e.message.clientMsgID,
            });
        };
      return (
        Z(
          o,
          (l) => {
            var h;
            l &&
              ((t.count =
                ((h = e.message.attachedInfoElem) == null
                  ? void 0
                  : h.burnDuration) ?? 30),
              v());
          },
          { immediate: !0 }
        ),
        He((l) => {
          l.name === "Conversation" && t.count !== 0 && p();
        }),
        (l, h) => {
          const y = ke;
          return (
            d(),
            A("div", null, [
              je(w(y, { size: "16", type: "spinner" }, null, 512), [
                [We, s.message.status === n(z).Sending],
              ]),
              s.message.status === n(z).Failed
                ? (d(),
                  A(
                    "img",
                    { key: 0, class: "mx-1 h-4 w-4", src: n(kt), onClick: g },
                    null,
                    8,
                    Ct
                  ))
                : S("", !0),
              n(o) ? (d(), A("span", bt, k(`${t.count}s`), 1)) : S("", !0),
            ])
          );
        }
      );
    },
  }),
  Mt =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAiCAYAAACuoaIwAAAAAXNSR0IArs4c6QAAA2xJREFUSEutlk+IHEUYxd+rbPUQ9LCXCIkJeBARzBKQXQgSjCEOJgqCBwl48c/BgEdjpmeSqBMw82clBrwoIuxJD17UQzYxrP8IScAkKrgoCF6ighFDPMiu071bT3rG2Z3ddHX3bLZv3fXq+9X3veqvish7GrrfmOhZkbshbQZ4FwAH6BqIHwVewKKdxhH+nBeKXkGrM0byPQI784Ik4wLOi3wVFfu1T38rTCLaC4dINQjYIqC+RoAIveEqwesgtXruSlhdI2Zj9CHAp4eBrNYKmtZ8cAB1/jM4tgx7WyXORR+T3H87oIEsL2nU7sZBxv1vSzDTit4FcXA9QEsxhHdcNXhpJawdlw10bl1B/wdzDuOoBVeT125mbEeXsnadgEUK7ztn31ra4k3dY0x8SMKLJALfQgV8rjB4tAdrRhPG4BuvWLguYT9qwXepmjc72+nwGcEtvhjOaAyHS7M0rc5xkK+lCZOMBDuGkD9llrih+2jiH/wZsu5Ce5xsRzME9nqCTbkweKGIl6YVTYF4LnXRwoyqQZlsd34luDVN5Bz3oGa/KgJDO95joC/SK6Q/FJY2J5nNEdiYCoPdhpC/FYI1tMlsiP/02CHN2yAbRnsvKvylEOyURk0U3/Ruknl7R1LGawS3pWZG8wQqI9OFYK14l6HOezybUzVIYNE5AmVPrT9RWHqqCMy0og9APOOBXVU1GKdpdxoAa970Hcuo2ZlMYDN+xBh9maE56cLgFaIdjRvgckYH+EvEY6gE36ZqJqMH6XCWxCbvgoEJhMGVXrtqRd+T2JEBjAlMOZgzwIYrvZN6caeR2yfgeRIjGXNnFQZjvXaVPJMLjxu500W8GVbjpAOolj5ahnWbcedTgk8OGyxLL+GiQrurf2ovH56nNMpONEvy7vUACvhbsd2OY/y9H2/ltaAZTZC4mOVB0YW45MSv2LOD+lsvPK34ZUOdLBo0VSdNumopXD2WepVju3OG4L61ACVc1r/2IdS5UAiGNfon4YYW7I5Bn7LL2B8d0r/kzihwL0Lr7ST+G3ECHco/NV1YOpJV+mxY7//L9U/ABc3bh1Gnuy1Ynn9dnxbtAzjK63kbKjezbgCPf0V8KrZBVi8z1T+dcGHpWF5G6R0kZ9agf0V9Wltmyazu/xefBnGnjC3jMFMvOL41/wcymmM+gc4Y+wAAAABJRU5ErkJggg==",
  St = { class: "message_quote_wrap" },
  yt = ["innerHTML"],
  _t = { key: 0, class: "mr-1.5" },
  xt = ["src"],
  wt = ["src"],
  Et = ["src"],
  Bt = ["src"],
  Rt = M({
    __name: "QuoteMessageRenderer",
    props: { message: null },
    setup(s) {
      const e = s,
        { t: r } = q(),
        a = P(),
        c = e.message.contentType === m.AtTextMessage,
        t = c
          ? e.message.atTextElem.quoteMessage
          : e.message.quoteElem.quoteMessage,
        i = t.contentType === m.PictureMessage,
        o = t.contentType === m.VideoMessage,
        g = t.contentType === m.FileMessage,
        v = t.contentType === m.LocationMessage,
        p = t.contentType === m.CardMessage,
        f = C(() => {
          var x, R;
          return o || i
            ? ""
            : (c &&
                ((x = e.message.atTextElem.quoteMessage) == null
                  ? void 0
                  : x.contentType) === m.RevokeMessage) ||
              (!c &&
                ((R = e.message.quoteElem.quoteMessage) == null
                  ? void 0
                  : R.contentType) === m.RevokeMessage)
            ? r("messageDesc.quoteRevokeMessage")
            : ue($e(t));
        }),
        l = C(() => `${t.senderNickname}: ${f.value}`),
        h = () => {
          o &&
            a.push({
              path: "/previewVideo",
              query: {
                url: t.videoElem.videoUrl,
                poster: t.videoElem.snapshotUrl,
              },
            }),
            i && xe({ images: [t.pictureElem.sourcePicture.url], loop: !1 }),
            g && ve(t.fileElem.sourceUrl, t.fileElem.fileName);
        },
        y = () => {
          ae.emit(
            "CHAT_MAIN_SCROLL_TO_CLIENTMSGID",
            e.message.quoteElem.quoteMessage.clientMsgID
          );
        };
      return (x, R) => (
        d(),
        A("div", St, [
          u("div", { class: "message_quote_text line-clamp-3", onClick: y }, [
            u("span", { innerHTML: n(l) }, null, 8, yt),
            p ? (d(), A("span", _t, k(n(t).cardElem.nickname), 1)) : S("", !0),
            u("div", { class: "message_quote_media", onClick: h }, [
              i
                ? (d(),
                  A(
                    "img",
                    {
                      key: 0,
                      src: n(t).pictureElem.snapshotPicture.url,
                      class: "ml-1.5 max-h-[32px] max-w-[32px] rounded-md",
                      alt: "img",
                    },
                    null,
                    8,
                    xt
                  ))
                : S("", !0),
              g
                ? (d(),
                  A(
                    "img",
                    {
                      key: 1,
                      src: n(fe)(s.message.fileElem.fileName),
                      class: "ml-1.5 max-h-[32px] max-w-[32px] rounded-md",
                      alt: "img",
                    },
                    null,
                    8,
                    wt
                  ))
                : S("", !0),
              v
                ? (d(),
                  A(
                    "img",
                    {
                      key: 2,
                      src: n(Mt),
                      class: "ml-1.5 max-h-[32px] max-w-[32px] rounded-md",
                      alt: "img",
                    },
                    null,
                    8,
                    Et
                  ))
                : S("", !0),
              p
                ? (d(),
                  D(
                    te,
                    {
                      key: 3,
                      src: n(t).cardElem.faceURL,
                      desc: n(t).cardElem.nickname,
                      size: 32,
                      "is-group": !1,
                    },
                    null,
                    8,
                    ["src", "desc"]
                  ))
                : S("", !0),
              o
                ? (d(),
                  A(
                    "img",
                    { key: 4, class: "play_icon ml-1.5", src: n(_e), alt: "" },
                    null,
                    8,
                    Bt
                  ))
                : S("", !0),
            ]),
          ]),
        ])
      );
    },
  });
const It = N(Rt, [["__scopeId", "data-v-9d08dcf8"]]);
var _ = ((s) => (
  (s[(s.Copy = 0)] = "Copy"),
  (s[(s.Delete = 1)] = "Delete"),
  (s[(s.ForWard = 2)] = "ForWard"),
  (s[(s.Replay = 3)] = "Replay"),
  (s[(s.Revoke = 4)] = "Revoke"),
  (s[(s.Multiple = 5)] = "Multiple"),
  (s[(s.Emoji = 6)] = "Emoji"),
  s
))(_ || {});
const Dt =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAAhtJREFUaEPtmbFqVUEQhr8fFFJoZSXkASII2uQptAlYpFPBQhA70xkSUVAwZSCFhRYWWgiCFnkHGzvzADbWphAURkb2SpBzk93NJu45zFYH7syc/59/zs7OXjHxpYnzIwiOXeFQMBTsPANRop0LdCS8UPDIFHVuEArWCGRm14AtYKnGf8BnH3gNrEny5+zVXEEzuwp8As5ko8g33JZ0P9+c9mdRM3sMPEwgngE/SgDNsb0BXAb2JZ0viXcSCr4EbjkISU3im9kGsFkTswmAgxk1syBYUmJuGwoekrEo0aHkmNkVwHe2xQO/70p6O/pvMDXx93P63EXg6ah3UTP7MnBC+QXsAivAi7ETtFSWW5LW/i3hKZTojOCmpEdBsLTpDdifah80s1BwKptMfIOjnCbiGxz7uJShoJ9k7qTd/qwkP+Uca5nZc+DBqQy8GQTvAdvHYjTfeU/SpZLYxeNSBsFz6dKp1Y3ajI9Xwoqkj/+VYJrAneTNdFG0UAJoju1X4J2kz6WxmitYCiAlxK8YL0j6VuN/mE8vBD8A14FVH5pbkuyF4M80QL+SdHuKBGcH+CBYqm5NiX4HfJfcA96UvnDA3mP9aeLAE0nrDWL+DVFDcAe42xJEiuV9brmmFbTeRT3js5szf26xvBr8r7GiJp7z4mIFc4L2ZBMEe1KjBksoWJO1nnxCwZ7UqMESCtZkrSefULAnNWqwTF7B38KVQ0jSMkckAAAAAElFTkSuQmCC",
  Pt =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAABAdJREFUaEPtmE+oT3kYxp+nLCwslA1RLKbGQqEoCwtKodwkhIwQQjPqKpqZ5m6EEMUNZaFQU4hCiGJBWVhcmQllocyUhZqNxdRYTD3TU++5nY6fe/78zu/eM7fz1q9bfM/5vp/v+77P+34PMc6N45wPLeD/PcJtBNsINvwE2hRteIBy3WsjmHtEDV/QRrDhAcp1b8wiKGkygB0AHpP8PdfTigvGEvAsgB8A/AvgO5LXKzKM+NhYAl4CsC3l3QDJo3VDNgnQbJcB7CLpqNZiTQE00IQgegxgDcm/6yBsCuBSALcAWHhsbwGsIPlnt5CNACRJSbMBPAAwK6A+AlhF8kU3kKMOKGkSgLkAjgNYbOcN6L+SpkYkFwWU09QKe6cq5KgASvoWwEanHYDE+WGfE8CA9AFYYdfFAtfnAZKDVSB7BijJorEBQD+ABSM5lwYMSD97zGCp584B2F9WYXsCKMlgRwB8kwH7DOAZgOcAXFvv/CPpf//CJH0P4ExKYe8B2FRGYWsFlDQzetmSlLdOsYcArvhvGecimqsAXAXg1LUNAegjaRHKtdoAJa0NuMQRg/0K4ChJR6qySZoXCmsRsn2INvIm76W1AEo6DGAgtZnT0BOJ+1ktJmlGQM6JF1ph3UaejrRB14CSToeQeB9HzTPliVqoMi+JFvMopcQfSU7rGaCkX0JMvIdPdD1J11tPrEMZ3CPZ1xPAUMprqXRZSdKp2ROT9GMMB8n7bwPYkidalVJUksepV6FsTkurWk8iF/3Ud8c9qZM7BeDnIj2xKqDrYFls+FOPa+5GTEBJjfeTPF80TUoDSloNwOlhc0ouLXKSiUOSpsdAbVW07E8meSjrcMylPsi0arrJu9kXtiqALwG4Lzk155N8/bXdJHmo9kDt9f7Z2YnZ9R1GNT/nlE/6npu6a/y3wmSxsBSgpOWxsR+/THJ7ekNJU9yb4ucUTu53I/qVGba9x83U5OIDNJybe2krC+h6SKb8hSSHQgTs1M4AS27mWWc+xUXWzf+PqOHsdWk3AA/VyTscRbeeyrf7woDRZP+KFHOqLASwOSaY7FBtOIM8AeBJYyg7rkka/ugUF96TmdvDBQD7ytR3p/CWAXTq3Y2XOIXcKrLXIIP7w9H9vPkzDRgpmWSGt6hNmcsAZk84OTCLjRv+oFO2aJFkAJPHnIrbSfoAa7EygP5e4ht52izZB6sM1R0ArZSut1qnoTKA71MfhCwSe7uZXjKArldPQ11dq7qtwX9CYKxyHpMqK5sdkbQVwMUQIkfOKlu7lYmgReATSX+YrcXcYrpVyTxHCgPmvaip/98CNjUyRf1qI1j0pJq6ro1gUyNT1K82gkVPqqnr2gg2NTJF/WojWPSkmrruP3WBWkgTtmY8AAAAAElFTkSuQmCC",
  Tt =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAABLJJREFUaEPtWU3IVVUUXQscNCgIQkoISgpyEJRQUFRgkFCUpJBoYJBk1CCoQAfRIB0ERkFFg4oKFI2SBI0CgwqNBIWEGhQ0KCoKMlQKctAgWLE+9pXzXd773t33fvfx+rgbHg/u3efsvfbP2XufSyxx4hLHhwHg/93DgwcHD864BYYQnXEHTVRv8OBEE41gkHQNgPsArAGwKn4l5w8AvgVwDMDHJH9sI6fJmkX1oKT7AWwHcHsT4QXPcQAvkfwwuW4i+6IAlHQDgDcA3FKT+DOAkwDssX8ALIvftcF7dY3fQB8n+d1EzRsydAYo6UlbPxS32LMBdi9JAxtLkgz0EYMCcGkw2hBPkXyzIYYF2ToBlPSylQkJ/wLYDeB5klayMUm6GMCzEd72sukVkk833mQMY2uANXAOxY0kT3VRSNJNAD4AUIVuZ5CtAEp6LMLQeL4HcCfJ013AVWslXQHgaHHybiP5Ttu90wAlXQ/gKwAXAbDnbl0scDWQJ8KTDvfVJG3INLUB+GWUAeecwXUKy3EaS/KJbFnOyc9Irk2jA3IDr6R7XZhD0G6Sz7QR2nRNLc/XkPyi6dqKL+VBSZ8CuAvAXwBWkvR/byTJpeOnKCGfkLwnK6wxQElXAvh1Wt4r8vHFKB9OCRv1twzIDMDy5HTSf5MR1JZX0o0Avo717nJSDUAG4HsANgM4TXJFW4XbrJP0OwCXj/0kH8rskQFoK9qa7v7XlUIkuWRcTvKXBU7Fy/yO5LkFeK4C8Ee9E5L0UUwnp0je3BfAPyPZ53UXkjwO+fBxjrpZXjtCwapftW7bSb5aM5BbNZcEG9A5dgdJ19g5Kk7TdPRkPKiQt5PkrkL4awCeKBTeQvLd4r3r2N/RGPjxeZKX1ABuA/BW8axuxOcA7IwIaKzzHH9Td0saB7BsuL2de9KDNQCV9/34LMnltfdbAOwrnnk23FEYaSoAXY/cBL9N8tFCuEPzEAA3ygb2IEkf6RdI0iavA+DnPgkP1N7by26y1wNwZ7SubP8kvR4jVa8h6v7TIFq3TZOiRdKyunEiB48AuNvg+zxkKiu6e1k+SpFJANq8N2gAZ+KAmxc9TfbL5GCZJx6PfGHUO0ny/Y5PWNNWknsyQjMA3RfakrboHpJbM4La8kry6epT1vm7gqSvRBpTY4CRC1U34xnNfeGiDLnjtI3h14ebG4mDJDc2RhaMWYCdwiWrnCSXDqeGybOnb+hSlAXoMmGLtsqHjGZxx3o41hwmuSGzvuKdSYCSrov7VOe9T21PLxdatwzQmQMY4HxCe3owbSBZeTKDbY53pgBGWO4H4Obb5AvgeY15FmEXgG69PD3U6Xj2Y4okj0m+NPa8WVFncF09OM6YrlfuSe2Jz8fdcscMeRuAhwNYdaPtnHNBbx2WpWIpD3qhJDfFDzQMFddL32f6U9n5WOPw8zcJz36ubyW9D2BH9t5lIV3SAAOkD4C6cn7l5/6Y4to16v0oXWwEe+uFPu55WgGc5L0IP3f/DkHfhHvqdwhWY1T1AdT3nJ5OKu9O2jr9vheAaS16XDAA7NG4U9l68OBUzNyjkMGDPRp3KlsPHpyKmXsUMniwR+NOZesl78H/AIrBsEhixTi8AAAAAElFTkSuQmCC",
  Nt =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAArxJREFUaEPtmD+ozlEYxz/fMhgMRorN4G4GhSwUccsiSopiNMgdKcpAbJgNbiEGg6IYDJRBYWK4xSApikG5g0E9enRevd3e1/ue8zvn53d/nWd5h99znvN8nu/585xX9NzUcz4q4HJXuCpYFex4BeoS7bhAE9OrCk4sUccdqoLTCmRmK4DrwCZgv6QP044t6ZdFwQB3BzgYkj0q6VbJxKeN3RhwBNxzYFbS4rRJlPRrBDgC7i2wrStwXrimgDeAY0GBBWCnpC8lFYmNnQxoZleAuS7DJSu4XOCSAM3sEnA6KPcTOA/kWpZ+tbzOuYejl6iZ/QBWxe6FCP9fwEPgqqRnEeNGuqYADivYdP5J4+eBk00UjQb0jJbswY/AoQzLdA2wATgA7AO8M3J7Fe7Vb5OqMep7EmCALHZFmJm3ex7ff92eArsl+fKNsiaAXuHh9ixrB2Nmvs8fADsC0VlJF6PoMlz0pSFXA2+AdYC3fuslfY+BTFZwMMmYXtSXk18hjc3MvFPy5eo2J+laTNDGgGE/LlXysKS7MYmM8zWzlcDXcDU9ljQbEzcLYID0PePvwY3h1Mt1+fup/QjY6ye1pLX/BTBm0lhfM/t7YkuKEiXKOTaxXP5mdhM44vH6CvgS2AwsSJqJKVznFTQz73A+B6h5Scf7Bjj87vQ/s+73BtDMtoc2za+h98BMbLvW2SVqZlsAV8uXqJs3D09i1PtzKMUOKO1vZt6enQqPar/k3S5IOpcydzZAM9sDbE1JIozxRsGbhF3AAMw/XZZ0JjVuFkAz83fcu9Qkxoz7BJyQ5K/7ZMsFONz1JycD+EvhBXAbuJejYc8C6EShKR4cCCmQi5KSXu3/miwbYApRG2MqYBtVLjlHVbBkdduIXRVso8ol56gKlqxuG7Grgm1UueQcVcGS1W0jdlWwjSqXnOM3gwHIOeKQHTYAAAAASUVORK5CYII=",
  Ft =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAAkZJREFUaEPtmb2KVEEQhb8DmhkIGvgG+gCauaCBqJGBgqlvIIKCgYsrGghusI9gKBiLCoKBCyLuAxj4AAYaCAaCC0cKekBnZndu3bl76R36JhNMdVV9dfq/xYp/WnE+GuBhV7gp2BSsvAKti1Yu0ML0moILS1S5QS8FbV8DngJnRuL7AtyV9CobLw1o+zLwJhtoIPsrkt5mfPUB/AycBb4XFX9kAvawPQHcB04CO5LOZXz0AXQJ8ETSeiZYX1vbj4EH0V5SKueUcQSwPQHckPSob9KZdrYfAhsNcE7VmoLTRWldNDO4OtquzBi0HUvCT0m7/7KvBKDt28Am8E7S1ZUCLHBbBWpmMT/UCtq+CbwocF+BNUnfVkJB29cL3BEgoC5Kio31f19VCto+DpyW9Gm/SbIrXNk91bOTsf0euABsSbozDzIDVyPgS+BGAZuBzMLVCHgMeA2cn4bsA1cdYEloBhLY7jKh7NGl6xmDkwRtT0NO/tpzttxrUqpqFp1avwIybgAmdzdpuCq76BTkqTIm48rh0rx1btGeu1oFFyXe9f8GuE+l2om+nei7DqQl7NoYHHgM/gHieLMp6d4SwnRuavtZvE0Au5KOdm4YF8UZ47Lofij7zF/A83KFn3WTsY/18xYQm4ZtSWuZxn0A413iY1ExE2tZ29/ltL+TcZQGLCoGZLwXxG9U+CC/eOQJqHVJKbhIqhfgQdIM7bsBDl3Rsf01Bceu+NDxmoJDV3Rsf03BsSs+dLym4NAVHdtfU3Dsig8d7y8b8XJIv7g+vwAAAABJRU5ErkJggg==",
  Ut =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAAiFJREFUaEPtmb+rT3EYx1/vMhgog4EyUAbFbjZZ3KIsNwayKsrAIlcWBkWxKQYmtygW+SvUVQblbu5gUAwG9dYnR307Xb7fz/l8P+ee8/V8lm+dnl/v5/18vud5niMW/GjB8REAx85wMBgMDjwDUaIDJ2hqeMHg1BQNXCAY7EKQ7YPAW2D/jPrrwDFJ6XeupwqDtk8CLzIjPSXpZabOVPEqAJNX26eBw1Mj+C3wXtLqjLJZYtUAZkVRUTgboO0zwFlge8W4NjP9A3gq6VmO3y4AvwE7cpzMUfa7pJ059roAvASkP5GtOKuSHuY4zgaYY3wIssUAbR8Fdkl6M09Ato8DG5LeldgtAmh7N/AZ2AYsSXpdEswfXdsngFfAT2CvpC9d7ZYCTJ3Kp8b5eUlPugYyqWf7HPC4eXagpMOpCtB2YmEfsCzpQwvEIeA5sC5paXQAbU+ye03SnRaIq8DtzVgaBYMtgCuSbrYA3gBWAiAM8w4Gg3aU6KBfE1GiUaID72SiRKNEo0RnGlyqTRP/wx3c0wzDKdOXJd1vNdtpt3OveZaG2o2JgXc08+CVZn1/XdLXFsC0DbgFfJR0d3Tz4EwX5C9Cti8Aj4bWqq0BD4C0oC05aaF8ETgyNIAloP6lu3XzYIrKdtqrpA8t8z5po5YWvcslhoteEyWO+9INgH1lupafYLBWZvuyGwz2lelafoLBWpnty24w2Fema/lZeAZ/Aalsr0hPRNn+AAAAAElFTkSuQmCC",
  Yt = { class: "flex max-w-[192px] flex-wrap px-2 py-2" },
  Vt = ["onClick"],
  Qt = ["src"],
  Ot = { class: "text-xs" },
  Kt = M({
    __name: "MessageMenu",
    props: {
      message: null,
      disabled: { type: Boolean },
      isSelfMsg: { type: Boolean },
      isPreView: { type: Boolean },
    },
    setup(s) {
      const e = s,
        r = [m.AtTextMessage, m.TextMessage, m.QuoteMessage],
        { t: a, locale: c } = q(),
        t = Me(),
        i = J(),
        o = G(),
        g = [
          { title: a("messageMenu.copy"), icon: Dt, hidden: !1, type: _.Copy },
          {
            title: a("messageMenu.delete"),
            icon: Ut,
            hidden: !1,
            type: _.Delete,
          },
          // {
          //   title: a("messageMenu.forward"),
          //   icon: Pt,
          //   hidden: !1,
          //   type: _.ForWard,
          // },
          {
            title: a("messageMenu.replay"),
            icon: Tt,
            hidden: !1,
            type: _.Replay,
          },
          {
            title: a("messageMenu.multipalChoise"),
            icon: Ft,
            hidden: !1,
            type: _.Multiple,
          },
          {
            title: a("messageMenu.revoke"),
            icon: Nt,
            hidden: !1,
            type: _.Revoke,
          },
        ];
      Z(c, () => {
        (g[0].title = a("messageMenu.copy")),
          (g[1].title = a("messageMenu.delete")),
          // (g[2].title = a("messageMenu.forward")),
          (g[3].title = a("messageMenu.replay")),
          (g[4].title = a("messageMenu.multipalChoise")),
          (g[5].title = a("messageMenu.revoke"));
      });
      const v = I(!1),
        p = I("top"),
        f = I(),
        l = P();
      let h = null;
      const { top: y } = es(f),
        { copy: x, isSupported: R } = ss(),
        b = C(() => {
          if (
            e.message.sessionType !== T.Single &&
            o.storeCurrentMemberInGroup.roleLevel !== as.Nomal
          )
            return !0;
          const B = (new Date().getTime() - e.message.sendTime) / 6e4;
          return e.message.sendID === t.storeSelfInfo.userID && B < 1440;
        }),
        E = C(
          () => (
            g.map((B) => {
              B.type === _.Copy &&
                !r.includes(e.message.contentType) &&
                (B.hidden = !0),
                B.type === _.Revoke && !b.value && (B.hidden = !0);
            }),
            e.isPreView
              ? r.includes(e.message.contentType)
                ? g.slice(0, 1)
                : []
              : g.filter((B) => !B.hidden)
          )
        );
      Se(
        f,
        () => {
          e.disabled ||
            E.value.length < 1 ||
            (e.isSelfMsg
              ? (p.value = y.value < 150 ? "bottom-end" : "top-end")
              : (p.value = y.value < 150 ? "bottom-start" : "top-start"),
            (v.value = !0));
        },
        { modifiers: { prevent: !0 } }
      );
      const F = () =>
          e.message.contentType === m.AtTextMessage
            ? e.message.atTextElem.text
            : e.message.contentType === m.QuoteMessage
            ? e.message.quoteElem.text
            : e.message.textElem.content,
        L = () => {
          h = ns({ forbidClick: !0 });
        },
        Ie = (B) => {
          switch (B) {
            case _.Copy:
              // R && (console.log(F()), x(F())),
              R && (console.log(F()), self.clipboardPlugin.write({string:F()})),
                j({
                  message: a(
                    // R ? "messageTip.copySuccess" : "messageTip.copyFailed"
                    "messageTip.copySuccess"
                  ),
                });
              break;
            case _.Delete:
              L(),
                console.log("deleteMessage"),
                O.deleteMessage({
                  conversationID: o.currentConversation.conversationID,
                  clientMsgID: e.message.clientMsgID,
                })
                  .then(() => i.deleteOneMessage(e.message))
                  .catch((U) => j({ error: U }))
                  .finally(() => (h == null ? void 0 : h.close()));
              break;
            case _.ForWard:
              l.push({
                path: "chooseUser",
                state: {
                  chooseType: gs.ForwardMessage,
                  extraData: JSON.stringify(e.message),
                },
              });
              break;
            case _.Multiple:
              ae.emit("UPDATE_MULTIPLE_CHECK_STATE", !0),
                i.updateOneMessage({ ...e.message, checked: !0 });
              break;
            case _.Replay:
              o.updateQuoteMessage(e.message);
              break;
            case _.Revoke:
              L(),
                console.log("newRevokeMessage"),
                O.revokeMessage({
                  conversationID: o.currentConversation.conversationID,
                  clientMsgID: e.message.clientMsgID,
                })
                  .then(() => {
                    i.updateOneMessage({
                      ...e.message,
                      contentType: m.RevokeMessage,
                      notificationElem: {
                        detail: JSON.stringify({
                          clientMsgID: e.message.clientMsgID,
                          revokeTime: Date.now(),
                          revokerID: t.storeSelfInfo.userID,
                          revokerNickname: a("you"),
                          revokerRole: 0,
                          seq: e.message.seq,
                          sessionType: e.message.sessionType,
                          sourceMessageSendID: e.message.sendID,
                          sourceMessageSendTime: e.message.sendTime,
                          sourceMessageSenderNickname: e.message.senderNickname,
                        }),
                      },
                    }),
                      i.updateQuoteMessageRevoke(e.message.clientMsgID);
                  })
                  .catch((U) => j({ error: U }))
                  .finally(() => (h == null ? void 0 : h.close()));
              break;
          }
          v.value = !1;
        };
      return (B, U) => {
        const De = us;
        return (
          d(),
          D(
            De,
            {
              theme: "dark",
              placement: p.value,
              trigger: "manual",
              show: v.value,
              "onUpdate:show": U[0] || (U[0] = (Y) => (v.value = Y)),
            },
            {
              reference: X(() => [
                u(
                  "div",
                  {
                    ref_key: "messageContentRef",
                    ref: f,
                    class: "flex items-center",
                  },
                  [ts(B.$slots, "default")],
                  512
                ),
              ]),
              default: X(() => [
                u("div", Yt, [
                  (d(!0),
                  A(
                    ee,
                    null,
                    Ce(
                      n(E),
                      (Y) => (
                        d(),
                        A(
                          "div",
                          {
                            key: Y.type,
                            onClick: ye((Wt) => Ie(Y.type), ["prevent"]),
                            class: "flex flex-col items-center px-2 py-1",
                          },
                          [
                            u(
                              "img",
                              { class: "h-7 w-7", src: Y.icon, alt: "" },
                              null,
                              8,
                              Qt
                            ),
                            u("span", Ot, k(Y.title), 1),
                          ],
                          8,
                          Vt
                        )
                      )
                    ),
                    128
                  )),
                ]),
              ]),
              _: 3,
            },
            8,
            ["placement", "show"]
          )
        );
      };
    },
  }),
  Xt = (s) => (ge("data-v-00fa1c02"), (s = s()), me(), s),
  Gt = { class: "message_container_wrap" },
  Jt = { class: "message_container" },
  Lt = { class: "mb-1 max-w-[240px] truncate text-xs text-[#666]" },
  zt = { className: "text-[var(--sub-text)]" },
  Zt = Xt(() => u("span", null, k(" "), -1)),
  qt = { key: 0 },
  Ht = M({
    __name: "MessageItem",
    props: {
      source: null,
      showCheck: { type: Boolean },
      isPreView: { type: Boolean },
      isActive: { type: Boolean },
    },
    setup(s) {
      const e = s,
        r = Me(),
        a = Ae(),
        c = G(),
        { source: t, showCheck: i } = os(e),
        o = I(),
        g = I(),
        v = C(() => c.currentConversation.conversationType === T.Single),
        p = C(() => r.selfInfo.userID === t.value.sendID),
        f = C(() => {
          var E, K;
          let b;
          if (e.source.contentType === m.GroupAnnouncementUpdated)
            try {
              b = JSON.parse(
                (E = e.source.notificationElem) == null ? void 0 : E.detail
              );
            } catch {}
          return {
            notification:
              (K = b == null ? void 0 : b.group) == null
                ? void 0
                : K.notification,
            opUser: b == null ? void 0 : b.opUser,
          };
        }),
        l = C(
          () =>
            p.value &&
            !f.value.notification &&
            t.value.status === z.Succeed &&
            t.value.contentType !== m.CustomMessage
        ),
        h = C(() => {
          switch (e.source.contentType) {
            case m.TextMessage:
            case m.AtTextMessage:
            case m.QuoteMessage:
              return ys;
            case m.VoiceMessage:
              return Rs;
            case m.VideoMessage:
            case m.PictureMessage:
              return ut;
            case m.CardMessage:
              return Fs;
            case m.FileMessage:
              return Ws;
            case m.LocationMessage:
              return ct;
            case m.MergeMessage:
              return pt;
            case m.GroupAnnouncementUpdated:
              return at;
            case m.CustomMessage:
              return zs;
            default:
              return Re;
          }
        });
      vt({
        messageContainerRef: o,
        isSelfMsg: p,
        message: e.source,
        isRead: e.source.isRead,
        isPreView: e.isPreView,
        isGroupAnnounce: !!f.value.notification,
        clientMsgID: e.source.clientMsgID,
      }),
        Se(
          g,
          () => {
            var b, E;
            ae.emit("AT_SOMEONE", {
              data: [
                {
                  userID:
                    ((b = f.value.opUser) == null ? void 0 : b.userID) ??
                    e.source.sendID,
                  nickname:
                    ((E = f.value.opUser) == null ? void 0 : E.nickname) ??
                    e.source.senderNickname,
                },
              ],
            });
          },
          { modifiers: { prevent: !0 } }
        );
      const x = async () => {
          var b;
          e.showCheck ||
            (e.source.groupID &&
              c.storeCurrentGroupInfo.lookMemberInfo === cs.NotAllowed) ||
            a.getUserCardData(
              ((b = f.value.opUser) == null ? void 0 : b.userID) ??
                e.source.sendID,
              e.source.groupID
            );
        },
        R = () => {
          !e.showCheck ||
            e.source.contentType === m.GroupAnnouncementUpdated ||
            (e.source.checked = !e.source.checked);
        };
      return (b, E) => {
        var F;
        const K = Cs;
        return (
          d(),
          A(
            "div",
            {
              ref_key: "messageContainerRef",
              ref: o,
              class: Q([
                "message_item",
                {
                  message_item_self: n(p),
                  message_item_checked: n(i),
                  message_item_active: s.isActive || n(t).jump,
                },
              ]),
              onClick: R,
            },
            [
              n(i)
                ? (d(),
                  D(
                    K,
                    {
                      key: 0,
                      class: "check_wrap",
                      modelValue: n(t).checked,
                      "onUpdate:modelValue":
                        E[0] || (E[0] = (L) => (n(t).checked = L)),
                      disabled:
                        n(t).disabled ||
                        n(t).contentType === n(m).GroupAnnouncementUpdated,
                      onClick: E[1] || (E[1] = ye(() => {}, ["stop"])),
                    },
                    null,
                    8,
                    ["modelValue", "disabled"]
                  ))
                : S("", !0),
              u("div", Gt, [
                w(
                  te,
                  {
                    ref_key: "avatarRef",
                    ref: g,
                    size: 42,
                    src: n(t).senderFaceUrl,
                    desc: n(t).senderNickname,
                    onClick: x,
                  },
                  null,
                  8,
                  ["src", "desc"]
                ),
                u("div", Jt, [
                  u("div", Lt, [
                    u("span", zt, k(n(rs)(n(t).sendTime)), 1),
                    Zt,
                    n(v)
                      ? S("", !0)
                      : (d(), A("span", qt, k(n(t).senderNickname), 1)),
                  ]),
                  w(
                    Kt,
                    {
                      message: n(t),
                      disabled: n(i),
                      isSelfMsg: n(p),
                      isPreView: e.isPreView,
                    },
                    {
                      default: X(() => [
                        n(p)
                          ? (d(),
                            D(oe, { key: 0, message: n(t) }, null, 8, [
                              "message",
                            ]))
                          : S("", !0),
                        (d(),
                        D(
                          pe(n(h)),
                          {
                            message: n(t),
                            "is-self-msg": n(p),
                            "announce-content": n(f).notification,
                            disabled: n(i) || s.isActive,
                          },
                          null,
                          8,
                          [
                            "message",
                            "is-self-msg",
                            "announce-content",
                            "disabled",
                          ]
                        )),
                        n(p)
                          ? S("", !0)
                          : (d(),
                            D(oe, { key: 1, message: n(t) }, null, 8, [
                              "message",
                            ])),
                      ]),
                      _: 1,
                    },
                    8,
                    ["message", "disabled", "isSelfMsg", "isPreView"]
                  ),
                  n(t).contentType === n(m).QuoteMessage ||
                  ((F = n(t).atTextElem) != null && F.quoteMessage)
                    ? (d(),
                      D(It, { key: 0, message: n(t) }, null, 8, ["message"]))
                    : S("", !0),
                  n(l)
                    ? (d(),
                      D(
                        ht,
                        { key: 1, message: n(t), disabled: n(i) },
                        null,
                        8,
                        ["message", "disabled"]
                      ))
                    : S("", !0),
                ]),
              ]),
            ],
            2
          )
        );
      };
    },
  });
const ra = N(Ht, [["__scopeId", "data-v-00fa1c02"]]),
  jt = ["innerHTML"],
  ca = M({
    __name: "SystemNotificationItem",
    props: { source: null },
    setup(s) {
      const e = s,
        r = J(),
        a = ls(e.source),
        c = I(),
        t = () => {
          const { stop: i } = be(c, ([{ isIntersecting: o }], g) => {
            o &&
              (r.updateOneMessage({
                clientMsgID: e.source.clientMsgID,
                isAppend: !1,
              }),
              i());
          });
        };
      return (
        se(() => {
          t();
        }),
        (i, o) => (
          d(),
          A(
            "div",
            {
              class: "px-6 py-3 text-center text-xs text-[#999] line-clamp-2",
              innerHTML: n(a),
            },
            null,
            8,
            jt
          )
        )
      );
    },
  });
export { ra as M, ca as _, bs as a };
