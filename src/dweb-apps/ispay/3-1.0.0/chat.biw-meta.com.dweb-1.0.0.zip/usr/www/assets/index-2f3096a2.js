import {
  d as h,
  v as C,
  a0 as D,
  j as I,
  aR as U,
  B as $,
  D as v,
  f as t,
  F as u,
  J as g,
  _ as k,
  E as n,
} from "./index-0085351d.js";
import { _ as B } from "./index.vue_vue_type_script_setup_true_lang-1f3350dc.js";
import { _ as r } from "./index.vue_vue_type_script_setup_true_lang-e2498643.js";
import "./index-fa95a9d8.js";
import "./arrows_left-58dc349e.js";
import "./back-099fa84a.js";
const S = { class: "page_container" },
  Y = { class: "my-2 mx-2 overflow-hidden rounded-md" },
  w = { class: "mx-2 overflow-hidden rounded-md" },
  z = h({
    __name: "index",
    setup(y) {
      var l, d;
      const { t: s } = C(),
        a = D(),
        p = I(() => {
          var e, o;
          return ((e = a.storeUserCardData.baseInfo) == null
            ? void 0
            : e.gender) === 1
            ? s("male")
            : ((o = a.storeUserCardData.baseInfo) == null
                ? void 0
                : o.gender) === 2
            ? s("female")
            : s("private");
        }),
        _ =
          (l = a.storeUserCardData.baseInfo) != null && l.birth
            ? U(
                (d = a.storeUserCardData.baseInfo) == null ? void 0 : d.birth
              ).format("YYYY-MM-DD")
            : "-";
      return (e, o) => {
        var c, i, m;
        return (
          $(),
          v("div", S, [
            t(B, { title: e.$t("userInfo") }, null, 8, ["title"]),
            u("div", Y, [
              t(
                r,
                { lable: e.$t("avatar") },
                {
                  default: g(() => {
                    var f, b;
                    return [
                      t(
                        k,
                        {
                          size: 32,
                          src:
                            (f = n(a).storeUserCardData.baseInfo) == null
                              ? void 0
                              : f.faceURL,
                          desc:
                            (b = n(a).storeUserCardData.baseInfo) == null
                              ? void 0
                              : b.nickname,
                        },
                        null,
                        8,
                        ["src", "desc"]
                      ),
                    ];
                  }),
                  _: 1,
                },
                8,
                ["lable"]
              ),
              t(
                r,
                {
                  lable: e.$t("name"),
                  content:
                    (c = n(a).storeUserCardData.baseInfo) == null
                      ? void 0
                      : c.nickname,
                },
                null,
                8,
                ["lable", "content"]
              ),
              t(r, { lable: e.$t("gender"), content: n(p) }, null, 8, [
                "lable",
                "content",
              ]),
              t(r, { lable: e.$t("birthday"), content: n(_) }, null, 8, [
                "lable",
                "content",
              ]),
            ]),
            // u("div", w, [
            //   t(
            //     r,
            //     {
            //       lable: e.$t("cellphone"),
            //       content:
            //         (i = n(a).storeUserCardData.baseInfo) == null
            //           ? void 0
            //           : i.phoneNumber,
            //     },
            //     null,
            //     8,
            //     ["lable", "content"]
            //   ),
            //   t(
            //     r,
            //     {
            //       lable: e.$t("email"),
            //       content:
            //         (m = n(a).storeUserCardData.baseInfo) == null
            //           ? void 0
            //           : m.email,
            //     },
            //     null,
            //     8,
            //     ["lable", "content"]
            //   ),
            // ]),
          ])
        );
      };
    },
  });
export { z as default };
