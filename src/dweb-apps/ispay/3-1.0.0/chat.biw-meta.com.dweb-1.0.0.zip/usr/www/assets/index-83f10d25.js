var kn = Object.defineProperty;
var Bn = (t, e, o) =>
  e in t
    ? kn(t, e, { enumerable: !0, configurable: !0, writable: !0, value: o })
    : (t[e] = o);
var Nt = (t, e, o) => (Bn(t, typeof e != "symbol" ? e + "" : e, o), o);
import {
  c as Po,
  a7 as lo,
  n as Yt,
  m as In,
  d as ue,
  a8 as Sn,
  f as L,
  a9 as Ht,
  aa as Dn,
  i as zo,
  ab as Mn,
  ac as Un,
  ad as Tn,
  ae as Rn,
  j as re,
  af as Fn,
  ag as Qn,
  W as On,
  $ as Lo,
  v as Te,
  N as ve,
  r as z,
  a as At,
  z as tt,
  I as H,
  C as Ke,
  ah as pe,
  A as jn,
  B as X,
  D as _,
  U as xo,
  E as S,
  ai as uo,
  H as De,
  G as ae,
  y as jt,
  J as Qe,
  F as M,
  Q as ht,
  a1 as to,
  S as gt,
  P as Nn,
  M as vt,
  aj as Xt,
  ak as bt,
  w as pt,
  al as yt,
  g as dt,
  x as Vn,
  am as Xe,
  an as Pn,
  R as de,
  T as fe,
  L as zn,
  Z as Jt,
  ao as Ce,
  ap as Ln,
  aq as Go,
  a2 as qo,
  ar as xn,
  as as Gn,
  at as qn,
  au as Yn,
  av as Hn,
  aw as Yo,
  ax as Xn,
  ay as Jn,
  a6 as Wt,
  az as fo,
  V as Rt,
  aA as Wn,
  aB as Kn,
  aC as Ao,
  aD as rt,
  aE as Zn,
  aF as _n,
  aG as $n,
  aH as es,
  aI as ts,
  aJ as os,
  aK as Ho,
  O as ns,
} from "./index-0085351d.js";
import { A as Xo } from "./index-e0807859.js";
import { N as ss } from "./index-fa95a9d8.js";
import { a as is } from "./arrows_left-58dc349e.js";
import { n as rs } from "./not_accept-1b9d42a2.js";
import { m as as } from "./more-f2b22f25.js";
import { u as Jo, R as Vt, C as W } from "./useInviteRtc-f97341da.js";
import { M as Ft } from "./data-2e062955.js";
import {
  a as cs,
  _ as ls,
  M as us,
} from "./SystemNotificationItem.vue_vue_type_script_setup_true_lang-e2ac2dd7.js";
import { V as Wo } from "./virtual-list-986f13ac.js";
import { u as Ko } from "./useCurrentMemberRole-3ba2452e.js";
import { C as ds, s as fs } from "./index-eca3851a.js";
import { U as As } from "./index-cc00d73d.js";
import { C as Zo } from "./data-7f4000cb.js";
import { u as gs } from "./useSendMessage-7be453b1.js";
import "./index-44364ad2.js";
import { S as ps } from "./index-08277207.js";
import { u as ms } from "./useGroupMemberList-d99b6774.js";
import { _ as hs } from "./index.vue_vue_type_script_setup_true_lang-d01a2f4a.js";
import { _ as vs } from "./index.vue_vue_type_script_setup_true_lang-c1182dc3.js";
import "./chating_message_video_play-2b29053c.js";
import "./function-call-6d0a9231.js";
import "./index-5417b32f.js";
import "./use-sync-prop-ref-17d54694.js";
import "./use-id-f9988c90.js";
import "./index-df8775be.js";
const [_o, bs] = Po("grid"),
  ys = {
    square: Boolean,
    center: lo,
    border: lo,
    gutter: Yt,
    reverse: Boolean,
    iconSize: Yt,
    direction: String,
    clickable: Boolean,
    columnNum: In(4),
  },
  $o = Symbol(_o);
var ws = ue({
  name: _o,
  props: ys,
  setup(t, { slots: e }) {
    const { linkChildren: o } = Sn($o);
    return (
      o({ props: t }),
      () => {
        var n;
        return L(
          "div",
          {
            style: { paddingLeft: Ht(t.gutter) },
            class: [bs(), { [Dn]: t.border && !t.gutter }],
          },
          [(n = e.default) == null ? void 0 : n.call(e)]
        );
      }
    );
  },
});
const Cs = zo(ws),
  [Es, kt] = Po("grid-item"),
  ks = Mn({}, Un, {
    dot: Boolean,
    text: String,
    icon: String,
    badge: Yt,
    iconColor: String,
    iconPrefix: String,
    badgeProps: Object,
  });
var Bs = ue({
  name: Es,
  props: ks,
  setup(t, { slots: e }) {
    const { parent: o, index: n } = Tn($o),
      a = Rn();
    if (!o) return;
    const s = re(() => {
        const { square: u, gutter: f, columnNum: d } = o.props,
          A = `${100 / +d}%`,
          p = { flexBasis: A };
        if (u) p.paddingTop = A;
        else if (f) {
          const h = Ht(f);
          (p.paddingRight = h), n.value >= +d && (p.marginTop = h);
        }
        return p;
      }),
      c = re(() => {
        const { square: u, gutter: f } = o.props;
        if (u && f) {
          const d = Ht(f);
          return { right: d, bottom: d, height: "auto" };
        }
      }),
      r = () => {
        if (e.icon)
          return L(On, Qn({ dot: t.dot, content: t.badge }, t.badgeProps), {
            default: e.icon,
          });
        if (t.icon)
          return L(
            Lo,
            {
              dot: t.dot,
              name: t.icon,
              size: o.props.iconSize,
              badge: t.badge,
              class: kt("icon"),
              color: t.iconColor,
              badgeProps: t.badgeProps,
              classPrefix: t.iconPrefix,
            },
            null
          );
      },
      i = () => {
        if (e.text) return e.text();
        if (t.text) return L("span", { class: kt("text") }, [t.text]);
      },
      l = () => (e.default ? e.default() : [r(), i()]);
    return () => {
      const {
          center: u,
          border: f,
          square: d,
          gutter: A,
          reverse: p,
          direction: h,
          clickable: b,
        } = o.props,
        y = [
          kt("content", [
            h,
            {
              center: u,
              square: d,
              reverse: p,
              clickable: b,
              surround: f && A,
            },
          ]),
          { [Fn]: f },
        ];
      return L("div", { class: [kt({ square: d })], style: s.value }, [
        L(
          "div",
          {
            role: b ? "button" : void 0,
            class: y,
            style: c.value,
            tabindex: b ? 0 : void 0,
            onClick: a,
          },
          [l()]
        ),
      ]);
    };
  },
});
const Is = zo(Bs),
  Ss =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAACv1JREFUaEPtmnuQU9UZwL/vu/dmcxNYlufuJthBRhSpLElWEF8ztrXio/h2tK3WVxVaR1sf1dZqtVYrglJHHYqPUUSsT5S2o9bqqCMWO+omuwuIMFpbJcnyUGHd3JvHvefrnJvckI3JJguIq8P9h9mce875ft/rfN+5IHzDH/yG88FewK+7hfdasIoFVWgKDYNtWzMAG82hbOXBWpD0QOgKBDwPCUcDsyUYXmeGa9PJ2P+GIuhgADU9EFqikPKjchAG3pazs4dlk2vWDTXIOgHbNT3IDyqIZ7sADNAvBQuAD42MeRhsebdnKEHWAfhFOMH8JjPfjQDfJaKfukCC4Xkj3nESAFi1ISd4obmxEUzbgt61nwNArvacwb9RA7ACnOCXjXTvafDp+70AoPgCkRVE+AN3a1uIeWYi9psBRWluG+dT1dcQ4EAA2AYA2xl4AzO/bAt+LtvTtXbwKJVnDASo+ILhBwnpJ0UL9YfL/xzYf4wfh61CxEnyT2awhOAzzWT0mWpC6oHwWQrRY5XGGTjDAl4TtjU/van7lV0FrQrobY1crCp474BwhUHP+EibBrgSARodSJl0BB6aTXS8V0lAPXDQPoieNxDxW3K8khCOopifNgVfBj2xLTsLWg0QfcH2KCGE8lbhV1Jm7ykFt6y4l7d12tkKqQ8hglqYsy5l9s6sOqe5za8puL8iqBGAJxDRUYgwCxBasQRZMH+UY/vkXKIrtjOQlQFH7dfo10dsQIRmmS1zdmZKPUeAHowsVBAvdwWxmO9Nx6Nz6xdsglcPNJ1KSNcj4uQd83ibsMQxRk/n2/WvlX+zMuDIiSP8vpHrXcDU9tQY+Py9T2ov3q75Avx3IpzlvMvc19drTBhgrlYxe44fr+s87lYCvKToEcDbrbQ9I7O1a0NtOXa8Uc1FVd/49vUEMJGZQdj2IWZP11v1LOxtbTtSUbTX5cJyrs32kelE1xv95o6dMsyneZcCQRsypJj5Hdu2V2Q2WS8CvJt1321oDc9VCW9HRH/B7VenzN4jBgqVchmrJhlfMPI3QpwtJ1i2fW062XlrXYDNbRcqmvaAC5jNZUK5zWu7SufqLeHTSaWnSjeXoQDM3bbFV6Y3xV5239cD4UuJ6C73XVvY881E5zX1yFLdRQGgoTUyR1VwcV5QWJOKd4RrHeB6IHQ4ofISIuhyccH8gRFPTym1ivzdE5g6WUPPW4AwvFzDzGAIEL8z47E7ipDByCPFKoq5L5fNhDNb1r5fD2T1c3BMOOD30jqZ+qWrWcI+NpPserHaonpz20xFU58HwJF5Y4Bt2faJmZ7O5yvN8TZPnYgKTWegfQnxJESc6Qojt7OF/fN0svN+OVcfPS1IurIGAZvk3zbznWY8WkxmA4EOWMn4A5HHkPCsvDXEv4x47EjnmCt7fC2h6aTSP6EggHxBCL7GTETn16NlmewaWkLHq4qyBBHGFBRk5KzszOym1asdyEB4nkLkuCYzbEzFP5kE8N90rfUHBNRawwd7iP6NCIoU2rLE8Zme2Auli0pLKJrW4WrXUYaAu41Ex2W1Ni8f9zS3HeTR1JVFRQl+MpWInum4dcu0b2uK2uXIUi15VdiwZrHtC0aWE+KpjuaEWJtKfHZwqeb01mmXK4q60F1bCH7WSETPkJ40WEDHUq2Ry0nBhYUkZQrT2t/8tHsjAKj+YPsaRDjAcVNbXGkmY8V9q+1VE9DTPHWqR9VWAeIwaUW7LKNqLdNmeFRlJQJ68u7D76XM3kMGk8r7CZc/gz9AhNHOfpZ9Xrqn82H5ji8YfoqQTi+EzMNGPHZeLSXWBMz7f2S+Qvir/MKcsqzcoW5sOBsHwveXtk22EHeYidhVtTavNu4PRF5HQhnvIIS4wUjEbspbN3yHotAVBcCXjHjsmFp71AUIo/Zr9HlHdBLBvoXFVxnxzHeK6b8lPNav4FpEHOtYEThrW/ax6Z6uV2sJUGlcD0SWKYQ/dlyR7T+Z8U4HSm8JX6modPvuB5TnYiD0fRWVF2SQOxsDLzA3Rq92BZQtECE94pZWskg2wIhAvJ4Srz+mPi50OGn0BAPkrFz2pOzmNd3yDSehqdpzAOC37NycTM/qfgmvkrLqs2Bhph6M3Kkg/qJgpYxl8SmlWbVU83ktD6bDLxdvvA7gFQDvZ/qPTJGx7gF4t68e7xgUIMAEry846jVCPKSQULbaljUjvan7Q2ezke0j/D5+ExFlp+48thB3mYmYo5Sv4hkkoOsmnrcRYVQBMpYye49ys6Yn0D5ZI37TPRdlJmTBNxqJ6O+/FoBSyIaWqcepqrbCPRqEEH81EjGZvp3LpoaW0Amqojzl1qT57lxcZyZit+1pyEFbcEdSCV1FpCxwFxAsFhvx2M/c8UKHL0svJykVyrf5ZiIqL6REDVCCcQeNbVCpKWP29cBn/9m+s4rZaUC5oS8Y/jMhOR17AWCBmdiRWX2t4blIdE8pJLN42jA/v7BaIaC1hKZrRAsRYTogNgDzZ8zwqJHu/e3OFA+7BCivDf3B8GOIJEszB5KFuMlIxG4os+R9rrsW4nYNC+tcI9kdLbVMvuCmJ90Gt3SMmWMWWz/MJLrXD8aauwoI0Nzm9ynKCiI6Oi+8bHX4hnQy+kdXECcmVVpWWpDL6wxbiOvMpLIIoCPX0Bw+UVXp8aIimPtkb4iE49x1mOFTy7bPqdaCVQLfdUC5qqx09EZZlOch8x3FbWai49fupvkmV3um9AhxLM5iFTD+BREXlDTK3XbGPiNjbd/s84++FRHmlvaKzHyzkYj+oY5Y3o1feIdPHu0brv+DiA4uuKEEXWTEo5cWBRk5cYTP13QnAp7jxmW51gVzt5FNzyr9xqEHwpcR0rxiVs4fPc8ahrgAtnXKm/Gqz+6xoLt8c9s4v6o8gUhHFd1KiMdTucxFsGVH5eELhE5GokUI2FoWZ6shmz4mVeEDjjcQPlpBesI9fwtKXGflcHZmc8cH1Qh3L6Drrt7G5UR5d3UEEbySs+aZxtZ1yaIgTaEmv59uBMCLAUFn5ihm0ydUgivG8vjQJJVpOSJOdX8TzHHm7KFmYs3HX14Mlq/sXAs2PEpEJ5YI8lFO8Gm5ZOyd0tdlF68gHWhm+16s6xgY2T7Cp/MjRPkbP/kI5vuMeHTOngPM76T6gpF7EHFO0U2Y+ywhrnAvkwaKnRpjqi8QfoaIHEinc4mnJ5Xf3smx3e+iZZLpgfA1hHRLv4qGeZlp9l5Sl8WqkOqB0NUKKU7pxwybUllzv9I4d6d96YByo4bmttmqpi7tdzEF8KGwrAt3pilucGJRWSk/LTgWFOIdIxGbUenGb48AOpBj2g5QPOqjRNheTD7yWyDzQwanrofEhq31uKwDB/QqAgYd6+W7/vPT8c4lezoGv7jfmAOG6x7/PEK82O388y4mNrHg64xkdmmlOOqXRUvg8tbjJUYien415ewxC5YKIGtORVEWE8I+O6zpkK62BcxPJzcvL///N+WWyyuGl6Xi0XMHqmi+EkAHqinU5PPBzUh0kdtXFoSW/3wsmFcIAS8gW+tZ1aYoAIsJ825ZL9weyaK14kobGwppmizD8HulbuvGl0yRgKXffOuz3B7NorUg5bg3MO0IQuWXADCLEIdVmpMvzmGpEe+4oN6b86/ORatQ66PaxqNHmc0KHkcAbQDsBSCZLZNC2IvSyc4HKh0HQyrJ1GPRwjsajJzoA0UTsHW9vCb8wpetWmsNOQvWEniw43sBB6uxofb+XgsONYsMVp7/A8Lm+XW0koxhAAAAAElFTkSuQmCC",
  Ds = { class: "flex items-center justify-center" },
  Ms = { key: 1, class: "text-xs font-normal text-[#999]" },
  Us = { key: 2, class: "text-xs font-normal text-[#999]" },
  Ts = ue({
    __name: "OnlineOrTypingStatus",
    setup(t) {
      const e = {
          1: "iOS",
          2: "Android",
          3: "Windows",
          4: "MacOSX",
          5: "Web",
          7: "Linux",
          8: "AndroidPad",
          9: "iPad",
        },
        { t: o } = Te(),
        n = ve(),
        a = re(() => n.storeCurrentConversation.userID),
        s = z(!1),
        c = z(null),
        r = At({ platformIDs: [], status: 1, userID: a.value }),
        i = (f) => {
          var A;
          if (!f || f.status === uo.Offline) return o("offline");
          let d = "";
          return (
            (A = f.platformIDs) == null ||
              A.map((p) => {
                d += `${e[p]}/`;
              }),
            `${d.slice(0, -1)}${o("online")}`
          );
        },
        l = ({ data: f }) => {
          f.userID === a.value &&
            ((r.platformIDs = f.platformIDs), (r.status = f.status));
        },
        u = () => {
          (s.value = !0),
            (c.value = setTimeout(() => {
              c.value && clearTimeout(c.value), (s.value = !1);
            }, 1e3));
        };
      return (
        tt(() => {
          H.on(Ke.OnUserStatusChanged, l),
            H.subscribeUsersStatus([a.value]).then(({ data: f }) => {
              (r.platformIDs = f[0].platformIDs), (r.status = f[0].status);
            }),
            pe.on("TYPING_UPDATE", u);
        }),
        jn(() => {
          H.off(Ke.OnUserStatusChanged, l),
            H.unsubscribeUsersStatus([a.value]),
            c.value && clearTimeout(c.value),
            pe.off("TYPING_UPDATE", u);
        }),
        (f, d) => (
          X(),
          _("div", Ds, [
            s.value
              ? De("", !0)
              : (X(),
                _(
                  "i",
                  {
                    key: 0,
                    class: xo([
                      "mr-1 inline-block h-[6px] w-[6px] rounded-full bg-[#10CC64]",
                      {
                        "bg-[#999]":
                          (r == null ? void 0 : r.status) === S(uo).Offline,
                      },
                    ]),
                  },
                  null,
                  2
                )),
            s.value
              ? (X(), _("span", Ms, ae(f.$t("typing")), 1))
              : (X(), _("span", Us, ae(i(r)), 1)),
          ])
        )
      );
    },
  }),
  Rs = ["src"],
  Fs = { class: "flex h-full flex-col justify-evenly" },
  Qs = { class: "flex items-center justify-center" },
  Os = { class: "flex-1 truncate" },
  js = ["src"],
  Ns = ["src"],
  Vs = ["src"],
  Ps = ue({
    __name: "ChatHeader",
    setup(t) {
      const { t: e } = Te(),
        o = re(() => [
          { name: e("rtc.voice"), type: Vt.VoiceCall },
          { name: e("rtc.video"), type: Vt.VideoCall },
        ]),
        n = jt(),
        { inviteRtc: a } = Jo(),
        s = ve(),
        c = z(!1),
        r = re(() => s.storeCurrentConversation.conversationType === gt.Single),
        i = re(() => s.storeCurrentConversation.recvMsgOpt !== Nn.Nomal),
        l = re(
          () => s.storeCurrentConversation.conversationType === gt.Notification
        ),
        u = re(() => {
          let p = "";
          return (
            !l.value &&
              !r.value &&
              (p = `(${s.storeCurrentGroupInfo.memberCount || 0})`),
            p
          );
        }),
        f = () => {
          n.push("conversation");
        },
        d = () => {
          n.push(r.value ? "singleSetting" : "groupSetting");
        },
        A = ({ type: p }) => {
          (c.value = !1),
            r.value
              ? a(p, "", [s.currentConversation.userID])
              : n.push({
                  path: "groupMemberList",
                  state: {
                    groupID: s.storeCurrentGroupInfo.groupID,
                    action:
                      p === Vt.VoiceCall ? Ft.VoiceInvite : Ft.VideoInvite,
                  },
                });
        };
      return (p, h) => {
        const b = ss,
          y = Xo;
        return (
          X(),
          _(
            to,
            null,
            [
              L(
                b,
                {
                  placeholder: "",
                  fixed: "",
                  "left-arrow": "",
                  clickable: !1,
                  border: !1,
                  onClickLeft: f,
                },
                {
                  left: Qe(() => [
                    M(
                      "img",
                      {
                        class: "mr-4 h-[23px] min-w-[23px]",
                        src: S(is),
                        alt: "",
                      },
                      null,
                      8,
                      Rs
                    ),
                  ]),
                  title: Qe(() => [
                    M("div", Fs, [
                      M("div", Qs, [
                        M(
                          "span",
                          Os,
                          ae(S(s).storeCurrentConversation.showName),
                          1
                        ),
                        M("span", null, ae(S(u)), 1),
                        S(i)
                          ? (X(),
                            _(
                              "img",
                              { key: 0, class: "h-4 w-4", src: S(rs), alt: "" },
                              null,
                              8,
                              js
                            ))
                          : De("", !0),
                      ]),
                      S(r) ? (X(), ht(Ts, { key: 0 })) : De("", !0),
                    ]),
                  ]),
                  right: Qe(() => [
                    // M(
                    //   "img",
                    //   {
                    //     class: "mr-4 h-[23px] min-w-[23px]",
                    //     src: S(Ss),
                    //     alt: "",
                    //     onClick: h[0] || (h[0] = (I) => (c.value = !0)),
                    //   },
                    //   null,
                    //   8,
                    //   Ns
                    // ),
                    M(
                      "img",
                      {
                        class: "h-[23px] min-w-[23px]",
                        src: S(as),
                        alt: "",
                        onClick: d,
                      },
                      null,
                      8,
                      Vs
                    ),
                  ]),
                  _: 1,
                }
              ),
              L(
                y,
                {
                  "cancel-text": p.$t("buttons.cancel"),
                  show: c.value,
                  "onUpdate:show": h[1] || (h[1] = (I) => (c.value = I)),
                  teleport: "body",
                  actions: S(o),
                  onSelect: A,
                },
                null,
                8,
                ["cancel-text", "show", "actions"]
              ),
            ],
            64
          )
        );
      };
    },
  });
const zs = vt(Ps, [["__scopeId", "data-v-9554d2e4"]]),
  Ls =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAuZJREFUWEfNl99LVFEQxz8TREEQ1IOpVJa/MsXVlCxcKVzNVOjHQ9F79EdEEPnSf9FfYL0UgVmaEG5lUYZilqalhpkPRkFFL03Mbe9297p6r7q7dJ5295wz38+ZmXN2RggxVLUSOA+0AIVAPrDNt/U7sADMA/eBmyLyNsi8rLZAVU3wOnAkyNAK80+AqyLSv9L+tACqWgTcAFrXKezf9gC4JCKz/ollAKraBNwCdmVI3DXzGTgnIoNeuykAqmonvgtsybC4a+4X0CEiA+4PSQBV3Qs8B/KyJO6aXQQOu+HwAvQA7VkWd83fE5EO++IAqOop4E6OxF2ZdhHpFVXdDIwBZTkGeANEDKABGMqxuCtXbwDXgK4ggE+LSzwbnqS8uJCDZXvSLh+fnGNiep6GQ+UU5O0IMmnzXQZgr9XRoNW3e4eYmllABJobq6mtKk7ZMvL6PX3xEVAoKcrnzMlQj+dTA5gB7AquOux0PQMvHQAbscYINVX7nc+vxqYZeDzqfFaFzlgdFaXpveQT+WAAP4GtQQA2b6fst1MmRks0wm/VFPHWpgiRyr9gIcYPA9AQC5NLnNPGRxMX2LNTIRb955WwNtcM4Lr8YXw0GQ6Le3N0eV6EgVgXgD8UJpQuMbMCYCFwT2/Bc5PSxCwn1hB/h8888BXYHobWn+2xaDWbROgbHEmCrNET3wzAyqbyIAD/NfQKeRPTMrqzuZ6K0t1BJm1+wgCsWgmsfOwhmp5dcO55uqvmhsaslu7L53RbqIeozwCuJOq+VYnX9hSXUZC3M4wHLhtALTAcZnUW1tS49UCoPMgwwISIHHABrObvzrBAkLkLItLtLcleAHVBuzI0PyQizj+wF6ACiAOhsmcDIF+AqIiMpwDYF1U9lmirslmWt4nII/cAuWxMrBw/KyJWACXHSq2ZFSjWmp3YgKu9W+2xuygiH/32/s/m1E+ZaFataTluLy1QkiZZl4Ap4B1grZc1H3NBHvwDJpMtekZGXbQAAAAASUVORK5CYII=",
  Se = yt(),
  go = ve();
function xs({ cancelMultiple: t }) {
  const e = z(),
    o = z(!1),
    n = z(!0),
    a = At({ loading: !1, lastMinSeq: 0 }),
    s = z(!1),
    c = z(!1),
    r = re(
      () => Se.storeHistoryMessageList.filter((k) => k.isAppend === !0).length
    ),
    i = Xt(() => {
      c.value =
        e.value.getScrollSize() - e.value.getOffset() >
        e.value.getClientSize() * 1.3;
    }, 500),
    l = async () => {
      if (Se.storeHistoryMessageHasMore && !a.loading) {
        const { messageIDList: k } = await u();
        await dt(), d(k);
      }
    },
    u = async () => {
      var B;
      a.loading = !0;
      const k = await Se.getHistoryMessageListFromReq({
        conversationID: go.storeCurrentConversation.conversationID,
        userID: "",
        groupID: "",
        count: 20,
        startClientMsgID:
          ((B = Se.storeHistoryMessageList[0]) == null
            ? void 0
            : B.clientMsgID) ?? "",
        lastMinSeq: n.value ? 0 : a.lastMinSeq,
      });
      return k.lastMinSeq && (a.lastMinSeq = k.lastMinSeq), k;
    },
    f = () => {
      if (!e.value || !n.value) return;
      Array.from(document.querySelectorAll(".need_preload_message")).findIndex(
        (w) => w.clientHeight < 2
      ) === -1 &&
        (setTimeout(() => {
          h(), (s.value = !1), (a.loading = !1);
        }),
        (n.value = !1),
        p());
    },
    d = (k) => {
      const B = k.reduce(
        (w, U) =>
          (typeof w == "string" && w !== 0 ? e.value.getSize(w) : w) +
          e.value.getSize(U),
        0
      );
      A(Number(B));
    },
    A = (k) => {
      e.value && (e.value.scrollToOffset(k), dt(() => (a.loading = !1)));
    },
    p = () => {
      e.value && (o.value = e.value.getScrollSize() > e.value.getClientSize());
    },
    h = (k) => {
      (k && c.value) || (e.value && dt(() => e.value.scrollToBottom()));
    },
    b = (k) => {
      e.value && e.value.scrollToIndex(k);
    },
    y = (k) => {
      const B = Se.storeHistoryMessageList.findIndex(
        (w) => w.clientMsgID === k
      );
      B > -1 &&
        ((Se.storeHistoryMessageList[B].jump = !0),
        setTimeout(() => {
          Se.storeHistoryMessageList[B].jump = !1;
        }, 3e3),
        b(B));
    },
    I = () => {
      const k = Se.storeHistoryMessageList.findIndex(
        (B) => B.isAppend === !0 && !B.isRead
      );
      console.log(k), k > -1 && b(k);
    },
    D = () => {
      pe.on("CHAT_MAIN_SCROLL_TO_BOTTOM", h),
        pe.on("CHAT_MAIN_SCROLL_TO_CLIENTMSGID", y);
    },
    T = () => {
      pe.off("CHAT_MAIN_SCROLL_TO_BOTTOM", h),
        pe.off("CHAT_MAIN_SCROLL_TO_CLIENTMSGID", y);
    };
  return (
    tt(() => {
      D();
    }),
    bt(() => {
      T();
    }),
    pt(
      () => go.storeCurrentConversation.conversationID,
      async (k) => {
        if (k) {
          t(), (n.value = !0), Se.resetHistoryMessageList(), (s.value = !0);
          const { messageIDList: B } = await u();
          B.length === 0 && ((n.value = !1), (s.value = !1), (a.loading = !1));
        }
      },
      { immediate: !0 }
    ),
    {
      vsl: e,
      overflow: o,
      initLoading: s,
      loadState: a,
      notScroll: c,
      unReadCount: r,
      onTotop: l,
      onItemRendered: f,
      onScoll: i,
      scrollToUnread: I,
    }
  );
}
const Gs = Vn(),
  Pt = yt(),
  po = ve();
function qs() {
  const t = () => {
      H.on(Ke.OnRecvC2CReadReceipt, o), H.on(Ke.OnRecvGroupReadReceipt, n);
    },
    e = () => {
      H.off(Ke.OnRecvC2CReadReceipt, o), H.off(Ke.OnRecvGroupReadReceipt, n);
    },
    o = ({ data: a }) => {
      po.storeCurrentConversation.conversationType === gt.Single &&
        a.map((s) => {
          (s.msgIDList ?? []).map((c) => {
            Pt.updateOneMessage({ clientMsgID: c, isRead: !0 });
          });
        });
    },
    n = ({ data: a }) => {
      a.conversationID === po.storeCurrentConversation.conversationID &&
        a.groupMessageReadInfo.forEach((s) => {
          var r;
          if (
            ((r = s.readMembers) == null ? void 0 : r[0].userID) ===
            Gs.selfInfo.userID
          )
            return;
          const c = Pt.storeHistoryMessageList.find(
            (i) => i.clientMsgID === s.clientMsgID
          );
          c &&
            Pt.updateOneMessage({
              ...c,
              isRead: !0,
              attachedInfoElem: {
                ...(c == null ? void 0 : c.attachedInfoElem),
                groupHasReadInfo: {
                  hasReadCount: s.hasReadCount,
                  unreadCount: s.unreadCount,
                },
              },
            });
        });
    };
  tt(() => {
    t();
  }),
    bt(() => {
      e();
    });
}
const Ys =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAiCAYAAAA6RwvCAAAAAXNSR0IArs4c6QAAAkRJREFUWEftlT9oFEEUxn/PO2EDKVJYCNrZWKSwsLQUtLBI4eEFlDQRIxiIENwVIy4Yk7uIJMHGkIBIToyYwiKFhaWFhYJ2FhYKFiksIgh3YPTJ7M1Kcu7dzp4WF9jplnnvzTffn1mhR5b0CA5yIK1K5IzkjKSlc494pKojwBkKTDIpn9Nulbg/rYfYzwKwgS+P2s3ozEhVnwFngS2EMa7J00xgKnoKoQYcANbxpdQdkFAH6OMhMGQHrFDnKqF87wgo1CIetxECW/eCOsOEstUdkLiropeABQQP5QNQJpD3baUosoZwAmUbYQpfqmlMupv1jg5S5AkwiNIAAgJZ3HXAbim+oAwTyKs0EGbfHYipDtWjj7vAFTt8g21G+cE3PG61SHGBUL66gMgOJJ46o0MUWI5MaOiHBkJ/Fimyv6yh9ieas6qHIWKnbIe+Acbx5fVfLLSbsaMwLb73gfORFL48TqTZHAJeWxnm9BzKA6CGL+PdpaaiJoJTUbNSo8Hl1OjGJzX9NA+M2f5pArnZHRDTNaujCPPWAx9RylyXtx1NOKdHUNaBYzZhEwSy1KnHLTUzepRCFF0z2LwNAb7cSxxspPjFyh/gPylxQ96lpccNSDO6RRvdCUv1SxqYiG5G3819I0Uc7TXqXHSV0h1IfKVZPc0+Vu3/w7wTAcomQggcd5Uie3yTOA31IB6rCCdbtj8BJXwxUc60sjOyc3xFTbRHEAaA59RZdJXi/zCS6a5uxf/GiNsZTlU5kNwjaUbJPdKzHvkNtFSqI//VHKEAAAAASUVORK5CYII=",
  Hs = { class: "relative flex-1 overflow-hidden chat_content_height" },
  Xs = { class: "flex w-full flex-row items-center justify-between" },
  Js = { class: "flex flex-row" },
  Ws = ["src"],
  Ks = { class: "ml-2 text-primary" },
  Zs = ["onClick"],
  _s = ["src"],
  $s = { class: "mt-2 px-1" },
  ei = { key: 0, class: "pt-2" },
  ti = { class: "spinner" },
  oi = ["src"],
  ni = { class: "ml-2 text-xs text-[#0089FF]" },
  si = {
    class:
      "!absolute top-0 flex h-full w-full items-center justify-center bg-white",
  },
  ii = ue({
    __name: "ChatContent",
    props: { multipleCheckVisible: { type: Boolean } },
    emits: [],
    setup(t, { emit: e }) {
      const o = jt(),
        n = yt(),
        a = ve(),
        { isNomal: s } = Ko(),
        c = () => {};
      qs();
      const r = xs({ cancelMultiple: c }),
        { onItemRendered: i, onTotop: l, onScoll: u, scrollToUnread: f } = r,
        d = Xe(r, "vsl"),
        A = Xe(r, "overflow"),
        p = Xe(r, "loadState"),
        h = Xe(r, "notScroll"),
        b = Xe(r, "unReadCount"),
        y = Xe(r, "initLoading"),
        I = re(
          () => a.storeCurrentConversation.groupAtType === Jt.AtGroupNotice
        ),
        D = () => {
          H.resetConversationGroupAtType(
            a.storeCurrentConversation.conversationID
          );
        },
        T = () => {
          D(),
            o.push({
              path: "groupAnnouncement",
              query: { isNomal: s.value + "" },
            });
        },
        k = re(() => (B) => {
          var w, U;
          if (B.contentType === Ce.GroupInfoUpdated) {
            let j;
            try {
              j = JSON.parse(
                (w = B.notificationElem) == null ? void 0 : w.detail
              );
            } catch {}
            return (
              ((U = j == null ? void 0 : j.group) == null
                ? void 0
                : U.notification) === void 0
            );
          }
          return Ln.includes(B.contentType);
        });
      return (B, w) => {
        const U = zn;
        return (
          X(),
          _("div", Hs, [
            S(I)
              ? (X(),
                _(
                  "div",
                  { key: 0, class: "group_announcement_tab", onClick: T },
                  [
                    M("div", Xs, [
                      M("div", Js, [
                        M(
                          "img",
                          { src: S(cs), width: "24", alt: "announce" },
                          null,
                          8,
                          Ws
                        ),
                        M("span", Ks, ae(B.$t("popover.groupAnnouncement")), 1),
                      ]),
                      M(
                        "div",
                        { onClick: Pn(D, ["stop"]) },
                        [
                          M(
                            "img",
                            { src: S(Ls), width: "16", alt: "announce_close" },
                            null,
                            8,
                            _s
                          ),
                        ],
                        8,
                        Zs
                      ),
                    ]),
                    M(
                      "div",
                      $s,
                      ae(S(a).storeCurrentGroupInfo.notification),
                      1
                    ),
                  ]
                ))
              : De("", !0),
            L(
              S(Wo),
              {
                class: xo([
                  { "!flex-col": S(A) },
                  "my_scrollbar h-full overflow-y-auto",
                ]),
                ref_key: "vsl",
                ref: d,
                "data-key": "clientMsgID",
                "data-sources": S(n).storeHistoryMessageList,
                topThreshold: 120,
                keeps: 50,
                "data-component": (j) => (S(k)(j) ? ls : us),
                "extra-props": { showCheck: t.multipleCheckVisible },
                "estimate-size": 80,
                onTotop: S(l),
                onResized: S(i),
                onScroll: S(u),
              },
              {
                header: Qe(() => [
                  S(A) && !S(y)
                    ? (X(),
                      _("div", ei, [
                        de(M("div", ti, null, 512), [[fe, S(p).loading]]),
                        de(
                          M(
                            "div",
                            { class: "finished" },
                            ae(B.$t("noMore")),
                            513
                          ),
                          [[fe, !S(n).storeHistoryMessageHasMore]]
                        ),
                      ]))
                    : De("", !0),
                ]),
                _: 1,
              },
              8,
              [
                "class",
                "data-sources",
                "data-component",
                "extra-props",
                "onTotop",
                "onResized",
                "onScroll",
              ]
            ),
            de(
              M(
                "div",
                {
                  class:
                    "absolute bottom-5 left-1/2 flex -translate-x-1/2 items-center rounded-xl bg-white py-2 px-3 shadow-md",
                  onClick: w[0] || (w[0] = (...j) => S(f) && S(f)(...j)),
                },
                [
                  M("img", { width: "17", src: S(Ys), alt: "" }, null, 8, oi),
                  M("span", ni, ae(B.$t("someNewMessage", { count: S(b) })), 1),
                ],
                512
              ),
              [[fe, S(b) && S(h)]]
            ),
            de(M("div", si, [L(U, { type: "spinner" })], 512), [[fe, S(y)]]),
          ])
        );
      };
    },
  });
const ri = vt(ii, [["__scopeId", "data-v-c0492f7f"]]),
  ai =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAACjBJREFUeF7dW3+IFPcVf+87c3cbOeGqN7M3s7NUiaVKDUQaQYmQKxiSgFILkSi50IRG2tCE3B+WWGKJJUINSWhDEmppggYNXonFFoUIKXglFlNi0eAVr8SicLM7uzvr3ZU7vb3bne8r37nbzezs7I+7nV3R+Xdm3vu+z3vf932/vggtfno07dudIG1BgPUEsAYQ1iBhDwB1A2KvYE8EKQTIAVCWAEYRcBTQGZmbmRmemJj4XyuXiC0gLq+Mxh5hDHcxwK2AsKoZHgR0GQnOkkNDmUziq2ZoBf0bGgCqqkZB7twLhAOI0Bf2Ql16RKMc4HB+ZvqjycnJyTB4NA2Aqqr3g9yxH4HtAoBIGIuqR4MAJon4ezmkd6aSyWy972u9bwaAiKLFXmXI9jYsOFGWEK4B4CgRFRDBXPABBiLKSLSKANc2akECCCC+L2MlPgSAwlKAWBIAqq4/jCQdr7e/CcgEwjOcO39Hnh+2bTvVyCJ7enp6Opct6yeSHkGkbQi4puZ/BBfzlH92PJX6dyP0vd8sGgBFN15BgoNCY0HMhGYBYMjh/KOb6eTfFrugoO8VXd/COHsKGD5fzdqIaBqA9masxB8Ww3MxAMiqZpxAxCerMMhxgsPO7K23x8fHXdMO+1EUpQ/kzp8j4CAidldRwPGMZT7X6JZoCABFUbqZ3HUaEPurMD1LhdmXbNu+FrbQQfRWrIgZUie8yZjreCseDnQG8rO7bduerreeugAI4VGOfIoIW/zEhNlxzvdk08mheoxa8b43GtsmMTxSDKi8PIjgPBVyT9QDoR4Awuw/QcQdFcIDXaY87LRtsy1arwagsIaOLjwWZJ1EdDZjmdtrbYeaAKha/PeI8LMK5kTDvDC7vR66rdB6FZqy0hc7FrQlOOdDdiqxu9paqgKg9MV+zBg7GmD2JzOWKQgu6dxtJSiKFv8tQxj08+AcXrRTY+8H8Q4EQFGMNSjDJb+nFfsqY409Cm7i0vQTUXTjaeAYyeemPg4rtFU14xgiDvhWl6MC3xSUSwQBIEe1+AVAeKjcqdAIFWY3h2T2sqobnyPgJpcHwY3ZmakNIYEg/NZpRHy8DASi0bRlPuC33AoAFN34CQP8wCf8dJ7nN0+k0yNN6x0AVkRjmzokdsFLy3Gc3WGdJst1vfc+kq74Q2oOtM9Omm94+ZYBIELQrvu6v/YfK45De7JpswyUZoDo7TP6JYbnvDQ458/ZqUSFz1kqn5VRfassSZ/5FVmYpXXj44lSoFYGgNpnvIYMD/hMZzhtmT9Y6kKC/msHAIJvoD/g9F46Zb5UXFcJgPkEZPl1BOgpvhRxvTPHH7h5Mzl6NwIgQmfsiFz1yiQcOM/nVhcTsxIAima8zBB/V2YywI9mkgkRV4f6tMsCXCsIsGpO/KBtJX4l3pcAUHXja2/aKbRPhdl1rYjv2wmA69eWLbe8WaRI0zNJM14CoFfTHpJQ/rJczXQmnXTDyNCfdgIgFh/tM94Fhi96BSk4zqMiXXctICiC4pzvtFOJk6FLDwDtBiBIwZzoA9sy97gARDXjKiCu9Ti/6YxlKiFFfBUYthsA1xf4trgIvtLW2GoUnpJ1RMQeKT1E9JeMZf6oFdoXNO8EAEFWPsvzq1Hpiz3JGPukTFiiwbRlvnMvAaDq+g4E6ZRXJhF9YuAxkecbbDtx+V4CYOE0mPAp+pCwgBP+PJrnc8tDSnoCMbwTW8D1A1rc8uYHRHQSo1r8S2/m5z0j7yULWHD257yVI7ftFtXi18vq+0QNx/6qqj9MrE7NPgBFJk4cxH3eV+JYAqLziwWdAG9kU+Y/GinQqHr8CAI8+423hxsY1Qy7LPtrEABFN04zwG2LXXArvhdVYDvpnlo1q1SKZvyRodtbmH+IshjV4+Q7AkXJa2ethQZHjq0QrXGajsO3Z9OJM7X+UHXjNYTybLcCAID6IXBQQaPxpbbmy0YKKlHN+I1/66HfM8JduAWIaCRjmRvrRa6VPkBsgQonCBfT1pggVvdRFH0LSEtwgoBrgeErPif44VKcICMy0+nkcL39P38M+gqm5DpB/zEIk5nk2LfqSt/EB3cqDvDLCgQXAwOh21OOMjXV3OBBTSfahppgEH9Vj094q0OiaSIs4FVAOOgzxydsyzzbhJJr/nonLKCnr29VF+u4XrYwgv0YlCQA0aG0Zf7yXgIgqNMlah4YlCQQ0BeZpLn5XgJA1WNHENg3USAA3AZHcQsiqm5cQsAHvQLnc7firRp0uANbQI5qhuWNeEUekEmaG4oVoYoAgTjszaTG3m6FFbQbAFXTHkOUy3waAb2VSZq/mK8JKrEHWQe7VO4gaGShlxY6Bu0HwDjln3FwqLAxa1kXS2XxqGZcAcT1ZdI6zo50OvnXsBFoJwCKoqxBuetq2VDXfKN0nZCrdmOE6HLGMjfczQAEOT9ONGgvlPy8vcGIqsWv+zuqRDSQscyPwwShXRbQq2nfZyB94dW+GK6cuz21utiKr9scFZPcczNT60Lq3bs4tgsAVTculGYQFjRInA5kUuaviwqtaI93Luu+goCGLzJ0mwhhWUE7ABADnQzwkM+xZ2dnpr/jVWbFgERvVN8lSdIJv7DccXbZ6eSfwgCh1QMSYpQXiA37p1kdoj1Zq3zOIXBGSNXinyHCVq+w7kwgOP1Zy/pXCCDIqhY/V5w9JKBrc7enN4axzdyWuBy5VOHLqkS3gQAszN5d8k+KCH/A0enPJpP/CQGEiNIX24UIkbmZW0NhCC9GY5YR+9zb5hPrFMqjAmwImmmsPianaI+zDvlTv6CibM6Bbw0JhBBwnCcxPwzRdcrv9MS7AtEzNy3zeBCzmoOSihZ7nSHbXwECQcrhtONm2vxnaBI0QUhV4/ejRGf8mp/XPhzOWGMvVCNfb1Q2sLdeMisOg3baFJcV7tijqtpjKIm7C/MXsHx+SzR5RYW7arm8LgAAUHNMXlRV8rlbL4SxhxeJYkTVjdcRUNxYqXjCGpYuEhZe+93AueF5c8hyBDGD1xZrUKL6U4xJh6rdWAl1XN4LbTWfUPqGaIQTvWWnEiJ0Dn2WOBrVf0iMHUAsr134zD78CxNeBitVfYckS6LHVhqnq9h7QCYRHXXIGVrKPR4vPfdWGuscAAYDde4O5Yj4YCuvzJTW5RYYURYXFQJvkJR7IrhByIeJwzByuEw0998arfeIqsa+S0hrkUn9CNQf5NkDnN0IFeiZpcw0NOIEq/omVTMGAPDNRq+5FQkVr8oS0DQgFMRVWkKS/TlIPacoMjskOpC2TDEKv6Qt1xQAYoHuhGmk+2VgOFhrW9QTZjHv3chODHQXcm80ehWvGv2mAfAQjiia8VMG8HxFZWkx0tX4VuQMSHR0dubW+2Edu2ECUFq6qDFiBz4NAFv91eZFY+HeF8azgM6f7WRy0QMU9fi1BAAv0+ItUCTpe5z4eoZM3ALtJYBI0XfM72WYJKRJILhGQKNA8BU4c+ebNfF6APwffOF6jY/H7kYAAAAASUVORK5CYII=",
  ci =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAACt9JREFUeF7lW3+IHFcd/37fbO5udxa81Jz0dlZIaYtJbHR3tkVDU0ygxYSmUDFiQiOmNKEBE4xY6UFbrFhJihUjjdSSlLZYSSSRBowkxUhPmmIg2d2zrc1pIw24sxfN2UQys7e523lfebO3l/m1Mztzu6fQ98/Cznvf932f997390PodRtakZYTA3cDwzsQ+TIgvIMAbgbABCJkxfREUAGgBgJcAqT3iNg4cHrPaNTfhsvv671kEXtBvP9ThVulBG1hCOsI8E5ESMSZhwgaCHSOE5w0G/ja9X8V/x6HTtCYbgKQkJXcQwjSNkBY3W1GLXoEpwnMg4Y29isAaHRjji4AsHRAzn7yUSDajYhLu8FUGA0iugiI+4zKv18EuFgP69+zEyAPq19GCfYD4G1hTBDBGAJcAIBxAmoeZaKK9YtoyQIEvBUAlhHAbYiQC6MJQBfIhJ3GROmN8L7+PeKdgExhSZrRAQB8sO3ERDoQHjaRvzFl0Cm4OnY1EpODucFUCtYwkO4HRhsBcLD9eDqmc9wO1eJkpDks0CO2ZCZ3N0PpcEuCu4dbO038Wb165dh8j+cN2ksHksriDQzxcQS8049loUk4mZumqmNvR1lSJABSGfVbiLjPV6oTnSGip4xq+VQUBqL2TWdza4DYHkD8og/4DSLaXauWft4p3Y4BkDP5PcjYiJcwXeUEIzWt9GKnk3ajX2o4t40xaQ8gLPHQI3hG14pPdTJPRwDIivpTRNztRZxOwXT9G8bl9y91Mlm3+8hDK26GvoFfIuK9PrztM7TSd8LmDAWg3c5zTk/XqqUfdUsfhzEa8D2RyqhPMIZPxzkJgQCIO88Y7rcTFtYZAe3s2ZEfzA3CoulGVBM4lck/gsh+4ZZPnNPOIJnQFoBZaT9qJygWz4FvntLKR+exY+2HDq1Ip/sGTogOulZaG/V0JZX8RgbskIdnMte00w7+AGQKS2SEslvVcaIdPdt5gERKKRxiCBsFAJzgaE0rfi0q0OIkMMYOuk5txSDI+9kJvgCks+rrbiNn9s7/ICpDnfZPK4UXAGGHg3HOR4xq+dlOabT6pTLq990yoR2gHgCa5i2edCJIpwyttD7qkYzCuJwtfBsB9rnlDQ84vkGCUVbUE27tQCatc5vNLgCWDqSzN73rtO3pKl2vL18IVSdn848jsL3OhdEFvfLRyqhWpVCR2Jd812kneGk5APDbhR7fe88myop6CBE32T9woidrmqVyIzXLWJKkA45TBbDbqBR/1vrPDkBCVtQPHC4t0RldK62KNOt8OwtN0D9Qtp9CAqjD9alb4pzCtKL+yW42C1fa0Eq3t67zHACykvsmovSKSwjd12vb3g8veVhdhxJa6rDViKgjy85Nz/IdQHrTScvcamhjr4r/5gBIK4W37JEc4dUZWjE/3w11jxfGVW2m/mqYoZPOFl4HgBvuNpGuG/zTkd1qAJCz6lmHF0lwWteK98wB0D+k3raoHz9wMMv5Zr1aPtxNAOZ8CoJx3TBXBS1GVnI5RKkcdH875U0YSBKyI/b+M9fp9uuXSxesE+DRmwJt7aOhqJI3iCG3Q0XERw2tfF+QapUV9beIuMF2D2LKJEu7TdiDKi3BagHgFhTA4aBeLW7vFOGwfn7yRYwJk+5BOxc2p0cWZAoHgME2N5gIIm7fl7xit585N79Sq44dizpJlBMg+grpbjbM5fVLYxf9xy4dSCs3XQbEdOt7XLWcyuQeZEwScsVqwq8xpqcWo5/E1XVzcRxhEwaYn44Hzg/q1XLb0+Y2y4nosKGVNofN5fk+mBtMp6UrDpli0nqUlcJ3EeE5GzI9kf4W/cHcoJyWzqOVGZrdCYC6oZvD7QD3GmfCmrP0eOQmKwXh4M1Fm4ngMUxn8wcAmO1uwFE9hhfWKTe+MQaTthgTJZHs8LSBzOdXJ1jiLfsHvVJcFMcvSSuFIzDrbTbp8YPoEYAR4mmdLtrZz3uviegVQys97EfPsun7kxOObzMzK/V/vvNe1PnTSuGHgPDk3DiiMygr6od285eIHja0ksMiDJsopeTuR5BENCYLROMNoJ11rfyHduPc6i3M6JKVwowz0mOu1Stjo2F8ub/LiroVEV++cd3popAB/7AHPqICkMwWvsAITjuiMAD1GT6dn66+O+7HpM9OTOpaaSgAMOcmmbTemCg5XPZOwPACABVMZwtkH0ycR7L/ZUV9GRG3uhkgoOeMSul7vgBk1J3A8HnXvW4bnuvGKRVzyZn8vcjY7+3zzh+ArHoCAdd5AAi41ylFfYIhPnPjKELD0CzB5tvcAMS1U3wBmO8V8A9iAHATttcmio7YXGt1qaz6PAPcab+Lhla6pR0AaUW9ZjeGALolA6AyfyFoRXKTJ5yeZHAIzauP6bihlR7wBcCKDySv2b+ZRKumtNKZTu69vY+vEOySGkykhgtbmUQKcPqrXrXC5r4FDH2Zlcv6WN95O2NBPkFqOH8nk9hZh7zg14ag+rfImWA5U9iDDG6k94QaXGhDyE9oEpl5Qxsb89tRT5ibYFLXim01RtCp8DWEFtIU9ku2QEjYTVZUkfvbYhOYo4ZWFEmTyM3XFF4oZ6g/87nPJNiiUbsfIFbAiR6oaaXj7QVg4bI9shs7P9HOGVoId9gylgCOuRdPQCeNipVv8Fd/PjmKBod76tXi6ajb39YdFoR6GRCxUtj9yQ8RYMDBNMGkCTP5Ke2dZp2QT0sphSOtVFnzM13VK5bFGLlCLN02IOIXErMm+mi4WyExT9KSSG+Qub5e/XPbnRRxykQfnncEaoD21yqlXVF3H8A3sGLlGizz0y8oagLfOFUp/yb6ZP4j5kAAqnOAzUH3XlCIqi2C+Exm81+VgDky2o6gaPMauMLiQOeMSumubgEg6Ih7CISV2kT5XBDd1LBaYBK6+4zqlZjSPywsPou4w1VsMsjX6JXyH7sJQge0ErJSOOutE4xn/qaz+S8BMIfrbPd4/+9SYx5rrYlY7N33CHiwQmrLPakx6xT4pKg559tq1fJLHezcvLvIw+pDKOFrdkIichwUWwi8Sn7FEgHJUbCkpTs9TjBJ01Mr4yQmoyAirEQJ2Umn1yfC1/wxQyv/JAotazPjpMetgf6JyZ4WSLRffOzCDJHp9iuQ8ESS2pTIuBKTQhw2y+J6UiLjX9xEFw3Cu+LU//qVyLTLJ0QrkuqhPLDLHwK4NMNh7XS16BtTjHzvCaIVSYkJRDxewsSbnpIz5Ju6aSDZFyNn1R8D4Ja4ixcGDyMmCrnnXqiIFJhJjbXtrM54hZLEd/RKMwjhFUfgphT1UQTc37VCydbOeELYsx8+FqWyLRA+1sXSYScBCCY58ZFeXYl2As8KlSHbuyDl8i0mwh5MANJIr30Hy7Yn3LvgDyZaIMxqB1GQbD108jSiMybSc1OVK7/rVjxBWKjJ7OL7GeBI0JMZkxqbg2IMfuyGvhfwXWSmsCSF8IIzWuPuSVeB41EO5vHalDQKV4r/iWTOLi58IpU0xaOpDYC0yW0iO/wFUTRBuCuO0RQPgNnZm2YzPN/pszkAGkfAC9R8Pifsy9lwGJt9Ngfi+V3UZ3O74iRKWwDOC4AmkYV/OGm9FwTc/z9/OOk60sIB2YKAj/T26Sy9ZGgl4TJHDox2TwaEXGYRY5T64OsMYENXHk8DHDen4deisDGSHOmgcxeuQMgszefzq4HhZyM+n/+L0aifDiup7WCNgV3+C5sZG8fa1hccAAAAAElFTkSuQmCC",
  li =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAADJlJREFUeF7dW2uQFNUVPuf2DCwvgWW7p7unR60oQuIDDcS3VFlRLIKW+EqMgorxEaMVYyjfGGN8xFjGaIpQARVRwVdUNDEaNL4SYohK1KgBkcTH9ExPd8/iKuuyuzN9T+oO7Gz37AzTPbNL0Ptz5p7Xd889fe855yIM8Rij620jiE0HhCkIOJmAJgOgDAAjgWhUSTzi5wDQBUAuAq4noHVA3ltbOtlfNm/OtA+lijgUzBUleQhI7GQAmoGI+zQjg4jeBoRVngePttvmP5rhVY120AAYO3bX8cNH8YsR4GwATA22ooIfEXxAAHcXuzsXfvLJJ58OhoymARCGt4zklxHgDxBhl8FQqh4PAugg4guL3V23NgtEUwDICf1sxtjNgKU9XXcQQAGAPgKAj4FjJyBtFhEACEcT0hhE3BWIdkPEWF1mwiMALE50ad4yV4SZP2hbYJyq7j4M4/cjwuHbFUzkEuLTSLS62MtXt7dn3wcAr46ysQmaNlECdgQAHo6IswCgtY6cFws9dMamTRkzKhCRPUBWkycjY3chwNhawjjRi8D5YtfOrgSA3qhKVcwf3qYbJzGCCxHx0Nq8qJ1zOMPNmU9HkRcJAEU1bkGGl9YSQESPc/BuylvW2ihKhJ0rvi4UY1cygONq6sDpOidn/jQsz7AAxBTNuAcR51RjTARrkfOLbDuzJqzgZubJmjYdQVqIiPtW48M5X+bmMueE2G4QBoCYrKYeZ2wg6qWgxvmVTi7zKwDgzRjVAG1MUY2rAOEniChV0hPRk45lnlQPhLoAKHpqGQKcOUBBoo8LnL6zaQetei2A2tTkkYyxFQigVc7hRHe7lik8oebYLgAJzfg5IF4xEF2+FnnxW7ZtOw2s3KCTtLYmjdhwfKbaqZOArnOytWNCTQAUxTgBJHgMEQNziOA5B73ZkM12DbolTTCUZXk0xlpWIsJRfjZUGjDLzZnPVGNfFYBEIvEVkob9s/JTR8RXOxbOADC3NKHr0JEaxgiFw/MIeEhQCLUXe2BKe7uZqRReFQBFN/6OgAcHJhOs69my+dCOjo6OobOgec7b7iRC/0kVILxgZ81v1gVA0ZLnIbLFQePp82Ivn9benl3fvIpDz2F8IrXPMIleBcARfmme5303b2cf8v8W8IDRqiqPZPENCDCuYh/NdSxz+dCrPngSZFWfx5i0NGCHuDv0bpmUz+fFHaQ0AgAounELQvCkR8Sfc6zMjMFTbcdxUjTjZUSc7pfICRa4VvrGAQCMHz9+bLxlVBoRx/T9SURFD7z92i1r3Y5Te/AkKUpyCki41n9QIqI88sLutm2LLFS/Byi6cRkC/qLC9e90LPO8wVNpx3NSNOM+RJwbjGn8x7ZVOr0GANiAgBN9q+8hL+xl2/Z/I6rdouj6VM9jxXbbFJeiYkR6//TYhIQxVZJ4zMlmBa/uqLwm6Ppkidi7iMjKtAT/tq303mUAxC0LY+yVitV/wLHM06MIbFOTsxhjy/uCKAFt5MCPzWez70XhI+aKSB6XaCUC7lmiJcoTeHMcy1oVlZeiGSsRcXYgFhS8r7tu9o1SEFRUYyEyvDAAAHjHONnss2GFybKsYmz4+4g4Ouhu8KFtpb8acfVaFN14HwGNikXppGLPRNd1c2H1Ktmnp2YjgMhN+JyAbnWy5qVbAdCN9xBwr7L7A1hONi2Eh77hKWpqPjK4tZpiHqcj8znzpbBKJxL6USBJz1WdT/Qj2zLvCMtr27x4QjdsABxftpFgrWOlp6FYORZvsSqQXuJY5vlRhMi6cTkDvLkqAB4/Lm9nngrLT9H12QhSYMX6aDnQFW7WDATrMHwTevJBAHZqPwDEC92ft6KsJr/NGHu4AoA5TsREY5umTZMw9loVZbp7ujZrUY7QopgyEqQ0ALRU8uMFfoDrZt4MY7R/jqImL0DGFgXiANFMlLXUDQzhav8fhW6eaiTBqOjGtQhYTkeJcwTnfG7l8TOM8rKaPBMR7/JniDnxG1wrc00Y+so5raq6d5zF3wksNKfLMKEZjwDiKb698ZljpWsmPOsJb00kD5YYzGLAunmx+2HXdTfWo6n1//hEYp+YFJ+FAC1U4M+7bnZ1o7wAIK5oRlcw5U5LUdGNNxBw//7wSK/alnlQE4J2WtIBwZ5gtQAgg4C6Lzg86lhm2SN2WmsaUEzRUs8iwtFlW4HeQ0VPdfgTHwRwr5NNn9UA/52eRNGM3yHiyb7FdlDRjIJ/XxDwRU42EzgU7fSWhVRQ1oy7GOL3+j0ACsIDehEg7guCix0r/f2QPL9Q02TNuJMhlrPE4islvgJ5QJzgc4sVjmVWLYB8oaytoqysJh9krP8wBEDtqGipDxBhd59b/N7Jpo//ohtbTf+EbjwFUCq2loboNxAxYA0ilj97BPSWkzX7P4tfIiQUzXg7UDsgek0AcL+/5kdEXY5lbu3d+XINTOgpkc4f7tvuD6Cipq5BBj/z29rt9e7xafREyE4NV1tbci9pGAvkJYjTtcIDTkDEx/3ac87PcnOZexuxqE3TpkqIBi8Unnddt7MRHpU0bbo+CThT87lSk1TkrJDgl9CMcwFxSYWdp2ApFY4xO1AC47TUzpnl72VYI2QteT1DtqAUYIA2bgF+yOZsNh+Wvto8WTMuZoi3b4ta67uQH9EIT0UzViDiaT73J+QFtZQQSWipdwHha77oaDtWOlmvtFyhcCyhp0S+vXyFJYI/O1ZaNDM0tGqlFBviE4ELTKMJEc2w/J97IHrHtsx9SwDImnEHQ/xhwD2IZrqW+acIqzcAgG2esKaXvFM7LEs0R4Uespq6EJFur2yY4hwucnPp34RmJBY4oR8PkvSEn4aI3+ZYmfklACaoxoExhoEmRM75w24uU86ghBG4naxQNyf4LXo9Cx3H+c92eLUomiG+0wsQfTfUbQQEZG4BfkDULaBohqhyn+iX61HxG3nLer1cGRp4VaQi8sKkqGnxygvHAGOJ1hPA64CwkQC6S3d9wnFYaqEF0RUWTKr2GU/UWeR0dNSGjBpp8XW2lS5t+X4AqiQ1iaiRwkhMVpP3B4+cYfyn9pxSY2TBO66RhEjlOae0LYnPd6zMbQEAEonEKJDiHwH47gUABY+KUxopjW3bwzfXWtHQkBC91EPFeR253IehabZNlOXk/hgrlcb6iyJAeRv4bn0NHoHiaEJLLQCE64PBgp51LPOYqMJLwVWWVYi1XI5A50QGguh18viNjpMNBK8oelQvjvKrXStzUx+fAABtbW1jWHzEBkRQAwHD807P29kHogj3zxXtK8TixzIJj0HCaQQweUA7bKnyg28S8JegCH9sJPPrl9mWMM6RJLwzuJiQo2K3KKyUD2gDOkRkNXkWY+yeCi/o5AWams9nNjQKQiWdaGziw7xST3Dc8/KDdWoU/ERVGGNM9CwG0uqc83luLrPMr0v1FpmKG2KJgODd3u7Ow5rtzh4sAGvxGZNMThhBuKZcU+z/irzqVEn2VgVAluU9MdaytrL9fWdvkhKBnFj8BUQ8MAAQ1W7xqdkmJ6vJUxhjj1QiTUSrHAtO2Pk6xYwRioZP+rO+fbpTkeY4TvWW+u02StZqjhaeUOjuOnZn2Q6tra27xIaPeBqRHTZgwThf5ORqJ3nrt8pW67DYGhPe4UU60XVN8Qbg/zba2vRJUlx6DBBKDQ/+wTl/yM1lRI9DzSp3XQAAoHazNNFm4vxc184Giqs7Co22hH6axNgSQByQweIAf3CzaXH+326HShgAhD2iXX7pgF6bvggL9GSPV7jkU9v+YEcYL8vGnhiDXyPizGryiGi5Y5miuFPvdUqodvmyjDoPJrqJ+CJe6PllPp/PDgUQ43V91xix+QxR9C6Uc3uBMwunW5yceXlY+WE9oMyv9GQG2d3beSHWSxweRPKW23b2xTCrUEfZmKwZRyHAXFHF9hdxAoYTfAZA8xzLDKT36gERGQDBUDRTgxRfAZX9xAO/mQ4hPkNAf+U9/G8hH03FW1V1YgylwwHwCESY6b+gVXV5oFd6efH0Ri5MDQHQp4Sipi4ABjdVttbWQn3bszlxq0tXPptDpDEEuBsA7Rr22RwAbSKiqxwrE+xtrrfsvv+bAkDwURQlgWzYJcBQNFSWm5Ai6BB9KlE7AC7pQu+2qNmhSmFNA9DHUBxDOcbnIcL5zb4Xru1B9BZwWuzEcBmYg/NmYdAA8Cs9IWEcJEl0JgDOQMA9oi9xPwURbSCCVYTefSKH1wyvarRDAoBfkLj2shacLnHYjxBE3k88nx8HQCNLT+i3ji4A7EKATQQiZ0jrgNO/gBdejtoUGRWg/wE+Jm8lrhnMBwAAAABJRU5ErkJggg==",
  ui =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAACs1JREFUeF7dW32QW1UV/537ku4mLxUr/WDzIgrSlnbobvMiIiCjYhFEGRTGUYEWBhAGabFMZVSoDg7FgQ4gHwVHPnTaSmEGwQEHhkFgVD51yMu28lGg0FHystQtpS15ye5mc49z093kbT5fsknp9v2XvHPPPed3zz333HPOI3T6mbmgJ9AVOEkDegEsYKL5AA4lIMiMoJqeCBkGMgA+IOatALbmgS3Z4exz2PnGQCdFpA4wFyHD/IoknEVMS4igFG75YcabTPy04PzDaXvz3wHIlplVGdg2ALqMvnkaxEoCnU1Es9sp5DgvZuxg8MP5EfxmeNDa1o45Jg1AcGY0TF20BqClRPC1Q6hGPJgxCuYNPEKrMzvjk9oikwHAp4cXryTSfgnC9DpC72HmF5npZYJ8Wwr5DphT2TQ72PPvjwrjDlk0PRAiHQRDSPE5hnYUEX+RiE5Qb+vw3svM1zq2dQeA0UbAVXvfEgDBnujnhaANIFpQjSmDByD5IUn0QNa2/jWJfSsCRvQ4wfg+hPguAT3V58NrnOfzMwNWvFkQmgYg2LP4YtLEOgJ1VUymHBbk9Y6d2AQg36wwDeg13YieSxDXgDCvnJbBw5C4zElZf2hm3mYAIN0wbyGilVUm2CMlX5NJWb+dxGp7lVsLhKM/0oS4rtr2YJY3O3biJ16ZeQXAp0ei6wninArkpdxEEivT7ycGvU7aDrrQnN7Z7PPdTkTfq5SJ73dS1gVe/IIXAHy6EXuUCKe7J2JGhlmuyKQSv2+HQq3yCPaYPySNbiMgMFE+ftyxrW83AqERAMrsH6iC8jsjeT5jZMB6o1XB2zlu2pzeY/x+/2MEHFEGwoOObSmr5Vrz1QUgaETvEiQumzCY8aYclidndiZS7VRisrwCRm9Eg+9ZEM1185LgdZmktaJpAIKGeYkg+t0ERIHtPIQTJxt8TFbZWuODM2M91I0Xyi1BIn9JJtl/j+c4QDeifSDxMgHdxUHMgzmSJw4n+9/ulALt4NsVWTzXz+J5uMJxBoZyudyxIzu2vFo+R5UtEPPrBm8mV5CjGHCev9RKoNEOpZrlEexZFCNt2vPuBWTgNSeZNYHXR9z8KgAIGubVguj6sn10SSZpVTWhZoXbX/TVt7D8mZNM3FgTgO7wwsM1EdjqPlIk+JFM0jp7fwneznmChvmwIDprnKc6uiVy87P2luT4fxMsQI/E7iXgIpcQe+QQFhyoTq8RWOqmKrrE1gmXNea707Z1aQUAgUP7DBHwbSfAP/5SSl6eSVl31psoaJiXCmANiGZOpOPdzHKlY/evd//fafpyWQPh6BWaELcVrQA8zEPZIzJjmaaiBegRcy2BrioRYruTjKszte6lJhQxPwTok1VBYt6Ztq1Z7nedpq8ih083zG1E9JmibhI3OKn4z9XvcQCEbsRSRJhTWn1cnknF72pkZqFIrGaUpcamk/EJ26zT9NXkDYTN5ZoglTMoPOq67iStiLq4FYQLRqLfEBBPlJwFf+jYe3uAbcMHAwCIRAI6z7aJaEbJCkZPdVKbnyoAoBux9URYVlx95rszLkdRD4ROr2iz/GvJGgzH7hWi5OCZ5XrHTlywD4CIaRMoXLIAucSxE880Wn31vlkBO01fS2Y9vPgUEtpTJR3xnmPHD6euWeZR/i4qhrfM7Di29QmviY36Tg0703a8CSc4efo6i6au9XuI9tUi1DOayx2prrsXEFExjcTMzzi2tcTL6hf8R+EYpDUgNHEMdo6+nty6YT5DRCe7LH0Z6eHYDSTw0+JAxpq0Hf+FVwCmEl3IiF0HwuqSrvxrChnmn0BUDHWZ5TLHTmycSop5lVU3okuJxAaXBTxEesTcTCBVtys8eZYnZO3ES16ZTiW6gBE9XiPxossR9pNuxN53B0DKMQzt2LJ9KinmVdbuOb1H+Pz+d4sAAAMUMmJ73ZeFNDszYW/9wCvTTsf2zfKvK3d43syQmO7KXvNuZQGjRNDGB6aTcXUZ8lxm6nRs3yz/+gu3cFooEihGt6qYonzAMIGmlQDANCCe82oBnQ5smuVfX+6YPxRBMSPE4BEKRcxdQClGTqfzM7C7f/dBCcAhi2aEpk/b5Tryd6kt8B4R1M1o3ymQHY1kP9hsH4wABMLHfFoTXf91nQLvqS3wGoEWjv8p8/LYzEDilYMSgMP6vqD5fP90nQKvqlD4MSI6o/inlOc4qcQD3gGolxCZfGzf7F2jntx6xDyXQH900TxKuhG9iUisKv4p+VfplHWtVwCm0l0gZJgqdXdNabF5LQXD0YuEEPeW9gU/7djWKV4BmEp0FZchyRdSV7h3vl/4VWta4Rm7Dqscn+dYYIqAUHEdzg3z3LGESCzlbj9hmf+6k+r/6xRRzJOYeo95Kmn0ZMkBcspJWsZYSszcQERLiyeBxH2ZVPxiT5ynCJEeNu8jQReWLN2VEgsa5rcE0V9KuvCHafzPQDKZbVW/2jF8qxyr1xk8cYtEAiHMTrnT9xL5b2aS/U+Mp6zV/hggV1YnL3lFNmWt8zRBFaK6x1erTKvUGbywCoSjKzQhbnf5uUHHtlQOdLRUGDHMW4noxy6i/zi2dVSrzrBRDO9F8Go05XUGD3zU4r5DhMNdut3q2NaV6ncRgLHC6LZmS2O1BDhQAKgsiiAnM7kjs7v2FUjLqjbRewDhdn57MCrnttIB1pktUBlZ1rMA1UkGv/+tCe10tYqjitFYn80bIAq5zGWjY1vFookHkyuQ1I4QvXIop2veCeqG+eCEBi/mtBzm+e7+pooGCd2IrSLCTe7pOc9LnQHLHUO3qsV+G1ee7lcTM8tVjp24xS1EtS4xTTdirxBhcdEKgCw4f4Jj9/fvNw0mMVEw3Bcl4VPNUsXeQWaOO7Z1XHm1u2qbnOr990GziEgvbQXsGKX8SVOkSeoFEJUqUszp3Ig0hwcrG7xq9gnqPeZ5pFF5feBdOSRPOtB6BMcXaazJ47nyNrm8lD/IphIPVjOquo2SethcS6LUNFHYR8D2UR49bdjerLzrAfOoS52PfE8S0Wcn+C/Ja52UVap8lUncqFUWejh6P4myJmnmwTz4zAOlgFIoeEA8Vl6fZMYGx46fX2+VGgIAoHqzNKAyx1c5yXix/+bjMAfdMK8E0Y3uAG6fxy80S5/ZqMXHCwAACs2TG6u1pkvmR2hk6HJn8PX39ycAqi1WdPNdAKmO8AkPQ25ykgm18g1zGh4BKPCnYMS8Q4Aur1CU8REzX+eA7kQqrr7/69wzp1fXNW05Ea12B2zjE441R19Rr0O8URxQV3iVQiMh7ijvzx8zu0EQ3+zk8uuwY4vTVhRmLQzpXYHlxFhV2YugTL617xeasYCiPoX+fJ9vPRGZVZVUFgF+nIA/p7N7n8SubXtbAmNG7JBQgE9j9REmcHq1Fd93MvEruTyWtfL9QksAjCkjAuHoco2E6g6p+dkcF5wlv8QSzxL4LW+fzYm5QuBrzHR83W8RGR/lma/OpizVztfSF6WTAaCAQyDSZwgW14PEOeWeuKVV9zBI1fTA2CSH8qubqWJVYz1pAMaZBj7VGxHd/uUgPo+IDA96NE3CzDaYN8qh/J3j9/mmmZQNaBsALr5CD/ctYfJ9h4CvAjyPiFqah5lVF+qbDPobcf4RJ9WvWvdaMvVaQLUkWFOoz1p4WMDf/WWNsAjA0Ux0tOfP50eG/oEOxxf/B+XKeaWIq28lAAAAAElFTkSuQmCC",
  di =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAAAXNSR0IArs4c6QAAA0lJREFUSEu9lktME0EYx+eb3VKe8hAESqGCIkYTEEv1ZELkgB6UE0TQQgtKJMYYDx6MJurBkydjIpEIiuUV8ILGKImJHrwgotFIgvKWUsUAItIX3Z0xW9Jmu5bu8nJvu/Pf/2/mm5nv+wApeFLyS5NYNnoPIJRFEYoBSqOF3yjAIiD0B3FkhDjpwNTgo1k5OwglSM41ZqrC2SKMQCtnJIwTgiY9gF5N9zWNrqQPCozXl8ZGQmQJg5ksJSCphidkxEHtT371d/2Wjv0D1OiNGQxmywDAG7a1PpTSRZ5wnbZ+yzexRwAw2VCRFYbUFQDArhUk/o9Syi25udbpT5Yx33c/UAhjFETVYoyjNgLm8yCE2O3U3uALrx+oNVSfxICyfUKVisV1xqM53T29ExNTPx1KJqFL2xZZUnxQV295/sXj4YgfStGQta+pVXj3AjW5p3LY8LBysWltRfGuKxfKymd+LcycqLvVPDRmWwwFzc7URHfUX6pKjN+SePN2Z3tDW89XsZ5wSy3W9y3DgNB1rNWPn8MM3ioWaJLjwp82X6sRDOSgYpigPVZ1o9E2Pe8KABI6Y32nuwvavMo0rGbPBJu91CjYSpVofN4OfukeaAtMhRjjwpXCFcpwNbDlxEBeg1ZvPo2Z0JkkmLFg4NszuZD7Dw9PrZBeYL4IGGLlTqEUKuiV7K/YlydkHtIN5qtKL7oYKhgpXZkPSgn1QIbBfBkBqOVWKIyvF4godYNWbzovvRJKTuxaQkp4MgtpBVWVclVhow4NT/hRSN1vOqRicdH/uBYc73kJSQZTSgTgs0rCuN6L73I46725NNg+bnhq48mstf/hHS8wJa9qb5iaKd3M5L3k5rt+fGwe8JenjAJzLcKgCSxPR3Y/fvZmVJqIV9rv5fJ0YHu95cVgQHlC1Gp9++C+vzx5S5S+PBEz6hqMcISSO6lcQ5wc72609bfPBACFl9T8Ch3Lqo1KM48cVGgxOM5t+f6hbcKn3bQmSmgtiMvVYfvcMSmeWIg2Meo4g/EOuVUEGxfaRCfj6Z7rbV2QjoduhA3VWSqgh5U3wvykB5jVN8LSWcXtM8XFAL+TMliHABIQoASvhqI5ROkcT9C4CxzDwRpfqddfGXoqtjdB+m0AAAAASUVORK5CYII=";
const fi =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAAB0CAYAAABUmhYnAAAAAXNSR0IArs4c6QAACT1JREFUeF7tnXuQ1WUZxz/PGndk2dghKBpCxriPyoBBlHRRxhgTaRLNUBlb4yLKRTM2HRocZDdtuQiGiF1MlIgom5gkh8ZgEhm0EksLoSAlIFu5y0WUt3kO5yxn13P5nd85u+/vHJ53Zv/Z/b3P+zzfz7739/d7hQIk59xHgWHAEKA/0AeoBMqBVgUoopRMnAIOAfXANuBV4CVgs4jszTdQCWvAOdcRuAGoAoaGtWP5GimwBXgUWCUiR8NokzNQ59yHgdvjP13CFGp5sirwNrBYf0Rkf9ankx4IDNQ5dx4wCbg/3pTmUo49G04BbZrvAZaKyOkgJgIBdc59HFgBXBbEqD1TcAU2Al8Xkd3ZLGcF6py7EngS0KbWkj8FtOlVqOsyuZARqHNuIrAE+JC/OKzkJAXeA6aIyPJ0qqQF6py7LQ7TFI2eApNF5JFUbqUE6pwbB6wEyqIXi3kE6ABpnIisaarGB4A65wYBOh9qa9JFWoHjupgjIq8ke9kIqHNO+8qXgQGRDsWcSyigq0wXi4j2rbHUFOi3gVrTq6gUqBaRBmYNQJ1z3YEdQPuiCsecPQb0FpF9jWqoc+4B4FumT1EqUCsi1Q1AnXOdgX8DnYoyHHP6INBTRA7Hmtz4AkLKeY1pVTQKfFMXHBJAN9g6bdGAS+foH0Tk8+Kcq4hvttoiQnEz1cWGSgV6DfCr4o7FvI8rMFaB1gEzTZKSUGC+An0G0C0yS8WvwDoF+negb/HHYhEArylQPWnWzeQoCQX2KVBdtbedlZLgyQkF6kojFositvRnQEvrH8GAlhZPq6ElxtOAGtBSU6DE4rE+1ICWmAIlFo7VUANaYgqUWDhWQw1oiSlQYuFEroZuefl11v9xKzt27eGten3fNbqpa2U5fS7owchhAxg2OBo7kJEBeuDgUb63dA1/26anSYsvDR7YmxlVY6jorJ+e8JciAVRh3jn3h5Gvkdkw9ejWhZpZN3uFGgmgs2oeT1kztUmLckrVJQzs05Pa6pu9ue0dqPaZ9y38WSMBvjjiIm65/grKz4/2azb1+w/zxJrn+P3zWxv5P3v69Vx68Se9QPUOdN6S1Wx6SY81nUkKc8atY7yIEbbQBct/3Qjqp4f04ztTrw1rLq983oHeOK2OA4feiQVRViY8sejOyNfMpoprTZ0wc2HDryvKO8Ti8JG8A71qwn0NcWuf+aPvT8uow/adezhx8l3atmnNhb30i3TRSOPvqOPg4TP/mJrW/mS2F8eKBuja9Vt46ukNHD6qZ9rOpE4d23HDNSO56vJLvYiXXOgtdy1qNEo3oEC6GlqzZDXPJ/WzTemNGNKPak99VsIXAxpXIluT+5v1W1i2IuO3lmKWJo6/ki97rKkGNADQ998/zfhpdRxJambTta2dO3VgxUN+BiLqkwENAFQHQDPmPBa4f1zw3SpvAyUDGgDoX/+xi+ranwYGWjPrJgb1/UTg5wv5oAENANRqaO7/cpGftnxt6oMt3oceP3GS3XvfprKiU+CFdquhAWqoPtKSo1wdhOlc95frXuDUqTMf5xrUtyfTq8bwkUr9UEz6ZEADAtXH5i1ezaY/nV3vbSrr54YP4q6JY3Nvn5JyKMwHlq5JOd/VpTzdFuvRXe9FSJ0MaA5AEzVVa0/yFEanKtdd/dm855+ZYCbwZYNqQHMEmhC20Gu5QWAGgWpAQwLNq11tkjkXmNmgGlDPQMPAzATVgHoEmg/MdFANaA5AFcCWra+z843/xrbMRgztT0V5uNN1hYCZCqoBDQhUTwTOWbiSHbvOXgumm9vTq67mM0P1mrXgqZAwm0KdXfek7YeqKJm2zxRmde3j7N6nN0c1TmVlZdw9+SuBoTYHzGSo7556j3eOnWxw0ja4m2xwZ4KZUC0o1OaEma59MKBJQIPADArVB0z1zYDGgdbd+420zWy62pCupvqCaUDjpHQE26lj+5R9ZrahT1OoPmEa0Gy0Av49AXX44L5pF9oDmsr7MWty85bwjAGF2rf3x3ht+5sFshjOjAENp1tkcxnQyKIJ55gBDadbZHMZ0MiiCeeYAQ2nW2RznbNAg57qiyy5FI51aN+GVT/Qix5bPnk/xjlnwUpe3Lq95SNvxhIv6t+L++++sRlLSG/aO9DnNr1C3aNPewm+uQqdctNoRn9hSHOZz2jXO1Bdort99jLe+M//vAhQ6EK7d63g4bmTad1aL0tu+eQdqIb85p56ZsxZzomTp1pegQKW2LZNq9j5XZ9vlkcCqGqqxzNrHl5dtN8q0peVq2+71itM1TEyQNUZfadk7foXeXbjX9j71oEC1p3mM9W1SzmjRl7CmFGfol3bNs1XUEDLkQKa7POhI8diH8eIctKzTVH7llJkgUYZZJR9M6BRphPCNwMaQrQoZzGgUaYTwjcDGkK0KGcxoFGmE8I3AxpCtChnMaBRphPCNwMaQrQoZzGgUaYTwjcDGkK0KGdRoPoOXOsoO2m+BVYgdqm6bmtk/qpSYHv2oGcF9ivQfwIXeHbEii+MAv9SoL8DRhXGnlnxrMCzCrQOmOnZESu+MArMV6DjgFWFsWdWPCswVoF2A/bocRTPzljx+SnggG4xiM65F4Bh+dmz3J4V2CwiwxNAJwKPeHbIis9PgUkisiwBVOehO20+mp+iHnMfBHqJyMGGftM5Nxe4x6NTVnR4BeaJSIxdMtCuwA7g/PB2LacHBY7owpCI1DcCGh8c6U1yZ6/Z8+CdFZmzAtNFZFEiV6OpinPuPGAT4P92uJzjOiczbAZGiMjplEDjtVRvsvkzUHFOSlQ8QetA6BIR2ZXscsrFBOfc5cBvgVbFE9855am+pjdaRNY3jTrt6pBzrgpYfk7JVDzB3ioiKS+Fy7jc55ybAizWD3QVT6wl7an2lVNFZGm6KLOu3zrnvgr8GAj3TfCS1rdFg9P7oCeIyC8ylZoVaHyg1A/4OTCwRUOwwhIKbAWuE5Ft2SQJBDQOVd9m1RtX7wXaZTNsfy+IAscAXcGbLyJnv3+ewXRgoAkb8e22O4BJNrUpCLRURvSc1zLgIRE5e3tCgOJyBpoEVvvU8cCXgCus1gZQO/MjxwE9DvQM8JSIHA1jMTTQ5MKcc22By4CRwACgD6BX+ZXbXPYDWHQOeQjQtVftE18FNgAbReREGIjJef4PG2ubPDDLZ3gAAAAASUVORK5CYII=",
  Ai =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAAB0CAYAAABUmhYnAAAAAXNSR0IArs4c6QAAC6xJREFUeF7tnXl0zdcWx7/bLCKkhqBoaT1zqdZUHrUURQe1QtqU91TNQQ2t4cnTR5+hqCEpMZb3YmxrqJllaihKTVGtlhr61NQgRYnxvLWvxMrNnc7v5ndzc3/2WSv/sM8++3w/9/zO+Z3fGQgmJKVUKQD1ADwPoAqAigCKAigEILcJRVjJxR0AfwBIAvATgCMAvgOwm4jOZbai5K0DpVQwgEgAXQDU9taP5LNTYA+AmQCWENF1b7QxDFQp9RiAPql/RbwpVPJ4VOASgFj+I6LLHq3TGWgDVUrlBNADwKjUR6mRcsTWOwX40TwMQBwR3ddxoQVUKVUGwHwAjXScio3pCiQAeJuIznjy7BGoUuplAAsA8KNWkv8U4EcvQ13vLgS3QJVS3QF8CiCX/+ohJadT4C6AXkQ0y5UqLoEqpaJSYYqi2U+BnkQ03VlYToEqpdoDWAQgR/ari0QEgAdI7YloaUY1HIAqpaoD4PehfCJdtlbgJk/mEFFi+ijtgCqluK88CKBqtq6KBJemAM8y1SQi7lttKSPQwQDGil4BpcBQInrI7CFQpVRJAMcBBAVUdSTYGwCeIqLzdi1UKTUOwAeiT0AqMJaIhj4EqpQqDOA0gJCArI4EnQzgCSK6anvkpk4gOH2vEa0CRoFuPOGQBvRrmacNGHCuAt1GRE1IKRWa+rFVJhECmylPNhRloG0ALA/sukj0qQq8wUA/ATBAJLGEAhMZ6DoA/IlMUuArsJ6B/gigUuDXRWoA4AcGyivNSogcllDgPAPlWXv5smIJnkhhoMoadZFa2Kb+BKi1fggC1Fo8pYVajKcAFaBWU8Bi9ZE+VIBaTAGLVUdaqAC1mAIWq460UAFqMQUsVh1LtNDVm/Zg3dZ9OP3b74bwlC5ZBI3qVkXEq42QM6c1VuAEPNBJs77C5m8OGQKZ0bhWtafwYf+3LAE1oIHuSzyODycuzBTMtMx93nkFLRrXMsWXP50ENNCp89Zg3bZ9puhXu0YFWysN9OR3oFt3JmLPwWNIvmr8FJcz55Jw5Y8/TWFQICgvypc1vnCjQFA+8I/hpYY1s8Uj229A7927j3FxS/HNd7ykKfBT5QplMHJgJPLny+vXyvgN6OKVCZi/bJtfK2924a2b1kbPji3NdmvIn9+Adh0Ui3MXrxgK1l/GuXPlREjBIFy6cs1tCPny5sGXM4b4K0xbuX4D+kqnkT6reLmyYShfJgxhxUJRJLSgrW+7eu0Gkq5cw7kLl3H46Cmk3OIj9zynGpXLYWifdggOygceVY+YvAj377tehjVnQl+EFeXNfP5JlgFa9vFiaN7oWTSqWw2PFeZjCF0n7r+P/PwrNu84hIRvv8edu/dcGseM7GY3WBoxaRH2Hjrm0l6AZvKHXLxoIXRu3wwN6/AhoMbTleTriF+2FRsTDjjNPOnDLqhQjg8bfZCGT1iA/d//IkAzKmDGI/flF59Dt8gWyJMn8+dicYvlUXfGfpJHr//o3Q6hhYKxaftBTJ6z0u2vRlqo8UaFHDkIUX9vbfrMDrfWj2KW4OcTvzlElTt3Lty58/CwEWmhZrVQhjmoR1s0rOP+5B3uJ3ni4er1G7h+IwUhwUEoXbIoChV0fybIzZRbGDZuvlOoOr89aaE6KqWz6dD2Rbz5mutDQXkEu3bLPtvAJeXWbQfvPAJuUr86mjeuZRu5OkvcUvuNmOXxNcVZXgFqAGiNKuUwalBHlxCm/mcNdh/gU789p5Dg/OjeoSUa16vm1Jj71MGj53l2lMFCgGpKxi/308dGOX3HO33mIqLHx3s1r/t687roGtnCaRQxn61yOfp1FbYA1QT6WrM66Pa2477ksxcuY/DouV7BTCs6vHUDdGrX1CESfvR2fn+K2/fUjJkEqCbQOeP7IqyY/QwMD3z6/WsWTv7vgqYX12bD+72JOjX/4mAwYcZybNt1WNu/ANWQit8Fxw97x8Fy1aY9mDHf7QHPGt4fmJQsHorpY6IcPoEdOHIC/xzPp7PrJQGqoZOrka3ZE/yDera1TR2mT7dv30VEr4+1H7sCVAPoiAGReO6Zp+0sj508i/4jZmvk1jf5a50qGNwr3CHDwJFz8JOTyQZnngWoht7OROKVftNNetymhRBaqADipwzMVD8qQDWAfjUn2qFvi1+6FUtWbdfIbcxk9bzhDhnmLN6I5et3azkSoBoyORM5Ln4d1mzeq5HbmImzshau+Br8p5MEqIZKC2Lfd5iD9cUSFp68WD6bLzKyTzGfrcTGBD653XMSoJ41QsaPzJxlx94fMHbqlxq59U14njd2JF9VY588fdROby1ANfQe2K0NmrzwjJ0lf0GJ7D3e7XIQDdd2JuGtXkCn9i85ZOs8cAouXuJryDwnAepZI9vSkr6dX3WwHP3pF9hp0jJQ/izHEwulwuxvBLvwezLe/SBGI8oHJgJUQ6qCwfkxf8pAh5HuqTMX0Xf4DFNaadMGNdC/6+sO0azYsBuzF23UiFKAaovEhkOiwtGwtuO6ITMGR7wyMGZkd6cfv3sNi8OvBna1SQvVxFquTBhiP3IcsHD2j6ctxfY9fCeN8cRbICZEv4sypfiGafu0a99RjIr93JBTAWpALnc7xP67dAs+X7XDgDfg8RJFEN03wilMnsONio4zvBhcgBpAwK2JH42uFjLzKoP5y7bi8FG+scR1Yj/8YTu8VUOXKwZnLtyAlRu/NRCd9KGGxeIMTz9ZEmOG/M3tpqBfTp/H7v1HcfzUOVxISratLSoaGmJbJFa90hOoV6ui2/xbdiZi4swVXsUnLdQL2Xy504snLMbFLcP9+1pXXjtEL0C9AMpZeJAU/V6EqftIvli9A/HLtnkNk+MSoF4C5WzcF3aOaJbpBdf8WJ4ev87tnhXdMAWorlJu7MqXDUNkm8aoV8vYXQhJl69i+fpdWLt1n9aqeJ1QBaiOSpo2PEFQv1Yl1KhaDpXKl0Zohl1o/Cpy5nySbTvh3oPHkHj0dKYer87CemSBhncfo71HU5OngxlvwA0pmN/277xC0NOGXW/LSZ9v8bRBLlfkm+Hfkw+/7Q/1tC3PU+DZ8f95j+q0UT39GprfgPIir0Gj5mqvpvOrShqF89ea4f3ewvMZFrNpZDXVxG9AuRaJP55C7NxVhqfXTFXABGeFQwqgR8eWTj8emODekAu/Ak2LlFurs51ihmriJ2Pup/l8o+xyVmC2AOonFpYsVoBaDKsAFaAWU8Bi1ZEWKkAtpoDFqiMtVIBaTAGLVUdaqAC1mAIWq460UAsCvQUgj8Xq9ahWx3apOh8r7b8Tex9V6X1T78sMlA9/Le8b/+I1ixU4wUA3AGiexQVLcb5RYCMD/QTAAN/4F69ZrMBEBtoewJIsLliK840CbzBQvk7oLN8Q4ZsyxGsWKcBXVZSwQVRK7QJQL4sKlmJ8o8BuIqqfBpR30k73TTniNYsU6EFEM9KA8nvoSXkfzSLpzS8mmfdvEVHyw35TKfVvAI6nLplfuHg0X4HRRGRjlx5ocQDHARQ0vzzx6EMF+EK28kSUZAc0dXD0HoDJPixcXJuvQD8impLm1u5VRSmVE8BOAHXML1c8+kABPiK0ARE93G7u8O6plHoSwH4AoT4IQFyapwAPhJ4lolPpXTqdTFBK8YF3awHkNq988WSiAnxXZisi2pTRp8vZIaVUFwCzTAxCXJmnQFcicno+u9vpPqVULwCxAHKYF4t4yoQC3Ff2JqI4Vz48zt8qpfhU/bkA3N+ymokoJauWAn8C6EREbg8J9gg09XWmMgA+9M75RWFa8YhRJhQ4BCCCiDxe7KYFNBVqXgB8ZUI0gAcHF0jytQI3APAM3kQi4rVfHpM20DRPqZ/b+gLoIa82HvX11oDXec0AEENE54w4MQw0HVjuUzsAaAmgmbRaI7I7tb0JgJcDrQOwkIiue+PRa6DpC1NK8c2qfEtrYwB89W5FAHwAbSF5l3XAwu+QfIA9z71yn8gH/fIdIglElOINxPR5/g+RfMI8GCb/eQAAAABJRU5ErkJggg==",
  gi =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAAB0CAYAAABUmhYnAAAAAXNSR0IArs4c6QAACr1JREFUeF7tnXlwVdUdxz8/EERFIJgiWFRqbSFFLZbUCUsRBC1Lbcsi6QLKIJWACG5IEabTMsBgBtACFjBVtAIKVay2JeLoBHBYRlkEZBEobgyCRXaQ/XR+z7z0JSR59968l3vve+fM5K+c5ff7ft65557fPYuQgGSMuQrIAbKBHwDNgUygPlArAU2kUhVngMPAfuAjYDOwBlgtIl9U1VHxWoExpi7wG2AQ8GOv9dhypRR4D3gGWCAix7xo4xqoMaYh8EDx3xVeGrVl4irwFTBd/0TkQNzcMRkcAzXG1ATygAnFj1I37di83hTQR/MYYKaInHdShSOgxpirgblAByeV2jwJV2A58FsR2R2v5rhAjTFdgXmAPmpt8k8BffQq1DcrM6FSoMaYwcAM4CL//LAtxyhwFhgqIgUVqVIhUGPM/cUwraLBU2CIiMwqz6xygRpj+gIvATWC54u1CNAXpL4i8mpZNS4Aaoy5EdD5UB0rXaAV+FqDOSKyMdbKUkCNMTpWfgC0DLQr1rioAhplaiUiOrZGUlmgo4BJVq9QKTBaREqYlQA1xjQBdgKXhsoda+wJ4LsisrdUDzXG5AMjrT6hVGCSiIwuAWqMaQB8CtQLpTvW6EPAtSJyJPLILQ4glDuvsVqFRoH7NOAQBbrMxmlDA64iQ5eKSCcxxmQUf2y1QYRwM9VgQ6YC/SXwWrh9sdYXK9BTgU4BHraSpIQCUxVoIaCfyGwKvwJvKtCtQIvw+2I9ALYoUF1p1tjKkRIK7FWgGrW3X1ZSgicnFahJDV+sF5HQnwWaWj8ECzS1eNoemmI8LVALNNUUSDF/7BhqgaaYAinmju2hFmiKKZBi7qRNDz19+iyz5hZStGoTZ86ULGN1jPOKjMvJ69eNNq2D/R0jbYA+v/AdXlm8wjHA8jLWqnURBU8MI7NhcNfSpQ3Q0ZNeYNM2XdhYtfRYXi865NxQUon2/LeWr2PJ8vU0bZzJqKG9q9ZAFUtboC4FfHDQz+nSvhUKsrBoTaTXHzx8vKSW56eOILOhnhXiT7JAXeo+9O7ukTG4LMhoNc9OHs6VmbrM2Z9kgbrUvUYN4fz5ir84WqAuBfWaPVFjaLz2LdAyCu0/cISilZs4eOQY7bKzaPn9a+Jp6Oj/FqgjmRKXadene5n/j2W8t2EH58///wSXMQ/0TcjczwJNHKtKazp37jwF85ewuGhtKZDRQg3qXUZB/jAuqXNxlSyyQKskn7PCCjN/5qusWKMrSStOuXe2p3/v25xVWkGuRAFt27oFH3++jy++PFhuS2k9hi4qXMlzC96OC0ojNE+Pz+OqK70flZQooDoP7dTmJopWbmTBP9+9AGzaAj146BgDR05zHFdtm53F48Puigu/ogyJBKqBBU36hIkFW+fiWjz/5EPUvdS/VbG+zUNffuNd5i4qcgVo/Mh+tGp5nasy0cwTZ/ydlXEe7U4qnjjqbm7KalYqq4J9b8N2mjRqSLOmjZxUk7Q8vgEdOWEOW3d87sqxa779LaaPG0zNmu53Pu74eA/aS0+e0uNqvaUfZjVjwqi7vRWuplK+Ac0d+gTHT5xy7ebgfl25s8strstpgX3/PcTq9ds8tas/pjY/auHpx+TJWI+FfAP6swHjPJl82aUX8+zkEb6OU54Mr6ZCvgH12kNVl26dWnP/PT2qSaJwNeMbUC9jaFTaGjVqMG3cfb6/gAQRtW9A5yx8m1cXr/SsSVWnMZ4bDnhB34Cu2biTP06d71meJo0yKMjXo+9tilXAN6BfnzxF7tD8Sr8tVoYqEeHAVPwp+AZUxRyT/yIbtnzsWledD457tF/gpxCuHUtAAV+BLlm2julz/uXKja4dWzOkfzcLswLVfAV6+OgJBjz0JGfOnnMEtedPc7j313c4ypuumXwFqqJPnv0aS1dtcqS/vgg9PX4ItWvbOw0qEsx3oNt27ubR8c85AqqZ7MtQ5VL5DlTNc/NpS4MK+Y8PoMX1TR3/CNIpYyCAbtr2CaMn/c2x7o0y6zNl7L1kNND79GwKxDy0LAY3vVTLZn3vaib9/h77tltGyED0ULVJV/09+KcCV4EGXeb52JDeFmoM1MAAVZtmvljIv99539Uz1EItLVeggGo48P6xs/hyv96y6Dzd0Pxaxo7IrfAbqS7efmvZek6fOUO327J93Xvi3CtvOQMFVF3YvP2zyFtvZftHynNV56hjh+dybZk1PVrfhGkLOHJMjzQEXUHYq2sOfXq0q/JaX2+SJ7dU4ICquy+/sZy5i5a69lxh9e/VkV/ckRMZV/fsO8CoiXNKbfeLVppR/zLu6dOZLj/5ZgVfqqRAAlVxq7JK7/pmTbj3V7fzzLwlkUXRlSXNq1vtU2VeG1igOp7+YfI8tu6Me6ltQjpXxzY3MuCuzoHebu/E0cACVeM1eD9qwhx279U7xpOf9JF9V4+29OnePrTx4kADVYS6wl5fkqoLqrapJ54MzL2dW2POUkj+zykxLQQeaBTqxBkLq+3xG5V2YG4XenVrmxilq6mWUABVLXRMfeIvi1izcUc1SfNNT33hyYeqrb1ENBQaoFFn5722lJdeX54I3+PWoXtT5057JG6+IGUIHVAVb/2Hu3jq2df56uDRpGrZo3M2Q/p3T2obia48lEBVhGMnTlIwbwnvrNiQaE1K6psxPi90i7lDCzSquob2dEv/zk/0+pnEpZybm0fiw2FLoQeqgkf2Z36wPXLoRrzIkBNAunH36QlDQhnETwmgsZBWrd1GYdFa1n34HyfsLsijB0vpeX7tb2npqbzfhVIOaFRQ3QtatGojK97f6rjX6hebR+7rGeq4bsoCje0p+tXlg8272LLjM7Zs/5wvvyr9vVWXs7TPzqJbp+zQhvyi/qYF0LKPQY0RHzl6IgIvo17d0EOM9S8tgfo9ziWzfQs0mer6ULcF6oPoyWzSAk2muj7UbYH6IHoym7RAk6muD3VboD6InswmLdBkqutD3QpUz2er7UPbtsnEKxC5VF1P8vXvXorEO5XONR5QoPpZwtuZpeksXTB936VAlwD2JIpgAnJr1VsKdArwsNuSNn8gFZiqQPsCCwJpnjXKrQI9FWhjYA8gbkvb/IFSQO/vahyBaIxZBeQEyjxrjFsFVotImyjQwcAstzXY/IFSIE9EZkeB6jxUT1G089FAMXJszCHgOyJyqGTcNMaM1wMyHVdhMwZJgYkiEmEXC1QvHNkJXB4kS60tcRXQ/SDXicj+UkCLX45GAE/FrcJmCJICD4rIn6MGlZqqGGNqAnoQvLeLUYLkZnrYshpoJyIl93NeMPc0xug9UOuAjPTQJLRe6ovQzSLySawH5QYTjDFdgMV6rE9o3U1tw/W+r+4icsHVjhVGh4wxg4CC1NYltN79TkT+Wp71lYb7jDFDgemA+9vjQqtVoA3XsXKYiMysyMq48VtjTB9gDmAPp/WX9XFggIi8UpkZcYEWT2eygIXADf76lLat6zb1XBH5KJ4CjoAWQ9VbzfUEibHAJfEqtv9PiAInAI3gTRURR3dzOgYaNa/4c9twIM9ObRICrbxKdJ3XbGCaiLg6a8A10BiwOqb209sfgdttr60yXD3/VZcDFQLzReSYlxo9A41tzBijt4h3AG4FdC97cyATqG/nshdg0Tmk7jjW2KuOiZuBZcByETnpBWJsmf8BKOBHPNCVmIMAAAAASUVORK5CYII=",
  pi =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAAB0CAYAAABUmhYnAAAAAXNSR0IArs4c6QAACVhJREFUeF7tnXuUVVUdxz+/QR7ydIKEIDDBBKMxDDEUFoQSNEQqLh6rEQMN5K0gWCpESeaD4mG4IhiztVIwSyMfSx5pIhUQsVQoVBIRbERU3hEO8dit33hnvDPeuWfuuffMnHPvb691/5nZv9/5/b6fs/c5Z5+z9xYyUJxzbYGewMXAF4DOQCugBVA/A4fIJhcngMPAPmA7sA3YDGwUkXfTTVT8OnDONQWKgDFAD79+zK6SApuApcBjInLUjzYpA3XOfQqYEvu19HNQs/FUYD+wSH8icsCzdlyFGgN1ztUDxgM/jnWlqRzH6vpTQLvmmcBiETldExc1Auqcaw88AvSpiVOrk3EF1gHXikiJl2dPoM65rwPLAO1qrdSdAtr1KtRVyUJICtQ5Nw54ADij7vKwI8cpcBKYKCLF1alSLVDn3KQYTFM0fApMEJFfJAorIVDn3HDgUSAvfLlYRIDeIA0XkSeqqvEJoM65AkCfhxqZdKFW4EMdzBGRrfFRVgLqnNNr5StA11CnYsGVK6CjTN1ERK+tZaUq0O8B95pekVLgdhGpYFYB1Dn3GWAH0DhS6Viwx4BOIrK3Ugt1zs0FbjV9IqnAvSJyewVQ59xZwG6geSTTsaAPAeeIyJGyLjc2gJDwuca0iowCN+qAQznQF22cNjLgqgt0rYj0E+dcfuxlqw0iRJupDja0UqBXAyuinYtFH1NgiAKdB9xikmSFAvMV6EpAX5FZib4CqxToa0CX6OdiGQCvKlD90qyNyZEVCuxVoDpqb29WsoInpQrUZUculkXZ0J8Bza4TwYBmF09roVnG04Aa0GxTIMvyCf019IX1W3nm+b+zu+QDSo//LxD5i67ui/7Kyw0z7ie/RdOyv3UvOC+QYwblNLRAPyw9zj0PPM5L/3wzqNwr/CYC+v4+nVYChf26c8OI/pzZqGHgcWTiAKEEqjBnz1vOa2/8OxM5evpIBlSNz23fmlk3j6B1K/2wI9wllEAXFD/J83/dUmvKeQHVQPJbNOG2ScPoen6HWovLz4FCB/SNt/Yw7c4H/eTi26YmQNV5o4YN+O6Ea7ik2/m+jxW0YeiA/nTJCtZu+EfQeVfyX1OgapSXl1cGtXcPXXkgfCV0QEdNW8D+g/+pVaVSARp2qKEDOnj0nFqFqQerCnT6nF+yfec7SePQlnrXrSO58ILP1Xq8yQ5oQIErB3yFG4sGVui0dNkqnvqjztdKXlrmN6P4vik0aBCe6bMGVB9LOrRm0Ryd2/xReW/fISbNXEzpcV2BJnm5747RobrzNaAxXovvnkj7trq00kdl89YdPLXmb5w4WTGxKyHZsUUD6dghPB98GNAYpp4XdS4bPIh6MaBxBHWI75rCyyLN1IBWwadjt6OGXUHTxtH8zMqAJmiP9eufQZdO7Ti7BmO3Qwf1qnTtrevmbUDTJHDPbd+moEt4nkUNqAFNUwEP87oYKUonI2uhBjSd88fT1rpcT4mSV7AWai00zVMouXkkW+hZzZvQrWtH6tULbtK5vmh/+50PPMW3FppmCx3QpxvjRw6qlTccTz+3iSWPJF3NFAOaBlD9WGvhD8cG2jKrhvezh55mzbqXq43agKYBdNTQyxk2uLdnN5jJCi9v28n3f6KLeScuBjQNoFOuH8zAvl/OJC9PXzvf3stNs3WjBgPqKVaiCskGFr56aQEzxg3x5dev0bN/2szPf/2sAfUrYDKgtf0dz74DR5h2ZzEHD//XgAYBVH0q1G/270GPL30+0Juj13eUsGLVBo4c1RULqi92DU3jGur3JAnSzoAa0CDPr/BN+LW3LenxjuTQX3opZ9baulzrcjN7RlXxZi00TXmthVoLTfMUSm4euRaqr87GX1dI94JOgU2TP3XqNK+/WULx8tXs2JV8011roWm00CaNG7LgB2Np27p2NkrUpQGm/+ihpO9FDWgaQL9xRQ8mXFcYaJdV1bmuwjJv6R9s6M+v6smeQ6eOuZL+vbv5de3LblfJ+0yeVf2GGdZC02ihRVf1pWjIx+sJ+SKUotGmV/7FnIW/sRaaom4V1ZO1UL0hKp47ObCboUQxz5z7MFtefcuABgFUfXbu2I7p44YEfmN09FgpxctWey6vY11uGl1uvOk57T5N82bB7LunMEve3c+JE8kn+2o8BjRDQP32AJm2M6AGNNPnVCV/kRspClQNH86thXqIVhcLT/ngWGFiQD3Uq4ul4dIBumzRDFoEdHPmJ67Qdbk7d+9l6p3FnD4d/t1H9BFq3uzv+NE9MJvQAdVMl61Yy6NPrgss6Uw4zssT5t5xPV3O+2wm3GXMRyiBanZec0oypoBPR2O/NYCrBvb0aR2cWWiBasq/X7meh594gRMnTwWnQIqe9RXeuGsLubzXhSla1k71UANVCfa8d4DfPfMX/rxpW43W3gtKtnZtWtLvsgIK+10cqpugqvmGHmh8wLqoYl2U/OZNa2U+aiZyixTQTCSc7T4MaJYRNqAGNMsUyLJ0rIUa0CxTIMvSsRaahUCPAw2yLK9cTadsU/WDQPh3actVRKnlfUCB6n6OHVOzs9ohVWCnAl0NDAhpgBZWagqsUaDzgFtSs7PaIVVgvgIdDjwW0gAtrNQUGKJAdVugPYCkZmu1Q6aAfrPTpgyic24DEL7X7yFTLOThbBSRS8uB6k5u1c+ZC3kmFl6ZAuNFZEk5UH0O1SlW9jwazbND3/yfKyKHKq6bzrm7gJnRzCfno75bRMrYxQM9G9gBNMt5eaIlgO5v3VFE9lUCGrs5uhlYGK18cj7aqSJyf7kKlR5VnHP1gPXAJTkvUzQE2Aj0EpHTCYHGWqnuzPYSkB+NnHI2Sr0RukhEdsUrkHAwwTnXH9B1uevnrFzhTlw3Bx8kIs9VDbPa0SHn3BigONx55Wx0Y0XkwUTZJx3uc85NBBbpyuA5K124Etdr5WQRWVxdWJ7jt865ocCvgKbhyi3notGdDEaLyOPJMvcEGrtRugD4LfDFnJMxHAlvAUaIyHavcGoENAa1ITAdmAWc6eXY/p8RBY4BOoI3X0T02y/PUmOg5Z5ir9tu0sFge7Tx1NdvBf3Oa4lOkxWR5Ou7VjlCykDjwOo1dSSgy2N+zVqtX3YVdrpBjH4OtBJYLiJH/Xj0DTT+YM65RkAfQFdW7KoruAGtgBb2LPsJLPoMeRjQsVe9Jm4DXgTWiUipH4jxNv8H9HnGLTFmKsgAAAAASUVORK5CYII=",
  mi =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAAB0CAYAAABUmhYnAAAAAXNSR0IArs4c6QAACiBJREFUeF7tnXl0VcUdxz+/hEUoiEgEZF9LDKVSCxThiEexHEGKBaxWWUpZIxQULGXtSalseggF2aWodaFNQTkqgtBCJSKCQFQUFQuCRw4CsskSwpbp+b0mnJDkvXffyw33vcvMOfkrM7+Z3/fzZu6d38ydEVxIxphaQFugFZACNAOSgCpAWReq8JOJC8D3wBFgF7AT2AZsFpFvS+qoRGvAGFMJeAQYCLSO1o4td4UCHwDPAhkicjoabSIGaoy5ERie91ctmkptmbAKHAXm6J+IHAubu0AGx0CNMYlAKjAlbyiNpB6bNzoFdGieACwQkVwnJhwBNcbUBV4GOjgxavO4rkAm0EtE9oezHBaoMeZe4BVAh1qbvFNAh16F+naoJoQEaowZAswFynjnh625gAIXgaEisjiYKkGBGmOG5cG0isaeAo+KyMLimlUsUGPMg8DfgYTY88W2CNAXpAdF5NXCahQBaoxpAeh86DorXUwrcFaDOSKyo2ArrwBqjNFn5UdA85h2xTYuXwGNMrUUEX22BlJhoGOA6VavuFJgnIhcZnYZqDHmZmA3UDGu3LGNzQYai8jBK3qoMeZpYLTVJy4VmC4i4y4DNcbcAHwNXB+X7thGnwDqi8jJwJCbF0Aodl5jtYobBQZrwCEf6AYbp40bcMEa+o6I3CXGmKp5i602iBDfTDXYkKRAfwmsiG9fbOvzFOiuQNOBUVYSXygwU4GuBnSJzKb4V+BtBfo5kBz/vlgPgM8UqO40q2nl8IUCBxWoRu3tyooveJKjQI0/fLFeBEJ/Fqi/fggWqL942h7qM54WqAXqNwV85o99hlqgPlPAZ+7YHmqB+kwBn7lje6gF6jMFfOZOTPTQA4eOsXLdVrI+2c2BQ8fJzXX0batnKBISEqiRVIUWyQ3o2rE1jerHzmKV50BfW72JF5atj3mIoX493e+9nX6/6khiovfbsjwFumzlRv62fL1nPc3NirWnpvbp7KbJqGx5BlSH2dRx8+O6ZxZWfNrYvoFh2MvkGdBnnnuTtZkfeum763XfmtKQKX/o47rdSAx6BjR17Dz2H9TTW/yTypYtw4rF4z11yDOg3fpP9tVwm0/xhZmPkXSjHqDmTfIMaNd+f/bG41KudcmMEdRI0m+/vEkWqMu6W6AuC+q1OQvUYwI/qFie9q1SaNa4diAwcDbnPB/t3BuIWl24eCni1lmgISSrXq0KKT+s5ygCcyY7h+07IoNwX8fW9Ol5F5UqFt2WrPPkhS+tJuvTPRFBtUCDyNWwbg3S/ziAcuWcH2KmQNNmLnUEoP9D99Cjc7uQeS9dymXGohW8+4EeNuIsWaBBdOrUoSUj+ndzpmJeLgVw/4DJYcu0vrUpaSMfDptPM5w/f5FhExfw7eHjjvJboEFk0mfbpFG9SG5Sx5GQKnzGm+8G/sKl2ZMG0ziCFZJV67cx/8VV4cwG/m+BOpLJvUz6XH4u/bGIDH5/Kptew2c4KmOBOpLJvUwtkuszbexvIjb4wJBp5JzT4+JDJws0nEIu/z9aoN0HTeXChcsnsAVtlQXqMrBw5vTZnDFfT8BznnQKM3iMHhscPlmg4TVyPcfk0b1p2byRY7v/eCOTl197x1F+CzSETM0a1Q4I72Rrh764ZG75lFOn9fvl0EnnuLP+NMiR3eMnTpM6fh5nss+FMxv4vwUaRKaUpnV5esJvHYmYn+m/ew8wctJfHZW5o01zfj+ke0io+iNJS3+F3fuc349jgQaRv2P7HzNykB6h5DzpXLTH4KmOC2j8dljf+4rdtbc56wueXbqGw0f0pg3nyQINopWu/o8c0I1mDgML+ga67K33WLfxY8fqly2TSKN6NbmtRWOaNqxFYkICl3Jzydyyk1179juODhWs0AJ1LL97GevVvolf/+IO2t6WHDJWfOTYSdZmZvH62i32GRpOfq92LPTs0o6+Pe929EKU74M+S9MXrXC08mJ7aDjyLv7fyQpLsOo08P/U/FfZtF3P6QqeLFAXgYUy1e6nyYwfrreXRJ/O5pxj2MSFIV+ULNDo9XVcUl9+5k15lFo1Sn7b1/vbv2DKnH8GrdsCdYwl+ow65xwztGf0BgqV7P/EbA4fLX46Y4EGkfn/66GPkNxEL0YMn3Q4zHhjI8tXvVck8+jUHtzZ9kfhjTjMseCl1by1bmuxuS3QICJGs2MhWGDhL2kDA/NMt9KaDVnMeX6lBVpQgXDTFp0rzkobFNGeoh2f72P8Uy8WEbpJg5sDm8FapjiLCwcDrz+YrR9/yZKMfwV9MbI9NES3qZ5UhZSmEez6+2RPyDVLHcb167CGdWvSoM5NXF+5ItXzdrlfX6kCFa4rz+nsHHQHoU5Tjh4/iQYXvt7/HV99c5DPvvyGnHPnQ3Z0C9StcTBG7FigMQLCrWZYoG4pGSN2LNAYAeFWM65ZoL1HpHPi5Bm3dIwZO68vmRhR4N/thnv2OeGTszPY8uEut/3x1J5Oj3Rri5fJM6CRfIfipUCR1D20bxe63N0qkiKu5/UMqHoyde4yNm0LvRzluselZPCWJnWYPq6fp8OtuuYpUI2/Tpu73NHCcSlxcMWsDrVpjz9M1RsquWKvJEY8BaoN14jMfzbtCHxk5PQLr5I47GbZalUrc3+nn9G1Y5uIQpRutqGwLc+BFmzQoe+OB12WKk0RorGtMGvVqBZN0VItE1NAS9XTa8S4Beoz0BaoBeozBXzmju2hFqjPFPCZO7aHWqA+U8Bn7tgeaoH6TAGfuWN7qA+B6uEB5Xzm17XqTuBSdT3EzrsjmK9V6UvH72MKVM8PdX7GS+k0xFp1R4GvFOgaoJM79qwVjxVYq0DTgVEeN8RW744CMxWoftac4Y49a8VjBborUL1a74DuL/K4Mbb6kilggJoBiMaY94G2JbNnS3uswGYRuT0f6BBgoccNstWXTIFUEVmUD1TnoXvtfLRkinpY+gTQUEROXH5uGmP09P0JHjbKVh29AlNFJMCuINDqwG6gcvR2bUkPFDilgSEROXIF0LyXIz1df5YHjbJVRq/A4yIyO7/4FVMVY0wisAloE719W/IqKrAZaC8il2+hLzL3NMboncNZQNWr2DBbVeQK6IvQT0RkX8GixQYTjDH3AHrzTNnI67ElroICet9IFxH5d+G6gkaHjDEDgcVXoXG2isgVGCQixZ7FHjLcZ4wZCswBEiKv05YoBQX0Wfk7EVkQzHbY+K0x5gHgecD7jx9LQaE4MqkHUvQTkeWh2hwWaN505hZAzxR17wTEOFIyBpqqB+k/JCJhD6VwBDQPanngCWAiUCEGnLwWmpANaARvpog4ujjGMdB89fKW20YAqXZqU2q/Kd3ntQh4RkScXxpTkjVQY4w+U3sDnYGf215bYrh6JZRuB1oNLBWR09FYjLiHFleJMUYvse4A3Ak0B5oBSUAVO5ctopjOIfU4bI296jNR74PeAGSKSE40EAuW+R+Q5iA8UDU3sAAAAABJRU5ErkJggg==",
  hi =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHQAAAB0CAYAAABUmhYnAAAAAXNSR0IArs4c6QAADCFJREFUeF7tnXd0V0UWx7+XoBSFAEGkqiSRIoiAVKWIKyx6AGlLWbAECG0jPYA0YYGIUkOAGJQuKKysrrB0kKqoKAEpB0tAAYMQagwkBDJ77u8k2QSSvHkvvzLvMfec/JU75X4/v1dm3swdghtMCFEeQCMA9QA8AaAqgNIA/AHc54YmnFRFKoCrABIAnABwFMABAPuJKD6/gZLVCoQQDwL4O4A+AOpbrUeXy6bANwAWAlhNRH9a0cY0UCFEKQBvpP8FWGlUlzFU4CKAKP4jokuG3lkcpIEKIfwA9AcwNf1WaqYd7WtNAb41jwUQTURpMlVIARVCVALwIYBmMpVqH7crsBtADyI6Y1SzIVAhRGsAKwHwrVab7xTgWy9D3ZRXF/IEKoToB2AegIK+i0O3nEWBWwAGEtH7uamSK1AhxD/SYWpF1VNgABG9l1O3cgQqhOgC4CMABdSLRfcIAL8gdSGitXeqcRdQIcSTAHg8VFhLp7QCN3gyh4gOZ+1lNqBCCH5WxgKooXQounMZCvAsU20i4mery+4EOgrANK2XrRR4k4gymWUCFUKUA/AzgKK2Ckd39jqAICI6l+0KFUK8CyBc62NLBaYR0ZuZQIUQJQD8CqC4LcPRnb4C4FEiuua65aZPIOQ4rtFa2UaBvjzhkAF0l56ntQ243Dq6k4hakBCiZPrHVj2JYG+mPNlQmoG2B/CpvWPRvU9XoAMDnQlgmJbEEQrMYqAbAfAnMm32V2ATAz0OoJr9Y9ERADjGQHmlWVkthyMUOMdAedZef1lxBE8kM1DhjFh0FK6pPw3UWT8EDdRZPPUV6jCeGqgG6jQFHBaPo56hyck3EXvsJA4di8Pp+Iu4cPEKribewPXrybi/0H14sGhhlC5VHOXKlESNKo+ibs1AlCnNn4KdY44AGn/+Ej7bvB879h3GjeSb0nSIgLo1g9C2ZUPUqxUsXU5lR1sDvXItCcs/2YHtew/hdprUXp5cWVQProhe3VqiejBv47Gv2Rbotj2xWLhqM67fSHGb+nzFvtiiHnp3a4lC99tzn7LtgKam3sKcRZ9j1/4jbgN5Z0WPVHgI4wZ1RfmH7bc/y1ZAb6bewuTIj3HwSJzHYGZUXKpEMUwd+QoqlefMAvYx2wC9fTvNBfPAYV467B1jqDPGhdjqTdg2QOcuXoctuw96h2SWViqWDcDsiaEoUvh+r7dtpUFbAP3ywHFEzPuXlfjcUqZV8zoYFNLWLXV5uhLlgf6ZlIx+o+fjamKSp7XIs35+nj71RGWf9kGmceWBLli+ARt2cBof6+ZfvCiSkpJx67b1sSq/HM2b0h9+BdRe7ao00IuXE9E7fC5u3bptimaJ4g/gr83rov5Tj6PyIw+7xpRpaQLnLlxG7NGT2L4vFid+OWuqTnYeOaAjmjWsabqcNwsoDXTJ6m1Yu/FLU3q0a9UQPTs8h6JFCuVZbvfXRzF/6XokmZiYCH6sHOZMDDXVH287Kw30taGzwVepjBERhoa+jOefqSXj7vI5/fsFTJi5ChcucjogOYt+eyAqlVN3bKos0OM/n0b4lCVyKgMI6fICOr30jLR/hmPcb+cQPmUxUm5mboLOs45XOz2PLm2bmG7HWwWUBbpm/V7XxLuMPV65PGZN6A2+Sq3YmnV7sHztF1JF69QMwuQRPaR8feGkLFCeFfr64I9Smkwc1h31aj0u5ZuTU3LKTYQMi0RiEq9ozdseKFIIq6M5c4GapizQfqPn4ew547yFDxQthFVR4fDzy99wYkbMp9j51Q9SlD6MHIYS/pyMVD1TFmjH0AjwZLyRNapTFeMGdzVyM/z/1j0HEblonaEfO8wY3wvVgipK+XrbSVmg7UImI01iDXi7lg3Qt0f+91od/fE3jIpYKqX/hCHd0KB2FSlfbzupC7TXZNdkgJH9rU0TvNb5eSM3w/+fOnMeYePkshKMGtgJTRuomcpJWaDdw6Yj8U/jl5QXmtTGkD7tDIEZOcQejcO46ZxB1tj+ObwH6j4ZZOzoAw9lgYaOjEL8+cuGkrhr9ubTTV9h0cdbDdtjh9lv9QEPlVQ0ZYGOfXcFDh07KaXZstlDEVCymJRvbk6j316GIyc4s4+xrYwaAf9iaubnUhboBx9tcS3NlDGeIeKZIqv286l4DJmYawrabNXyD4d/QKqaskB5je2s9z+T0o2/pkRHDLC8VMTM3YC/4Lw1tLtUv3zhpCxQnjAPGR4prUmVwAqYPjbE9ATD2g37sGTNdul2eIlnh9aNpf297agsUBbijfExOHn6D2lN+M1z9MDOhp/OMir898YvXTDN7Hle+E6Y0ss7lQa6Yu0OrF63VxooO5Yp7Y/eXVvh2frVcy3369nzWPzxNnz3g7kVhBXKBiBmGmduV9eUBnr69wQMGLPAknplAvzxdK1gVK70sAvytcQbOHMuAbFH4vDTqXhTV2VGB17p1AJd2za11B9vFVIaKItgZjjhSdH409zSWYMRUFLthKXKA+UvIPwlxNfGc7c8h6u6KQ+UF4j1CY9CwuVrPtVySnhP1K4R6NM+yDSuPFAOYt3WbxCzMs8DhWRitexTNagCZo7vbbm8NwvaAmhKSip6hc/F1Wu+WWyt8ueyO38stgDKnd74xXeYv+y/3vyxu9qqVf0xRIx61evtWm3QNkDT0tIQNj4Gv529YDVW0+V4zVnkpL4IfMQ+qRBtA5RpHD5+EmPeWWEajNUCrZ+ri7DX21gt7pNytgLKCkUu+hxb9/DhT541/qoSHTFQehrRs72Rr912QJOuJ7tmjy5dsXREtbQydnoRyhqU7YBy57899BMmzebDEz1jLzR5CkP6vOyZyj1cqy2Bsibzlq7Hpp3fu12ehwL8sWBqfxQpnPdmJ7c37KYKbQs0OSUVgyfE4OwfxouxzWjFQxQeqtjVbAuUBeeNRiMmL5ZakC0DqEf75ujevrmMq7I+tgbKqnICKs5blF+rUyMQk4b3QIEC1jY85bd9d5W3PVAWYu6Sddiyy3qGFP52OmdSKIo/qOZKPjOwHQGUs4uNjFiKn07+biZ2l+99Bf1ca5GCFV1nazYgRwDloC9dScSIKUtwPoFPXpS3UQM6oWlDNbc1yEfxf0/HAOWQzsQnuK7Ua4l86K2xvdKxBbq2U3tJiXEU2T0cBZRDOxF3FmOmLUfKzdQ8tWjzl/ro17O15V3fZoX2lr/jgLJwPJPEO8Bz273WqlkdDOplj8xgZn8IjgTKInBS5Nkf/OcuPRrXrYY3wzqjgOIJpMyCzPB3LFAOcPPO7xG1dH2mNo2frgZ+CSpY0M+qXsqXczRQVn/99m/x3oqNePrJIIwf3M3RMDlexwPNGNIUL1YUBf2ce2XeE7dc5e+PHujgPXGFekA3ZavUQJVFY61jGqg13ZQtpYEqi8ZaxzRQa7opW0oDVRaNtY4xUD5ryh5nWFiL8V4q5TpUnbM7OevMxXsJYfZYLzHQXwCov/Hx3oVkJvI4BroZQCszpbSvsgpsYaAzAQxTtou6Y2YUmMVAuwBYbaaU9lVWgQ4MlDc/8nI5ey9IVVZjr3WMkwuXdUEUQnwFoJHXmtYNeUKB/UTUOANoPwBy6Zw90RVdpzsU6E9EMRlAeRzKyWn1eNQd0nq/Dl6MXJmIrmQ+N4UQUwCM9X5fdItuUCCCiFzssgItA4CzGeYvNbQbeqerMKUAHw4XSEQJ2YCmvxwNBjDHVHXa2dcKDCGizMTC2YYqQgheRcXnOzbwdS91+1IKcA73Z4ko86Tbu8aeQgjevsx73UtKVamdfKUAvwjVIaJTWTuQ42SCEIIz8m/g3Xa+6q1uN08FeOPOS0S07U6vXGeHhBB9AMgdlaDV97YCoUT0QU6N5jndJ4QYCCAKQP6O/vN2uM5tj5+VYUQUnVuIhvO3QojOAPioXTXPV3QuvDsj41SkrxPRJ3mFbAg0fTjDGfnXAFD7iHjnwj0EoCsRnTAKUQpoOlTOxDQcwDgARYwq1v93iwK8FZ1n8GYREa/9MjRpoBk1pX9uGwSgvx7aGOpr1YHXecVwghciijdTiWmgWcDyM7UngBcBtNRXrRnZc/TlszV5OdBGAKuIyFJ2SstAs3ZJCFEYQDMAnIaLU4pUBVAagL8ey94Fj8eQVwHw3Cs/E48C2AVgNxEl5/dn8T/LzFY88eq0ogAAAABJRU5ErkJggg==",
  vi = (t) => (Gn("data-v-b50875b1"), (t = t()), qn(), t),
  bi = vi(() => M("div", { class: "dac" }, null, -1)),
  yi = ue({
    __name: "ChatFooterAction",
    emits: ["closeActionBar", "getFile"],
    setup(t, { emit: e }) {
      const { t: o, locale: n } = Te(),
        { inviteRtc: a } = Jo(),
        s = [
          { text: o("footerAction.album"), icon: fi, type: W.Album },
          { text: o("footerAction.shoot"), icon: Ai, type: W.Shoot },
          // { text: o("rtc.video"), icon: gi, type: W.VideoCall },
          // { text: o("footerAction.file"), icon: pi, type: W.File },
          { text: o("footerAction.idCard"), icon: mi, type: W.IDCard },
          // { text: o("footerAction.location"), icon: hi, type: W.Location },
        ],
        c = [
          { name: o("picture"), type: W.Album },
          { name: o("video"), type: W.Album },
        ],
        r = [
          { name: o("photograph"), type: W.Shoot },
          { name: o("recording"), type: W.Shoot },
        ],
        i = [
          { name: o("rtc.voice"), type: W.VoiceCall },
          { name: o("rtc.video"), type: W.VideoCall },
        ];
      pt(n, () => {
        (s[0].text = o("footerAction.album")),
          (s[1].text = o("footerAction.shoot")),
          (s[2].text = o("rtc.video")),
          // (s[3].text = o("footerAction.file")),
          (s[4].text = o("footerAction.idCard")),
          // (s[5].text = o("footerAction.location")),
          (c[0].name = o("picture")),
          (c[1].name = o("video")),
          (r[0].name = o("photograph")),
          (r[1].name = o("recording")),
          (i[0].name = o("rtc.voice")),
          (i[1].name = o("rtc.video"));
      });
      const l = jt(),
        u = ve(),
        f = re(() => u.storeCurrentConversation.conversationType === gt.Single),
        d = z(!1),
        A = z([]),
        p = At({ accept: "*", capture: void 0 }),
        h = z(null),
        b = z();
      let y = null;
      Go(h, () => e("closeActionBar"), {
        ignore: [".van-overlay", ".van-action-sheet__content"],
      });
      const I = ({ type: k }, B) => {
          if (k === W.VoiceCall || k === W.VideoCall) {
            (d.value = !1),
              f.value
                ? a(k, "", [u.currentConversation.userID])
                : l.push({
                    path: "groupMemberList",
                    state: {
                      groupID: u.storeCurrentGroupInfo.groupID,
                      action:
                        k === W.VoiceCall ? Ft.VoiceInvite : Ft.VideoInvite,
                    },
                  });
            return;
          }
          (p.accept = B === 0 ? "image/*" : "video/*"),
            k === W.Shoot && (p.capture = B === 0 ? "camera" : "camcorder"),
            dt(() => {
              var w;
              return (w = b.value) == null ? void 0 : w.chooseFile();
            }),
            (d.value = !1);
        },
        D = ({ type: k }) => {
          switch ((console.log(k), k)) {
            case W.Album:
              (A.value = [...c]), (d.value = !0);
              break;
            case W.Shoot:
              (A.value = [...r]), (d.value = !0);
              break;
            case W.File:
              (p.accept = "*"),
                (p.capture = void 0),
                dt(() => {
                  var B;
                  return (B = b.value) == null ? void 0 : B.chooseFile();
                });
              break;
            case W.VideoCall:
              (A.value = [...i]), (d.value = !0);
              break;
            case W.IDCard:
              l.push({
                path: "chooseUser",
                state: { chooseType: Zo.ChooseCard },
              });
              break;
            case W.Location:
              (y = xn({
                message: o("messageTip.getLocation"),
                forbidClick: !0,
              })),
                navigator.geolocation &&
                  navigator.geolocation.getCurrentPosition(
                    (B) => {
                      console.log(B),
                        y == null || y.close(),
                        (y = null),
                        l.push({
                          path: "geolacationPage",
                          state: {
                            lng: B.coords.longitude,
                            lat: B.coords.latitude,
                          },
                        });
                    },
                    (B) => {
                      y &&
                        ((y.message = o("messageTip.getLocationFailed")),
                        y.close(),
                        (y = null));
                    }
                  );
              break;
          }
        },
        T = (k) => {
          Array.isArray(k) || (k = [k]),
            k.map((B) => {
              e("getFile", B);
            });
        };
      return (k, B) => {
        const w = Is,
          U = Cs,
          j = As,
          $ = Xo;
        return (
          X(),
          _(
            "div",
            { ref_key: "target", ref: h, class: "bg-[#F0F2F6]" },
            [
              L(
                U,
                { class: "px-3 py-3", border: !1, "column-num": 4 },
                {
                  default: Qe(() => [
                    (X(),
                    _(
                      to,
                      null,
                      qo(s, (oe) =>
                        L(
                          w,
                          {
                            key: oe.type,
                            clickable: "",
                            icon: oe.icon,
                            text: oe.text,
                            onClick: (K) => D(oe),
                          },
                          null,
                          8,
                          ["icon", "text", "onClick"]
                        )
                      ),
                      64
                    )),
                  ]),
                  _: 1,
                }
              ),
              de(
                L(
                  j,
                  {
                    ref_key: "uploaderRef",
                    ref: b,
                    accept: p.accept,
                    capture: p.capture,
                    "preview-image": !1,
                    multiple: "",
                    "max-count": "9",
                    "after-read": T,
                  },
                  null,
                  8,
                  ["accept", "capture"]
                ),
                [[fe, !1]]
              ),
              L(
                $,
                {
                  show: d.value,
                  "onUpdate:show": B[0] || (B[0] = (oe) => (d.value = oe)),
                  teleport: "body",
                  actions: A.value,
                  onSelect: I,
                },
                null,
                8,
                ["show", "actions"]
              ),
              bi,
            ],
            512
          )
        );
      };
    },
  });
const wi = vt(yi, [["__scopeId", "data-v-b50875b1"]]);
function Bt(t) {
  if (typeof t != "string" || !t)
    throw new Error("expected a non-empty string, got: " + t);
}
function zt(t) {
  if (typeof t != "number") throw new Error("expected a number, got: " + t);
}
const Ci = 1,
  Ei = 1,
  je = "emoji",
  mt = "keyvalue",
  oo = "favorites",
  ki = "tokens",
  en = "tokens",
  Bi = "unicode",
  tn = "count",
  Ii = "group",
  Si = "order",
  on = "group-order",
  mo = "eTag",
  Kt = "url",
  ho = "skinTone",
  ot = "readonly",
  no = "readwrite",
  nn = "skinUnicodes",
  Di = "skinUnicodes",
  Mi =
    "https://cdn.jsdelivr.net/npm/emoji-picker-element-data@^1/en/emojibase/data.json",
  Ui = "en";
function Ti(t, e) {
  const o = new Set(),
    n = [];
  for (const a of t) {
    const s = e(a);
    o.has(s) || (o.add(s), n.push(a));
  }
  return n;
}
function vo(t) {
  return Ti(t, (e) => e.unicode);
}
function Ri(t) {
  function e(o, n, a) {
    const s = n
      ? t.createObjectStore(o, { keyPath: n })
      : t.createObjectStore(o);
    if (a)
      for (const [c, [r, i]] of Object.entries(a))
        s.createIndex(c, r, { multiEntry: i });
    return s;
  }
  e(mt),
    e(je, Bi, { [en]: [ki, !0], [on]: [[Ii, Si]], [nn]: [Di, !0] }),
    e(oo, void 0, { [tn]: [""] });
}
const Zt = {},
  Ut = {},
  Qt = {};
function sn(t, e, o) {
  (o.onerror = () => e(o.error)),
    (o.onblocked = () => e(new Error("IDB blocked"))),
    (o.onsuccess = () => t(o.result));
}
async function Fi(t) {
  const e = await new Promise((o, n) => {
    const a = indexedDB.open(t, Ci);
    (Zt[t] = a),
      (a.onupgradeneeded = (s) => {
        s.oldVersion < Ei && Ri(a.result);
      }),
      sn(o, n, a);
  });
  return (e.onclose = () => so(t)), e;
}
function Qi(t) {
  return Ut[t] || (Ut[t] = Fi(t)), Ut[t];
}
function Me(t, e, o, n) {
  return new Promise((a, s) => {
    const c = t.transaction(e, o, { durability: "relaxed" }),
      r =
        typeof e == "string"
          ? c.objectStore(e)
          : e.map((l) => c.objectStore(l));
    let i;
    n(r, c, (l) => {
      i = l;
    }),
      (c.oncomplete = () => a(i)),
      (c.onerror = () => s(c.error));
  });
}
function so(t) {
  const e = Zt[t],
    o = e && e.result;
  if (o) {
    o.close();
    const n = Qt[t];
    if (n) for (const a of n) a();
  }
  delete Zt[t], delete Ut[t], delete Qt[t];
}
function Oi(t) {
  return new Promise((e, o) => {
    so(t);
    const n = indexedDB.deleteDatabase(t);
    sn(e, o, n);
  });
}
function ji(t, e) {
  let o = Qt[t];
  o || (o = Qt[t] = []), o.push(e);
}
const Ni = new Set([
  ":D",
  "XD",
  ":'D",
  "O:)",
  ":X",
  ":P",
  ";P",
  "XP",
  ":L",
  ":Z",
  ":j",
  "8D",
  "XO",
  "8)",
  ":B",
  ":O",
  ":S",
  ":'o",
  "Dx",
  "X(",
  "D:",
  ":C",
  ">0)",
  ":3",
  "</3",
  "<3",
  "\\M/",
  ":E",
  "8#",
]);
function _e(t) {
  return t
    .split(/[\s_]+/)
    .map((e) =>
      !e.match(/\w/) || Ni.has(e)
        ? e.toLowerCase()
        : e
            .replace(/[)(:,]/g, "")
            .replace(/’/g, "'")
            .toLowerCase()
    )
    .filter(Boolean);
}
const Vi = 2;
function rn(t) {
  return t
    .filter(Boolean)
    .map((e) => e.toLowerCase())
    .filter((e) => e.length >= Vi);
}
function Pi(t) {
  return t.map(
    ({
      annotation: o,
      emoticon: n,
      group: a,
      order: s,
      shortcodes: c,
      skins: r,
      tags: i,
      emoji: l,
      version: u,
    }) => {
      const f = [
          ...new Set(
            rn([...(c || []).map(_e).flat(), ...i.map(_e).flat(), ..._e(o), n])
          ),
        ].sort(),
        d = {
          annotation: o,
          group: a,
          order: s,
          tags: i,
          tokens: f,
          unicode: l,
          version: u,
        };
      if ((n && (d.emoticon = n), c && (d.shortcodes = c), r)) {
        (d.skinTones = []), (d.skinUnicodes = []), (d.skinVersions = []);
        for (const { tone: A, emoji: p, version: h } of r)
          d.skinTones.push(A), d.skinUnicodes.push(p), d.skinVersions.push(h);
      }
      return d;
    }
  );
}
function an(t, e, o, n) {
  t[e](o).onsuccess = (a) => n && n(a.target.result);
}
function Oe(t, e, o) {
  an(t, "get", e, o);
}
function cn(t, e, o) {
  an(t, "getAll", e, o);
}
function io(t) {
  t.commit && t.commit();
}
function zi(t, e) {
  let o = t[0];
  for (let n = 1; n < t.length; n++) {
    const a = t[n];
    e(o) > e(a) && (o = a);
  }
  return o;
}
function ln(t, e) {
  const o = zi(t, (a) => a.length),
    n = [];
  for (const a of o)
    t.some((s) => s.findIndex((c) => e(c) === e(a)) === -1) || n.push(a);
  return n;
}
async function Li(t) {
  return !(await dn(t, mt, Kt));
}
async function xi(t, e) {
  return Me(t, je, ot, (n, a, s) => {
    let c;
    const r = () => {
      n.getAll(c && IDBKeyRange.lowerBound(c, !0), 50).onsuccess = (i) => {
        const l = i.target.result;
        for (const u of l) if (((c = u.unicode), e(u))) return s(u);
        if (l.length < 50) return s();
        r();
      };
    };
    r();
  });
}
async function Gi(t, e, o, n) {
  try {
    const a = Pi(e);
    await Me(t, [je, mt], no, ([s, c], r) => {
      let i,
        l,
        u = 0;
      function f() {
        ++u === 2 && d();
      }
      function d() {
        if (!(i === n && l === o)) {
          s.clear();
          for (const A of a) s.put(A);
          c.put(n, mo), c.put(o, Kt), io(r);
        }
      }
      Oe(c, mo, (A) => {
        (i = A), f();
      }),
        Oe(c, Kt, (A) => {
          (l = A), f();
        });
    });
  } finally {
  }
}
async function qi(t, e) {
  return Me(t, je, ot, (o, n, a) => {
    const s = IDBKeyRange.bound([e, 0], [e + 1, 0], !1, !0);
    cn(o.index(on), s, a);
  });
}
async function un(t, e) {
  const o = rn(_e(e));
  return o.length
    ? Me(t, je, ot, (n, a, s) => {
        const c = [],
          r = () => {
            c.length === o.length && i();
          },
          i = () => {
            const l = ln(c, (u) => u.unicode);
            s(l.sort((u, f) => (u.order < f.order ? -1 : 1)));
          };
        for (let l = 0; l < o.length; l++) {
          const u = o[l],
            f =
              l === o.length - 1
                ? IDBKeyRange.bound(u, u + "￿", !1, !0)
                : IDBKeyRange.only(u);
          cn(n.index(en), f, (d) => {
            c.push(d), r();
          });
        }
      })
    : [];
}
async function Yi(t, e) {
  const o = await un(t, e);
  return o.length
    ? o.filter((n) =>
        (n.shortcodes || [])
          .map((s) => s.toLowerCase())
          .includes(e.toLowerCase())
      )[0] || null
    : (await xi(t, (a) => (a.shortcodes || []).includes(e.toLowerCase()))) ||
        null;
}
async function Hi(t, e) {
  return Me(t, je, ot, (o, n, a) =>
    Oe(o, e, (s) => {
      if (s) return a(s);
      Oe(o.index(nn), e, (c) => a(c || null));
    })
  );
}
function dn(t, e, o) {
  return Me(t, e, ot, (n, a, s) => Oe(n, o, s));
}
function Xi(t, e, o, n) {
  return Me(t, e, no, (a, s) => {
    a.put(n, o), io(s);
  });
}
function Ji(t, e) {
  return Me(t, oo, no, (o, n) =>
    Oe(o, e, (a) => {
      o.put((a || 0) + 1, e), io(n);
    })
  );
}
function Wi(t, e, o) {
  return o === 0
    ? []
    : Me(t, [oo, je], ot, ([n, a], s, c) => {
        const r = [];
        n.index(tn).openCursor(void 0, "prev").onsuccess = (i) => {
          const l = i.target.result;
          if (!l) return c(r);
          function u(A) {
            if ((r.push(A), r.length === o)) return c(r);
            l.continue();
          }
          const f = l.primaryKey,
            d = e.byName(f);
          if (d) return u(d);
          Oe(a, f, (A) => {
            if (A) return u(A);
            l.continue();
          });
        };
      });
}
const It = "";
function Ki(t, e) {
  const o = new Map();
  for (const a of t) {
    const s = e(a);
    for (const c of s) {
      let r = o;
      for (let l = 0; l < c.length; l++) {
        const u = c.charAt(l);
        let f = r.get(u);
        f || ((f = new Map()), r.set(u, f)), (r = f);
      }
      let i = r.get(It);
      i || ((i = []), r.set(It, i)), i.push(a);
    }
  }
  return (a, s) => {
    let c = o;
    for (let l = 0; l < a.length; l++) {
      const u = a.charAt(l),
        f = c.get(u);
      if (f) c = f;
      else return [];
    }
    if (s) return c.get(It) || [];
    const r = [],
      i = [c];
    for (; i.length; ) {
      const u = [...i.shift().entries()].sort((f, d) => (f[0] < d[0] ? -1 : 1));
      for (const [f, d] of u) f === It ? r.push(...d) : i.push(d);
    }
    return r;
  };
}
const Zi = ["name", "url"];
function _i(t) {
  const e = t && Array.isArray(t),
    o = e && t.length && (!t[0] || Zi.some((n) => !(n in t[0])));
  if (!e || o) throw new Error("Custom emojis are in the wrong format");
}
function bo(t) {
  _i(t);
  const e = (d, A) => (d.name.toLowerCase() < A.name.toLowerCase() ? -1 : 1),
    o = t.sort(e),
    a = Ki(t, (d) => [
      ...new Set((d.shortcodes || []).map((A) => _e(A)).flat()),
    ]),
    s = (d) => a(d, !0),
    c = (d) => a(d, !1),
    r = (d) => {
      const A = _e(d),
        p = A.map((h, b) => (b < A.length - 1 ? s : c)(h));
      return ln(p, (h) => h.name).sort(e);
    },
    i = new Map(),
    l = new Map();
  for (const d of t) {
    l.set(d.name.toLowerCase(), d);
    for (const A of d.shortcodes || []) i.set(A.toLowerCase(), d);
  }
  return {
    all: o,
    search: r,
    byShortcode: (d) => i.get(d.toLowerCase()),
    byName: (d) => l.get(d.toLowerCase()),
  };
}
const $i = typeof wrappedJSObject < "u";
function at(t) {
  if (!t) return t;
  if (($i && (t = structuredClone(t)), delete t.tokens, t.skinTones)) {
    const e = t.skinTones.length;
    t.skins = Array(e);
    for (let o = 0; o < e; o++)
      t.skins[o] = {
        tone: t.skinTones[o],
        unicode: t.skinUnicodes[o],
        version: t.skinVersions[o],
      };
    delete t.skinTones, delete t.skinUnicodes, delete t.skinVersions;
  }
  return t;
}
function er(t) {
  t ||
    console.warn(
      "emoji-picker-element is more efficient if the dataSource server exposes an ETag header."
    );
}
const tr = ["annotation", "emoji", "group", "order", "tags", "version"];
function or(t) {
  if (
    !t ||
    !Array.isArray(t) ||
    !t[0] ||
    typeof t[0] != "object" ||
    tr.some((e) => !(e in t[0]))
  )
    throw new Error("Emoji data is in the wrong format");
}
function nr(t, e) {
  if (Math.floor(t.status / 100) !== 2)
    throw new Error("Failed to fetch: " + e + ":  " + t.status);
}
async function sr(t) {
  const e = await fetch(t);
  nr(e, t);
  const o = e.headers.get("etag");
  er(o);
  const n = await e.json();
  return or(n), [o, n];
}
function ir(t) {
  for (var e = "", o = new Uint8Array(t), n = o.byteLength, a = -1; ++a < n; )
    e += String.fromCharCode(o[a]);
  return e;
}
function rr(t) {
  for (
    var e = t.length, o = new ArrayBuffer(e), n = new Uint8Array(o), a = -1;
    ++a < e;

  )
    n[a] = t.charCodeAt(a);
  return o;
}
async function ar(t) {
  const e = JSON.stringify(t),
    o = rr(e),
    n = await crypto.subtle.digest("SHA-1", o),
    a = ir(n);
  return btoa(a);
}
async function cr(t, e) {
  let [o, n] = await sr(e);
  o || (o = await ar(n)), await Gi(t, n, e, o);
}
class lr {
  constructor({
    dataSource: e = Mi,
    locale: o = Ui,
    customEmoji: n = [],
  } = {}) {
    (this.dataSource = e),
      (this.locale = o),
      (this._dbName = `emoji-picker-element-${this.locale}`),
      (this._db = void 0),
      (this._lazyUpdate = void 0),
      (this._custom = bo(n)),
      (this._clear = this._clear.bind(this)),
      (this._ready = this._init());
  }
  async _init() {
    const e = (this._db = await Qi(this._dbName));
    ji(this._dbName, this._clear);
    const o = this.dataSource;
    (await Li(e)) && (await cr(e, o));
  }
  async ready() {
    const e = async () => (
      this._ready || (this._ready = this._init()), this._ready
    );
    await e(), this._db || (await e());
  }
  async getEmojiByGroup(e) {
    return zt(e), await this.ready(), vo(await qi(this._db, e)).map(at);
  }
  async getEmojiBySearchQuery(e) {
    Bt(e), await this.ready();
    const o = this._custom.search(e),
      n = vo(await un(this._db, e)).map(at);
    return [...o, ...n];
  }
  async getEmojiByShortcode(e) {
    Bt(e), await this.ready();
    const o = this._custom.byShortcode(e);
    return o || at(await Yi(this._db, e));
  }
  async getEmojiByUnicodeOrName(e) {
    Bt(e), await this.ready();
    const o = this._custom.byName(e);
    return o || at(await Hi(this._db, e));
  }
  async getPreferredSkinTone() {
    return await this.ready(), (await dn(this._db, mt, ho)) || 0;
  }
  async setPreferredSkinTone(e) {
    return zt(e), await this.ready(), Xi(this._db, mt, ho, e);
  }
  async incrementFavoriteEmojiCount(e) {
    return Bt(e), await this.ready(), Ji(this._db, e);
  }
  async getTopFavoriteEmoji(e) {
    return (
      zt(e), await this.ready(), (await Wi(this._db, this._custom, e)).map(at)
    );
  }
  set customEmoji(e) {
    this._custom = bo(e);
  }
  get customEmoji() {
    return this._custom.all;
  }
  async _shutdown() {
    await this.ready();
    try {
      await this._lazyUpdate;
    } catch {}
  }
  _clear() {
    this._db = this._ready = this._lazyUpdate = void 0;
  }
  async close() {
    await this._shutdown(), await so(this._dbName);
  }
  async delete() {
    await this._shutdown(), await Oi(this._dbName);
  }
}
function et() {}
function fn(t) {
  return t();
}
function yo() {
  return Object.create(null);
}
function nt(t) {
  t.forEach(fn);
}
function ro(t) {
  return typeof t == "function";
}
function ur(t, e) {
  return t != t
    ? e == e
    : t !== e || (t && typeof t == "object") || typeof t == "function";
}
let St;
function Ot(t, e) {
  return t === e
    ? !0
    : (St || (St = document.createElement("a")), (St.href = e), t === St.href);
}
function dr(t) {
  return Object.keys(t).length === 0;
}
function fr(t) {
  return t && ro(t.destroy) ? t.destroy : et;
}
const Ar =
  typeof window < "u" ? window : typeof globalThis < "u" ? globalThis : global;
function P(t, e) {
  t.appendChild(e);
}
function me(t, e, o) {
  t.insertBefore(e, o || null);
}
function he(t) {
  t.parentNode && t.parentNode.removeChild(t);
}
function V(t) {
  return document.createElement(t);
}
function Ee(t) {
  return document.createTextNode(t);
}
function ge(t, e, o, n) {
  return t.addEventListener(e, o, n), () => t.removeEventListener(e, o, n);
}
function g(t, e, o) {
  o == null
    ? t.removeAttribute(e)
    : t.getAttribute(e) !== o && t.setAttribute(e, o);
}
function ke(t, e) {
  (e = "" + e), t.data !== e && (t.data = e);
}
function wo(t, e) {
  t.value = e ?? "";
}
function Ue(t, e, o, n) {
  o == null
    ? t.style.removeProperty(e)
    : t.style.setProperty(e, o, n ? "important" : "");
}
let ao;
function ft(t) {
  ao = t;
}
const We = [],
  Ze = [];
let $e = [];
const Co = [],
  gr = Promise.resolve();
let _t = !1;
function pr() {
  _t || ((_t = !0), gr.then(An));
}
function $t(t) {
  $e.push(t);
}
const Lt = new Set();
let Je = 0;
function An() {
  if (Je !== 0) return;
  const t = ao;
  do {
    try {
      for (; Je < We.length; ) {
        const e = We[Je];
        Je++, ft(e), mr(e.$$);
      }
    } catch (e) {
      throw ((We.length = 0), (Je = 0), e);
    }
    for (ft(null), We.length = 0, Je = 0; Ze.length; ) Ze.pop()();
    for (let e = 0; e < $e.length; e += 1) {
      const o = $e[e];
      Lt.has(o) || (Lt.add(o), o());
    }
    $e.length = 0;
  } while (We.length);
  for (; Co.length; ) Co.pop()();
  (_t = !1), Lt.clear(), ft(t);
}
function mr(t) {
  if (t.fragment !== null) {
    t.update(), nt(t.before_update);
    const e = t.dirty;
    (t.dirty = [-1]),
      t.fragment && t.fragment.p(t.ctx, e),
      t.after_update.forEach($t);
  }
}
function hr(t) {
  const e = [],
    o = [];
  $e.forEach((n) => (t.indexOf(n) === -1 ? e.push(n) : o.push(n))),
    o.forEach((n) => n()),
    ($e = e);
}
const vr = new Set();
function br(t, e) {
  t && t.i && (vr.delete(t), t.i(e));
}
function we(t) {
  return (t == null ? void 0 : t.length) !== void 0 ? t : Array.from(t);
}
function ct(t, e) {
  t.d(1), e.delete(t.key);
}
function lt(t, e, o, n, a, s, c, r, i, l, u, f) {
  let d = t.length,
    A = s.length,
    p = d;
  const h = {};
  for (; p--; ) h[t[p].key] = p;
  const b = [],
    y = new Map(),
    I = new Map(),
    D = [];
  for (p = A; p--; ) {
    const w = f(a, s, p),
      U = o(w);
    let j = c.get(U);
    j ? n && D.push(() => j.p(w, e)) : ((j = l(U, w)), j.c()),
      y.set(U, (b[p] = j)),
      U in h && I.set(U, Math.abs(p - h[U]));
  }
  const T = new Set(),
    k = new Set();
  function B(w) {
    br(w, 1), w.m(r, u), c.set(w.key, w), (u = w.first), A--;
  }
  for (; d && A; ) {
    const w = b[A - 1],
      U = t[d - 1],
      j = w.key,
      $ = U.key;
    w === U
      ? ((u = w.first), d--, A--)
      : y.has($)
      ? !c.has(j) || T.has(j)
        ? B(w)
        : k.has($)
        ? d--
        : I.get(j) > I.get($)
        ? (k.add(j), B(w))
        : (T.add($), d--)
      : (i(U, c), d--);
  }
  for (; d--; ) {
    const w = t[d];
    y.has(w.key) || i(w, c);
  }
  for (; A; ) B(b[A - 1]);
  return nt(D), b;
}
function yr(t, e, o) {
  const { fragment: n, after_update: a } = t.$$;
  n && n.m(e, o),
    $t(() => {
      const s = t.$$.on_mount.map(fn).filter(ro);
      t.$$.on_destroy ? t.$$.on_destroy.push(...s) : nt(s),
        (t.$$.on_mount = []);
    }),
    a.forEach($t);
}
function wr(t, e) {
  const o = t.$$;
  o.fragment !== null &&
    (hr(o.after_update),
    nt(o.on_destroy),
    o.fragment && o.fragment.d(e),
    (o.on_destroy = o.fragment = null),
    (o.ctx = []));
}
function Cr(t, e) {
  t.$$.dirty[0] === -1 && (We.push(t), pr(), t.$$.dirty.fill(0)),
    (t.$$.dirty[(e / 31) | 0] |= 1 << e % 31);
}
function Er(t, e, o, n, a, s, c = null, r = [-1]) {
  const i = ao;
  ft(t);
  const l = (t.$$ = {
    fragment: null,
    ctx: [],
    props: s,
    update: et,
    not_equal: a,
    bound: yo(),
    on_mount: [],
    on_destroy: [],
    on_disconnect: [],
    before_update: [],
    after_update: [],
    context: new Map(i ? i.$$.context : []),
    callbacks: yo(),
    dirty: r,
    skip_bound: !1,
    root: e.target || i.$$.root,
  });
  c && c(l.root);
  let u = !1;
  (l.ctx = o
    ? o(t, e.props || {}, (f, d, ...A) => {
        const p = A.length ? A[0] : d;
        return (
          l.ctx &&
            a(l.ctx[f], (l.ctx[f] = p)) &&
            (!l.skip_bound && l.bound[f] && l.bound[f](p), u && Cr(t, f)),
          d
        );
      })
    : []),
    l.update(),
    (u = !0),
    nt(l.before_update),
    (l.fragment = n ? n(l.ctx) : !1),
    e.target && (l.fragment && l.fragment.c(), yr(t, e.target, void 0), An()),
    ft(i);
}
class kr {
  constructor() {
    Nt(this, "$$");
    Nt(this, "$$set");
  }
  $destroy() {
    wr(this, 1), (this.$destroy = et);
  }
  $on(e, o) {
    if (!ro(o)) return et;
    const n = this.$$.callbacks[e] || (this.$$.callbacks[e] = []);
    return (
      n.push(o),
      () => {
        const a = n.indexOf(o);
        a !== -1 && n.splice(a, 1);
      }
    );
  }
  $set(e) {
    this.$$set &&
      !dr(e) &&
      ((this.$$.skip_bound = !0), this.$$set(e), (this.$$.skip_bound = !1));
  }
}
const gn = [
    [-1, "✨", "custom"],
    [0, "😀", "smileys-emotion"],
    [1, "👋", "people-body"],
    [3, "🐱", "animals-nature"],
    [4, "🍎", "food-drink"],
    [5, "🏠️", "travel-places"],
    [6, "⚽", "activities"],
    [7, "📝", "objects"],
    [8, "⛔️", "symbols"],
    [9, "🏁", "flags"],
  ].map(([t, e, o]) => ({ id: t, emoji: e, name: o })),
  Dt = gn.slice(1),
  Br = gn[0],
  Ir = 2,
  Eo = 6,
  pn =
    typeof requestIdleCallback == "function" ? requestIdleCallback : setTimeout;
function ko(t) {
  return t.unicode.includes("‍");
}
const Sr = {
    "🫨": 15,
    "🫠": 14,
    "🥲": 13.1,
    "🥻": 12.1,
    "🥰": 11,
    "🤩": 5,
    "👱‍♀️": 4,
    "🤣": 3,
    "👁️‍🗨️": 2,
    "😀": 1,
    "😐️": 0.7,
    "😃": 0.6,
  },
  Dr = 1e3,
  Mr = "🖐️",
  Ur = 8,
  Tr = [
    "😊",
    "😒",
    "♥️",
    "👍️",
    "😍",
    "😂",
    "😭",
    "☺️",
    "😔",
    "😩",
    "😏",
    "💕",
    "🙌",
    "😘",
  ],
  mn =
    '"Twemoji Mozilla","Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji","EmojiOne Color","Android Emoji",sans-serif',
  Rr = (t, e) => (t < e ? -1 : t > e ? 1 : 0),
  Bo = (t, e) => {
    const o = document.createElement("canvas");
    o.width = o.height = 1;
    const n = o.getContext("2d");
    return (
      (n.textBaseline = "top"),
      (n.font = `100px ${mn}`),
      (n.fillStyle = e),
      n.scale(0.01, 0.01),
      n.fillText(t, 0, 0),
      n.getImageData(0, 0, 1, 1).data
    );
  },
  Fr = (t, e) => {
    const o = [...t].join(","),
      n = [...e].join(",");
    return o === n && !o.startsWith("0,0,0,");
  };
function Qr(t) {
  const e = Bo(t, "#000"),
    o = Bo(t, "#fff");
  return e && o && Fr(e, o);
}
function Or() {
  const t = Object.entries(Sr);
  try {
    for (const [e, o] of t) if (Qr(e)) return o;
  } catch {
  } finally {
  }
  return t[0][1];
}
let xt;
const Io = () => (xt || (xt = new Promise((t) => pn(() => t(Or())))), xt),
  eo = new Map(),
  jr = "️",
  Nr = "\uD83C",
  Vr = "‍",
  Pr = 127995,
  zr = 57339;
function Lr(t, e) {
  if (e === 0) return t;
  const o = t.indexOf(Vr);
  return o !== -1
    ? t.substring(0, o) + String.fromCodePoint(Pr + e - 1) + t.substring(o)
    : (t.endsWith(jr) && (t = t.substring(0, t.length - 1)),
      t + Nr + String.fromCodePoint(zr + e - 1));
}
function ye(t) {
  t.preventDefault(), t.stopPropagation();
}
function Gt(t, e, o) {
  return (
    (e += t ? -1 : 1), e < 0 ? (e = o.length - 1) : e >= o.length && (e = 0), e
  );
}
function hn(t, e) {
  const o = new Set(),
    n = [];
  for (const a of t) {
    const s = e(a);
    o.has(s) || (o.add(s), n.push(a));
  }
  return n;
}
function xr(t, e) {
  const o = (n) => {
    const a = {};
    for (const s of n)
      typeof s.tone == "number" && s.version <= e && (a[s.tone] = s.unicode);
    return a;
  };
  return t.map(
    ({
      unicode: n,
      skins: a,
      shortcodes: s,
      url: c,
      name: r,
      category: i,
      annotation: l,
    }) => ({
      unicode: n,
      name: r,
      shortcodes: s,
      url: c,
      category: i,
      annotation: l,
      id: n || r,
      skins: a && o(a),
    })
  );
}
const Tt = requestAnimationFrame;
let Gr = typeof ResizeObserver == "function";
function qr(t, e) {
  let o;
  return (
    Gr
      ? ((o = new ResizeObserver((n) => e(n[0].contentRect.width))),
        o.observe(t))
      : Tt(() => e(t.getBoundingClientRect().width)),
    {
      destroy() {
        o && o.disconnect();
      },
    }
  );
}
function So(t) {
  {
    const e = document.createRange();
    return e.selectNode(t.firstChild), e.getBoundingClientRect().width;
  }
}
let qt;
function Yr(t, e, o) {
  for (const n of t) {
    const a = o(n),
      s = So(a);
    typeof qt > "u" && (qt = So(e));
    const c = s / 1.8 < qt;
    eo.set(n.unicode, c);
  }
}
function Hr(t) {
  return hn(t, (e) => e);
}
function Xr(t) {
  t && (t.scrollTop = 0);
}
const { Map: ut } = Ar;
function Do(t, e, o) {
  const n = t.slice();
  return (n[66] = e[o]), (n[68] = o), n;
}
function Mo(t, e, o) {
  const n = t.slice();
  return (n[69] = e[o]), (n[68] = o), n;
}
function Uo(t, e, o) {
  const n = t.slice();
  return (n[66] = e[o]), (n[68] = o), n;
}
function To(t, e, o) {
  const n = t.slice();
  return (n[72] = e[o]), n;
}
function Ro(t, e, o) {
  const n = t.slice();
  return (n[75] = e[o]), (n[68] = o), n;
}
function Fo(t, e) {
  let o,
    n = e[75] + "",
    a,
    s,
    c,
    r,
    i,
    l;
  return {
    key: t,
    first: null,
    c() {
      (o = V("div")),
        (a = Ee(n)),
        g(o, "id", (s = "skintone-" + e[68])),
        g(o, "class", (c = "emoji " + (e[68] === e[20] ? "active" : ""))),
        g(o, "aria-selected", (r = e[68] === e[20])),
        g(o, "role", "option"),
        g(o, "title", (i = e[0].skinTones[e[68]])),
        g(o, "aria-label", (l = e[0].skinTones[e[68]])),
        (this.first = o);
    },
    m(u, f) {
      me(u, o, f), P(o, a);
    },
    p(u, f) {
      (e = u),
        f[0] & 512 && n !== (n = e[75] + "") && ke(a, n),
        f[0] & 512 && s !== (s = "skintone-" + e[68]) && g(o, "id", s),
        f[0] & 1049088 &&
          c !== (c = "emoji " + (e[68] === e[20] ? "active" : "")) &&
          g(o, "class", c),
        f[0] & 1049088 &&
          r !== (r = e[68] === e[20]) &&
          g(o, "aria-selected", r),
        f[0] & 513 && i !== (i = e[0].skinTones[e[68]]) && g(o, "title", i),
        f[0] & 513 &&
          l !== (l = e[0].skinTones[e[68]]) &&
          g(o, "aria-label", l);
    },
    d(u) {
      u && he(o);
    },
  };
}
function Qo(t, e) {
  let o,
    n,
    a = e[72].emoji + "",
    s,
    c,
    r,
    i,
    l,
    u,
    f;
  function d() {
    return e[51](e[72]);
  }
  return {
    key: t,
    first: null,
    c() {
      (o = V("button")),
        (n = V("div")),
        (s = Ee(a)),
        g(n, "class", "nav-emoji emoji"),
        g(o, "role", "tab"),
        g(o, "class", "nav-button"),
        g(o, "aria-controls", (c = "tab-" + e[72].id)),
        g(o, "aria-label", (r = e[0].categories[e[72].name])),
        g(o, "aria-selected", (i = !e[4] && e[13].id === e[72].id)),
        g(o, "title", (l = e[0].categories[e[72].name])),
        (this.first = o);
    },
    m(A, p) {
      me(A, o, p), P(o, n), P(n, s), u || ((f = ge(o, "click", d)), (u = !0));
    },
    p(A, p) {
      (e = A),
        p[0] & 4096 && a !== (a = e[72].emoji + "") && ke(s, a),
        p[0] & 4096 &&
          c !== (c = "tab-" + e[72].id) &&
          g(o, "aria-controls", c),
        p[0] & 4097 &&
          r !== (r = e[0].categories[e[72].name]) &&
          g(o, "aria-label", r),
        p[0] & 12304 &&
          i !== (i = !e[4] && e[13].id === e[72].id) &&
          g(o, "aria-selected", i),
        p[0] & 4097 &&
          l !== (l = e[0].categories[e[72].name]) &&
          g(o, "title", l);
    },
    d(A) {
      A && he(o), (u = !1), f();
    },
  };
}
function Jr(t) {
  let e, o;
  return {
    c() {
      (e = V("img")),
        g(e, "class", "custom-emoji"),
        Ot(e.src, (o = t[66].url)) || g(e, "src", o),
        g(e, "alt", ""),
        g(e, "loading", "lazy");
    },
    m(n, a) {
      me(n, e, a);
    },
    p(n, a) {
      a[0] & 32768 && !Ot(e.src, (o = n[66].url)) && g(e, "src", o);
    },
    d(n) {
      n && he(e);
    },
  };
}
function Wr(t) {
  let e = t[27](t[66], t[8]) + "",
    o;
  return {
    c() {
      o = Ee(e);
    },
    m(n, a) {
      me(n, o, a);
    },
    p(n, a) {
      a[0] & 33024 && e !== (e = n[27](n[66], n[8]) + "") && ke(o, e);
    },
    d(n) {
      n && he(o);
    },
  };
}
function Oo(t, e) {
  let o, n, a, s, c, r, i;
  function l(d, A) {
    return d[66].unicode ? Wr : Jr;
  }
  let u = l(e),
    f = u(e);
  return {
    key: t,
    first: null,
    c() {
      (o = V("button")),
        f.c(),
        g(o, "role", (n = e[4] ? "option" : "menuitem")),
        g(o, "aria-selected", (a = e[4] ? e[68] == e[5] : "")),
        g(o, "aria-label", (s = e[28](e[66], e[8]))),
        g(o, "title", (c = e[29](e[66]))),
        g(
          o,
          "class",
          (r = "emoji " + (e[4] && e[68] === e[5] ? "active" : ""))
        ),
        g(o, "id", (i = "emo-" + e[66].id)),
        (this.first = o);
    },
    m(d, A) {
      me(d, o, A), f.m(o, null);
    },
    p(d, A) {
      (e = d),
        u === (u = l(e)) && f
          ? f.p(e, A)
          : (f.d(1), (f = u(e)), f && (f.c(), f.m(o, null))),
        A[0] & 16 &&
          n !== (n = e[4] ? "option" : "menuitem") &&
          g(o, "role", n),
        A[0] & 32816 &&
          a !== (a = e[4] ? e[68] == e[5] : "") &&
          g(o, "aria-selected", a),
        A[0] & 33024 && s !== (s = e[28](e[66], e[8])) && g(o, "aria-label", s),
        A[0] & 32768 && c !== (c = e[29](e[66])) && g(o, "title", c),
        A[0] & 32816 &&
          r !== (r = "emoji " + (e[4] && e[68] === e[5] ? "active" : "")) &&
          g(o, "class", r),
        A[0] & 32768 && i !== (i = "emo-" + e[66].id) && g(o, "id", i);
    },
    d(d) {
      d && he(o), f.d();
    },
  };
}
function jo(t, e) {
  let o,
    n =
      (e[4]
        ? e[0].searchResultsLabel
        : e[69].category
        ? e[69].category
        : e[15].length > 1
        ? e[0].categories.custom
        : e[0].categories[e[13].name]) + "",
    a,
    s,
    c,
    r,
    i = [],
    l = new ut(),
    u,
    f,
    d,
    A = we(e[69].emojis);
  const p = (h) => h[66].id;
  for (let h = 0; h < A.length; h += 1) {
    let b = Uo(e, A, h),
      y = p(b);
    l.set(y, (i[h] = Oo(y, b)));
  }
  return {
    key: t,
    first: null,
    c() {
      (o = V("div")), (a = Ee(n)), (r = V("div"));
      for (let h = 0; h < i.length; h += 1) i[h].c();
      g(o, "id", (s = "menu-label-" + e[68])),
        g(
          o,
          "class",
          (c =
            "category " +
            (e[15].length === 1 && e[15][0].category === "" ? "gone" : ""))
        ),
        g(o, "aria-hidden", "true"),
        g(r, "class", "emoji-menu"),
        g(r, "role", (u = e[4] ? "listbox" : "menu")),
        g(r, "aria-labelledby", (f = "menu-label-" + e[68])),
        g(r, "id", (d = e[4] ? "search-results" : "")),
        (this.first = o);
    },
    m(h, b) {
      me(h, o, b), P(o, a), me(h, r, b);
      for (let y = 0; y < i.length; y += 1) i[y] && i[y].m(r, null);
    },
    p(h, b) {
      (e = h),
        b[0] & 40977 &&
          n !==
            (n =
              (e[4]
                ? e[0].searchResultsLabel
                : e[69].category
                ? e[69].category
                : e[15].length > 1
                ? e[0].categories.custom
                : e[0].categories[e[13].name]) + "") &&
          ke(a, n),
        b[0] & 32768 && s !== (s = "menu-label-" + e[68]) && g(o, "id", s),
        b[0] & 32768 &&
          c !==
            (c =
              "category " +
              (e[15].length === 1 && e[15][0].category === "" ? "gone" : "")) &&
          g(o, "class", c),
        b[0] & 939557168 &&
          ((A = we(e[69].emojis)),
          (i = lt(i, b, p, 1, e, A, l, r, ct, Oo, null, Uo))),
        b[0] & 16 && u !== (u = e[4] ? "listbox" : "menu") && g(r, "role", u),
        b[0] & 32768 &&
          f !== (f = "menu-label-" + e[68]) &&
          g(r, "aria-labelledby", f),
        b[0] & 16 && d !== (d = e[4] ? "search-results" : "") && g(r, "id", d);
    },
    d(h) {
      h && (he(o), he(r));
      for (let b = 0; b < i.length; b += 1) i[b].d();
    },
  };
}
function Kr(t) {
  let e, o;
  return {
    c() {
      (e = V("img")),
        g(e, "class", "custom-emoji"),
        Ot(e.src, (o = t[66].url)) || g(e, "src", o),
        g(e, "alt", ""),
        g(e, "loading", "lazy");
    },
    m(n, a) {
      me(n, e, a);
    },
    p(n, a) {
      a[0] & 1024 && !Ot(e.src, (o = n[66].url)) && g(e, "src", o);
    },
    d(n) {
      n && he(e);
    },
  };
}
function Zr(t) {
  let e = t[27](t[66], t[8]) + "",
    o;
  return {
    c() {
      o = Ee(e);
    },
    m(n, a) {
      me(n, o, a);
    },
    p(n, a) {
      a[0] & 1280 && e !== (e = n[27](n[66], n[8]) + "") && ke(o, e);
    },
    d(n) {
      n && he(o);
    },
  };
}
function No(t, e) {
  let o, n, a, s;
  function c(l, u) {
    return l[66].unicode ? Zr : Kr;
  }
  let r = c(e),
    i = r(e);
  return {
    key: t,
    first: null,
    c() {
      (o = V("button")),
        i.c(),
        g(o, "role", "menuitem"),
        g(o, "aria-label", (n = e[28](e[66], e[8]))),
        g(o, "title", (a = e[29](e[66]))),
        g(o, "class", "emoji"),
        g(o, "id", (s = "fav-" + e[66].id)),
        (this.first = o);
    },
    m(l, u) {
      me(l, o, u), i.m(o, null);
    },
    p(l, u) {
      (e = l),
        r === (r = c(e)) && i
          ? i.p(e, u)
          : (i.d(1), (i = r(e)), i && (i.c(), i.m(o, null))),
        u[0] & 1280 && n !== (n = e[28](e[66], e[8])) && g(o, "aria-label", n),
        u[0] & 1024 && a !== (a = e[29](e[66])) && g(o, "title", a),
        u[0] & 1024 && s !== (s = "fav-" + e[66].id) && g(o, "id", s);
    },
    d(l) {
      l && he(o), i.d();
    },
  };
}
function _r(t) {
  let e,
    o,
    n,
    a,
    s,
    c,
    r,
    i,
    l,
    u = t[0].searchLabel + "",
    f,
    d,
    A = t[0].searchDescription + "",
    p,
    h,
    b,
    y,
    I,
    D,
    T,
    k = t[0].skinToneDescription + "",
    B,
    w,
    U = [],
    j = new ut(),
    $,
    oe,
    K,
    ne,
    Z,
    ee = [],
    Re = new ut(),
    Be,
    se,
    R,
    F,
    Q,
    q,
    x,
    J,
    Y = [],
    te = new ut(),
    ce,
    be,
    Ne,
    Ve,
    ie,
    le = [],
    Pe = new ut(),
    ze,
    Le,
    Ie,
    Fe,
    st,
    it,
    xe = we(t[9]);
  const Ge = (v) => v[75];
  for (let v = 0; v < xe.length; v += 1) {
    let C = Ro(t, xe, v),
      N = Ge(C);
    j.set(N, (U[v] = Fo(N, C)));
  }
  let qe = we(t[12]);
  const wt = (v) => v[72].id;
  for (let v = 0; v < qe.length; v += 1) {
    let C = To(t, qe, v),
      N = wt(C);
    Re.set(N, (ee[v] = Qo(N, C)));
  }
  let Ye = we(t[15]);
  const Ct = (v) => v[69].category;
  for (let v = 0; v < Ye.length; v += 1) {
    let C = Mo(t, Ye, v),
      N = Ct(C);
    te.set(N, (Y[v] = jo(N, C)));
  }
  let He = we(t[10]);
  const Et = (v) => v[66].id;
  for (let v = 0; v < He.length; v += 1) {
    let C = Do(t, He, v),
      N = Et(C);
    Pe.set(N, (le[v] = No(N, C)));
  }
  return {
    c() {
      (e = V("section")),
        (o = V("div")),
        (n = V("div")),
        (a = V("div")),
        (s = V("input")),
        (l = V("label")),
        (f = Ee(u)),
        (d = V("span")),
        (p = Ee(A)),
        (h = V("div")),
        (b = V("button")),
        (y = Ee(t[21])),
        (T = V("span")),
        (B = Ee(k)),
        (w = V("div"));
      for (let v = 0; v < U.length; v += 1) U[v].c();
      Z = V("div");
      for (let v = 0; v < ee.length; v += 1) ee[v].c();
      (se = V("div")),
        (R = V("div")),
        (F = V("div")),
        (Q = Ee(t[18])),
        (x = V("div")),
        (J = V("div"));
      for (let v = 0; v < Y.length; v += 1) Y[v].c();
      ie = V("div");
      for (let v = 0; v < le.length; v += 1) le[v].c();
      (Ie = V("button")),
        (Ie.textContent = "😀"),
        g(o, "class", "pad-top"),
        g(s, "id", "search"),
        g(s, "class", "search"),
        g(s, "type", "search"),
        g(s, "role", "combobox"),
        g(s, "enterkeyhint", "search"),
        g(s, "placeholder", (c = t[0].searchLabel)),
        g(s, "autocapitalize", "none"),
        g(s, "autocomplete", "off"),
        g(s, "spellcheck", "true"),
        g(s, "aria-expanded", (r = !!(t[4] && t[1].length))),
        g(s, "aria-controls", "search-results"),
        g(s, "aria-describedby", "search-description"),
        g(s, "aria-autocomplete", "list"),
        g(s, "aria-activedescendant", (i = t[26] ? `emo-${t[26]}` : "")),
        g(l, "class", "sr-only"),
        g(l, "for", "search"),
        g(d, "id", "search-description"),
        g(d, "class", "sr-only"),
        g(a, "class", "search-wrapper"),
        g(b, "id", "skintone-button"),
        g(b, "class", (I = "emoji " + (t[6] ? "hide-focus" : ""))),
        g(b, "aria-label", t[23]),
        g(b, "title", t[23]),
        g(b, "aria-describedby", "skintone-description"),
        g(b, "aria-haspopup", "listbox"),
        g(b, "aria-expanded", t[6]),
        g(b, "aria-controls", "skintone-list"),
        g(
          h,
          "class",
          (D = "skintone-button-wrapper " + (t[19] ? "expanded" : ""))
        ),
        g(T, "id", "skintone-description"),
        g(T, "class", "sr-only"),
        g(w, "id", "skintone-list"),
        g(
          w,
          "class",
          ($ = "skintone-list hide-focus " + (t[6] ? "" : "hidden no-animate"))
        ),
        Ue(
          w,
          "transform",
          "translateY(" +
            (t[6]
              ? 0
              : "calc(-1 * var(--num-skintones) * var(--total-emoji-size))") +
            ")"
        ),
        g(w, "role", "listbox"),
        g(w, "aria-label", (oe = t[0].skinTonesLabel)),
        g(w, "aria-activedescendant", (K = "skintone-" + t[20])),
        g(w, "aria-hidden", (ne = !t[6])),
        g(w, "tabindex", "-1"),
        g(n, "class", "search-row"),
        g(Z, "class", "nav"),
        g(Z, "role", "tablist"),
        Ue(Z, "grid-template-columns", "repeat(" + t[12].length + ", 1fr)"),
        g(Z, "aria-label", (Be = t[0].categoriesLabel)),
        g(R, "class", "indicator"),
        Ue(
          R,
          "transform",
          "translateX(" + (t[24] ? -1 : 1) * t[11] * 100 + "%)"
        ),
        g(se, "class", "indicator-wrapper"),
        g(F, "class", (q = "message " + (t[18] ? "" : "gone"))),
        g(F, "role", "alert"),
        g(F, "aria-live", "polite"),
        g(x, "class", (ce = "tabpanel " + (!t[14] || t[18] ? "gone" : ""))),
        g(x, "role", (be = t[4] ? "region" : "tabpanel")),
        g(
          x,
          "aria-label",
          (Ne = t[4] ? t[0].searchResultsLabel : t[0].categories[t[13].name])
        ),
        g(x, "id", (Ve = t[4] ? "" : `tab-${t[13].id}`)),
        g(x, "tabindex", "0"),
        g(ie, "class", (ze = "favorites emoji-menu " + (t[18] ? "gone" : ""))),
        g(ie, "role", "menu"),
        g(ie, "aria-label", (Le = t[0].favoritesLabel)),
        Ue(ie, "padding-inline-end", t[25] + "px"),
        g(Ie, "aria-hidden", "true"),
        g(Ie, "tabindex", "-1"),
        g(Ie, "class", "abs-pos hidden emoji"),
        g(e, "class", "picker"),
        g(e, "aria-label", (Fe = t[0].regionLabel)),
        g(e, "style", t[22]);
    },
    m(v, C) {
      me(v, e, C),
        P(e, o),
        P(e, n),
        P(n, a),
        P(a, s),
        wo(s, t[2]),
        P(a, l),
        P(l, f),
        P(a, d),
        P(d, p),
        P(n, h),
        P(h, b),
        P(b, y),
        P(n, T),
        P(T, B),
        P(n, w);
      for (let N = 0; N < U.length; N += 1) U[N] && U[N].m(w, null);
      t[50](w), P(e, Z);
      for (let N = 0; N < ee.length; N += 1) ee[N] && ee[N].m(Z, null);
      P(e, se), P(se, R), P(e, F), P(F, Q), P(e, x), P(x, J);
      for (let N = 0; N < Y.length; N += 1) Y[N] && Y[N].m(J, null);
      t[52](x), P(e, ie);
      for (let N = 0; N < le.length; N += 1) le[N] && le[N].m(ie, null);
      P(e, Ie),
        t[53](Ie),
        t[54](e),
        st ||
          ((it = [
            ge(s, "input", t[49]),
            ge(s, "keydown", t[31]),
            ge(b, "click", t[36]),
            ge(w, "focusout", t[39]),
            ge(w, "click", t[35]),
            ge(w, "keydown", t[37]),
            ge(w, "keyup", t[38]),
            ge(Z, "keydown", t[33]),
            fr(t[30].call(null, J)),
            ge(x, "click", t[34]),
            ge(ie, "click", t[34]),
          ]),
          (st = !0));
    },
    p(v, C) {
      C[0] & 1 && c !== (c = v[0].searchLabel) && g(s, "placeholder", c),
        C[0] & 18 &&
          r !== (r = !!(v[4] && v[1].length)) &&
          g(s, "aria-expanded", r),
        C[0] & 67108864 &&
          i !== (i = v[26] ? `emo-${v[26]}` : "") &&
          g(s, "aria-activedescendant", i),
        C[0] & 4 && s.value !== v[2] && wo(s, v[2]),
        C[0] & 1 && u !== (u = v[0].searchLabel + "") && ke(f, u),
        C[0] & 1 && A !== (A = v[0].searchDescription + "") && ke(p, A),
        C[0] & 2097152 && ke(y, v[21]),
        C[0] & 64 &&
          I !== (I = "emoji " + (v[6] ? "hide-focus" : "")) &&
          g(b, "class", I),
        C[0] & 8388608 && g(b, "aria-label", v[23]),
        C[0] & 8388608 && g(b, "title", v[23]),
        C[0] & 64 && g(b, "aria-expanded", v[6]),
        C[0] & 524288 &&
          D !== (D = "skintone-button-wrapper " + (v[19] ? "expanded" : "")) &&
          g(h, "class", D),
        C[0] & 1 && k !== (k = v[0].skinToneDescription + "") && ke(B, k),
        C[0] & 1049089 &&
          ((xe = we(v[9])),
          (U = lt(U, C, Ge, 1, v, xe, j, w, ct, Fo, null, Ro))),
        C[0] & 64 &&
          $ !==
            ($ =
              "skintone-list hide-focus " +
              (v[6] ? "" : "hidden no-animate")) &&
          g(w, "class", $),
        C[0] & 64 &&
          Ue(
            w,
            "transform",
            "translateY(" +
              (v[6]
                ? 0
                : "calc(-1 * var(--num-skintones) * var(--total-emoji-size))") +
              ")"
          ),
        C[0] & 1 && oe !== (oe = v[0].skinTonesLabel) && g(w, "aria-label", oe),
        C[0] & 1048576 &&
          K !== (K = "skintone-" + v[20]) &&
          g(w, "aria-activedescendant", K),
        C[0] & 64 && ne !== (ne = !v[6]) && g(w, "aria-hidden", ne),
        (C[0] & 12305) | (C[1] & 2) &&
          ((qe = we(v[12])),
          (ee = lt(ee, C, wt, 1, v, qe, Re, Z, ct, Qo, null, To))),
        C[0] & 4096 &&
          Ue(Z, "grid-template-columns", "repeat(" + v[12].length + ", 1fr)"),
        C[0] & 1 &&
          Be !== (Be = v[0].categoriesLabel) &&
          g(Z, "aria-label", Be),
        C[0] & 16779264 &&
          Ue(
            R,
            "transform",
            "translateX(" + (v[24] ? -1 : 1) * v[11] * 100 + "%)"
          ),
        C[0] & 262144 && ke(Q, v[18]),
        C[0] & 262144 &&
          q !== (q = "message " + (v[18] ? "" : "gone")) &&
          g(F, "class", q),
        C[0] & 939565361 &&
          ((Ye = we(v[15])),
          (Y = lt(Y, C, Ct, 1, v, Ye, te, J, ct, jo, null, Mo))),
        C[0] & 278528 &&
          ce !== (ce = "tabpanel " + (!v[14] || v[18] ? "gone" : "")) &&
          g(x, "class", ce),
        C[0] & 16 &&
          be !== (be = v[4] ? "region" : "tabpanel") &&
          g(x, "role", be),
        C[0] & 8209 &&
          Ne !==
            (Ne = v[4]
              ? v[0].searchResultsLabel
              : v[0].categories[v[13].name]) &&
          g(x, "aria-label", Ne),
        C[0] & 8208 &&
          Ve !== (Ve = v[4] ? "" : `tab-${v[13].id}`) &&
          g(x, "id", Ve),
        C[0] & 939525376 &&
          ((He = we(v[10])),
          (le = lt(le, C, Et, 1, v, He, Pe, ie, ct, No, null, Do))),
        C[0] & 262144 &&
          ze !== (ze = "favorites emoji-menu " + (v[18] ? "gone" : "")) &&
          g(ie, "class", ze),
        C[0] & 1 &&
          Le !== (Le = v[0].favoritesLabel) &&
          g(ie, "aria-label", Le),
        C[0] & 33554432 && Ue(ie, "padding-inline-end", v[25] + "px"),
        C[0] & 1 && Fe !== (Fe = v[0].regionLabel) && g(e, "aria-label", Fe),
        C[0] & 4194304 && g(e, "style", v[22]);
    },
    i: et,
    o: et,
    d(v) {
      v && he(e);
      for (let C = 0; C < U.length; C += 1) U[C].d();
      t[50](null);
      for (let C = 0; C < ee.length; C += 1) ee[C].d();
      for (let C = 0; C < Y.length; C += 1) Y[C].d();
      t[52](null);
      for (let C = 0; C < le.length; C += 1) le[C].d();
      t[53](null), t[54](null), (st = !1), nt(it);
    },
  };
}
function $r(t, e, o) {
  let { skinToneEmoji: n } = e,
    { i18n: a } = e,
    { database: s } = e,
    { customEmoji: c } = e,
    { customCategorySorting: r } = e,
    { emojiVersion: i } = e,
    l = !0,
    u = [],
    f = [],
    d = "",
    A = "",
    p,
    h,
    b,
    y = !1,
    I = -1,
    D,
    T = !1,
    k = !1,
    B,
    w = 0,
    U = 0,
    j,
    $,
    oe = "",
    K = [],
    ne = [],
    Z,
    ee = Ur,
    Re = !1,
    Be = 0,
    se = 0,
    R = Dt,
    F,
    Q = !1,
    q;
  const x = [],
    J = (m) => {
      p.getRootNode().getElementById(m).focus();
    },
    Y = (m, E) => {
      p.dispatchEvent(
        new CustomEvent(m, { detail: E, bubbles: !0, composed: !0 })
      );
    },
    te = (m, E) => (E && m.skins && m.skins[E]) || m.unicode,
    ce = (m, E) =>
      Hr(
        [m.name || te(m, E), m.annotation, ...(m.shortcodes || x)].filter(
          Boolean
        )
      ).join(", "),
    be = (m) => m.annotation || (m.shortcodes || x).join(", ");
  function Ne(m) {
    return qr(m, (E) => {
      {
        const O = getComputedStyle(p),
          G = parseInt(O.getPropertyValue("--num-columns"), 10),
          Ae = O.getPropertyValue("direction") === "rtl",
          En = m.parentElement.getBoundingClientRect().width - E;
        o(48, (ee = G)), o(25, (Be = En)), o(24, (Re = Ae));
      }
    });
  }
  function Ve(m) {
    const E = p.getRootNode();
    Yr(m, h, (G) => E.getElementById(`emo-${G.id}`)),
      o(1, u),
      o(14, Q),
      o(46, A),
      o(13, F),
      o(44, i),
      o(3, b),
      o(0, a),
      o(40, s),
      o(2, d),
      o(12, R),
      o(11, se),
      o(42, c);
  }
  function ie(m) {
    return !m.unicode || !ko(m) || eo.get(m.unicode);
  }
  async function le(m) {
    const E = i || (await Io());
    return m.filter(({ version: O }) => !O || O <= E);
  }
  async function Pe(m) {
    return xr(m, i || (await Io()));
  }
  async function ze(m) {
    const E = m === -1 ? c : await s.getEmojiByGroup(m);
    return Pe(await le(E));
  }
  async function Le(m) {
    return Pe(await le(await s.getEmojiBySearchQuery(m)));
  }
  function Ie(m) {
    if (!y || !u.length) return;
    const E = (O) => {
      ye(m), o(5, (I = Gt(O, I, u)));
    };
    switch (m.key) {
      case "ArrowDown":
        return E(!1);
      case "ArrowUp":
        return E(!0);
      case "Enter":
        if (I !== -1) return ye(m), it(u[I].id);
        u.length && o(5, (I = 0));
    }
  }
  function Fe(m) {
    o(2, (d = "")),
      o(46, (A = "")),
      o(5, (I = -1)),
      o(11, (se = R.findIndex((E) => E.id === m.id)));
  }
  function st(m) {
    const { target: E, key: O } = m,
      G = (Ae) => {
        Ae && (ye(m), Ae.focus());
      };
    switch (O) {
      case "ArrowLeft":
        return G(E.previousSibling);
      case "ArrowRight":
        return G(E.nextSibling);
      case "Home":
        return G(E.parentElement.firstChild);
      case "End":
        return G(E.parentElement.lastChild);
    }
  }
  async function it(m) {
    const E = await s.getEmojiByUnicodeOrName(m),
      O = [...u, ...ne].find((Ae) => Ae.id === m),
      G = O.unicode && te(O, w);
    await s.incrementFavoriteEmojiCount(m),
      Y("emoji-click", {
        emoji: E,
        skinTone: w,
        ...(G && { unicode: G }),
        ...(O.name && { name: O.name }),
      });
  }
  async function xe(m) {
    const { target: E } = m;
    if (!E.classList.contains("emoji")) return;
    ye(m);
    const O = E.id.substring(4);
    it(O);
  }
  function Ge(m) {
    o(8, (w = m)),
      o(6, (T = !1)),
      J("skintone-button"),
      Y("skin-tone-change", { skinTone: m }),
      s.setPreferredSkinTone(m);
  }
  function qe(m) {
    const {
        target: { id: E },
      } = m,
      O = E && E.match(/^skintone-(\d)/);
    if (!O) return;
    ye(m);
    const G = parseInt(O[1], 10);
    Ge(G);
  }
  function wt(m) {
    o(6, (T = !T)), o(20, (U = w)), T && (ye(m), Tt(() => J("skintone-list")));
  }
  function Ye(m) {
    if (!T) return;
    const E = async (O) => {
      ye(m), o(20, (U = O));
    };
    switch (m.key) {
      case "ArrowUp":
        return E(Gt(!0, U, K));
      case "ArrowDown":
        return E(Gt(!1, U, K));
      case "Home":
        return E(0);
      case "End":
        return E(K.length - 1);
      case "Enter":
        return ye(m), Ge(U);
      case "Escape":
        return ye(m), o(6, (T = !1)), J("skintone-button");
    }
  }
  function Ct(m) {
    if (T)
      switch (m.key) {
        case " ":
          return ye(m), Ge(U);
      }
  }
  async function He(m) {
    const { relatedTarget: E } = m;
    (!E || E.id !== "skintone-list") && o(6, (T = !1));
  }
  function Et() {
    (d = this.value), o(2, d);
  }
  function v(m) {
    Ze[m ? "unshift" : "push"](() => {
      (B = m), o(7, B);
    });
  }
  const C = (m) => Fe(m);
  function N(m) {
    Ze[m ? "unshift" : "push"](() => {
      (b = m), o(3, b);
    });
  }
  function wn(m) {
    Ze[m ? "unshift" : "push"](() => {
      (h = m), o(17, h);
    });
  }
  function Cn(m) {
    Ze[m ? "unshift" : "push"](() => {
      (p = m), o(16, p);
    });
  }
  return (
    (t.$$set = (m) => {
      "skinToneEmoji" in m && o(41, (n = m.skinToneEmoji)),
        "i18n" in m && o(0, (a = m.i18n)),
        "database" in m && o(40, (s = m.database)),
        "customEmoji" in m && o(42, (c = m.customEmoji)),
        "customCategorySorting" in m && o(43, (r = m.customCategorySorting)),
        "emojiVersion" in m && o(44, (i = m.emojiVersion));
    }),
    (t.$$.update = () => {
      if (
        (t.$$.dirty[1] & 2560 && c && s && o(40, (s.customEmoji = c), s),
        (t.$$.dirty[0] & 1) | (t.$$.dirty[1] & 512))
      ) {
        async function m() {
          let E = !1;
          const O = setTimeout(() => {
            (E = !0), o(18, (D = a.loadingMessage));
          }, Dr);
          try {
            await s.ready(), o(14, (Q = !0));
          } catch (G) {
            console.error(G), o(18, (D = a.networkErrorMessage));
          } finally {
            clearTimeout(O), E && ((E = !1), o(18, (D = "")));
          }
        }
        s && m();
      }
      if (
        ((t.$$.dirty[0] & 6144) | (t.$$.dirty[1] & 2048) &&
          (c && c.length
            ? o(12, (R = [Br, ...Dt]))
            : R !== Dt && (se && o(11, se--, se), o(12, (R = Dt)))),
        t.$$.dirty[0] & 4 &&
          pn(() => {
            o(46, (A = (d || "").trim())), o(5, (I = -1));
          }),
        t.$$.dirty[0] & 6144 && o(13, (F = R[se])),
        (t.$$.dirty[0] & 24576) | (t.$$.dirty[1] & 32768))
      ) {
        async function m() {
          if (!Q) o(1, (u = [])), o(4, (y = !1));
          else if (A.length >= Ir) {
            const E = A,
              O = await Le(E);
            E === A && (o(1, (u = O)), o(4, (y = !0)));
          } else if (F) {
            const E = F.id,
              O = await ze(E);
            E === F.id && (o(1, (u = O)), o(4, (y = !1)));
          }
        }
        m();
      }
      if (
        (t.$$.dirty[0] & 4112 &&
          o(
            22,
            ($ = `
  --num-groups: ${R.length}; 
  --indicator-opacity: ${y ? 0 : 1}; 
  --num-skintones: ${Eo};`)
          ),
        (t.$$.dirty[0] & 16384) | (t.$$.dirty[1] & 512))
      ) {
        async function m() {
          Q && o(8, (w = await s.getPreferredSkinTone()));
        }
        m();
      }
      if (
        (t.$$.dirty[1] & 1024 &&
          o(
            9,
            (K = Array(Eo)
              .fill()
              .map((m, E) => Lr(n, E)))
          ),
        t.$$.dirty[0] & 768 && o(21, (j = K[w])),
        t.$$.dirty[0] & 257 &&
          o(23, (oe = a.skinToneLabel.replace("{skinTone}", a.skinTones[w]))),
        (t.$$.dirty[0] & 16384) | (t.$$.dirty[1] & 512))
      ) {
        async function m() {
          o(
            47,
            (Z = (
              await Promise.all(Tr.map((E) => s.getEmojiByUnicodeOrName(E)))
            ).filter(Boolean))
          );
        }
        Q && m();
      }
      if ((t.$$.dirty[0] & 16384) | (t.$$.dirty[1] & 197120)) {
        async function m() {
          const E = await s.getTopFavoriteEmoji(ee),
            O = await Pe(
              hn([...E, ...Z], (G) => G.unicode || G.name).slice(0, ee)
            );
          o(10, (ne = O));
        }
        Q && Z && m();
      }
      if ((t.$$.dirty[0] & 10) | (t.$$.dirty[1] & 8192)) {
        const m = u
          .filter((E) => E.unicode)
          .filter((E) => ko(E) && !eo.has(E.unicode));
        !i && m.length
          ? Tt(() => Ve(m))
          : (o(1, (u = i ? u : u.filter(ie))), Tt(() => Xr(b)));
      }
      (t.$$.dirty[0] & 1026) | (t.$$.dirty[1] & 16384),
        (t.$$.dirty[0] & 18) | (t.$$.dirty[1] & 4096) &&
          o(
            15,
            (f = (function () {
              if (y) return [{ category: "", emojis: u }];
              const E = new Map();
              for (const O of u) {
                const G = O.category || "";
                let Ae = E.get(G);
                Ae || ((Ae = []), E.set(G, Ae)), Ae.push(O);
              }
              return [...E.entries()]
                .map(([O, G]) => ({ category: O, emojis: G }))
                .sort((O, G) => r(O.category, G.category));
            })())
          ),
        t.$$.dirty[0] & 34 && o(26, (q = I !== -1 && u[I].id)),
        t.$$.dirty[0] & 192 &&
          (T
            ? B.addEventListener(
                "transitionend",
                () => {
                  o(19, (k = !0));
                },
                { once: !0 }
              )
            : o(19, (k = !1)));
    }),
    [
      a,
      u,
      d,
      b,
      y,
      I,
      T,
      B,
      w,
      K,
      ne,
      se,
      R,
      F,
      Q,
      f,
      p,
      h,
      D,
      k,
      U,
      j,
      $,
      oe,
      Re,
      Be,
      q,
      te,
      ce,
      be,
      Ne,
      Ie,
      Fe,
      st,
      xe,
      qe,
      wt,
      Ye,
      Ct,
      He,
      s,
      n,
      c,
      r,
      i,
      l,
      A,
      Z,
      ee,
      Et,
      v,
      C,
      N,
      wn,
      Cn,
    ]
  );
}
class ea extends kr {
  constructor(e) {
    super(),
      Er(
        this,
        e,
        $r,
        _r,
        ur,
        {
          skinToneEmoji: 41,
          i18n: 0,
          database: 40,
          customEmoji: 42,
          customCategorySorting: 43,
          emojiVersion: 44,
        },
        null,
        [-1, -1, -1]
      );
  }
}
const ta =
    "https://cdn.jsdelivr.net/npm/emoji-picker-element-data@^1/en/emojibase/data.json",
  oa = "en";
var na = {
  categoriesLabel: "Categories",
  emojiUnsupportedMessage: "Your browser does not support color emoji.",
  favoritesLabel: "Favorites",
  loadingMessage: "Loading…",
  networkErrorMessage: "Could not load emoji.",
  regionLabel: "Emoji picker",
  searchDescription:
    "When search results are available, press up or down to select and enter to choose.",
  searchLabel: "Search",
  searchResultsLabel: "Search results",
  skinToneDescription:
    "When expanded, press up or down to select and enter to choose.",
  skinToneLabel: "Choose a skin tone (currently {skinTone})",
  skinTonesLabel: "Skin tones",
  skinTones: [
    "Default",
    "Light",
    "Medium-Light",
    "Medium",
    "Medium-Dark",
    "Dark",
  ],
  categories: {
    custom: "Custom",
    "smileys-emotion": "Smileys and emoticons",
    "people-body": "People and body",
    "animals-nature": "Animals and nature",
    "food-drink": "Food and drink",
    "travel-places": "Travel and places",
    activities: "Activities",
    objects: "Objects",
    symbols: "Symbols",
    flags: "Flags",
  },
};
const vn = [
    "customEmoji",
    "customCategorySorting",
    "database",
    "dataSource",
    "i18n",
    "locale",
    "skinToneEmoji",
    "emojiVersion",
  ],
  sa = `:host{--emoji-font-family:${mn}}`;
class co extends HTMLElement {
  constructor(e) {
    super(), this.attachShadow({ mode: "open" });
    const o = document.createElement("style");
    (o.textContent =
      ":host{--emoji-size:1.375rem;--emoji-padding:0.5rem;--category-emoji-size:var(--emoji-size);--category-emoji-padding:var(--emoji-padding);--indicator-height:3px;--input-border-radius:0.5rem;--input-border-size:1px;--input-font-size:1rem;--input-line-height:1.5;--input-padding:0.25rem;--num-columns:8;--outline-size:2px;--border-size:1px;--skintone-border-radius:1rem;--category-font-size:1rem;display:flex;width:min-content;height:400px}:host,:host(.light){color-scheme:light;--background:#fff;--border-color:#e0e0e0;--indicator-color:#385ac1;--input-border-color:#999;--input-font-color:#111;--input-placeholder-color:#999;--outline-color:#999;--category-font-color:#111;--button-active-background:#e6e6e6;--button-hover-background:#d9d9d9}:host(.dark){color-scheme:dark;--background:#222;--border-color:#444;--indicator-color:#5373ec;--input-border-color:#ccc;--input-font-color:#efefef;--input-placeholder-color:#ccc;--outline-color:#fff;--category-font-color:#efefef;--button-active-background:#555555;--button-hover-background:#484848}@media (prefers-color-scheme:dark){:host{color-scheme:dark;--background:#222;--border-color:#444;--indicator-color:#5373ec;--input-border-color:#ccc;--input-font-color:#efefef;--input-placeholder-color:#ccc;--outline-color:#fff;--category-font-color:#efefef;--button-active-background:#555555;--button-hover-background:#484848}}:host([hidden]){display:none}button{margin:0;padding:0;border:0;background:0 0;box-shadow:none;-webkit-tap-highlight-color:transparent}button::-moz-focus-inner{border:0}input{padding:0;margin:0;line-height:1.15;font-family:inherit}input[type=search]{-webkit-appearance:none}:focus{outline:var(--outline-color) solid var(--outline-size);outline-offset:calc(-1*var(--outline-size))}:host([data-js-focus-visible]) :focus:not([data-focus-visible-added]){outline:0}:focus:not(:focus-visible){outline:0}.hide-focus{outline:0}*{box-sizing:border-box}.picker{contain:content;display:flex;flex-direction:column;background:var(--background);border:var(--border-size) solid var(--border-color);width:100%;height:100%;overflow:hidden;--total-emoji-size:calc(var(--emoji-size) + (2 * var(--emoji-padding)));--total-category-emoji-size:calc(var(--category-emoji-size) + (2 * var(--category-emoji-padding)))}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}.hidden{opacity:0;pointer-events:none}.abs-pos{position:absolute;left:0;top:0}.gone{display:none!important}.skintone-button-wrapper,.skintone-list{background:var(--background);z-index:3}.skintone-button-wrapper.expanded{z-index:1}.skintone-list{position:absolute;inset-inline-end:0;top:0;z-index:2;overflow:visible;border-bottom:var(--border-size) solid var(--border-color);border-radius:0 0 var(--skintone-border-radius) var(--skintone-border-radius);will-change:transform;transition:transform .2s ease-in-out;transform-origin:center 0}@media (prefers-reduced-motion:reduce){.skintone-list{transition-duration:.001s}}@supports not (inset-inline-end:0){.skintone-list{right:0}}.skintone-list.no-animate{transition:none}.tabpanel{overflow-y:auto;-webkit-overflow-scrolling:touch;will-change:transform;min-height:0;flex:1;contain:content}.emoji-menu{display:grid;grid-template-columns:repeat(var(--num-columns),var(--total-emoji-size));justify-content:space-around;align-items:flex-start;width:100%}.category{padding:var(--emoji-padding);font-size:var(--category-font-size);color:var(--category-font-color)}.custom-emoji,.emoji,button.emoji{height:var(--total-emoji-size);width:var(--total-emoji-size)}.emoji,button.emoji{font-size:var(--emoji-size);display:flex;align-items:center;justify-content:center;border-radius:100%;line-height:1;overflow:hidden;font-family:var(--emoji-font-family);cursor:pointer}@media (hover:hover) and (pointer:fine){.emoji:hover,button.emoji:hover{background:var(--button-hover-background)}}.emoji.active,.emoji:active,button.emoji.active,button.emoji:active{background:var(--button-active-background)}.custom-emoji{padding:var(--emoji-padding);object-fit:contain;pointer-events:none;background-repeat:no-repeat;background-position:center center;background-size:var(--emoji-size) var(--emoji-size)}.nav,.nav-button{align-items:center}.nav{display:grid;justify-content:space-between;contain:content}.nav-button{display:flex;justify-content:center}.nav-emoji{font-size:var(--category-emoji-size);width:var(--total-category-emoji-size);height:var(--total-category-emoji-size)}.indicator-wrapper{display:flex;border-bottom:1px solid var(--border-color)}.indicator{width:calc(100%/var(--num-groups));height:var(--indicator-height);opacity:var(--indicator-opacity);background-color:var(--indicator-color);will-change:transform,opacity;transition:opacity .1s linear,transform .25s ease-in-out}@media (prefers-reduced-motion:reduce){.indicator{will-change:opacity;transition:opacity .1s linear}}.pad-top,input.search{background:var(--background);width:100%}.pad-top{height:var(--emoji-padding);z-index:3}.search-row{display:flex;align-items:center;position:relative;padding-inline-start:var(--emoji-padding);padding-bottom:var(--emoji-padding)}.search-wrapper{flex:1;min-width:0}input.search{padding:var(--input-padding);border-radius:var(--input-border-radius);border:var(--input-border-size) solid var(--input-border-color);color:var(--input-font-color);font-size:var(--input-font-size);line-height:var(--input-line-height)}input.search::placeholder{color:var(--input-placeholder-color)}.favorites{display:flex;flex-direction:row;border-top:var(--border-size) solid var(--border-color);contain:content}.message{padding:var(--emoji-padding)}" +
      sa),
      this.shadowRoot.appendChild(o),
      (this._ctx = {
        locale: oa,
        dataSource: ta,
        skinToneEmoji: Mr,
        customCategorySorting: Rr,
        customEmoji: null,
        i18n: na,
        emojiVersion: null,
        ...e,
      });
    for (const n of vn)
      n !== "database" &&
        Object.prototype.hasOwnProperty.call(this, n) &&
        ((this._ctx[n] = this[n]), delete this[n]);
    this._dbFlush();
  }
  connectedCallback() {
    this._cmp ||
      (this._cmp = new ea({ target: this.shadowRoot, props: this._ctx }));
  }
  disconnectedCallback() {
    Promise.resolve().then(() => {
      if (!this.isConnected && this._cmp) {
        this._cmp.$destroy(), (this._cmp = void 0);
        const { database: e } = this._ctx;
        e.close().catch((o) => console.error(o));
      }
    });
  }
  static get observedAttributes() {
    return ["locale", "data-source", "skin-tone-emoji", "emoji-version"];
  }
  attributeChangedCallback(e, o, n) {
    this._set(
      e.replace(/-([a-z])/g, (a, s) => s.toUpperCase()),
      e === "emoji-version" ? parseFloat(n) : n
    );
  }
  _set(e, o) {
    (this._ctx[e] = o),
      this._cmp && this._cmp.$set({ [e]: o }),
      ["locale", "dataSource"].includes(e) && this._dbFlush();
  }
  _dbCreate() {
    const { locale: e, dataSource: o, database: n } = this._ctx;
    (!n || n.locale !== e || n.dataSource !== o) &&
      this._set("database", new lr({ locale: e, dataSource: o }));
  }
  _dbFlush() {
    Promise.resolve().then(() => this._dbCreate());
  }
}
const bn = {};
for (const t of vn)
  bn[t] = {
    get() {
      return t === "database" && this._dbCreate(), this._ctx[t];
    },
    set(e) {
      if (t === "database") throw new Error("database is read-only");
      this._set(t, e);
    },
  };
Object.defineProperties(co.prototype, bn);
customElements.get("emoji-picker") || customElements.define("emoji-picker", co);
const ia = ue({
    __name: "ChatFooterEmoji",
    emits: ["closeEmojiBar", "emojiClick"],
    setup(t, { emit: e }) {
      var c;
      const o = new co({ emojiVersion: 14, dataSource: "/emojis.json" });
      o.className = "light w-full h-full";
      const n = document.createElement("style");
      (n.textContent = `
    .search-row,.favorites {
      display: none;
    }
    .tabpanel::-webkit-scrollbar {
      width: 6px;
      background-color: transparent;
    }
    .tabpanel::-webkit-scrollbar-track {
      background: transparent;
    }
    .tabpanel::-webkit-scrollbar-thumb {
      border-radius: 3px;
      background: #b7bdcb;
      box-shadow: 4px 4px 15px rgba(112, 124, 151, 0.05),
        2px 2px 10px rgba(112, 124, 151, 0.1), 1px 1px 50px rgba(112, 124, 151, 0.15);
    }
    .tabpanel::-webkit-scrollbar-thumb:hover {
      border-radius: 3px;
      box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
      background-color: rgba(245, 238, 238, 1);
    }
`),
        (c = o.shadowRoot) == null || c.appendChild(n);
      const a = z();
      Go(a, () => e("closeEmojiBar"), { ignore: [".custom_rich_input"] });
      const s = (r) => {
        e("emojiClick", r.detail.unicode);
      };
      return (
        tt(() => {
          var r;
          (r = a.value) == null || r.appendChild(o),
            o.addEventListener("emoji-click", s);
        }),
        (r, i) => (
          X(),
          _(
            "div",
            {
              ref_key: "target",
              ref: a,
              class: "flex h-[204px] flex-wrap overflow-y-auto bg-[#F0F2F6]",
            },
            [L(S(o), { "emoji-version": "15.0" })],
            512
          )
        )
      );
    },
  }),
  ra =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAACU5JREFUeF7tnH2QHEUVwN+b3bu9k5DKnSC5qwiCplKJpgANKtEkRflJtChFPAxqMLmbfn134TQB/MCPrMinJwqLm0zPslwRFDDyYRUl5g8lJVG0FEuh0CqjSJCyjNF4UdlLbm9untXWHnUm0z2ze7fuLV7/ud09/d5v3rzufv16EeaLlQDO87ETmAcUYyHzgF5qgPL5/OJUKnWylPJ3/wv30FQWVCgUTgvDcC8AtAVBsHpwcPBgvSE1DaCdO3e+IpVKPcrMr61A+WU6nV7X29v7r3pCagpAuVzu1Ewm8ygAvO44GN8HgPVENFEvSHMekFLqFADQcFYaINxCRFf9XwJiZvR9/2cAsMoCgFOp1Pq+vr499YA05y3I9/2PMvNdAGCT9VAQBGfXw2nPeUDaKjzP+xQi3hRjIXuI6MLZtqKmAKSVVkrtAIB+GwBEvEQI8cBsQmoaQLlcLpPJZH4CAOdaABwolUortm3bdnS2IDUNIK3wjh07lqVSqScAYIEJACJuF0Jc+5IClM1mne7u7lsR8Q7XdZ+yKaeU6gOAgqXNmOM4Z7mu+5fZgNRwC6pM5XcAwGYA+BMArCaiP1qU01P/48z8ZkubG4jos00PqALHBwBtFVPlN+3t7W/cuHFjyaSg7/vnMfNPAcAxtBkNguD0wcHBF2YKqZEWhEopDwBEhBIjRKQtyliUUncCwCZTA8dxtrque2uzAtJw8rZpGxE3CCHuMymolHo1APwWAFKGNs8S0VlNCahYLC4LguBXOmxhUeDQ2NjYsq1btx6xQNoNAB801TPzaimlXhrUXBr2iXmedzEiagVNFgDMfJuU8hMm7YrF4qogCH5u0T5HRB+vmU7M/mYmz03UVym1HQCylsY6jLGciJ6xWJFeF73BUH+wo6NjSU9Pz2QigSIaNcyCtCy7d+9OHTlyZC8zr7EosJOIBiyArgSAr1g+s3VSyseaEpAWulAoLA/D8EkAaIlSgpmPtra2nrF58+a/RtUXCoUlYRg+Z5ryZ7qyrqsF6f1Ta2vrSiml/gyMRSn1NQAw+hpEvFII8VWLFT0OAOcb6n9ARG+fcxaklGpBxPuZ+YJ0Or2mt7dXW0lkGRkZWVwulw8AQMbQ5AkiOs8C6HoAuCaqHhFLzNxRa1i2LhaUzWbT3d3d9zLzJRWh97e3t7/etjpWShUr240T9EREZualJmfted67EfF7JoBhGL6pv79fRyarLrMOSG88u7q67gaAy46T5iYi+oxJwkKhsCYMQ5szlUSkovoXi8WTgyD4OwCko+odx7ncdd1dVdOZ7Wle760KhcKdzPyxCGGOBUFwpiksWtmX6U3qEoMi9xDRhy2f2X4AWGpw9NdJKT/faEC2vdV/ZEPEa4UQeu0TWTzPG0HEKLi6/QEiOtMC6BEAiAy5IuJ9QogNDQXk+36Oma+IEeIZInqNqY3v+5uZWfuiqBKWSqUFpmihUuo2ABgy9LU6eZvMs+KDfN8fZuZEZ1OpVGppX1/f76OEqoQxjM40DMOV/f39T0f1VUptBQDTUuA5InpVQyxIKXUdACQOTiHiR4QQ34wSdmRkZFG5XB41KcLM75FS6k/phGKzPmY+LKXUB5BVlxlZkFJKO75q479fJCLj/kspdcy0HmLmD0kpv2UA1MPMkXUAME5EtsiBEVzNgJRSVwPAl6t9JYh4uxDC5Cv08c7fAODlUc9l5j4pZaSP8jxvPSJ+1yJPay2LxZoBeZ73DUQ0TrsWQeM2n4cA4NSo/ogohBCRAfs4QB0dHZmenp5y1S+02g5T7Ss78buZudrpc5iIPmka1/O8MURsN1jQZVLKe2v4xCaIqLUWXWu2ID2YhjQ6Oqod7qVVDH4FEX3dMBO9DBFf0ItGA6CLpJQPV+ukAWCUiDqrkPHFpjMCpJ+i911dXV332EKf0wVzHGet67r7DIB0iovxXMxxnFWu6/7C0Nc4zTPz81LK0xsCaBokHWD/gE0IvbNuaWk5ZdOmTXqmOqF4nnepXvVanrGIiP5hAGRbKD5JROc0DJAeeO/even9+/frafZiiyDfJqIeU71S6nYA2GKoP0REp1n6GrcaAPAgEVlfnum5M/7Epj9Yx4C0awKA90UN6DjO21zX1dlikcX3/aen5SAe3+ZhIrrIAsi4WUXEm4UQn26oBU0NXoF0PwD8lzKI+GMhxFtNQnqetwIRf218k4hXCyEiY89x4Q4AcIlIH29XXWbVgqZGz2azrd3d3Q8w83srv01MTk6ePzAwEOlgdRul1I0AYHzLNgcdFzCbnJxcOzAwEDkxxBGrCyA9qI5Ht7W1PcjMeoV7jRBCA4gsu3btOuno0aM6FmSaiv9ARPokNbJ4nncDIpqCceVSqbSo1pyhugGagpTJZIiIcrY3pZSyHt0AwPVE9DmL/zEG7eM+7YZZUNzAU/WVHGjtYBcZ+oSIuFwIoducUBIc+9wohIgM6CeRsa4WlEQAz/PuQsSNFuf8kBDCuHTwff8qZh429WfmC6WUNacINxSQ53kbEFGvwo0lLgFBKWU7ej4yPj6+eGhoaDzJy4pq0zBAnuedDQCPIeJCi/DfIaL3m+rjkhcQsSiEmJ6cVTWnhgDK5/OvTKfTOkOs2yLxMcdxVriu+6zFOVvTXxDxHUIIfZ+j5tIQQMPDwyctXLhQbw3WWiT/AhF9yQLHmkDFzAc7OztnlNmhx24IID1wPp9f0NLS8khUZgcz7+vs7LzAlrYSl4LHzNullNWGg094Hw0DNA3SHmZ+yzTJDgdBcO7g4ODzJutJkMRZmpiYOGPLli2Ha/62Kh0bCkjLUNlH6Wl4NQDoDPl3EtGPLIolSQOecWbZ1PgNB6QFyeVyC9va2rRPukUI8ZDtrSdIJJ+onL3pnKEZlzkBSGuhkx6y2Wxo0yjJVQQNeTYv2M0ZQHGvOsllFj1zlcvlZUNDQ/+Me17S+qYBlOQ6FDNfLqWsKc3FBKwpACW5UIeI+4QQ6wCAk1pHknZzHlDCK5n6PP+cmEswSXjMrXVQnMRJLvXq9Dx9mhI3+8WN1bSfWIJr4XkiMp2E1MrlxX5z/hOrrJNMfyzww/Hx8XfNJJwRR7ApAGkljv9rCkR8ipnXmg4S4xRPWt80gLRC0/7cRCc36JuJf06qaK3tmgqQVnL+73FqfdV16td0FlQnDsbHzgOKIT4PKAbQvwHYz7h2KUZKsAAAAABJRU5ErkJggg==";
var yn = { exports: {} };
/*!
 *
 * js-audio-recorder - js audio recorder plugin
 *
 * @version v1.0.7
 * @homepage https://github.com/2fps/recorder
 * @author 2fps <echoweb@126.com> (https://www.zhuyuntao.cn)
 * @license MIT
 *
 */ (function (t, e) {
  (function (o, n) {
    t.exports = n();
  })(Yn, function () {
    return (function (o) {
      var n = {};
      function a(s) {
        if (n[s]) return n[s].exports;
        var c = (n[s] = { i: s, l: !1, exports: {} });
        return o[s].call(c.exports, c, c.exports, a), (c.l = !0), c.exports;
      }
      return (
        (a.m = o),
        (a.c = n),
        (a.d = function (s, c, r) {
          a.o(s, c) || Object.defineProperty(s, c, { enumerable: !0, get: r });
        }),
        (a.r = function (s) {
          typeof Symbol < "u" &&
            Symbol.toStringTag &&
            Object.defineProperty(s, Symbol.toStringTag, { value: "Module" }),
            Object.defineProperty(s, "__esModule", { value: !0 });
        }),
        (a.t = function (s, c) {
          if (
            (1 & c && (s = a(s)),
            8 & c || (4 & c && typeof s == "object" && s && s.__esModule))
          )
            return s;
          var r = Object.create(null);
          if (
            (a.r(r),
            Object.defineProperty(r, "default", { enumerable: !0, value: s }),
            2 & c && typeof s != "string")
          )
            for (var i in s)
              a.d(
                r,
                i,
                function (l) {
                  return s[l];
                }.bind(null, i)
              );
          return r;
        }),
        (a.n = function (s) {
          var c =
            s && s.__esModule
              ? function () {
                  return s.default;
                }
              : function () {
                  return s;
                };
          return a.d(c, "a", c), c;
        }),
        (a.o = function (s, c) {
          return Object.prototype.hasOwnProperty.call(s, c);
        }),
        (a.p = ""),
        a((a.s = 1))
      );
    })([
      function (o, n, a) {
        function s(c, r, i) {
          for (var l = 0; l < i.length; l++) c.setUint8(r + l, i.charCodeAt(l));
        }
        Object.defineProperty(n, "__esModule", { value: !0 }),
          (n.compress = function (c, r, i) {
            for (
              var l = r / i,
                u = Math.max(l, 1),
                f = c.left,
                d = c.right,
                A = Math.floor((f.length + d.length) / l),
                p = new Float32Array(A),
                h = 0,
                b = 0;
              h < A;

            ) {
              var y = Math.floor(b);
              (p[h] = f[y]), h++, d.length && ((p[h] = d[y]), h++), (b += u);
            }
            return p;
          }),
          (n.encodePCM = function (c, r, i) {
            i === void 0 && (i = !0);
            var l = 0,
              u = c.length * (r / 8),
              f = new ArrayBuffer(u),
              d = new DataView(f);
            if (r === 8)
              for (var A = 0; A < c.length; A++, l++) {
                var p =
                  (h = Math.max(-1, Math.min(1, c[A]))) < 0 ? 128 * h : 127 * h;
                (p = +p + 128), d.setInt8(l, p);
              }
            else
              for (A = 0; A < c.length; A++, l += 2) {
                var h = Math.max(-1, Math.min(1, c[A]));
                d.setInt16(l, h < 0 ? 32768 * h : 32767 * h, i);
              }
            return d;
          }),
          (n.encodeWAV = function (c, r, i, l, u, f) {
            f === void 0 && (f = !0);
            var d = i > r ? r : i,
              A = u,
              p = new ArrayBuffer(44 + c.byteLength),
              h = new DataView(p),
              b = l,
              y = 0;
            s(h, y, "RIFF"),
              (y += 4),
              h.setUint32(y, 36 + c.byteLength, f),
              s(h, (y += 4), "WAVE"),
              s(h, (y += 4), "fmt "),
              (y += 4),
              h.setUint32(y, 16, f),
              (y += 4),
              h.setUint16(y, 1, f),
              (y += 2),
              h.setUint16(y, b, f),
              (y += 2),
              h.setUint32(y, d, f),
              (y += 4),
              h.setUint32(y, b * d * (A / 8), f),
              (y += 4),
              h.setUint16(y, b * (A / 8), f),
              (y += 2),
              h.setUint16(y, A, f),
              s(h, (y += 2), "data"),
              (y += 4),
              h.setUint32(y, c.byteLength, f),
              (y += 4);
            for (var I = 0; I < c.byteLength; )
              h.setUint8(y, c.getUint8(I)), y++, I++;
            return h;
          });
      },
      function (o, n, a) {
        var s,
          c =
            (this && this.__extends) ||
            ((s = function (f, d) {
              return (s =
                Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array &&
                  function (A, p) {
                    A.__proto__ = p;
                  }) ||
                function (A, p) {
                  for (var h in p) p.hasOwnProperty(h) && (A[h] = p[h]);
                })(f, d);
            }),
            function (f, d) {
              function A() {
                this.constructor = f;
              }
              s(f, d),
                (f.prototype =
                  d === null
                    ? Object.create(d)
                    : ((A.prototype = d.prototype), new A()));
            });
        Object.defineProperty(n, "__esModule", { value: !0 });
        var r = a(2),
          i = a(0),
          l = a(3),
          u = (function (f) {
            function d(A) {
              A === void 0 && (A = {});
              var p = f.call(this, A) || this;
              return (
                (p.isrecording = !1), (p.ispause = !1), (p.isplaying = !1), p
              );
            }
            return (
              c(d, f),
              (d.prototype.setOption = function (A) {
                A === void 0 && (A = {}), this.setNewOption(A);
              }),
              (d.prototype.start = function () {
                return this.isrecording
                  ? Promise.reject()
                  : ((this.isrecording = !0), this.startRecord());
              }),
              (d.prototype.pause = function () {
                this.isrecording &&
                  !this.ispause &&
                  ((this.ispause = !0), this.pauseRecord());
              }),
              (d.prototype.resume = function () {
                this.isrecording &&
                  this.ispause &&
                  ((this.ispause = !1), this.resumeRecord());
              }),
              (d.prototype.stop = function () {
                this.isrecording &&
                  ((this.isrecording = !1),
                  (this.ispause = !1),
                  this.stopRecord());
              }),
              (d.prototype.play = function () {
                this.stop(),
                  (this.isplaying = !0),
                  this.onplay && this.onplay(),
                  l.default.addPlayEnd(this.onplayend);
                var A = this.getWAV();
                A.byteLength > 44 && l.default.play(A.buffer);
              }),
              (d.prototype.getPlayTime = function () {
                return l.default.getPlayTime();
              }),
              (d.prototype.pausePlay = function () {
                !this.isrecording &&
                  this.isplaying &&
                  ((this.isplaying = !1),
                  this.onpauseplay && this.onpauseplay(),
                  l.default.pausePlay());
              }),
              (d.prototype.resumePlay = function () {
                this.isrecording ||
                  this.isplaying ||
                  ((this.isplaying = !0),
                  this.onresumeplay && this.onresumeplay(),
                  l.default.resumePlay());
              }),
              (d.prototype.stopPlay = function () {
                this.isrecording ||
                  ((this.isplaying = !1),
                  this.onstopplay && this.onstopplay(),
                  l.default.stopPlay());
              }),
              (d.prototype.destroy = function () {
                return l.default.destroyPlay(), this.destroyRecord();
              }),
              (d.prototype.getRecordAnalyseData = function () {
                return this.getAnalyseData();
              }),
              (d.prototype.getPlayAnalyseData = function () {
                return l.default.getAnalyseData();
              }),
              (d.prototype.getPCM = function () {
                this.stop();
                var A = this.getData();
                return (
                  (A = i.compress(
                    A,
                    this.inputSampleRate,
                    this.outputSampleRate
                  )),
                  i.encodePCM(A, this.oututSampleBits, this.littleEdian)
                );
              }),
              (d.prototype.getPCMBlob = function () {
                return new Blob([this.getPCM()]);
              }),
              (d.prototype.downloadPCM = function (A) {
                A === void 0 && (A = "recorder");
                var p = this.getPCMBlob();
                r.downloadPCM(p, A);
              }),
              (d.prototype.getWAV = function () {
                var A = this.getPCM();
                return i.encodeWAV(
                  A,
                  this.inputSampleRate,
                  this.outputSampleRate,
                  this.config.numChannels,
                  this.oututSampleBits,
                  this.littleEdian
                );
              }),
              (d.prototype.getWAVBlob = function () {
                return new Blob([this.getWAV()], { type: "audio/wav" });
              }),
              (d.prototype.downloadWAV = function (A) {
                A === void 0 && (A = "recorder");
                var p = this.getWAVBlob();
                r.downloadWAV(p, A);
              }),
              (d.prototype.download = function (A, p, h) {
                r.download(A, p, h);
              }),
              (d.prototype.getChannelData = function () {
                var A = this.getPCM(),
                  p = A.byteLength,
                  h = this.littleEdian,
                  b = { left: null, right: null };
                if (this.config.numChannels === 2) {
                  var y = new DataView(new ArrayBuffer(p / 2)),
                    I = new DataView(new ArrayBuffer(p / 2));
                  if (this.config.sampleBits === 16)
                    for (var D = 0; D < p / 2; D += 2)
                      y.setInt16(D, A.getInt16(2 * D, h), h),
                        I.setInt16(D, A.getInt16(2 * D + 2, h), h);
                  else
                    for (D = 0; D < p / 2; D += 2)
                      y.setInt8(D, A.getInt8(2 * D)),
                        I.setInt8(D, A.getInt8(2 * D + 1));
                  (b.left = y), (b.right = I);
                } else b.left = A;
                return b;
              }),
              d
            );
          })(a(5).default);
        n.default = u;
      },
      function (o, n, a) {
        function s(c, r, i) {
          var l = document.createElement("a");
          (l.href = window.URL.createObjectURL(c)),
            (l.download = r + "." + i),
            l.click();
        }
        Object.defineProperty(n, "__esModule", { value: !0 }),
          (n.downloadWAV = function (c, r) {
            r === void 0 && (r = "recorder"), s(c, r, "wav");
          }),
          (n.downloadPCM = function (c, r) {
            r === void 0 && (r = "recorder"), s(c, r, "pcm");
          }),
          (n.download = function (c, r, i) {
            return s(c, r, i);
          });
      },
      function (o, n, a) {
        Object.defineProperty(n, "__esModule", { value: !0 });
        var s = a(4),
          c = null,
          r = 0,
          i = 0,
          l = null,
          u = null,
          f = null,
          d = !1,
          A = 0,
          p = function () {};
        function h() {
          return (
            (d = !1),
            l.decodeAudioData(
              f.slice(0),
              function (I) {
                ((c = l.createBufferSource()).onended = function () {
                  d || ((A = l.currentTime - i + r), p());
                }),
                  (c.buffer = I),
                  c.connect(u),
                  u.connect(l.destination),
                  c.start(0, r),
                  (i = l.currentTime);
              },
              function (I) {
                s.throwError(I);
              }
            )
          );
        }
        function b() {
          c && (c.stop(), (c = null));
        }
        var y = (function () {
          function I() {}
          return (
            (I.play = function (D) {
              return (
                l ||
                  ((l = new (window.AudioContext ||
                    window.webkitAudioContext)()),
                  ((u = l.createAnalyser()).fftSize = 2048)),
                this.stopPlay(),
                (f = D),
                (A = 0),
                h()
              );
            }),
            (I.pausePlay = function () {
              b(), (r += l.currentTime - i), (d = !0);
            }),
            (I.resumePlay = function () {
              return h();
            }),
            (I.stopPlay = function () {
              (r = 0), (f = null), b();
            }),
            (I.destroyPlay = function () {
              this.stopPlay();
            }),
            (I.getAnalyseData = function () {
              var D = new Uint8Array(u.frequencyBinCount);
              return u.getByteTimeDomainData(D), D;
            }),
            (I.addPlayEnd = function (D) {
              D === void 0 && (D = function () {}), (p = D);
            }),
            (I.getPlayTime = function () {
              var D = d ? r : l.currentTime - i + r;
              return A || D;
            }),
            I
          );
        })();
        n.default = y;
      },
      function (o, n, a) {
        Object.defineProperty(n, "__esModule", { value: !0 }),
          (n.throwError = function (s) {
            throw new Error(s);
          });
      },
      function (o, n, a) {
        Object.defineProperty(n, "__esModule", { value: !0 });
        var s = a(0),
          c = (function () {
            function r(i) {
              i === void 0 && (i = {}),
                (this.size = 0),
                (this.lBuffer = []),
                (this.rBuffer = []),
                (this.tempPCM = []),
                (this.inputSampleBits = 16),
                (this.fileSize = 0),
                (this.duration = 0),
                (this.needRecord = !0);
              var l,
                u = new (window.AudioContext || window.webkitAudioContext)();
              (this.inputSampleRate = u.sampleRate),
                this.setNewOption(i),
                (this.littleEdian =
                  ((l = new ArrayBuffer(2)),
                  new DataView(l).setInt16(0, 256, !0),
                  new Int16Array(l)[0] === 256)),
                r.initUserMedia();
            }
            return (
              (r.prototype.setNewOption = function (i) {
                i === void 0 && (i = {}),
                  (this.config = {
                    sampleBits: ~[8, 16].indexOf(i.sampleBits)
                      ? i.sampleBits
                      : 16,
                    sampleRate: ~[
                      8e3, 11025, 16e3, 22050, 24e3, 44100, 48e3,
                    ].indexOf(i.sampleRate)
                      ? i.sampleRate
                      : this.inputSampleRate,
                    numChannels: ~[1, 2].indexOf(i.numChannels)
                      ? i.numChannels
                      : 1,
                  }),
                  (this.outputSampleRate = this.config.sampleRate),
                  (this.oututSampleBits = this.config.sampleBits);
              }),
              (r.prototype.startRecord = function () {
                var i = this;
                return (
                  this.context && this.destroyRecord(),
                  this.initRecorder(),
                  navigator.mediaDevices
                    .getUserMedia({ audio: !0 })
                    .then(function (l) {
                      (i.audioInput = i.context.createMediaStreamSource(l)),
                        (i.stream = l);
                    })
                    .then(function () {
                      i.audioInput.connect(i.analyser),
                        i.analyser.connect(i.recorder),
                        i.recorder.connect(i.context.destination);
                    })
                );
              }),
              (r.prototype.pauseRecord = function () {
                this.needRecord = !1;
              }),
              (r.prototype.resumeRecord = function () {
                this.needRecord = !0;
              }),
              (r.prototype.stopRecord = function () {
                this.audioInput && this.audioInput.disconnect(),
                  this.source && this.source.stop(),
                  this.recorder.disconnect(),
                  this.analyser.disconnect(),
                  (this.needRecord = !0);
              }),
              (r.prototype.destroyRecord = function () {
                return (
                  this.clearRecordStatus(),
                  this.stopStream(),
                  this.closeAudioContext()
                );
              }),
              (r.prototype.getAnalyseData = function () {
                var i = new Uint8Array(this.analyser.frequencyBinCount);
                return this.analyser.getByteTimeDomainData(i), i;
              }),
              (r.prototype.getData = function () {
                return this.flat();
              }),
              (r.prototype.clearRecordStatus = function () {
                (this.lBuffer.length = 0),
                  (this.rBuffer.length = 0),
                  (this.size = 0),
                  (this.fileSize = 0),
                  (this.PCM = null),
                  (this.audioInput = null),
                  (this.duration = 0);
              }),
              (r.prototype.flat = function () {
                var i = null,
                  l = new Float32Array(0);
                this.config.numChannels === 1
                  ? (i = new Float32Array(this.size))
                  : ((i = new Float32Array(this.size / 2)),
                    (l = new Float32Array(this.size / 2)));
                for (var u = 0, f = 0; f < this.lBuffer.length; f++)
                  i.set(this.lBuffer[f], u), (u += this.lBuffer[f].length);
                for (u = 0, f = 0; f < this.rBuffer.length; f++)
                  l.set(this.rBuffer[f], u), (u += this.rBuffer[f].length);
                return { left: i, right: l };
              }),
              (r.prototype.initRecorder = function () {
                var i = this;
                this.clearRecordStatus(),
                  (this.context = new (window.AudioContext ||
                    window.webkitAudioContext)()),
                  (this.analyser = this.context.createAnalyser()),
                  (this.analyser.fftSize = 2048);
                var l =
                  this.context.createScriptProcessor ||
                  this.context.createJavaScriptNode;
                (this.recorder = l.apply(this.context, [
                  4096,
                  this.config.numChannels,
                  this.config.numChannels,
                ])),
                  (this.recorder.onaudioprocess = function (u) {
                    if (i.needRecord) {
                      var f,
                        d = u.inputBuffer.getChannelData(0),
                        A = null;
                      i.lBuffer.push(new Float32Array(d)),
                        (i.size += d.length),
                        i.config.numChannels === 2 &&
                          ((A = u.inputBuffer.getChannelData(1)),
                          i.rBuffer.push(new Float32Array(A)),
                          (i.size += A.length)),
                        (i.fileSize =
                          Math.floor(
                            i.size /
                              Math.max(
                                i.inputSampleRate / i.outputSampleRate,
                                1
                              )
                          ) *
                          (i.oututSampleBits / 8)),
                        (f = 100 * Math.max.apply(Math, d)),
                        (i.duration += 4096 / i.inputSampleRate),
                        i.onprocess && i.onprocess(i.duration),
                        i.onprogress &&
                          i.onprogress({
                            duration: i.duration,
                            fileSize: i.fileSize,
                            vol: f,
                          });
                    }
                  });
              }),
              (r.prototype.stopStream = function () {
                this.stream &&
                  this.stream.getTracks &&
                  (this.stream.getTracks().forEach(function (i) {
                    return i.stop();
                  }),
                  (this.stream = null));
              }),
              (r.prototype.closeAudioContext = function () {
                return this.context &&
                  this.context.close &&
                  this.context.state !== "closed"
                  ? this.context.close()
                  : new Promise(function (i) {
                      i();
                    });
              }),
              (r.initUserMedia = function () {
                navigator.mediaDevices === void 0 &&
                  (navigator.mediaDevices = {}),
                  navigator.mediaDevices.getUserMedia === void 0 &&
                    (navigator.mediaDevices.getUserMedia = function (i) {
                      var l =
                        navigator.getUserMedia ||
                        navigator.webkitGetUserMedia ||
                        navigator.mozGetUserMedia;
                      return l
                        ? new Promise(function (u, f) {
                            l.call(navigator, i, u, f);
                          })
                        : Promise.reject(
                            new Error("浏览器不支持 getUserMedia !")
                          );
                    });
              }),
              (r.prototype.transformIntoPCM = function (i, l) {
                var u = new Float32Array(i),
                  f = new Float32Array(l),
                  d = s.compress(
                    { left: u, right: f },
                    this.inputSampleRate,
                    this.outputSampleRate
                  );
                return s.encodePCM(d, this.oututSampleBits, this.littleEdian);
              }),
              (r.getPermission = function () {
                return (
                  this.initUserMedia(),
                  navigator.mediaDevices
                    .getUserMedia({ audio: !0 })
                    .then(function (i) {
                      i &&
                        i.getTracks().forEach(function (l) {
                          return l.stop();
                        });
                    })
                );
              }),
              r
            );
          })();
        n.default = c;
      },
    ]).default;
  });
})(yn);
var aa = yn.exports,
  ca = aa;
const Vo = Hn(ca);
function la() {
  const t = z(!1);
  let e = null;
  const o = () => Vo.getPermission(),
    n = () => {
      (e = new Vo()),
        e.start().then(
          () => {
            t.value = !0;
          },
          (r) => {
            console.error(`recorder error ,${r.name}:${r.message}`);
          }
        );
    },
    a = async () => {
      t.value = !1;
      const r = e == null ? void 0 : e.getWAVBlob(),
        i = Math.floor((e == null ? void 0 : e.duration) ?? 0),
        l = (e == null ? void 0 : e.fileSize) ?? 0,
        u = new File([r], `${Date.now()}_record.wav`, {
          type: r == null ? void 0 : r.type,
          lastModified: Date.now(),
        });
      try {
        await c();
      } catch {}
      return { file: u, duration: i, size: l };
    },
    s = async () => {
      (t.value = !1), await c();
    },
    c = async () => {
      if (e) {
        try {
          await e.destroy();
        } catch {
          console.error("destroyRecorder failed");
        }
        e = null;
      }
    };
  return (
    Yo(() => s()),
    bt(() => {
      s();
    }),
    {
      isRecording: t,
      requestPermission: o,
      startRecord: n,
      stopRcord: a,
      cancelRecord: s,
    }
  );
}
const ua = { class: "record_container" },
  da = ["data-tip"],
  fa = ["src"],
  Aa = { class: "layer_container" },
  ga = { class: "prompt-layer prompt-layer-1" },
  pa = { class: "prompt-loader" },
  ma = ue({
    __name: "ChatFooterRecording",
    emits: ["recordFinish"],
    setup(t, { expose: e, emit: o }) {
      const n = z(),
        { t: a } = Te(),
        { top: s } = Xn(n),
        c = z(!1),
        r = z(!1),
        { requestPermission: i, startRecord: l, stopRcord: u } = la(),
        f = (p) => {
          const h = p.touches[0];
          r.value = h.pageY < s.value;
        },
        d = async () => {
          const { duration: p, size: h, file: b } = await u();
          r.value
            ? Wt(a("messageTip.messageTip"))
            : p < 1
            ? Wt(a("messageTip.recordingTooShort"))
            : (console.log(p, h, b), o("recordFinish", b, p)),
            (r.value = !1);
        };
      return (
        e({
          isShowOverlay: (p = !0) => {
            p ? l() : d(), (c.value = p);
          },
          touchMoveSpeech: f,
          requestPermission: i,
        }),
        (p, h) => {
          const b = Jn;
          return (
            X(),
            ht(
              b,
              { show: c.value },
              {
                default: Qe(() => [
                  M("div", ua, [
                    M(
                      "div",
                      {
                        "data-tip": r.value
                          ? p.$t("buttons.releaseCancel")
                          : p.$t("buttons.releaseSend"),
                        ref_key: "recordAreaRef",
                        ref: n,
                        class: "record_area",
                      },
                      [M("img", { src: S(ra), alt: "" }, null, 8, fa)],
                      8,
                      da
                    ),
                    M("div", Aa, [
                      M("div", ga, [
                        M("div", pa, [
                          (X(),
                          _(
                            to,
                            null,
                            qo(20, (y, I) => M("div", { class: "em", key: I })),
                            64
                          )),
                        ]),
                      ]),
                    ]),
                  ]),
                ]),
                _: 1,
              },
              8,
              ["show"]
            )
          );
        }
      );
    },
  });
const ha = vt(ma, [["__scopeId", "data-v-eb7ae201"]]),
  Mt = ve();
function va({ messageContent: t }) {
  const e = () => {
      let i = t.value;
      return (
        (i = i
          .replace(
            /<div>/g,
            `
`
          )
          .replace(/<\/div>/g, "")),
        fo(i)
      );
    },
    o = () =>
      Array.from(document.getElementsByClassName("at_el")).map((l) => {
        var u, f;
        return {
          userID:
            (u = l.attributes.getNamedItem("data_id")) == null
              ? void 0
              : u.value,
          nickname:
            (f = l.attributes.getNamedItem("data_name")) == null
              ? void 0
              : f.value,
          tag: l.outerHTML,
        };
      }),
    n = (i) => (
      o().forEach((u) => {
        i = i.replace(u.nickname, `${u.userID} `);
      }),
      i
    ),
    a = async () => {
      const i = e();
      return console.log(i), (await H.createTextMessage(i)).data;
    },
    s = async () => {
      const i = n(e()),
        l = o(),
        u = {
          text: i,
          atUserIDList: l.map((f) => f.userID),
          atUsersInfo: l.map((f) => ({
            groupNickname: f.nickname,
            atUserID: f.userID,
          })),
        };
      return (
        Mt.storeQuoteMessage && (u.message = Mt.storeQuoteMessage),
        (await H.createTextAtMessage(u)).data
      );
    },
    c = async () => {
      const l = { text: n(e()), message: JSON.stringify(Mt.storeQuoteMessage) };
      return (await H.createQuoteMessage(l)).data;
    };
  return {
    getAtList: o,
    switchNomalMessage: async () => {
      let i;
      if (
        (o().length > 0
          ? (i = await s())
          : Mt.storeQuoteMessage
          ? (i = await c())
          : (i = await a()),
        !i)
      ) {
        Rt({
          error: "create message failed",
          message: "create message failed",
        });
        return;
      }
      return i;
    },
    getCleanText: fo,
  };
}
function ba() {
  const { t } = Te(),
    e = (r) =>
      new Promise((i, l) => {
        let u = new FileReader();
        (u.onload = function () {
          i(u.result);
        }),
          u.readAsArrayBuffer(r);
      }),
    o = async (r) => {
      const { width: i, height: l } = await Ao(r),
        u = {
          uuid: rt(),
          type: r.type,
          size: r.size,
          width: i,
          height: l,
          url: URL.createObjectURL(r),
        },
        f = {
          sourcePicture: u,
          bigPicture: u,
          snapshotPicture: u,
          sourcePath: "",
          file: r,
        };
      return (await H.createImageMessageByFile(f)).data;
    },
    n = async (r, i) => {
      const l = {
        file: r,
        uuid: rt(),
        soundPath: "",
        sourceUrl: "",
        dataSize: r.size,
        soundType: r.type,
        duration: i,
      };
      return (await H.createSoundMessageByFile(l)).data;
    },
    a = async (r, i) => {
      const { width: l, height: u } = await Ao(i),
        f = {
          videoFile: r,
          snapshotFile: i,
          videoPath: "",
          duration: await Zn(URL.createObjectURL(r)),
          videoType: r.type,
          snapshotPath: "",
          videoUUID: rt(),
          videoUrl: "",
          videoSize: r.size,
          snapshotUUID: rt(),
          snapshotSize: i.size,
          snapshotUrl: URL.createObjectURL(i),
          snapshotWidth: l,
          snapshotHeight: u,
          snapShotType: r.type,
        };
      return (await H.createVideoMessageByFile(f)).data;
    },
    s = async (r) => {
      const i = {
        file: r,
        filePath: "",
        fileName: r.name,
        uuid: rt(),
        sourceUrl: "",
        fileSize: r.size,
        fileType: r.type,
      };
      return (await H.createFileMessageByFile(i)).data;
    };
  return {
    createFileMessage: async (r, i, l) => {
      let u;
      if (i === Ce.VideoMessage)
        try {
          u = await Wn(URL.createObjectURL(r));
        } catch (f) {
          return (
            Kn(t("messageTip.generateImageFailed")),
            console.error("get video snapShotFile failed: " + f),
            { error: "get video snapShotFile failed" }
          );
        }
      switch (i) {
        case Ce.PictureMessage:
          return { message: await o(r), buffer: await e(r) };
        case Ce.VoiceMessage:
          return { message: await n(r, l), buffer: await e(r) };
        case Ce.VideoMessage:
          return {
            message: await a(r, u),
            buffer: await e(r),
            snapBuffer: await e(u),
          };
        case Ce.FileMessage:
          return { message: await s(r), buffer: await e(r) };
        default:
          return { error: "message type error" };
      }
    },
  };
}
const ya =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAABYCAYAAABxlTA0AAAAAXNSR0IArs4c6QAACU9JREFUeF7tnQtwFtUVgL9NeIanBBpIQ2JIYngrAvISiiLPICAviwq0wFDGpiiKNZlqZdBCoFg60AwvAQEpVkEeAkLAUqTaAgqBYQTCs0ZgCPIIAQIhyXYO9/8nIf8jIfnv/plkz0xmMrt3z+759sy955x7978G3mS2GUUucQTSC4gBwoA6Xq+p6CdNsjD4ETiByU7uspW3jVOezDbcnnjXjKI60zH5JRBQ0ZmV0b48TNYQwDR+7wraFXCSORJYjkFQGW9c2S6/SQCjecNYX9jw+wHPMl8H/gy49+zKhuzB7c0nn6kkGnOdlxaAnGEOIZB1dpfw4FSLXJEPDONNY4McV4BlMMsnFYPaZVZvKxACWeTzGInGaQU4yVyNwQs2Gx8SMFlJgjHWYI4ZQS6nMexowYd4RVUe+UQbJJmvYPBXHyu31QkBk8kGs8wtwACbiBYCm8SDj2LQXIv6yq7U5JgAzsSgbmVnocV+k+vSRZhalNtK7xGwAWt2BBuwDVgzAc3qbQ+2AWsmoFm97cE2YM0ENKu3PdgGrJmAZvW2B9uANRPQrL7ce3CzehBSC34WpP5kkisrBzJuwrHLcP6mZkJlVF/uAAdVgWejoV8k9I2EJsXMEl66BSlnYONJ2HAC7sqUYzmScgO4eiBMfBQSOxcP1RO/8zdg7n6Y9x3klBPQ5QJw9zD4aCCEF6pKSxH1u4uw+SSkXYWLN+GnbHioBoTWVn/N6sOQGPV/YTl+BcZthW/O+9+V/Q5YvHb+M1AtUMG4kwt/O6g88dyN4gEFGNCzKbzYEka3hqqOhV45efC7nbD4UPE6dLbwK+Bp3eCdbgXmSV86KQXOZJbO5PYhsCIOWjVU18tMgkBOPlA6fb64ym+Ahz8CnwwGw7G2aGEqxO+AvDLOr0hfPqcnxLdXePJNGPwZbPa4/tEXGD3r8AvglsGwdzTUrqYe7C/74fVdvjX07wNhVEulUyKNNsvg4i3f3qMk2vwCeNsIFYKJfJUOvT6G3DJ6blFjawTCv0ZBp1B1ZsFBeHlHSZD4to3lgLv+HL5+URkhCUPsErjgIVmQmHhMa+jYGCLqweVs+M85WH4EMu+oxGNgVIGuT4/fDyeyHhyboAZQGfSiF0N6lm8BFqfNcsDbR0Afh/fO2gsJu90/ooRfi/tCIzerlDNuwbD1ahD7t+Nlnb4GUYtddS3qq+JrEbmX3NNKsRRwgxqQEQ+BAXDzLkQuhEvZruaOaQXL+qt2nuTaHZi4TQ2UIp4Adw2Fr19Sbfadh04fWYnX4mn7kc3hH4OUgZ+lwbB7K2jvl4i6cGRcwQB44QZM/wZ2nlURRvvGMLWj6lvlJdWq6h2wBCmXJ6sE5U4e1JlrbTptqQcv7Qfj2iogEu8uSnUFvCoOXmqljsvo33kVnC4SF0ufKu3khTnFkwfL+X8+D09FqJYSTRz5yTovthTwt2OUB4rELIaT1+43tGYV1YU4w7fJO2G+hyQhJAhO/aZ4D5Y7FH5pPdfA7vQKCviHSdC0rgr+q89xDc2eiYAdzyvjpU2TZJABzZMs6gMTH/PeRcjZ5N7wcjvVbtA6+NzCpMNSD85+DWpUgSvZEDzfFduv26jBTST9OoQv9O5pr3aAuU8XD1h0im6Rpz+GXT9UQA+WwejGFGVY2hWI/cDVyIROMPMX6njqRWi3wjuIwdGwYWjxgNcOhmGxqt2jy+HwpQoIWKpeOVMh0ICTVyFmiauR8Y+ryprI0cvQcql3EKNbwcq44gEX7vtDkz0nNjqwW9pFXIqHhkFquick2dWc4bHwqSOulUytwTzVF3uSd7rCtCe9A5byZdYUkCLQuSwIW6ADo2edlgL+fjy0CFbQJB69lXv/g7VoAN9PKDjWaRXsu+D54SXlltRbxFOYJjUPqX2IrDgCv9pagQEXTpM7rFAzFkXl6HhoHqyOrj0OIza6B9I/ErY6wEmLs5kQuci17bohMPQRdXz4BliXVoEBJ3SGmT2UgVN3wfv7XY19rSO8/5Q6Lr3DH76CpP+q/53SOwLWDILgmgXH7uZBw/lwPafgmBSCNg1TX1sezoB2H4LVU3WWdhEy4/DtWAVgTzr0WOMKuEoAHBgLbRoVnJPM68uzCnKHxtAlVNUppAQpKfPjIartllPqhUgKPSgG3usOkrxIlxS3FradsdZ75W6WApbazYV4VWaUSU0Jww5luBotZcaUkRD9kGcgMrH5xEqVLi/p57mdvJTfpsACN2m5FbgtBSwGvd0FpndXpm06qaZz3Im8hOlPwtjWKjlxSl4+rD8Bk7bD5dvq6Iwe8MYTIN5fWGTgS9wNnxSpE1sB1nkPywHXrQZnJoGULkVkHi75oGeTpZ9t20hN6UsGmJrhvmgeXR8GRkN4HRXnShwtk6j+Xh9hOWBBmdgJZjgyNpmm77oaDriJKKz0NF338gtgyea+GAG9H1Zm/S8TnlsPB930x7oMt0qvXwCLcdJF7BsDUfWVqbdzVejmrbuwCoov7+M3wGKE9JtSrHEuFJFjMvD9cQ8csrAg40ugRXX5FbA8TO2q8OGAgmqXHJMQbs+PsPGEKi3KgHU7zxWDRA0S0kn63SsckvZaW8gpyYvxO2DnQ45qAW91gZaOZU+FH15CM1k0IllaTi4EVVWzHhJhONeiSftmi0q/7KoksErTptwAloeXMHZoLExoC7LiUkCWVGSNRYsPSrZgsKQ6fdGuXAEubJBMbMqUe7cwaFJLrY9oWFMlHVdvwxX5y1ZVNAnxpOrm75jX3Qspt4B94T3lQYcNWPNbsAHbgDUT0Kze9mAbsGYCmtXbHmwD1kxAs3rbg23AmgloVm97sA1YMwHN6m0PtgFrJqBZve3BNmDNBDSrtz1YO2D7B5r1Ib73A81J5nEMHCto9d2rUmo2SRPA2zHoUykB6DbaJMVgtvkKpr3NgxbWJq8azDQfJoDT9gZRPkdsEkikc6udpRiM8/ktKrNCk2UkGOMV4PfMplTlMOBYileZyfjAdpNMcmnDW0Z6wXZnSWZ/DDbb252VGbDskPgsCcYXosndhn2zbcilhiwfMU3hTWOeU4PrzoczzecIQL4Srtyboz4oYxP5Gb0XSDA+L3yp+60lk8xw4E+OPebsTVO9w5YuYbV830OC4fIdv/e9O9VOiQMwkE+0YzAJw6j0ni2/W6W2/c3jS/LY4m3b3/8DwW4mpwT9OKAAAAAASUVORK5CYII=",
  wa = { class: "flex h-screen flex-col" },
  Ca = { class: "flex justify-between bg-white px-[22px] pt-3" },
  Ea = M("div", null, null, -1),
  ka = ["src"],
  Ba = { class: "ml-[10px]" },
  Ia = ue({
    __name: "ChatFooterAtPop",
    emits: ["finish", "cancel"],
    setup(t, { emit: e }) {
      const { t: o } = Te(),
        n = ve(),
        a = z(!0),
        s = At({ keyword: "", searching: !1 }),
        c = At({ showCheck: !0, checkedMemberList: [] }),
        {
          fetchState: r,
          getMemberData: i,
          searchMember: l,
        } = ms(n.storeCurrentConversation.groupID),
        { isNomal: u } = Ko(n.storeCurrentConversation.groupID),
        f = re(() => (s.searching ? r.searchMemberList : r.groupMemberList)),
        d = () => {
          e("finish", {
            data: [{ nickname: o("atAll"), userID: "AtAllTag" }],
            needDelete: !0,
          });
        },
        A = () => {
          if (!c.showCheck) {
            (c.checkedMemberList = []), (c.showCheck = !0);
            return;
          }
          e("finish", { data: c.checkedMemberList, needDelete: !0 });
        },
        p = () => {
          s.keyword &&
            ((s.searching = !0),
            (r.searchOffset = 0),
            (r.searchMemberList = []),
            l(s.keyword));
        },
        h = () => {
          s.keyword || (s.searching = !1);
        },
        b = () => {
          r.hasMore && (s.searching ? l(s.keyword) : i());
        },
        y = (D) => {
          if (!c.showCheck) {
            e("finish", { data: [D], needDelete: !0 });
            return;
          }
          const T = c.checkedMemberList.findIndex((k) => D.userID === k.userID);
          if (T > -1) {
            const k = [...c.checkedMemberList];
            k.splice(T, 1), (c.checkedMemberList = k);
          } else c.checkedMemberList = [...c.checkedMemberList, D];
        },
        I = () => e("cancel");
      return (D, T) => {
        const k = Lo,
          B = ps,
          w = _n;
        return (
          X(),
          ht(
            w,
            {
              show: a.value,
              "onUpdate:show": T[2] || (T[2] = (U) => (a.value = U)),
              position: "bottom",
              round: "",
              onClickOverlay: T[3] || (T[3] = (U) => (a.value = !1)),
              onClosed: I,
              class: "!bg-[#F8F9FA]",
            },
            {
              default: Qe(() => [
                M("div", wa, [
                  M("div", Ca, [
                    M(
                      "div",
                      { onClick: T[0] || (T[0] = (U) => (a.value = !1)) },
                      [L(k, { name: "arrow-down" })]
                    ),
                    M("div", null, ae(D.$t("selectAtMember")), 1),
                    Ea,
                  ]),
                  L(
                    B,
                    {
                      modelValue: s.keyword,
                      "onUpdate:modelValue":
                        T[1] || (T[1] = (U) => (s.keyword = U)),
                      placeholder: D.$t("placeholder.search"),
                      onSearch: p,
                      onBlur: h,
                    },
                    null,
                    8,
                    ["modelValue", "placeholder"]
                  ),
                  S(u)
                    ? De("", !0)
                    : (X(),
                      _(
                        "div",
                        {
                          key: 0,
                          class:
                            "my-[10px] flex h-[64px] flex-row items-center bg-white",
                          onClick: d,
                        },
                        [
                          M(
                            "img",
                            {
                              class: "ml-[22px] h-[44px] w-[44px]",
                              src: S(ya),
                              alt: "",
                            },
                            null,
                            8,
                            ka
                          ),
                          M("span", Ba, ae(D.$t("atAll")), 1),
                        ]
                      )),
                  L(
                    S(Wo),
                    {
                      class: "my_scrollbar flex-1 overflow-scroll",
                      "data-key": "userID",
                      onTobottom: b,
                      "data-sources": S(f),
                      "data-component": vs,
                      "estimate-size": 88,
                      "extra-props": (U) => ({
                        total: S(f).length,
                        showCheck: c.showCheck,
                        checked: !!c.checkedMemberList.find(
                          (j) => j.userID === U.userID
                        ),
                        onClickItem: y,
                      }),
                    },
                    null,
                    8,
                    ["data-sources", "extra-props"]
                  ),
                  L(
                    hs,
                    {
                      "all-checked-list": c.checkedMemberList,
                      total: S(f).length,
                      onConfirm: A,
                    },
                    null,
                    8,
                    ["all-checked-list", "total"]
                  ),
                ]),
              ]),
              _: 1,
            },
            8,
            ["show"]
          )
        );
      };
    },
  }),
  Sa = { id: "chat_footer", class: "flex items-center bg-[#F0F2F6] px-3 py-3" },
  Da = ["src"],
  Ma = { class: "flex-grow" },
  Ua = {
    key: 0,
    class:
      "relative mt-1 break-all rounded bg-white py-1 pl-1 pr-5 text-xs text-[#666] line-clamp-2",
  },
  Ta = ["src"],
  Ra = ["src"],
  Fa = ["src"],
  Qa = ["src"],
  Oa = ue({
    __name: "ChatFooter",
    emits: [],
    setup(t, { emit: e }) {
      const { t: o } = Te(),
        n = ve(),
        a = z(""),
        s = z(),
        { createFileMessage: c } = ba(),
        { getAtList: r, switchNomalMessage: i } = va({ messageContent: a }),
        { sendMessage: l } = gs(),
        u = re(() =>
          n.storeQuoteMessage
            ? `${o("messageMenu.replay")}：${Ho(n.storeQuoteMessage)}`
            : null
        ),
        f = () => {
          n.updateQuoteMessage();
        },
        d = z(!1),
        A = () => {
          n.storeCurrentConversation.groupID && (d.value = !0);
        },
        p = ({ data: R, needDelete: F }) => {
          F && s.value.deletePreviousChar();
          const Q = [];
          R.map((q) => {
            if (r().find((Y) => Y.userID === q.userID)) return;
            const J = document.createElement("b");
            (J.textContent = `@${q.nickname} `),
              J.setAttribute("class", "at_el"),
              J.setAttribute("data_id", q.userID),
              J.setAttribute("data_name", q.nickname),
              J.setAttribute("contenteditable", "false"),
              Q.push(J),
              Q.push(document.createTextNode("​"));
          }),
            s.value.insertAtCursor(Q),
            (d.value = !1);
        },
        h = Xt(() => {
          n.storeCurrentConversation.conversationType === gt.Single &&
            H.typingStatusUpdate({
              recvID: n.storeCurrentConversation.userID,
              msgTip: "yes",
            });
        }, 2e3),
        b = (R) => {
          os() &&
            (setTimeout(() => pe.emit("KEYBOARD_UPDATE"), 100),
            R && setTimeout(() => window.scroll(0, 0), 101));
        },
        y = async () => {
          const R = await i();
          R && l({ message: R }), D();
        },
        I = (R) => {
          const Q = new DOMParser().parseFromString(R, "text/html"),
            q = Array.from(Q.body.childNodes);
          s.value.insertAtCursor(q);
        },
        D = () => {
          (a.value = ""), n.updateQuoteMessage(), s.value.clear();
        },
        T = z(!1),
        k = z(),
        B = z();
      $n(
        k,
        () => {
          B.value.isShowOverlay();
        },
        { modifiers: { prevent: !0 } }
      );
      const U = async () => {
          if (!T.value)
            try {
              await B.value.requestPermission();
            } catch (R) {
              console.log(R), Wt(o("messageTip.environmentNotSupported"));
              return;
            }
          T.value = !T.value;
        },
        j = Xt((R) => {
          B.value.touchMoveSpeech(R);
        }, 250),
        $ = () => {
          B.value.isShowOverlay(!1);
        },
        oe = async (R, F) => {
          const {
            error: Q,
            message: q,
            buffer: x,
          } = await c(R, Ce.VoiceMessage, F);
          if (Q || !q) {
            Rt({ error: Q, message: Q });
            return;
          }
          l({ message: q, fileArrayBuffer: x });
        },
        K = z(!1),
        ne = z(!1),
        Z = () => {
          K.value = !1;
        },
        ee = () => {
          ne.value = !1;
        },
        Re = () => {
          ne.value && (ne.value = !1), (K.value = !K.value);
        },
        Be = () => {
          K.value && (K.value = !1), (ne.value = !ne.value);
        },
        se = async (R) => {
          var Y, te;
          let F = Ce.FileMessage;
          (Y = R.file) != null &&
            Y.type.includes("image") &&
            (F = Ce.PictureMessage),
            (te = R.file) != null &&
              te.type.includes("video") &&
              (F = Ce.VideoMessage);
          const {
            error: Q,
            message: q,
            buffer: x,
            snapBuffer: J,
          } = await c(R.file, F);
          if (Q || !q) {
            Rt({ error: Q, message: Q });
            return;
          }
          l({ message: q, fileArrayBuffer: x, snpFileArrayBuffer: J });
        };
      return (
        pt(
          () => n.storeQuoteMessage,
          (R) => {
            R && s.value.inputRef.focus();
          }
        ),
        pt(
          () => n.currentConversation.conversationID,
          (R, F) => {
            var x;
            let Q = a.value;
            const q = r();
            if (R) {
              const J =
                (x = n.currentConversation) == null ? void 0 : x.draftText;
              setTimeout(() => {
                s.value.inputRef.focus();
                const te = new DOMParser().parseFromString(J, "text/html"),
                  ce = Array.from(te.body.childNodes);
                s.value.insertAtCursor(ce),
                  H.setConversationDraft({ conversationID: R, draftText: "" });
              }, 50);
            }
            if (a.value && F) {
              if (q.length > 0) {
                q.map((te) => (Q = Q.replace(te.tag, `@${te.userID} `)));
                const J = /@\S+\s/g,
                  Y = Q.match(J);
                Y == null ||
                  Y.map((te) => {
                    const ce = q.find((be) => be.userID === te.slice(1, -1));
                    if (ce) {
                      const be = new RegExp(te, "g");
                      Q = Q.replace(
                        be,
                        `<b class="at_el" contenteditable="false" data_id="${ce.userID}" data_name="${ce.nickname}">@${ce.nickname} </b>`
                      );
                    }
                  });
              }
              H.setConversationDraft({
                conversationID: F,
                draftText: Q.trim(),
              });
            }
            !a.value.trim() &&
              F &&
              H.setConversationDraft({ conversationID: F, draftText: "" });
          },
          { immediate: !0 }
        ),
        tt(() => {
          s.value.inputRef.focus(), pe.on("AT_SOMEONE", p);
        }),
        es(() => {
          s.value.clear(), s.value.inputRef.focus();
        }),
        bt(() => {
          pe.off("AT_SOMEONE", p);
        }),
        (R, F) => (
          X(),
          _("div", null, [
            M("div", Sa, [
              // M(
              //   "img",
              //   {
              //     onClick: U,
              //     class: "mr-3 h-[26px] min-w-[26px]",
              //     src: T.value ? S(ui) : S(ci),
              //     alt: "",
              //   },
              //   null,
              //   8,
              //   Da
              // ),
              M("div", Ma, [
                de(
                  M(
                    "div",
                    {
                      ref_key: "recordingBtnRef",
                      ref: k,
                      onTouchmove:
                        F[0] || (F[0] = (...Q) => S(j) && S(j)(...Q)),
                      onTouchend: $,
                      class:
                        "flex h-8 items-center justify-center rounded bg-white",
                    },
                    [M("span", null, ae(R.$t("buttons.holdSpeak")), 1)],
                    544
                  ),
                  [[fe, T.value]]
                ),
                de(
                  L(
                    ds,
                    {
                      class: "bg-[#fff]",
                      ref_key: "inputRef",
                      ref: s,
                      onChange: S(h),
                      onFocus: F[1] || (F[1] = (Q) => b(!0)),
                      onBlur: F[2] || (F[2] = (Q) => b(!1)),
                      input: a.value,
                      "onUpdate:input": F[3] || (F[3] = (Q) => (a.value = Q)),
                      placeholder: R.$t("placeholder.pleaseInput"),
                      onTriggerAt: A,
                    },
                    null,
                    8,
                    ["onChange", "input", "placeholder"]
                  ),
                  [[fe, !T.value]]
                ),
                S(u)
                  ? (X(),
                    _("div", Ua, [
                      ts(ae(S(u)) + " ", 1),
                      M(
                        "img",
                        {
                          class: "absolute right-1 top-1",
                          width: "16",
                          src: S(di),
                          alt: "",
                          onClick: f,
                        },
                        null,
                        8,
                        Ta
                      ),
                    ]))
                  : De("", !0),
              ]),
              M(
                "img",
                {
                  onClick: Be,
                  class: "ml-3 h-[26px] min-w-[26px]",
                  src: S(li),
                  alt: "",
                },
                null,
                8,
                Ra
              ),
              de(
                M(
                  "img",
                  {
                    onClick: Re,
                    class: "ml-3 h-[26px] min-w-[26px]",
                    src: S(ai),
                    alt: "",
                  },
                  null,
                  8,
                  Fa
                ),
                [[fe, !a.value]]
              ),
              de(
                M(
                  "img",
                  {
                    onClick: y,
                    class: "ml-3 h-[26px] min-w-[26px]",
                    src: S(fs),
                    alt: "send",
                  },
                  null,
                  8,
                  Qa
                ),
                [[fe, a.value]]
              ),
            ]),
            de(L(wi, { onCloseActionBar: Z, onGetFile: se }, null, 512), [
              [fe, K.value],
            ]),
            de(L(ia, { onCloseEmojiBar: ee, onEmojiClick: I }, null, 512), [
              [fe, ne.value],
            ]),
            L(
              ha,
              { ref_key: "recordingOverlayRef", ref: B, onRecordFinish: oe },
              null,
              512
            ),
            d.value
              ? (X(),
                ht(Ia, {
                  key: 0,
                  onCancel: F[4] || (F[4] = (Q) => (d.value = !1)),
                  onFinish: p,
                }))
              : De("", !0),
          ])
        )
      );
    },
  });
const ja = vt(Oa, [["__scopeId", "data-v-f958ea87"]]),
  Na =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAABShJREFUeF7tnWuIVVUUx3/LPjlmSEFkPqaykUp6UmFICBkNlYVaRDiGpVFfLJXxU1AMkRAWFBYWRIWTYUE+qEYZSUPCiooegllOijVjRlBUpn5ydmxn7nBn7rmP5dnn7jPddT7O2eu/9v7/ztr3DPucs4UKh3NuGnAnMAdoASYD4yvF2DmOAX1AD/ARsE1EDpbzRZJODBr/NHA/MMZMTeXAKWAj0JEEogSAc+4+4E2gKVVaCx7pwHHgARHZUnxiGADnXDvwHJBYGeZpagf6gVUi8kJBacho59w8YJNNOalNribgIdwjIlt9w9MABuf8b4Gzq0Xb+SAO+B/qa0TkUAHA28DCINImUqsDnSKyWJxzzcAhm3pq9S1YO393dKkHsBx4MZisCWkceNwD6ALu0ERZ22AOvO8B7AcuCyZpQhoHfvAA/gbO0URZ22AO/OMBuGByJqR2wACoLQsbYADC+qlWMwBqy8IGGICwfqrVDIDasrABBiCsn2o1A6C2LGyAAQjrp1rNAKgtCxtgAML6qVYzAGrLwgYYgLB+qtUMgNqysAEGIKyfarXRAWDXNvh8N/T7ZdQajjFnwczZcEv+F/ryD2D/Xlhydw2uJzRZ3wXTZ5xZbJ2i8g/g8E/Q1lr71V8wzlfBOzthykV1svLM0uQfgB/XgX3Q871uhC1X5P7q9wMaHQB01o+q1vEAHO2D776EUzX+sGZp63UzYaJ/9aH+RxwAv/bColY4eaL+I07KOLYJNnTDhVPq3p84APycvti/eJOjI9IdUxwA3vfNG2DfN/kgMONaWLAoSl/iAYgy3PwlzReAv/6ECedm69KJ49A0LtscCvX8AHj+KdjUCa3zoCOjh7U7VkD3VnhwGTy6SmFTdk3zA2D+LPjtyMBIPzuczYhvGvyv+IJJsGVPNjmUqqMLQC1TVKU2BqDC5VGtAtY9C2+9CtfPgpf8G1UJx2Nt8NUeWLocHl5Z2sAApABw72w48vOAwIdfwHnnDxf743eYe+PA3yY1w3u7DYBqOqxWAcXnN38CE0f813q0FxbcPJCy3BxvFZCiAgyA6nrWN7YK0HsWNMIABLVTL2YA9J4FjTAAQe3UixkAvWdBIwxAUDv1YgZA71nQCAMQ1E69mAHQexY0wgAEtVMvZgD0ngWNMABB7dSLGQC9Z0EjDEBQO/Vi1QAUL8hs/7r06YniBZmpl8C7u0r7YOsBKdYDOtfBK2tgzlx45uVkofaH4NOPYdkT0PaIAVCVQbUKUImVaWwVUGMFJE0xaQEUT1H2WEqCm8UVMLkZrr4hreXD4/2j8H2Di/oGoAqAsNaXqhmABIfXroaNr2Vt/YC+PZpYxmf/RuRJ/5n9DI+x4+DyqzJMoJPOz6OJun7/b1obgMgoDYABiOxA5PRWAQYgsgOR01sFGIDIDkRObxVgACI7EDm9VYABiOxA5PRWAQYgsgOR01sFGIDIDkRObxWQAwC2kVs8CKc3cvsRmB6vDw2d+YAH0A3c1tA2xBv8Dg/AtrONB2CFB+C/YuQ3dB7aXz5efxoqs9/D8+LCluavA0saavjxB/uGiCwtAPDfftkLTIjfr4bogb/zvFJEeoemHefc7f5TSLa3fOYXgP9W810ist1nGjbvO+fagTUGITMI/cBKEVlbyFDyw+ucmw+sB8Zn1o3GFP4XWCgiHxQPP/HOxzk3FVjtA6waUl8tfsrxXxl8UkR+GalW8dbTOTcN8Bux3Aq0AP4b71YZlZkcA/qAHmAn0CUiB8uF/Ad+iCdnK4TrQQAAAABJRU5ErkJggg==",
  Va =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAACL9JREFUeF7tnXtQFVUcx79HHVGpptTwhY8GFV9ompn5qEgzxEypEUWzEMlHmi9AQzNATBBlePTwEaT5LNNwJEpIBx1NLPOR5SgppmJOmTq+00bd5rdyt3vxwj3LPcsudfYvZX+/7+75fnbPnj3n3LMM5WyKovgAGACgD4BWALwB3F9ejtyHKwBOAzgKYAuArxhjRWX5wpztKDF+DoBhAKpJU91y4DaAtQBinYG4B4CiKMEAlgGo49ZhZXJpB64BGMkYy7Lf4QBAUZQIAAsAOL0zpKduO3AHQCRjLMWmpBmtKMpgABtkleO2ya4ECMLLjLGNFKgCKKnzDwC4z1W23C/EAXpQP8oYO24DsBrAcCHSUoTXgRWMsdeYoijNARyXVQ+vb8LiqHXUkgBMBpAqTFYK6XFgEgHIARCoJ0vGCnNgEwE4DKCNMEkppMeBIwTgEoAH9GTJWGEOXCYAijA5KaTbAQlAt2ViEyQAsX7qVpMAdFsmNkECEOunbjUJQLdlYhMkALF+6laTAHRbJjZBAhDrp241CUC3ZWITJACxfupWkwB0WyY2QQIQ66duNQlAt2ViEyQAsX7qVpMAdFsmNkECEOunbjXLALh67ToOFxbhxs2/nRbi8c4dUKuWB1cBi04Uo0lDL+54LlGDgkwHUHjsBGIS3sOW7QW4WYb5VPahQQHISJ/LZYN3+2fQ1tcHazOSUb/ug1w5ZgWZCiB/x3cICY/Etet/uSx/cFAAMjkB3N+0q6rXyqc5Pl+eCp8WTV3qmxVgGoDCY7/i6QGvaub7tWuF14YNhqfnvZOyPT1r47lneuA+J/ucGWcDQPu8Hq6HtRkL0a2Ln1kel3tc0wAMGx2BnLzt6smNDwtBUhxNzBaz2QMgRc86tfFR2hwMDPAXcwCBKqYAoAdui0591TqfrvxdufT7BXGbDUCdOrVxvaR6q169OubHTMPYUUPFHUiAkikAvt/3E/oMGqWe/sI5URU25WTxGRTsOYDjJ+gXQf9uCSlL1f+kzHsLBd8fwLqNm7Wdk8a8gndnTxFgnRgJUwDsKPgBgcHj1BIsSo7BK8EDdZXmm227sCA9EwV7fiw3z6ad/MFyxC9YhNu3aT4sMCjwWWSkxVuimVqlAFDVNTFqLjZk53EBW7E4EUED+qqx3+TvwshxM7SHfvfHO1mimVplAJy7cBHBoVOwZ//PDuZTKyegTy/49+qGBl71tH0eHh7o0rEtatSoof2N3jlCwiNwtOik+jcrNFOrBIBbt26hf/BY7LarcqhlEz11DMaGBuuqSi5euoLQCdHYun23CsHsZmqVADArPhXpS1dpV3Jnv7ZYuWQ+mjdtzFUVlQ4ioOOmxeGzrK/VXQTzwI4sNPSqXyE9d5IsD+DQkWPoGTBCe4B279oJWave434pc2YOPQ9GTZyJS5evagB+Lsg2pdvC8gDsX9j82rVG3hcZbpmftmQlYhLe14BSFZS1Mh0d2/u6cyFXONfSAH478wfaPEErJQAeNWvi29zV8G35iFZYeg9YvykPO3fvxaniM/f0pC77YJ7WBXHjxk1Mjk7AmvVfavn0EM5e+yGaNGpQYQPdTbQ0AGq/xya+r5ZxfNgwJMVFqv+mB+msualY/fmX2pXszAjbe8AfZ8+pnX72Lahe3buoHXW8/UvuGl1WvqUB9B8yBjt371PP/ch3OWjSuAHoJS580js48/tZl54QgNYtW6jmn/3zvBYfPDgAS1JiHZqoLsUMCrA0gIa+vdUXJ1t/UVJaJualLHV4IPv37oZm3o3RvGkjzSLbW/bzfXpi2849DuMMUW+G4Z3pbxhkp35ZywKg+r1DjxfVEr0xOgTnL1zUmo1UfcyPjSjzwVm6N5Q0qDMuNSEaoSG0IoN1NssCsO8vatzQS6ty3o4chxmTw8t10Fl39MrF8/Gcfw/rOF9yJlUCgM21xJhpmBDuekWF0gMyZjYzXRGvMgDCRryEtMSZrsqj7rcfkjS7menqhC0LwH7MoJl3I+zNX8/d50OD8vTSZoVmZpUFQG33lo8FqOe/YlEigl64263MsxX9Wqy2iux7QnnyzIix7B1AZtCVXPehB7Fv23pDzKTxhSnRCfDwqInk+Oncd5hIUJYGkJSWAb/2vujft7fIMmta2ZvzMfz1KPX/X61bjN5P3p3OUpmbpQEYbcSqddkYHxEnAegdExYFRgKo4KC8BOCmA+7OinDz8Fq6vAPkHQBTHsIOE7PiozA21JzZakuWf4bI2bROLZC74SP06NZZ1M3FrWMKAGp/e7f3V7uV6Y11V+4a7hMWGfhU4Ejs/+mw2lN6+lC+KYMzpgAgE+3Heqm7mbqXK3ObEZuMDzPvzkkd0O9pfJqZXJmH145lGoDS09M7d2yLEUNeMPwqpLuPhjL3H6S1Cu9OSdmes8JhrLkySZgGgAr59ZYdGDVhJtcPNIwwhcyngXuj3rR5ztlUAHSCdCfQNJHNW3eWO8DOUxjeGKrzaTpjXPRE065827maDsB2IlQ1HDxUaDgEMp/mAJk9G8JyAHiv3v9anGXugP+asbzlkQB4nTIoTgIwyFheWQmA1ymD4iQAg4zllZUAeJ0yKE4CMMhYXlkJgNcpg+IkAIOM5ZWVAHidMihOAjDIWF5ZCYDXKYPiJACDjOWVlQB4nTIoTgIwyFheWQmA1ymD4giA/JCbQeZyyKofcisE0JojWIaId+AXApALoJ94banI4UAeAZCfs+VwyqCQKQSgRckHnbXvyxt0MCnr6AB9w/MR2yfNMwGESYcq1YGPGWOjbQBobd+DAKy90HKl+mPowajl6ccYK9aqHUVR+gOgxXSqGXpoKU5rZw5kjKnrpTnU+4qi0BTlJAnBsKvkDoCpjLF02xHuefAqihIE4BP6xb9hp/H/FKYF6oYzxrLti++05aMoSjMA71KCvBvcvlqoylkNYDZj7FRptXKbnoqi+AAIBEDrBLSiH6/LO8MlkCsAaDHrowC2AshhjBWVlfUP5m9AdvpvcH0AAAAASUVORK5CYII=",
  Pa = { class: "flex h-[92px] bg-[#F0F2F6] py-3" },
  za = ["src"],
  La = { class: "mt-1.5" },
  xa = ["src"],
  Ga = { class: "mt-1.5 text-error-text" },
  qa = ue({
    __name: "MutipleAction",
    setup(t) {
      const { t: e } = Te(),
        o = jt(),
        n = yt(),
        a = ve(),
        s = () => {
          const r = n.storeHistoryMessageList.filter((l) => l.checked),
            i = r.map(async (l) =>
              H.deleteMessage({
                conversationID: a.currentConversation.conversationID,
                clientMsgID: l.clientMsgID,
              })
            );
          Promise.all(i).then(() => {
            r.map((l) => n.deleteOneMessage(l)),
              o.back(),
              Rt({ message: e("messageTip.deleteSuccess") });
          });
        },
        c = () => {
          const r = n.storeHistoryMessageList.filter((u) => u.checked),
            i = a.storeCurrentConversation.showName,
            l = {
              messageList: r,
              title: a.storeCurrentConversation.userID
                ? e("singleMerge", { name: i })
                : e("groupMerge", { name: i }),
              summaryList: r.map((u) => `${u.senderNickname}：${Ho(u)}`),
            };
          console.log(l),
            o.push({
              path: "chooseUser",
              state: {
                chooseType: Zo.MergeMessage,
                extraData: JSON.stringify(l),
              },
            });
        };
      return (r, i) => (
        X(),
        _("div", Pa, [
          M(
            "div",
            {
              onClick: c,
              class:
                "flex flex-1 flex-col items-center justify-center px-6 text-xs text-[#898989]",
            },
            [
              M(
                "img",
                { src: S(Va), width: "48", alt: "forward" },
                null,
                8,
                za
              ),
              M("text", La, ae(r.$t("forward")), 1),
            ]
          ),
          M(
            "div",
            {
              onClick: s,
              class:
                "flex flex-1 flex-col items-center justify-center px-6 text-xs text-[#898989]",
            },
            [
              M("img", { src: S(Na), width: "48", alt: "delete" }, null, 8, xa),
              M("text", Ga, ae(r.$t("messageMenu.delete")), 1),
            ]
          ),
        ])
      );
    },
  });
function Ya() {
  const t = ve(),
    e = yt(),
    o = z(!1),
    n = () => {
      ns.includes(t.storeCurrentConversation.conversationType) &&
        (t.getCurrentGroupInfoFromReq(), t.getCurrentMemberInGroupFromReq());
    },
    a = () => {
      t.storeCurrentConversation.unreadCount > 0 &&
        H.markConversationMessageAsRead(
          t.storeCurrentConversation.conversationID
        ),
        t.storeCurrentConversation.groupAtType !== Jt.AtNormal &&
          t.storeCurrentConversation.groupAtType !== Jt.AtGroupNotice &&
          H.resetConversationGroupAtType(
            t.storeCurrentConversation.conversationID
          );
    };
  pt(
    () => t.storeCurrentConversation.conversationID,
    async (c) => {
      c && (n(), a(), (o.value = !1));
    },
    { immediate: !0 }
  ),
    Yo((c, r, i) => {
      if (o.value && c.name !== "ChooseUser") {
        (o.value = !1), e.resetCheckState(), i(!1);
        return;
      }
      c.name === "Conversation" &&
        (a(), t.updateCurrentConversation({}), t.updateQuoteMessage()),
        i();
    });
  const s = (c) => {
    o.value = c;
  };
  return (
    tt(() => {
      pe.on("UPDATE_MULTIPLE_CHECK_STATE", s);
    }),
    bt(() => {
      pe.off("UPDATE_MULTIPLE_CHECK_STATE", s);
    }),
    { multipleCheckVisible: o }
  );
}
const Ha = { class: "flex h-full flex-col overflow-hidden" },
  Xa = ue({ name: "chat" }),
  Cc = ue({
    ...Xa,
    setup(t) {
      const { multipleCheckVisible: e } = Ya();
      return (o, n) => (
        X(),
        _("div", Ha, [
          L(zs),
          L(ri, { multipleCheckVisible: S(e) }, null, 8, [
            "multipleCheckVisible",
          ]),
          de(L(ja, null, null, 512), [[fe, !S(e)]]),
          S(e) ? (X(), ht(qa, { key: 0 })) : De("", !0),
        ])
      );
    },
  });
export { Cc as default };
