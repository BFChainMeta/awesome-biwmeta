import {
  ab as U,
  aZ as O,
  dV as A,
  s as E,
  c as N,
  dW as C,
  d as _,
  r as b,
  j as S,
  w as V,
  ce as $,
  f as u,
  ag as L,
  a_ as j,
  i as G,
  v as K,
  x as Z,
  B as q,
  D as z,
  F,
  J as P,
  _ as J,
  E as v,
  R as W,
  T as X,
  aL as H,
  ar as Q,
  I as ee,
  aM as te,
  aD as ae,
  bl as ne,
  aR as R,
  dX as oe,
  V as le,
} from "./index-0085351d.js";
import "./index-f81b7dd3.js";
import { p as B, P as re } from "./index-507b837f.js";
import { A as se } from "./index-e0807859.js";
import { U as ie } from "./index-cc00d73d.js";
import { _ as D } from "./index.vue_vue_type_script_setup_true_lang-e2498643.js";
import { _ as ce } from "./index.vue_vue_type_script_setup_true_lang-1f3350dc.js";
import "./use-id-f9988c90.js";
import "./use-sync-prop-ref-17d54694.js";
import "./function-call-6d0a9231.js";
import "./back-099fa84a.js";
import "./index-fa95a9d8.js";
import "./arrows_left-58dc349e.js";
const ue = U({}, B, {
    modelValue: O(),
    filter: Function,
    formatter: { type: Function, default: (t, l) => l },
  }),
  me = Object.keys(B);
function fe(t, l) {
  if (t < 0) return [];
  const o = Array(t);
  let s = -1;
  for (; ++s < t; ) o[s] = l(s);
  return o;
}
const de = (t, l) => 32 - new Date(t, l - 1, 32).getDate(),
  Y = (t, l, o, s, c, m) => {
    const f = fe(l - t + 1, (h) => {
      const g = A(t + h);
      return s(o, { text: g, value: g });
    });
    return c ? c(o, f, m) : f;
  },
  ve = (t, l) =>
    t.map((o, s) => {
      const c = l[s];
      if (c.length) {
        const m = +c[0].value,
          f = +c[c.length - 1].value;
        return A(E(+o, m, f));
      }
      return o;
    }),
  T = new Date().getFullYear(),
  [he] = N("date-picker"),
  ge = U({}, ue, {
    columnsType: { type: Array, default: () => ["year", "month", "day"] },
    minDate: {
      type: Date,
      default: () => new Date(T - 10, 0, 1),
      validator: C,
    },
    maxDate: {
      type: Date,
      default: () => new Date(T + 10, 11, 31),
      validator: C,
    },
  });
var De = _({
  name: he,
  props: ge,
  emits: ["confirm", "cancel", "change", "update:modelValue"],
  setup(t, { emit: l, slots: o }) {
    const s = b(t.modelValue),
      c = b(!1),
      m = () => {
        const e = t.minDate.getFullYear(),
          r = t.maxDate.getFullYear();
        return Y(e, r, "year", t.formatter, t.filter);
      },
      f = (e) => e === t.minDate.getFullYear(),
      h = (e) => e === t.maxDate.getFullYear(),
      g = (e) => e === t.minDate.getMonth() + 1,
      p = (e) => e === t.maxDate.getMonth() + 1,
      y = (e) => {
        const { minDate: r, columnsType: d } = t,
          i = d.indexOf(e),
          x = c.value ? t.modelValue[i] : s.value[i];
        if (x) return +x;
        switch (e) {
          case "year":
            return r.getFullYear();
          case "month":
            return r.getMonth() + 1;
          case "day":
            return r.getDate();
        }
      },
      w = () => {
        const e = y("year"),
          r = f(e) ? t.minDate.getMonth() + 1 : 1,
          d = h(e) ? t.maxDate.getMonth() + 1 : 12;
        return Y(r, d, "month", t.formatter, t.filter);
      },
      I = () => {
        const e = y("year"),
          r = y("month"),
          d = f(e) && g(r) ? t.minDate.getDate() : 1,
          i = h(e) && p(r) ? t.maxDate.getDate() : de(e, r);
        return Y(d, i, "day", t.formatter, t.filter);
      },
      k = S(() =>
        t.columnsType.map((e) => {
          switch (e) {
            case "year":
              return m();
            case "month":
              return w();
            case "day":
              return I();
            default:
              return [];
          }
        })
      );
    V(s, (e) => {
      $(e, t.modelValue) || l("update:modelValue", e);
    }),
      V(
        () => t.modelValue,
        (e, r) => {
          (c.value = $(r, s.value)),
            (e = ve(e, k.value)),
            $(e, s.value) || (s.value = e),
            (c.value = !1);
        },
        { immediate: !0 }
      );
    const M = (...e) => l("change", ...e),
      n = (...e) => l("cancel", ...e),
      a = (...e) => l("confirm", ...e);
    return () =>
      u(
        re,
        L(
          {
            modelValue: s.value,
            "onUpdate:modelValue": (e) => (s.value = e),
            columns: k.value,
            onChange: M,
            onCancel: n,
            onConfirm: a,
          },
          j(t, me)
        ),
        o
      );
  },
});
const pe = G(De),
  ye = { class: "page_container" },
  we = { class: "mx-3 mt-2 overflow-hidden rounded-md" },
  be = { class: "mx-3 mt-2 overflow-hidden rounded-md" },
  Ue = _({
    __name: "index",
    setup(t) {
      const { t: l } = K(),
        o = Z(),
        s = b(),
        c = b(!1),
        m = b(!1),
        f = [
          { name: l("private") },
          { name: l("male") },
          { name: l("female") },
        ],
        h = S(() =>
          o.storeSelfInfo.gender === 1
            ? l("male")
            : o.storeSelfInfo.gender === 2
            ? l("female")
            : l("private")
        ),
        g = S(() =>
          o.storeSelfInfo.birth
            ? R(o.storeSelfInfo.birth).format("YYYY-MM-DD")
            : "-"
        ),
        p = S(() => R(o.storeSelfInfo.birth).format("YYYY-MM-DD").split("-")),
        y = () => {
          var n;
          (n = s.value) == null || n.chooseFile();
        },
        w = (n) => {
          oe({ ...n, userID: o.storeSelfInfo.userID })
            .then(() => o.getSelfInfoFromReq())
            .catch((a) => le({ error: a }));
        },
        I = (n) => {
          var e, r;
          const a = Array.isArray(n) ? n[0] : n;
          Q({ message: l("uploading"), forbidClick: !0, duration: 0 }),
            ee
              .uploadFile({
                name:
                  new Date().getTime() +
                  te(((e = a.file) == null ? void 0 : e.name) ?? ""),
                contentType: (r = a.file) == null ? void 0 : r.type,
                uuid: ae(),
                file: a.file,
              })
              .then((d) => {
                w({ faceURL: d.data.url });
              })
              .finally(ne);
        },
        k = (n, a) => {
          w({ gender: a });
        },
        M = ({ selectedValues: n }) => {
          const a = new Date(n[0], n[1], n[2]).getTime();
          w({ birth: a / 1e3 }), (m.value = !1);
        };
      return (n, a) => {
        const e = ie,
          r = se,
          d = pe;
        return (
          q(),
          z("div", ye, [
            u(ce, { title: n.$t("profileMenu.personalInformation") }, null, 8, [
              "title",
            ]),
            F("div", we, [
              u(
                D,
                { arrow: "", lable: n.$t("avatar"), onClick: y },
                {
                  default: P(() => [
                    u(
                      J,
                      {
                        size: 32,
                        src: v(o).storeSelfInfo.faceURL,
                        desc: v(o).storeSelfInfo.nickname,
                      },
                      null,
                      8,
                      ["src", "desc"]
                    ),
                  ]),
                  _: 1,
                },
                8,
                ["lable"]
              ),
              u(
                D,
                {
                  arrow: "",
                  lable: n.$t("name"),
                  content: v(o).storeSelfInfo.nickname,
                  onClick:
                    a[0] ||
                    (a[0] = (i) => n.$router.push("changeNameOrRemark")),
                },
                null,
                8,
                ["lable", "content"]
              ),
              u(
                D,
                {
                  arrow: "",
                  lable: n.$t("gender"),
                  content: v(h),
                  onClick: a[1] || (a[1] = (i) => (c.value = !0)),
                },
                null,
                8,
                ["lable", "content"]
              ),
              u(
                D,
                {
                  arrow: "",
                  lable: n.$t("birthday"),
                  content: v(g),
                  onClick: a[2] || (a[2] = (i) => (m.value = !0)),
                },
                null,
                8,
                ["lable", "content"]
              ),
            ]),
            // F("div", be, [
            //   u(
            //     D,
            //     {
            //       lable: n.$t("cellphone"),
            //       content: v(o).storeSelfInfo.phoneNumber,
            //     },
            //     null,
            //     8,
            //     ["lable", "content"]
            //   ),
            //   u(
            //     D,
            //     {
            //       arrow: "",
            //       lable: n.$t("email"),
            //       content: v(o).storeSelfInfo.email,
            //       onClick:
            //         a[3] || (a[3] = (i) => n.$router.push("changeEmail")),
            //     },
            //     null,
            //     8,
            //     ["lable", "content"]
            //   ),
            // ]),
            W(
              u(
                e,
                {
                  ref_key: "uploaderRef",
                  ref: s,
                  accept: "image/*",
                  capture: "camcorder",
                  "preview-image": !1,
                  multiple: !1,
                  "after-read": I,
                },
                null,
                512
              ),
              [[X, !1]]
            ),
            u(
              r,
              {
                show: c.value,
                "onUpdate:show": a[4] || (a[4] = (i) => (c.value = i)),
                actions: f,
                "cancel-text": n.$t("buttons.cancel"),
                "close-on-click-action": "",
                onCancel: a[5] || (a[5] = (i) => (c.value = !1)),
                onSelect: k,
              },
              null,
              8,
              ["show", "cancel-text"]
            ),
            u(
              r,
              {
                show: m.value,
                "onUpdate:show": a[8] || (a[8] = (i) => (m.value = i)),
                "cancel-text": n.$t("buttons.cancel"),
                onCancel: a[9] || (a[9] = (i) => (m.value = !1)),
              },
              {
                default: P(() => [
                  u(
                    d,
                    {
                      modelValue: v(p),
                      "onUpdate:modelValue":
                        a[6] || (a[6] = (i) => (H(p) ? (p.value = i) : null)),
                      title: n.$t("selectDate"),
                      "min-date": new Date(1970, 0, 1),
                      "max-date": new Date(),
                      onConfirm: M,
                      onCancel: a[7] || (a[7] = (i) => (m.value = !1)),
                    },
                    null,
                    8,
                    ["modelValue", "title", "min-date", "max-date"]
                  ),
                ]),
                _: 1,
              },
              8,
              ["show", "cancel-text"]
            ),
          ])
        );
      };
    },
  });
export { Ue as default };
