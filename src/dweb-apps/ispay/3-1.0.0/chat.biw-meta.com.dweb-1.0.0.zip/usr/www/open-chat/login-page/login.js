// import {
//   dwebServiceWorker,
//   windowPlugin,
//   toastPlugin,
//   clipboardPlugin,
// } from "../plaoc-module/plaoc/src/client/components/index.js";
import {
  dwebServiceWorker,
  windowPlugin,
  toastPlugin,
  clipboardPlugin,
} from "../plaoc-modulev3/node_modules/@plaoc/plugins/esm/components/index.js";
import { PromiseOut } from "../util/extends-promise-out/index.js";
import { postData } from "../fetch.js";

const getExternalAppData = async (mmid, pathname, search) => {
  // const url = new URL(pathname, document.baseURI);
  const url = new URL(pathname, `file://${mmid}`);

  if (search) {
    if (pathname === "/wallet/authorize/signature") {
      url.searchParams.set("signaturedata", JSON.stringify(search));
    } else {
      for (const key in search) {
        url.searchParams.set(key, search[key]);
      }
    }
  }

  const promiseOut = new PromiseOut();
  dwebServiceWorker
    .fetch(url)
    .then(async (response) => {
      if (response.ok) {
        const dataJson = await response.json();
        promiseOut.resolve(dataJson.data);
        return response;
      } else {
        const error = await response.text();
        promiseOut.reject(error);
        return;
      }
    })
    .catch((error) => {
      promiseOut.reject(error);
    });
  return {
    getData: () => promiseOut.promise,
    abort: () => {
      return promiseOut.reject(new Error("request abort"));
    },
  };
};
const getExternalAppDataV2 = async (mmid, pathname, search) => {
  const controller = new AbortController();
  const url = new URL(pathname, document.baseURI);
  if (search) {
    if (pathname === "/wallet/authorize/signature") {
      url.searchParams.set("signaturedata", JSON.stringify(search));
    } else {
      for (const key in search) {
        url.searchParams.set(key, search[key]);
      }
    }
  }

  const promiseOut = new PromiseOut();
  dwebServiceWorker
    .externalFetch(mmid, url, {
      signal: controller.signal,
    })
    .then(async (response) => {
      const dataJson = await response.json();
      promiseOut.resolve(dataJson.data);
      return response;
    })
    .catch((error) => {
      promiseOut.reject(error);
    });
  return {
    getData: () => promiseOut.promise,
    abort: () => {
      promiseOut.reject(new Error("request abort"));
      return controller.abort();
    },
  };
};

const awaitWallet = (time) =>
  new Promise((resolve) => {
    setTimeout(resolve, time);
  });

const connectWalletToIM = async () => {
  const connectRes = await getExternalAppData(
    "biw-meta.com.dweb",
    "/wallet/authorize/address",
    { type: "main" }
  );
  const walletInfo = await connectRes.getData();
  console.log(walletInfo);
  await windowPlugin.focusWindow();
  const userInfo = walletInfo.find((item) => item.name === "BIW");
  const loginerAddress = userInfo.address;
  const codeData = await postData("/account/challenge", {
    publicKey: userInfo.publicKey,
  });
  console.log(codeData.challenge);
  const openSheetBtn = $("#open-sheet");
  openSheetBtn.text("正在请求签名...");
  await awaitWallet(500);
  const signRes = await getExternalAppData(
    "biw-meta.com.dweb",
    "/wallet/authorize/signature",
    [
      {
        type: 0,
        chainName: "BIWMeta",
        senderAddress: userInfo.address,
        message: codeData.challenge,
      },
    ]
  );
  const signInfo = await signRes.getData();
  await windowPlugin.focusWindow();
  console.log(signInfo);
  openSheetBtn.text("签名成功,正在登录中...");
  const tokenInfo = await postData("/account/auth", {
    sign: signInfo[0],
    publicKey: userInfo.publicKey,
    address: userInfo.address,
  });
  console.log(tokenInfo);

  // const loginerAddress = "123addressqqqqqq";
  // const tokenInfo = {
  //   chatToken:
  //     "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVc2VySUQiOiI1NDYwMDkwOTM4IiwiVXNlclR5cGUiOjEsIlBsYXRmb3JtSUQiOjAsImV4cCI6OTE3MTIyNjg2NiwibmJmIjoxNzA2MjY2NTY2LCJpYXQiOjE3MDYyNjY4NjZ9.SYUyEAjkQ8yxbDx4a19n7E8Kslh59CZGg2qm06SwXaw",

  //   imToken:
  //     "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVc2VySUQiOiI1NDYwMDkwOTM4IiwiUGxhdGZvcm1JRCI6NSwiZXhwIjoxNzE0MDQyODY2LCJuYmYiOjE3MDYyNjY1NjYsImlhdCI6MTcwNjI2Njg2Nn0.fq9j641XmAHolWfM7JvE-s3sPsO47aPthrWspZVa-p8",

  //   userID: "5460090938",
  // };

  // const tokenInfo = {
  //   chatToken:
  //     "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVc2VySUQiOiI4NDg0NzYzMzI3IiwiVXNlclR5cGUiOjEsIlBsYXRmb3JtSUQiOjAsImV4cCI6OTE3MTI4NTA1MSwibmJmIjoxNzA2MzI0NzUxLCJpYXQiOjE3MDYzMjUwNTF9.k0ZPAgXOM2zKz190Mmx19EXf0HrgmMjzQB1ezMfC3V8",
  //   imToken:
  //     "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJVc2VySUQiOiI4NDg0NzYzMzI3IiwiUGxhdGZvcm1JRCI6NSwiZXhwIjoxNzE0MTAxMDUxLCJuYmYiOjE3MDYzMjQ3NTEsImlhdCI6MTcwNjMyNTA1MX0.F4LOwY8or-0jEoCZTQjSuZ7nKh01N8gX4eow9PDSK3o",
  //   userID: "8484763327",
  // };

  const loginerAddressInfo = {
    loginerAddress,
    displayLoginerAddress:
      loginerAddress.slice(0, 5) + "..." + loginerAddress.slice(-5),
  };
  return { tokenInfo, loginerAddressInfo };
};
const checkCanConnecetWallet = async () => {
  const result = await dwebServiceWorker.canOpenUrl("biw-meta.com.dweb");
  return result.success;
  // return true;
};

const tryToLoginIM = async () => {
  document.getElementById("login-page").style.display = "none";
  document.getElementById("app").style.display = "block";
  const script = document.createElement("script");
  script.type = "module";
  script.src = "/assets/index-0085351d.js";
  document.body.appendChild(script);
};
$(function () {
  const tokeninfo = localStorage.getItem("IM_TOKEN");
  const loginerAddress = localStorage.getItem("IM_ADDRESS");
  if (tokeninfo && loginerAddress) {
    const displayLoginerAddress =
      loginerAddress.slice(0, 5) + "..." + loginerAddress.slice(-5);
    Object.assign(self, {
      loginerAddress,
      displayLoginerAddress,
      dwebServiceWorker,
      clipboardPlugin,
    });
    tryToLoginIM();
  } else {
    const openSheetBtn = $("#open-sheet");
    document.getElementById("connect-btn").onclick = async () => {
      const canConnecetWallet = await checkCanConnecetWallet();
      if (canConnecetWallet) {
        //关闭钱包选择弹窗
        const sheet = $("#sheet");
        sheet.attr("aria-hidden", true);
        //将登录按钮置为不可点击，文字设置为正在登录中
        openSheetBtn.attr("disabled", true);
        openSheetBtn.text("正在请求授权...");
        openSheetBtn.addClass("disable");
        try {
          const { tokenInfo, loginerAddressInfo } = await connectWalletToIM();
          localStorage.setItem("IMAccount", loginerAddressInfo.loginerAddress);
          localStorage.setItem("IM_ADDRESS", loginerAddressInfo.loginerAddress);
          localStorage.setItem("IM_TOKEN", tokenInfo.imToken);
          localStorage.setItem("IM_CHAT_TOKEN", tokenInfo.chatToken);
          localStorage.setItem("IM_USERID", tokenInfo.userID);
          Object.assign(self, {
            loginerAddress: loginerAddressInfo.loginerAddress,
            displayLoginerAddress: loginerAddressInfo.displayLoginerAddress,
            dwebServiceWorker,
            clipboardPlugin,
          });
          await tryToLoginIM();
        } catch (error) {
          console.error(error);
        } finally {
          openSheetBtn.attr("disabled", false);
          openSheetBtn.text("使用钱包登录");
          openSheetBtn.removeClass("disable");
        }
      } else {
        toastPlugin.show({ text: "请先安装COT钱包,如已安装请重启应用" });
      }
    };
    openSheetBtn.attr("disabled", false);
    openSheetBtn.text("使用钱包登录");
    openSheetBtn.removeClass("disable");
  }
});
