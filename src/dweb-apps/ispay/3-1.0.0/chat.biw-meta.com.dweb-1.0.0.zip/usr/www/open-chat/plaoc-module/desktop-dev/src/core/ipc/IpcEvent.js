var _IpcEvent_binary, _IpcEvent_text, _IpcEvent_jsonAble;
import { __classPrivateFieldGet } from "../../../../../tslib/modules/index.js";
import { CacheGetter } from "../../helper/cacheGetter.js";
import { simpleDecoder } from "../../helper/encoding.js";
import { $dataToBinary, $dataToText, IPC_DATA_ENCODING, IPC_MESSAGE_TYPE, IpcMessage } from "./const.js";
export class IpcEvent extends IpcMessage {
    constructor(name, data, encoding) {
        super(IPC_MESSAGE_TYPE.EVENT);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: name
        });
        Object.defineProperty(this, "data", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: data
        });
        Object.defineProperty(this, "encoding", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: encoding
        });
        _IpcEvent_binary.set(this, new CacheGetter(() => $dataToBinary(this.data, this.encoding)));
        _IpcEvent_text.set(this, new CacheGetter(() => $dataToText(this.data, this.encoding)));
        _IpcEvent_jsonAble.set(this, new CacheGetter(() => {
            if (this.encoding === IPC_DATA_ENCODING.BINARY) {
                return IpcEvent.fromBase64(this.name, this.data);
            }
            return this;
        }));
    }
    static fromBase64(name, data) {
        return new IpcEvent(name, simpleDecoder(data, "base64"), IPC_DATA_ENCODING.BASE64);
    }
    static fromBinary(name, data) {
        return new IpcEvent(name, data, IPC_DATA_ENCODING.BINARY);
    }
    static fromUtf8(name, data) {
        return new IpcEvent(name, simpleDecoder(data, "utf8"), IPC_DATA_ENCODING.UTF8);
    }
    static fromText(name, data) {
        return new IpcEvent(name, data, IPC_DATA_ENCODING.UTF8);
    }
    get binary() {
        return __classPrivateFieldGet(this, _IpcEvent_binary, "f").value;
    }
    get text() {
        return __classPrivateFieldGet(this, _IpcEvent_text, "f").value;
    }
    get jsonAble() {
        return __classPrivateFieldGet(this, _IpcEvent_jsonAble, "f").value;
    }
    toJSON() {
        return { ...this.jsonAble };
    }
}
_IpcEvent_binary = new WeakMap(), _IpcEvent_text = new WeakMap(), _IpcEvent_jsonAble = new WeakMap();
