export var MWEBVIEW_LIFECYCLE_EVENT;
(function (MWEBVIEW_LIFECYCLE_EVENT) {
    // State = "state", // 获取窗口状态
    MWEBVIEW_LIFECYCLE_EVENT["Activity"] = "activity";
    MWEBVIEW_LIFECYCLE_EVENT["Close"] = "close";
    MWEBVIEW_LIFECYCLE_EVENT["Renderer"] = "renderer";
    // WindowAllClosed = "window-all-closed", // 关闭应用程序窗口
    // DidBecomeActive = "did-become-active", // 每次应用程序激活时都会发出，而不仅仅是在单击 Dock 图标或重新启动应用程序时发出。
    // Quit = "quit", // 尝试关闭所有窗口。该before-quit事件将首先发出。如果所有窗口都成功关闭，will-quit将发出该事件，默认情况下应用程序将终止。当前只有quit事件。
    // BeforeQuit = "before-quit",
    // willQuit = "will-quit",
    // Exit = "exit", // 所有窗口将在不询问用户的情况下立即关闭，并且不会发出before-quit 和事件。will-quit
    // Relaunch = "relaunch", // 当前实例退出时重新启动应用程序。
})(MWEBVIEW_LIFECYCLE_EVENT || (MWEBVIEW_LIFECYCLE_EVENT = {}));
