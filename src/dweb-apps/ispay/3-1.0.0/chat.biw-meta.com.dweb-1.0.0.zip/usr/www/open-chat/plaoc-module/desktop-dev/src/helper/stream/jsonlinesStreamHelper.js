import { JsonlinesStream } from "./JsonlinesStream.js";
import { streamRead, streamReadAll } from "./readableStreamHelper.js";
export const binaryToJsonlinesStream = (stream) => {
    return textToJsonlinesStream(stream
        // 先 解码成 utf8
        .pipeThrough(new TextDecoderStream()));
};
export const textToJsonlinesStream = (stream) => {
    return (stream
        // 交给 jsonlinesStream 来处理
        .pipeThrough(new JsonlinesStream()));
};
export const jsonlinesStreamReadBinary = (stream, options) => {
    return streamRead(binaryToJsonlinesStream(stream), options);
};
export const jsonlinesStreamReadText = (stream, options) => {
    return streamRead(textToJsonlinesStream(stream), options);
};
export const jsonlinesStreamReadBinaryAll = (stream, options) => {
    return streamReadAll(binaryToJsonlinesStream(stream), options);
};
export const jsonlinesStreamReadTextAll = (stream, options) => {
    return streamReadAll(textToJsonlinesStream(stream), options);
};
