import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { PromiseOut } from "../../helper/PromiseOut.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
import { SupportedFormat } from "./barcode-scanning.type.js";
export class BarcodeScannerPlugin extends BasePlugin {
    constructor() {
        super("barcode-scanning.sys.dweb");
    }
    async process(data, rotation = 0, formats = SupportedFormat.QR_CODE) {
        return (await this.processV2(data, rotation, formats)).map((item) => item.data);
    }
    async processV2(data, rotation = 0, formats = SupportedFormat.QR_CODE) {
        const req = this.buildApiRequest("/process", {
            search: {
                rotation,
                formats,
            },
            method: "POST",
            body: data,
        });
        const result = (await (await fetch(req)).json());
        return result;
    }
    /**
     *  识别二维码
     * @param blob
     * @param rotation
     * @param formats
     * @returns
     */
    async createProcesser(formats = SupportedFormat.QR_CODE) {
        const wsUrl = this.buildApiRequest("/process", {
            search: {
                formats,
            },
            method: "GET",
        }).url.replace("http", "ws");
        const ws = new WebSocket(wsUrl);
        ws.binaryType = "blob";
        await new Promise((resolve, reject) => {
            ws.onopen = resolve;
            ws.onerror = reject;
            ws.onclose = reject;
        });
        ws.onmessage = async (ev) => {
            const lock = locks.shift();
            const data = typeof ev.data === "string" ? ev.data : await ev.data.text();
            if (lock) {
                lock.resolve(JSON.parse(data));
            }
        };
        ws.onclose = () => {
            controller.stop();
        };
        const rotation_ab = new ArrayBuffer(4);
        const rotation_i32 = new Int32Array(rotation_ab);
        const locks = [];
        const controller = {
            setRotation(rotation) {
                rotation_i32[0] = rotation;
                ws.send(rotation_ab);
            },
            process(data) {
                const task = new PromiseOut();
                locks.push(task);
                ws.send(data);
                return task.promise;
            },
            stop() {
                if (ws.readyState < WebSocket.CLOSING) {
                    ws.close();
                }
                for (const lock of locks) {
                    lock.reject("stop");
                }
                locks.length = 0;
            },
        };
        return controller;
    }
    /**
     * 停止扫码
     * @returns
     */
    async stop() {
        return await this.fetchApi(`/stop`).boolean();
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BarcodeScannerPlugin.prototype, "createProcesser", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BarcodeScannerPlugin.prototype, "stop", null);
export const barcodeScannerPlugin = new BarcodeScannerPlugin();
