export class BaseEvent extends EventTarget {
    constructor(lnstenObj) {
        super();
        Object.defineProperty(this, "app_kit", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.app_kit = lnstenObj;
    }
    /**
     *  dwebview 注册一个监听事件
     * @param eventName
     * @param listenerFunc
     * @returns
     */
    addEventListener(eventName, 
    // deno-lint-ignore no-explicit-any
    listenerFunc, options) {
        // 监听一个事件
        const listeners = this.app_kit._listeners[eventName];
        if (!listeners) {
            this.app_kit._listeners[eventName] = [];
        }
        this.app_kit._listeners[eventName].push(listenerFunc);
        // 看看有没有添加过监听
        const windowListener = this.app_kit._windowListeners[eventName];
        if (windowListener && !windowListener.registered) {
            this.addWindowListener(windowListener, options);
        }
        const remove = () => this.removeEventListener(eventName, listenerFunc);
        // deno-lint-ignore no-explicit-any
        const p = Promise.resolve({ remove });
        // 注册一个移除监听的方法
        Object.defineProperty(p, "remove", {
            value: () => {
                console.warn(`Using addListener() without 'await' is deprecated.`);
                remove();
            },
        });
        return p;
    }
    /**添加一个监听器 */
    addWindowListener(handle, options) {
        super.addEventListener(handle.windowEventName, handle.handler, options);
        handle.registered = true;
    }
    /**移除监听器 */
    removeEventListener(eventName, 
    // deno-lint-ignore no-explicit-any
    listenerFunc, options) {
        const listeners = this.app_kit._listeners[eventName];
        if (!listeners) {
            return;
        }
        const index = listeners.indexOf(listenerFunc);
        this.app_kit._listeners[eventName].splice(index, 1);
        // 如果监听器为空，移除监听器
        if (!this.app_kit._listeners[eventName].length) {
            this.removeWindowListener(this.app_kit._windowListeners[eventName], options);
        }
    }
    /**移除全局监听 */
    removeWindowListener(handle, options) {
        if (!handle) {
            return;
        }
        super.removeEventListener(handle.windowEventName, handle.handler, options);
        handle.registered = false;
    }
    /**是否存在 */
    hasListeners(eventName) {
        return !!this.app_kit._listeners[eventName].length;
    }
    // deno-lint-ignore no-explicit-any
    notifyListeners(eventName, data) {
        const listeners = this.app_kit._listeners[eventName];
        if (listeners) {
            listeners.forEach((listener) => listener(data));
        }
    }
}
