import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { domInsetsToJson, insetsToDom } from "../../util/insets.js";
import { StateObserver } from "../../util/StateObserver.js";
import { BasePlugin } from "./BasePlugin.js";
class InsetsPlugin extends BasePlugin {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "baseCoder", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: {
                decode: (raw) => ({
                    ...raw,
                    insets: insetsToDom(raw.insets),
                }),
                encode: (state) => ({
                    ...state,
                    insets: domInsetsToJson(state.insets),
                }),
            }
        });
    }
    get state() {
        return new StateObserver(this, () => this.commonGetState(), this.coder);
    }
    async commonSetState(state) {
        await this.fetchApi("/setState", {
            search: state,
        }).ok();
    }
    async commonGetState() {
        return await this.fetchApi("/getState", {
            search: { rid: InsetsPlugin.rid_acc++ },
        }).object();
    }
    get getState() {
        return this.state.getState;
    }
    setOverlay(overlay) {
        return this.setStateByKey("overlay", overlay);
    }
    async getOverlay() {
        return (await this.state.getState()).overlay;
    }
}
Object.defineProperty(InsetsPlugin, "rid_acc", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: 1
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], InsetsPlugin.prototype, "state", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], InsetsPlugin.prototype, "commonSetState", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], InsetsPlugin.prototype, "commonGetState", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", void 0)
], InsetsPlugin.prototype, "setOverlay", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], InsetsPlugin.prototype, "getOverlay", null);
export { InsetsPlugin };
