import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { configPlugin } from "./config.plugin.js";
class HTMLDwebConfigElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: configPlugin
        });
    }
    get setLang() {
        return this.plugin.setLang;
    }
    get getLang() {
        return this.plugin.getLang;
    }
}
Object.defineProperty(HTMLDwebConfigElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-config"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebConfigElement.prototype, "setLang", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebConfigElement.prototype, "getLang", null);
export { HTMLDwebConfigElement };
if (!customElements.get(HTMLDwebConfigElement.tagName)) {
    customElements.define(HTMLDwebConfigElement.tagName, HTMLDwebConfigElement);
}
