// import { HTMLDwebConfigElement } from "./config.wc.ts";
// // 插入自定义标签
// document.addEventListener(
//   "DOMContentLoaded",
//   () => {
//     const el = new HTMLDwebConfigElement();
//     document.body.append(el);
//   },
//   { once: true }
// );
export * from "./config.plugin.js";
export * from "./config.wc.js";
