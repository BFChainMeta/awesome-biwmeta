import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
export class DevicePlugin extends BasePlugin {
    constructor() {
        super("device.sys.dweb");
    }
    getUUID() {
        return this.fetchApi(`/uuid`).object();
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], DevicePlugin.prototype, "getUUID", null);
export const devicePlugin = new DevicePlugin();
