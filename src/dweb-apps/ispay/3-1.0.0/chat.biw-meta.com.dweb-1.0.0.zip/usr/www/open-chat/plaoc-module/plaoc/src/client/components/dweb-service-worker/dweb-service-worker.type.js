export class IpcRequest {
    constructor(req_id, url, method, headers, body, metaBody) {
        Object.defineProperty(this, "req_id", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: req_id
        });
        Object.defineProperty(this, "url", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: url
        });
        Object.defineProperty(this, "method", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: method
        });
        Object.defineProperty(this, "headers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: headers
        });
        Object.defineProperty(this, "body", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: body
        });
        Object.defineProperty(this, "metaBody", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: metaBody
        });
    }
}
export class IpcBody {
    constructor(_bodyHub) {
        Object.defineProperty(this, "_bodyHub", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: _bodyHub
        });
    }
}
export class BodyHub {
    constructor(data) {
        Object.defineProperty(this, "data", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: data
        });
    }
}
export var IPC_METHOD;
(function (IPC_METHOD) {
    IPC_METHOD["GET"] = "GET";
    IPC_METHOD["POST"] = "POST";
    IPC_METHOD["PUT"] = "PUT";
    IPC_METHOD["DELETE"] = "DELETE";
    IPC_METHOD["OPTIONS"] = "OPTIONS";
    IPC_METHOD["TRACE"] = "TRACE";
    IPC_METHOD["PATCH"] = "PATCH";
    IPC_METHOD["PURGE"] = "PURGE";
    IPC_METHOD["HEAD"] = "HEAD";
})(IPC_METHOD || (IPC_METHOD = {}));
