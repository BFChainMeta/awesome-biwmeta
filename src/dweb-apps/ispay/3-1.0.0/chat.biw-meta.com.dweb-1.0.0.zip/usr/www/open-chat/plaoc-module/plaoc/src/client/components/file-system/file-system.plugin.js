import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
export class FileSystemPlugin extends BasePlugin {
    constructor() {
        super("file.sys.dweb");
    }
    async writeFile(options) {
        const result = await this.fetchApi("/writeFile", {
            search: options,
        }).text();
        return {
            uri: result,
        };
    }
    async getUri(options) {
        const result = await this.fetchApi("/getUri", {
            search: options,
        });
        return {
            uri: await result.json(),
        };
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], FileSystemPlugin.prototype, "writeFile", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], FileSystemPlugin.prototype, "getUri", null);
export const fileSystemPlugin = new FileSystemPlugin();
