import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import * as dntShim from "../../../../../_dnt.shims.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
self.navigator;
class HapticsPlugin extends BasePlugin {
    constructor() {
        super(HapticsPlugin.isIOSDWebBrowser ? "haptics.browser.dweb" : "haptics.sys.dweb");
    }
    /** 触碰轻质量物体 */
    async impactLight(options) {
        return await this.fetchApi("/impactLight", {
            search: {
                style: options.style,
            },
        });
    }
    /** 振动通知 */
    async notification(options) {
        return await this.fetchApi("/notification", {
            search: {
                style: options.type,
            },
        });
    }
    /** 单击手势的反馈振动 */
    async vibrateClick() {
        return await this.fetchApi("/vibrateClick");
    }
    /** 禁用手势的反馈振动
     * 与 headShak 特效一致, 详见 ripple-button.animation.ts
     * headShak 是一段抖动特效, 前面抖动增强然后衰退
     * 这里只针对抖动增强阶段提供同步的振动反馈
     */
    async vibrateDisabled() {
        return await this.fetchApi("/vibrateDisabled");
    }
    /** 双击手势的反馈振动 */
    async vibrateDoubleClick() {
        return await this.fetchApi("/vibrateDoubleClick");
    }
    /** 重击手势的反馈振动, 比如菜单键/惨案/3Dtouch */
    async vibrateHeavyClick() {
        return await this.fetchApi("/vibrateHeavyClick");
    }
    /** 滴答 */
    async vibrateTick() {
        return await this.fetchApi("/vibrateTick");
    }
    /**
     * 自定义效果
     * @param VibrateOptions
     */
    async vibrate(options) {
        const duration = options?.duration || [300];
        return await this.fetchApi("/customize", {
            search: {
                duration: JSON.stringify(duration),
            },
        });
    }
    fetchApi(url, init) {
        if (HapticsPlugin.isIOSDWebBrowser) {
            // deno-lint-ignore no-explicit-any
            return dntShim.dntGlobalThis.webkit.messageHandlers.haptics.postMessage({
                path: url,
                search: init?.search,
            });
        }
        return this.buildApiRequest(url, init).fetch();
    }
}
Object.defineProperty(HapticsPlugin, "isIOSDWebBrowser", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: typeof self?.webkit?.messageHandlers?.haptics?.postMessage === "function"
});
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], HapticsPlugin.prototype, "impactLight", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], HapticsPlugin.prototype, "notification", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], HapticsPlugin.prototype, "vibrateClick", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], HapticsPlugin.prototype, "vibrateDisabled", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], HapticsPlugin.prototype, "vibrateDoubleClick", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], HapticsPlugin.prototype, "vibrateHeavyClick", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], HapticsPlugin.prototype, "vibrateTick", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], HapticsPlugin.prototype, "vibrate", null);
export { HapticsPlugin };
export const hapticsPlugin = new HapticsPlugin();
