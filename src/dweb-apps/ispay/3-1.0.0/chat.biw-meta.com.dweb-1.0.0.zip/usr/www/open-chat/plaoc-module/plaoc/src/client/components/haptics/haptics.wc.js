import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { hapticsPlugin } from "./haptics.plugin.js";
class HTMLDwebHapticsElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: hapticsPlugin
        });
    }
    get vibrate() {
        return this.plugin.vibrate;
    }
    get impactLight() {
        return this.plugin.impactLight;
    }
    get notification() {
        return this.plugin.notification;
    }
    get vibrateClick() {
        return this.plugin.vibrateClick;
    }
    get vibrateDisabled() {
        return this.plugin.vibrateDisabled;
    }
    get vibrateDoubleClick() {
        return this.plugin.vibrateDoubleClick;
    }
    get vibrateHeavyClick() {
        return this.plugin.vibrateHeavyClick;
    }
    get vibrateTick() {
        return this.plugin.vibrateTick;
    }
}
Object.defineProperty(HTMLDwebHapticsElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-haptics"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebHapticsElement.prototype, "vibrate", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebHapticsElement.prototype, "impactLight", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebHapticsElement.prototype, "notification", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebHapticsElement.prototype, "vibrateClick", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebHapticsElement.prototype, "vibrateDisabled", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebHapticsElement.prototype, "vibrateDoubleClick", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebHapticsElement.prototype, "vibrateHeavyClick", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebHapticsElement.prototype, "vibrateTick", null);
export { HTMLDwebHapticsElement };
if (!customElements.get(HTMLDwebHapticsElement.tagName)) {
    customElements.define(HTMLDwebHapticsElement.tagName, HTMLDwebHapticsElement);
}
