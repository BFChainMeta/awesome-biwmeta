import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { JsonlinesStreamResponse } from "../../helper/JsonlinesStreamHelper.js";
import { bindThis } from "../../helper/bindThis.js";
import { Signal } from "../../helper/createSignal.js";
import { BasePlugin } from "../base/BasePlugin.js";
export class MotionSensorsPlugin extends BasePlugin {
    constructor() {
        super("motion-sensors.sys.dweb");
        Object.defineProperty(this, "coder", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: {
                decode: (raw) => raw,
                encode: (state) => state,
            }
        });
        Object.defineProperty(this, "response", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new JsonlinesStreamResponse(this, this.coder)
        });
        Object.defineProperty(this, "accelerometerSignal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Signal()
        });
        Object.defineProperty(this, "onAccelerometer", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: this.accelerometerSignal.listen
        });
        Object.defineProperty(this, "gyroscopeSignal", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new Signal()
        });
        Object.defineProperty(this, "onGyroscope", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: this.gyroscopeSignal.listen
        });
    }
    /**
     * 启动加速计传感器
     * @param fps 每秒帧率
     */
    async startAccelerometer(fps) {
        for await (const data of this.response.jsonlines("/observe/accelerometer", {
            searchParams: new URLSearchParams(fps !== undefined ? "?fps=" + fps : ""),
        })) {
            console.log(data);
            this.accelerometerSignal.emit(data);
        }
    }
    /**
     * 启动陀螺仪传感器
     * @param fps 每秒帧率
     */
    async startGyroscope(fps) {
        for await (const data of this.response.jsonlines("/observe/gyroscope", {
            searchParams: new URLSearchParams(fps !== undefined ? "?fps=" + fps : ""),
        })) {
            this.gyroscopeSignal.emit(data);
        }
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], MotionSensorsPlugin.prototype, "startAccelerometer", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], MotionSensorsPlugin.prototype, "startGyroscope", null);
export const motionSensorsPlugin = new MotionSensorsPlugin();
