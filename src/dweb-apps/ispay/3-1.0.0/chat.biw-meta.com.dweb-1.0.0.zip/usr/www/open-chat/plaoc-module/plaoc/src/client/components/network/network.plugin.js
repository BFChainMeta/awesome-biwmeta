import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import * as dntShim from "../../../../../_dnt.shims.js";
import { bindThis } from "../../helper/bindThis.js";
import { BaseEvent } from "../base/BaseEvent.js";
const _network_status = {
    _listeners: {},
    _windowListeners: {},
};
export class NetworkPlugin extends BaseEvent {
    constructor() {
        super(_network_status);
        Object.defineProperty(this, "handleOnline", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: () => {
                const connectionType = translatedConnection();
                const status = {
                    connected: true,
                    connectionType: connectionType,
                };
                this.notifyListeners("onLine", new Event("onLine"));
                this.notifyListeners("change", status);
            }
        });
        Object.defineProperty(this, "handleOffline", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: () => {
                const status = {
                    connected: false,
                    connectionType: "none",
                };
                this.notifyListeners("offLine", new Event("offLine"));
                this.notifyListeners("change", status);
            }
        });
        if (typeof dntShim.dntGlobalThis !== "undefined") {
            globalThis.addEventListener("online", this.handleOnline);
            globalThis.addEventListener("offline", this.handleOffline);
        }
    }
    /**
     * 查看网络是否在线
     */
    onLine() {
        return navigator.onLine;
    }
    /**
     * 获取网络状态
     * （android only）
     * @returns ConnectionStatus
     */
    // deno-lint-ignore require-await
    async getStatus() {
        if (!globalThis.navigator) {
            throw Error("Browser does not support the Network Information API");
        }
        const connected = globalThis.navigator.onLine;
        const connectionType = translatedConnection();
        const status = {
            connected,
            connectionType: connected ? connectionType : "none",
        };
        return status;
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Boolean)
], NetworkPlugin.prototype, "onLine", null);
__decorate([
    bindThis
    // deno-lint-ignore require-await
    ,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], NetworkPlugin.prototype, "getStatus", null);
export const networkPlugin = new NetworkPlugin();
/**
 * 查看当前的网络连接
 * @returns
 */
function translatedConnection() {
    const connection = globalThis.navigator.connection || globalThis.navigator.mozConnection || globalThis.navigator.webkitConnection;
    let result = "unknown";
    const type = connection ? connection.type || connection.effectiveType : null;
    if (type && typeof type === "string") {
        switch (type) {
            // possible type values
            case "bluetooth":
            case "cellular":
                result = "cellular";
                break;
            case "none":
                result = "none";
                break;
            case "ethernet":
            case "wifi":
            case "wimax":
                result = "wifi";
                break;
            case "other":
            case "unknown":
                result = "unknown";
                break;
            // possible effectiveType values
            case "slow-2g":
            case "2g":
                result = "2g";
                break;
            case "3g":
                result = "3g";
                break;
            case "4g":
                result = "4g";
                break;
            case "5g":
                result = "5g";
                break;
            case "6g":
                result = "6g";
                break;
            default:
                break;
        }
    }
    return result;
}
