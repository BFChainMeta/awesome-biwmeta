import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { cacheGetter } from "../../helper/cacheGetter.js";
import { networkPlugin } from "./network.plugin.js";
class HTMLDwebNetworkElement extends HTMLElement {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "plugin", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: networkPlugin
        });
    }
    get getStatus() {
        return this.plugin.getStatus;
    }
    get onLine() {
        return this.plugin.onLine;
    }
}
Object.defineProperty(HTMLDwebNetworkElement, "tagName", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: "dweb-network"
});
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNetworkElement.prototype, "getStatus", null);
__decorate([
    cacheGetter(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], HTMLDwebNetworkElement.prototype, "onLine", null);
export { HTMLDwebNetworkElement };
if (!customElements.get(HTMLDwebNetworkElement.tagName)) {
    customElements.define(HTMLDwebNetworkElement.tagName, HTMLDwebNetworkElement);
}
