import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { BasePlugin } from "../base/BasePlugin.js";
/**
 * TODO 挪到 nativeui 中控制
 */
export class TorchPlugin extends BasePlugin {
    constructor() {
        super("torch.nativeui.browser.dweb");
    }
    /**
     * 打开/关闭手电筒
     */
    async toggleTorch() {
        return await this.fetchApi("/toggleTorch").boolean();
    }
    /**
     * 手电筒状态
     */
    async getTorchState() {
        return await this.fetchApi("/torchState").boolean();
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TorchPlugin.prototype, "toggleTorch", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TorchPlugin.prototype, "getTorchState", null);
export const torchPlugin = new TorchPlugin();
