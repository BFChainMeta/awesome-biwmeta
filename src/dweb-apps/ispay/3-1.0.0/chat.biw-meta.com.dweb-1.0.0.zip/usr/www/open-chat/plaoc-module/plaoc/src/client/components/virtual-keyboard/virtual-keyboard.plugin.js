var _a;
import { __decorate, __metadata } from "../../../../../../tslib/modules/index.js";
import { bindThis } from "../../helper/bindThis.js";
import { DOMInsets } from "../../util/insets.js";
import { BasePlugin } from "../base/BasePlugin.js";
import { windowPlugin } from "../window/window.plugin.js";
export class VirtualKeyboardPlugin extends BasePlugin {
    constructor() {
        super("window.sys.dweb");
    }
    async setState(state) {
        await windowPlugin.setStyle({
            keyboardOverlaysContent: state.overlay,
        });
    }
    setStateByKey(key, value) {
        return this.setState({ [key]: value });
    }
    async getState() {
        const winState = await windowPlugin.getState();
        return {
            overlay: winState.keyboardOverlaysContent,
            insets: new DOMInsets(0, 0, 0, 0),
        };
    }
    setOverlay(overlay) {
        return this.setStateByKey("overlay", overlay);
    }
    async getOverlay() {
        return (await this.getState()).overlay;
    }
}
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], VirtualKeyboardPlugin.prototype, "setState", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [typeof (_a = typeof K !== "undefined" && K) === "function" ? _a : Object, Object]),
    __metadata("design:returntype", void 0)
], VirtualKeyboardPlugin.prototype, "setStateByKey", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], VirtualKeyboardPlugin.prototype, "getState", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", void 0)
], VirtualKeyboardPlugin.prototype, "setOverlay", null);
__decorate([
    bindThis,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], VirtualKeyboardPlugin.prototype, "getOverlay", null);
export const virtualKeyboardPlugin = new VirtualKeyboardPlugin();
