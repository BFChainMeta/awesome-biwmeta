class FreeAborter {
    wrapAsync(task) {
        return task;
    }
    wrapAsyncRunner(task) {
        return task;
    }
    wrapAsyncIterator(aIterator) {
        return aIterator;
    }
    async wrapAsyncIteratorReturn(aIterator) {
        do {
            const item = await aIterator.next();
            if (item.done) {
                return item.value;
            }
        } while (true);
    }
}
/** 零成本的 aborter wrapper
 * 一般用于需要aborter环境的默认参数
 * ```ts
 * function foo(aborter = freeAborter) {
 *      await aborter.wrapAsync(bar())
 * }
 * ```
 */
export const freeAborter = new FreeAborter();
