///<reference lib="dom" />
export * from "./bindThis.js";
export * from "./cacheGetter.js";
export * from "./expirableCacheGetter.js";
export * from "./PropArrayHelper.js";
export * from "./throttleWrap.js";
export * from "./quene.js";
export function ClassStaticImplement() {
    return (constructor) => constructor;
}
