import { BBuffer as Buffer } from "../buffer/index.js";
export const isBuffer = Buffer.isBuffer;
export const copy = Buffer.from;
