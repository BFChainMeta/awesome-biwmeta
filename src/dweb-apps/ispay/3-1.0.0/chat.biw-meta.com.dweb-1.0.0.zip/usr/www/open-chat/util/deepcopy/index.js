import { detectType } from "./detector.js";
import { get, isCollection, set } from "./collection.js";
import { copy } from "./copier.js";
/**
 * deepcopy function
 *
 * @param {*} value
 * @param {Object|Function} [options]
 * @return {*}
 */
export function deepCopy(value, options = {}) {
    if (typeof options === "function") {
        options = {
            customizer: options,
        };
    }
    const { 
    // TODO: before/after customizer
    customizer,
    // TODO: max depth
    // depth = Infinity,
     } = options;
    const valueType = detectType(value);
    if (!isCollection(valueType)) {
        return copy(value, valueType);
    }
    const copiedValue = copy(value, valueType, customizer);
    const references = new WeakMap([[value, copiedValue]]);
    const visited = new WeakSet([value]);
    return recursiveCopy(value, copiedValue, references, visited, customizer);
}
/**
 * recursively copy
 *
 * @param {*} value target value
 * @param {*} clone clone of value
 * @param {WeakMap} references visited references of clone
 * @param {WeakSet} visited visited references of value
 * @param {Function} customizer user customize function
 * @return {*}
 */
function recursiveCopy(value, clone, references, visited, customizer) {
    const type = detectType(value);
    const copiedValue = copy(value, type);
    // return if not a collection value
    if (!isCollection(type)) {
        return copiedValue;
    }
    let keys;
    switch (type) {
        case "Arguments":
        case "Array":
            keys = Object.keys(value);
            break;
        case "Object":
            keys = Object.keys(value).concat(Object.getOwnPropertySymbols(value));
            break;
        case "Map":
        case "Set":
            keys = value.keys();
            break;
        default:
    }
    // walk within collection with iterator
    if (keys) {
        for (const collectionKey of keys) {
            const collectionValue = get(value, collectionKey, type);
            if (visited.has(collectionValue)) {
                // for [Circular]
                set(clone, collectionKey, references.get(collectionValue), type);
            }
            else {
                const collectionValueType = detectType(collectionValue);
                const copiedCollectionValue = copy(collectionValue, collectionValueType, customizer);
                // save reference if value is collection
                if (isCollection(collectionValueType)) {
                    references.set(collectionValue, copiedCollectionValue);
                    visited.add(collectionValue);
                }
                if (copiedCollectionValue)
                    set(clone, collectionKey, Object.isFrozen(copiedCollectionValue)
                        ? copiedCollectionValue
                        : recursiveCopy(collectionValue, copiedCollectionValue, references, visited, customizer), type);
            }
        }
    }
    // TODO: isSealed/isFrozen/isExtensible
    return clone;
}
