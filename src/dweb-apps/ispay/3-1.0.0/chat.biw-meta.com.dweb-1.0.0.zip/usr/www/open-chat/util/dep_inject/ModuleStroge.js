var _a, _b, _c;
import { __decorate, __metadata } from "../../tslib/modules/index.js";
import { Injectable } from "./Injectable.js";
import { getInjectionGroups } from "./common.js";
import { EasyMap } from "../extends-map/index.js";
export const MODULE_MAP = Symbol("module-map");
/**有几层面具 */
const _MASK_LEVEL_SYMBOL_ = Symbol("mask-level");
/**面具下的实际对象 */
const _MASK_SELF_SYMBOL_ = Symbol("mask-self");
let ModuleStroge = class ModuleStroge {
    constructor(entries, parent) {
        Object.defineProperty(this, "parent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: parent
        });
        Object.defineProperty(this, _a, {
            enumerable: true,
            configurable: true,
            writable: true,
            value: "ModuleStroge"
        });
        Object.defineProperty(this, "_stroge", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        /**面具的层数 */
        Object.defineProperty(this, _b, {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
        });
        /**指向真实的自己 */
        Object.defineProperty(this, _c, {
            enumerable: true,
            configurable: true,
            writable: true,
            value: this
        });
        /**
         * 组收集器
         */
        Object.defineProperty(this, "_groupCollection", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this._stroge = new Map(entries);
        this.set(MODULE_MAP, this);
    }
    clear() {
        return this._stroge.clear();
    }
    delete(key) {
        return this._stroge.delete(key);
    }
    forEach(callbackfn, thisArg) {
        return this._stroge.forEach(callbackfn, thisArg);
    }
    set(key, value) {
        this._stroge.set(key, value);
        return this;
    }
    get size() {
        return this._stroge.size;
    }
    /**
     * @TODO 应该也提供对parent、mask的迭代、size计算等功能
     */
    [Symbol.iterator]() {
        return this._stroge[Symbol.iterator]();
    }
    entries() {
        return this._stroge.entries();
    }
    keys() {
        return this._stroge.keys();
    }
    values() {
        return this._stroge.values();
    }
    get(key) {
        /**
         * 原型链方式的查询自己与父级
         */
        return !this.parent || this._stroge.has(key)
            ? this._stroge.get(key)
            : this.parent.get(key);
    }
    has(key) {
        /**
         * 原型链方式的查询自己与父级
         */
        if (this._stroge.has(key)) {
            return true;
        }
        if (this.parent) {
            return this.parent.has(key);
        }
        return false;
    }
    /**
     * 带上面具
     * 创建原型链
     * 使用Proxy，避过原型链的拦截，确保`_groupCollection`等可空的属性能够正确作用到`this`的属性上
     * @param mask
     */
    installMask(mask) {
        const maskGet = (key) => {
            /**如果是要获取自身，那么返回proxy对象 */
            if (key === MODULE_MAP) {
                const moduleMap = mask.get(key);
                if (moduleMap === mask) {
                    return proxyMask;
                }
            }
            /**
             * 优先从面具集群中寻找
             */
            if (mask.has(key)) {
                return mask.get(key);
            }
            return this.get(key);
        };
        const maskHas = (key) => {
            /**
             * 优先从面具集群中寻找
             */
            return mask.has(key) || this.has(key);
        };
        const proxyMask = new Proxy(this, {
            get: (target, prop, receiver) => {
                if (prop === "_mask") {
                    return mask;
                }
                if (prop === _MASK_LEVEL_SYMBOL_) {
                    return this[_MASK_LEVEL_SYMBOL_] + 1;
                }
                if (prop === _MASK_SELF_SYMBOL_) {
                    return this; // 这里的this，随着面具层的叠加，会发生改变，变成指向Proxy
                }
                if (prop === "get") {
                    return maskGet;
                }
                if (prop === "has") {
                    return maskHas;
                }
                return Reflect.get(target, prop, receiver);
            },
        });
        return proxyMask;
    }
    /**
     * 卸下面具
     */
    uninstallMask(deep = 1) {
        deep = Math.min(this[_MASK_LEVEL_SYMBOL_], deep);
        let res = this;
        for (let i = 0; i < deep; i += 1) {
            res = this[_MASK_SELF_SYMBOL_];
        }
        return res;
    }
    /**
     * 添加一个组实例
     * @param groupName
     * @param instance
     */
    groupInsert(groupName, instance) {
        const pluginCollection = this._groupCollection ||
            (this._groupCollection = new EasyMap((name) => new Set()));
        const plugins = pluginCollection.forceGet(groupName);
        plugins.add(instance);
    }
    /**
     * 获取模块注入的组
     * @param CtorRoot
     */
    groupGet(...CtorRootList) {
        let result;
        for (const CtorRoot of CtorRootList) {
            let groups;
            switch (typeof CtorRoot) {
                case "function":
                    groups = [...getInjectionGroups(CtorRoot)];
                    break;
                case "object":
                    groups = CtorRoot;
                    break;
                default:
                    groups = [CtorRoot];
            }
            if (!(groups instanceof Array)) {
                throw new TypeError();
            }
            /// 从自身上找
            const _result = this.groupsGet_(groups);
            if (_result) {
                if (result) {
                    for (const ins of _result) {
                        result.add(ins);
                    }
                }
                else {
                    result = _result;
                }
            }
            if (this.parent) {
                /// 从原型链上找
                const parentResult = this.parent.groupsGet_(groups);
                if (parentResult) {
                    if (result) {
                        for (const ins of parentResult) {
                            result.add(ins);
                        }
                    }
                    else {
                        result = parentResult;
                    }
                }
            }
        }
        return result || new Set();
    }
    /**
     * 递归获取出组模块集合
     * @param groups
     */
    groupsGet_(groups) {
        groups = groups.slice();
        let result;
        /**
         * 过滤器，因为要区交集，所以一开始默认收集全部
         * @param ins
         */
        let filter = (ins) => true;
        do {
            const groupName = groups.shift();
            if (groupName === undefined) {
                break;
            }
            result = new Set();
            for (const ins of this.groupGet_(groupName)) {
                if (filter(ins)) {
                    result.add(ins);
                }
            }
            /// 重写过滤器
            if (result.size) {
                const inSet = result;
                filter = (ins) => inSet.has(ins);
            }
            else {
                break;
            }
        } while (true);
        return result;
    }
    /**
     * 递归获取出组模块集合
     * @param groupName
     */
    groupGet_(groupName) {
        const result = [];
        if (this._groupCollection) {
            const plugins = this._groupCollection.get(groupName);
            if (plugins) {
                result.push(...plugins);
            }
        }
        if (this.parent) {
            result.push(...this.parent.groupGet_(groupName));
        }
        return result;
    }
};
_a = Symbol.toStringTag, _b = _MASK_LEVEL_SYMBOL_, _c = _MASK_SELF_SYMBOL_;
ModuleStroge = __decorate([
    Injectable(MODULE_MAP),
    __metadata("design:paramtypes", [Object, ModuleStroge])
], ModuleStroge);
export { ModuleStroge };
