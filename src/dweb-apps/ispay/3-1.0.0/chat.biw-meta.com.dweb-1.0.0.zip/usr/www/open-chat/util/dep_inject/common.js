import { GROUP_TOKEN_SYMNOL, INJECTION_TOKEN_SYMNOL, SINGLETON_TOKEN_SYMNOL, } from "./_inner.js";
/**获取构造函数的模块名称 */
export function getInjectionToken(Ctor) {
    return Ctor[INJECTION_TOKEN_SYMNOL];
}
/**获取构造函数的分组名称 */
export function getInjectionGroups(Ctor) {
    const groups = new Set();
    let curCtor = Ctor;
    do {
        const curGroups = curCtor[GROUP_TOKEN_SYMNOL];
        if (curGroups) {
            for (const groupName of curGroups) {
                groups.add(groupName);
            }
            curCtor = Object.getPrototypeOf(curCtor);
            if (!curCtor) {
                break;
            }
        }
        else {
            break;
        }
    } while (true);
    return groups;
}
//#endregion
