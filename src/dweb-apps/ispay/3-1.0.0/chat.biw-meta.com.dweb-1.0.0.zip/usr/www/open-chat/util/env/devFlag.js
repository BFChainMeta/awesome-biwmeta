import { platformInfo } from "../platform/index.js";
const ENV = platformInfo.getGlobalFlag("dev-flag", "development");
ENV.split(",").map((flag) => flag.trim());
const _envFlags = new Map();
for (const flag of ENV.split(",")) {
    const [_flagKey, flagValue] = flag.split("=").map((item) => item.trim());
    let flagKey = _flagKey;
    let remove = false;
    if (flagKey.startsWith("- ")) {
        remove = true;
        flagKey = flagKey.substr(2);
    }
    if (remove) {
        _envFlags.delete(flagKey);
    }
    else {
        _envFlags.set(flagKey, flagValue);
    }
}
export function isFlagInDev(flag) {
    return _envFlags.has(flag);
}
