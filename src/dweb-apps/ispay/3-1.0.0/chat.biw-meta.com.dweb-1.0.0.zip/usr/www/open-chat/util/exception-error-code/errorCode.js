/**
 * # 错误码
 *
 * 共8位，前三位为大类，后五位为具体错误。
 *
 * 后五位中在引用的地方自定义分类
 *
 * ## 大类分类
 *
 * - 001: 来自core包的共识错误
 * - 002: 来自pc节点包的错误
 * - 003: 来自browser的错误
 * - 004: 来自app的错误
 *
 * 后续自行补充。。。
 *
 */
export class ErrorCode {
    constructor(code, message) {
        Object.defineProperty(this, "__code", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "__message", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.__code = code;
        this.__message = message;
    }
    get code() {
        return this.__code;
    }
    get message() {
        return this.__message;
    }
    set message(newMessage) {
        this.__message = newMessage;
    }
    build(args) {
        return args
            ? this.__message.replace(/\{([^\\]+?)\}/g, (match, key) => {
                return args[key] ?? match;
            })
            : this.__message;
    }
}
