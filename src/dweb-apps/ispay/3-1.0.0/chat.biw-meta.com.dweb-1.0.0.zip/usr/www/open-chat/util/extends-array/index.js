export * from "./FastQuene.js";
