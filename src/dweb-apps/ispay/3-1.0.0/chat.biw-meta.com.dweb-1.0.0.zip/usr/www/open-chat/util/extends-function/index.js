export function renameFunction(fun, newName) {
    const hanlder_name_des = Object.getOwnPropertyDescriptor(fun, "name");
    if (hanlder_name_des && hanlder_name_des.configurable) {
        Object.defineProperty(fun, "name", {
            value: newName,
            configurable: true,
        });
    }
}
export function OmitStatic(ctor, ...k) {
    return ctor;
}
