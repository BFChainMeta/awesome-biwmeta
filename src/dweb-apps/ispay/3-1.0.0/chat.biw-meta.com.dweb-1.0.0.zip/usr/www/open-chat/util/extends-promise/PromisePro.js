import { __decorate, __metadata } from "../../tslib/modules/index.js";
import { cacheGetter } from "../decorator/index.js";
import { EventEmitter } from "../event/index.js";
import { PromiseOut } from "../extends-promise-out/index.js";
import { $ignoreAwait } from "../typings/index.js";
import { DelayPromise } from "./DelayPromise.js";
import { PromiseAbortError } from "./PromiseAbortError.js";
/**
 * PromiseOut的加强版
 * 提供了中断、跟随
 *
 */
export class PromisePro extends PromiseOut {
    constructor() {
        super();
        Object.defineProperty(this, "abort_error", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "_hasAbortEvent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
    }
    get is_done() {
        return this.is_resolved || this.is_rejected;
    }
    abort(abort_message = "Abort") {
        if (this.is_done) {
            return;
        }
        this.reject((this.abort_error = new PromiseAbortError(abort_message)));
        this._hasAbortEvent &&
            this._abortEvent.emit("abort", this.abort_error, this);
    }
    get _abortEvent() {
        this._hasAbortEvent = true;
        return new EventEmitter();
    }
    onAbort(cb) {
        this._abortEvent.on("abort", cb);
    }
    follow(from_promise) {
        from_promise.then(this.resolve).catch(this.reject);
        return this.promise;
    }
    static fromPromise(promise) {
        const res = new PromisePro();
        if (promise instanceof DelayPromise) {
            $ignoreAwait(promise.delayThen(res.resolve, res.reject));
        }
        else {
            $ignoreAwait(promise.then(res.resolve, res.reject));
        }
        return res;
    }
    finally(cb) {
        return this.promise.finally(cb);
    }
}
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], PromisePro.prototype, "_abortEvent", null);
