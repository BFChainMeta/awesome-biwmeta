import { __decorate, __metadata } from "../../tslib/modules/index.js";
import { cacheGetter } from "../decorator/index.js";
export class EasyWeakSet {
    constructor(entries, transformKey = (v) => v, _afterDelete) {
        Object.defineProperty(this, "transformKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: transformKey
        });
        Object.defineProperty(this, "_afterDelete", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: _afterDelete
        });
        Object.defineProperty(this, "_ws", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this._ws = new WeakSet(entries);
    }
    static from(args) {
        return new EasyWeakSet(args.entries, args.transformKey, args.afterDelete);
    }
    tryAdd(key) {
        return this.add(this.transformKey(key));
    }
    tryDelete(key) {
        return this.delete(this.transformKey(key));
    }
    tryHas(key) {
        return this.has(this.transformKey(key));
    }
    get delete() {
        const deleteHanlder = this._ws.delete.bind(this._ws);
        const { _afterDelete } = this;
        if (_afterDelete) {
            return (key) => {
                if (deleteHanlder(key)) {
                    _afterDelete(key);
                    return true;
                }
                return false;
            };
        }
        return deleteHanlder;
    }
    get add() {
        return this._ws.add.bind(this._ws);
    }
    get has() {
        return this._ws.has.bind(this._ws);
    }
    get [Symbol.toStringTag]() {
        return "EasyWeakSet";
    }
}
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasyWeakSet.prototype, "delete", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasyWeakSet.prototype, "add", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], EasyWeakSet.prototype, "has", null);
