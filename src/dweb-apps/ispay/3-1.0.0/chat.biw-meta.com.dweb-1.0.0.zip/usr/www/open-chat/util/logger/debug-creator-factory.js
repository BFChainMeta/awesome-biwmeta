import DebugCreaterFactory from "./debug-creator@browser.js";
export default DebugCreaterFactory;
