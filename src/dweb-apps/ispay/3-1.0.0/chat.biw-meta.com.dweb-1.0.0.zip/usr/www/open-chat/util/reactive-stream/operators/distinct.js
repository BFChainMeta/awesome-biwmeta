export const distinct = (keySelector) => {
    const set = new Set();
    let index = 0;
    return new TransformStream({
        transform: (chunk, controller) => {
            const key = (keySelector ? keySelector(chunk, index++, set) : chunk);
            if (set.has(key)) {
                return;
            }
            set.add(key);
            controller.enqueue(key);
        },
    });
};
