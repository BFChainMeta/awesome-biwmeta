import * as dntShim from "../_dnt.shims.js";
const freeGlobalThis = typeof dntShim.dntGlobalThis !== "undefined" &&
    dntShim.dntGlobalThis !== null &&
    globalThis.Object === Object &&
    dntShim.dntGlobalThis;
const freeGlobal = typeof global !== "undefined" &&
    global !== null &&
    global.Object === Object &&
    global;
const freeSelf = typeof self !== "undefined" &&
    self !== null &&
    self.Object === Object &&
    self;
export const $global = freeGlobalThis || freeGlobal || freeSelf || Function("return this")();
if (Reflect.get($global, "globalThis") === undefined) {
    Reflect.set($global, "globalThis", $global);
}
