import { __decorate, __metadata } from "../../tslib/modules/index.js";
import { Injectable } from "../dep_inject/index.js";
import { platformInfo, isNodejs, isWin32, isCordova, isWebView, isWebMainThread, isWebWorker, } from "../platform/index.js";
import { cacheGetter } from "../decorator/index.js";
import Perf from "./performance.js";
let PlatformHelper = class PlatformHelper {
    constructor() {
        Object.defineProperty(this, "platformInfo", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: platformInfo
        });
        Object.defineProperty(this, "performance", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: Perf()
        });
    }
    get platformName() {
        return platformInfo.platformName();
    }
    get isNodejs() {
        return isNodejs;
    }
    get isWin32() {
        return isWin32;
    }
    get isCordova() {
        return isCordova;
    }
    get isWebView() {
        return isWebView;
    }
    get isWebMainThread() {
        return isWebMainThread;
    }
    get isWebWorker() {
        return isWebWorker;
    }
};
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], PlatformHelper.prototype, "platformName", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], PlatformHelper.prototype, "isNodejs", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], PlatformHelper.prototype, "isWin32", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], PlatformHelper.prototype, "isCordova", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], PlatformHelper.prototype, "isWebView", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], PlatformHelper.prototype, "isWebMainThread", null);
__decorate([
    cacheGetter,
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [])
], PlatformHelper.prototype, "isWebWorker", null);
PlatformHelper = __decorate([
    Injectable()
], PlatformHelper);
export { PlatformHelper };
