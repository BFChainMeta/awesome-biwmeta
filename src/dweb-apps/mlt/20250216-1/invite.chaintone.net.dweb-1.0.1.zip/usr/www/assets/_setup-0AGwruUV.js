import{p}from"./sha256-DpTdJ0vv.js";const a=async()=>{await p.prepare()};export{a as p};
