import{p}from"./sha256-DcAjz1WB.js";const a=async()=>{await p.prepare()};export{a as p};
