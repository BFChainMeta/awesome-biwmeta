import{p}from"./sha256-CsrHknaL.js";const a=async()=>{await p.prepare()};export{a as p};
