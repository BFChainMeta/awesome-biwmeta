import{p}from"./sha256-DVMw4zpg.js";const a=async()=>{await p.prepare()};export{a as p};
