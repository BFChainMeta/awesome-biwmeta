import{a as e}from"./page-DDWssSmD.js";import{R as o}from"./index-CJS2cisD.js";import"./preloader-Cif-dwC9.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
