import{p}from"./sha256-DU6XVxn_.js";const a=async()=>{await p.prepare()};export{a as p};
