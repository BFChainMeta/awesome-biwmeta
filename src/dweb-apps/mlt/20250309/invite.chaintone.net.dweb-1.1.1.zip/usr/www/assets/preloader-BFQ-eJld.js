import{a as e}from"./page-BSoS-bas.js";import{R as o}from"./index-DpIsCDhb.js";import"./preloader-B909fUVn.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
