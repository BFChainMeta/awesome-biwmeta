import{a as e}from"./page-D58NR9Co.js";import{R as o}from"./index-BLPKJkPn.js";import"./preloader-CWnYVFT6.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
