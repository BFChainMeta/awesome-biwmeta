import{B as e}from"./page-DD4HqGrb.js";import{R as o}from"./index-Sc3seovD.js";import"./preloader-D0pCAzKY.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
