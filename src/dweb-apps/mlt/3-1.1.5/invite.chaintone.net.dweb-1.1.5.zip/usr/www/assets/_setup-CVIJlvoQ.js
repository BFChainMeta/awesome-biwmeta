import{p}from"./sha256-pXI_06Xf.js";const a=async()=>{await p.prepare()};export{a as p};
