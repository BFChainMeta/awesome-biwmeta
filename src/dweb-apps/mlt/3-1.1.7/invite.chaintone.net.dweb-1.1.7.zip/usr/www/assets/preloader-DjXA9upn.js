import{B as e}from"./page-BRgrRZt0.js";import{R as o}from"./index-BzSa9pPg.js";import"./preloader-BIpOo0-U.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
