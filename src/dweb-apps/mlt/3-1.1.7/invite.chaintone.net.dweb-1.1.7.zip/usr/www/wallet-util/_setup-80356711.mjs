import { p as prepareSHA256 } from './sha256-098a9414.mjs';

const prepareBs58check = async () => {
    await prepareSHA256.prepare();
};

export { prepareBs58check as p };
//# sourceMappingURL=_setup-80356711.mjs.map
