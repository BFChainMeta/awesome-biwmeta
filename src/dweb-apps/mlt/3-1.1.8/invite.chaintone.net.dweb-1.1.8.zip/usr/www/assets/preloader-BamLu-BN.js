import{B as e}from"./page-CIPQbQ5M.js";import{R as o}from"./index-CERVSraJ.js";import"./preloader-8GZRN-Cj.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
