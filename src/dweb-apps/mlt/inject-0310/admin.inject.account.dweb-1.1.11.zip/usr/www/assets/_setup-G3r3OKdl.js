import{p}from"./sha256-D0ooK2P0.js";const a=async()=>{await p.prepare()};export{a as p};
