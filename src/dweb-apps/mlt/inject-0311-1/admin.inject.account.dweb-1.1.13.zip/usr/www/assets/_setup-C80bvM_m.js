import{p}from"./sha256-D0v9RAja.js";const a=async()=>{await p.prepare()};export{a as p};
