import{p}from"./sha256-1vq_YvNL.js";const a=async()=>{await p.prepare()};export{a as p};
