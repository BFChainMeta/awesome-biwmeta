import{p}from"./sha256-Dhf1fNlP.js";const a=async()=>{await p.prepare()};export{a as p};
