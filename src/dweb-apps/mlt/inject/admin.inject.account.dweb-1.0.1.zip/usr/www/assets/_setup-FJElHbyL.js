import{p}from"./sha256-COaFC7ZX.js";const a=async()=>{await p.prepare()};export{a as p};
