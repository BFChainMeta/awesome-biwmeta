import{B as e}from"./page-CWhcmYIc.js";import{R as o}from"./index-CLEJ7ok8.js";import"./preloader-AZoj8G1s.js";const s=r=>o.createElement(e,{size:24,...r});export{s as P};
