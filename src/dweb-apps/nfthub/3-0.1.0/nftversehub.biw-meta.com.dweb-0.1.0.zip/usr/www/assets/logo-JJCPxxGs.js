const s="/assets/logo-HPrsLyvI.svg";export{s as _};
