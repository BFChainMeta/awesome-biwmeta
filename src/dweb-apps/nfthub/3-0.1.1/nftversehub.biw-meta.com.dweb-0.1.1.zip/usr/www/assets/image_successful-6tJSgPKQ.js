const s="/assets/image_successful-s4W5UE-E.svg";export{s as _};
